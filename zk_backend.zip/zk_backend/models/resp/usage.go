package resp

type (
	AreaSuspendRsp struct {
		ID   int64  `json:"id" form:"id"`
		Name string `json:"name" form:"name"`
		Type uint   `json:"type" xorm:"type"`
		Isp  string `json:"isp" xorm:"isp"`
		Area string `json:"area" xorm:"area"`
	}
)
