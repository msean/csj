package resp

import "time"

type (
	CrontabListItem struct {
		JobName string    `json:"job_name"`
		ID      int64     `json:"id"`
		Type    int       `json:"type"`
		Status  int       `json:"status"`
		Spec    string    `json:"spec"`
		Created time.Time `json:"created"`
	}
	CrontabListRsp struct {
		Records  []CrontabListItem `json:"records"`
		Count    int               `json:"count"`
		Page     int               `json:"page"`
		PageSize int               `json:"page_size"`
	}
	CrontabLogItem struct {
		JobName string    `json:"job_name"`
		Type    int64     `json:"type"`
		Created time.Time `json:"created"`
		ID      int64     `json:"id"`
		Info    string    `json:"info"`
	}
	CrontabLogListRsp struct {
		Records  []CrontabLogItem `json:"records"`
		Count    int              `json:"count"`
		Page     int              `json:"page"`
		PageSize int              `json:"page_size"`
	}
)
