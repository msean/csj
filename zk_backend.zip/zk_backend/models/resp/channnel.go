package resp

type TemplateDescribeRsp struct {
	ID          int64  `json:"id"`
	TemplateKey string `json:"template_key"`
	Description string `json:"description"`
}
