package resp

import (
	"application/constant"
	"application/utils"
	"encoding/xml"
	"fmt"

	"net/http"

	"github.com/labstack/echo"
)

type Result struct {
	Uuid    string      `json:"uuid"`
	Success bool        `json:"success"`
	Code    int         `json:"code"`
	Msg     string      `json:"msg"`
	Data    interface{} `json:"data"`
}

type ResultTotalList struct {
	Total int64       `json:"total"`
	List  interface{} `json:"list"`
}

type ResultList struct {
	List interface{} `json:"list"`
}

// Resp API Response
func Resp(c echo.Context, success bool, code int, msg string, data interface{}) error {
	res := &Result{
		Uuid:    utils.GetContextUUID(c),
		Success: success,
		Code:    code,
		Msg:     msg,
		Data:    data,
	}
	return c.JSON(http.StatusOK, res)
}

func OK(c echo.Context, data ...interface{}) error {
	var d interface{}
	if len(data) == 0 {
		d = struct{}{}
	} else if len(data) == 1 {
		d = data[0]
	} else {
		d = data
	}
	res := &Result{
		Uuid:    utils.GetContextUUID(c),
		Success: true,
		Code:    1000,
		Msg:     "success",
		Data:    d,
	}
	return c.JSON(http.StatusOK, res)
}

func OKWithList(c echo.Context, total, page, pageSize int, objs interface{}) error {
	if objs == nil {
		objs = make([]any, 0)
	}
	res := &Result{
		Uuid:    utils.GetContextUUID(c),
		Success: true,
		Code:    1000,
		Msg:     "success",
		Data: map[string]any{
			"records":   objs,
			"page":      page,
			"page_size": pageSize,
			"total":     total,
		},
	}
	return c.JSON(http.StatusOK, res)
}

func Fail(c echo.Context, msg string) error {
	res := &Result{
		Uuid:    utils.GetContextUUID(c),
		Success: false,
		Code:    5000,
		Msg:     msg,
		Data:    struct{}{},
	}
	return c.JSON(http.StatusOK, res)
}

func AuthMsg(c echo.Context, msg string) error {
	res := &Result{
		Uuid:    utils.GetContextUUID(c),
		Success: false,
		Code:    401,
		Msg:     msg,
		Data:    struct{}{},
	}
	return c.JSON(http.StatusOK, res)
}

func ApiRsp(c echo.Context, format string, rtn any) (err error) {
	if format == constant.RtnFormatJson {
		return c.JSON(http.StatusOK, rtn)
	}

	var output []byte
	if output, err = xml.MarshalIndent(rtn, "", "  "); err != nil {
		return err
	}
	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationXML)
	return c.String(http.StatusOK, string(output))
}

func FailOrderApiRsp(c echo.Context, format string, orderID string, codeMsg constant.ApiCodeMsg) (err error) {
	or := OrderResult{
		OrderID: orderID,
		Code:    int(codeMsg.ApiCode),
		CodeMsg: codeMsg.OrderMsg,
	}
	if format == constant.RtnFormatJson {
		return c.JSON(http.StatusOK, or)
	}

	var output []byte
	if output, err = xml.MarshalIndent(or, "", "  "); err != nil {
		return err
	}
	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationXML)
	return c.String(http.StatusOK, string(output))
}

func FailOrderQryApiRsp(c echo.Context, format string, orderID string, codeMsg constant.ApiCodeMsg) (err error) {
	or := OrderQryResult{
		OrderID: orderID,
		Code:    int(codeMsg.ApiCode),
		CodeMsg: codeMsg.OrderMsg,
	}
	if format == constant.RtnFormatJson {
		return c.JSON(http.StatusOK, or)
	}

	var output []byte
	if output, err = xml.MarshalIndent(or, "", "  "); err != nil {
		return err
	}
	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationXML)
	return c.String(http.StatusOK, string(output))
}

func FailBalanceQryApiRsp(c echo.Context, format string, agentID string, codeMsg constant.ApiCodeMsg) (err error) {
	or := BalanceResult{
		Agent:   agentID,
		Code:    int(codeMsg.ApiCode),
		CodeMsg: codeMsg.OrderMsg,
	}
	if format == constant.RtnFormatJson {
		return c.JSON(http.StatusOK, or)
	}

	var output []byte
	if output, err = xml.MarshalIndent(or, "", "  "); err != nil {
		return err
	}
	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationXML)
	return c.String(http.StatusOK, string(output))
}

func InvalidToken(c echo.Context) error {
	res := &Result{
		Uuid:    utils.GetContextUUID(c),
		Success: false,
		Code:    401,
		Msg:     "token 认证失败",
		Data:    struct{}{},
	}
	return c.JSON(http.StatusOK, res)
}

func InvalidPermission(c echo.Context) error {
	res := &Result{
		Uuid:    utils.GetContextUUID(c),
		Success: false,
		Code:    431,
		Msg:     "权限不足",
		Data:    struct{}{},
	}
	return c.JSON(http.StatusOK, res)
}

func InvalidParams(c echo.Context) error {
	return Fail(c, "invalid params")
}

func InvalidParamsEx(c echo.Context, msg string) error {
	return Fail(c, "invalid params, "+msg)
}

func Exist(c echo.Context, key string) error {
	return Fail(c, fmt.Sprintf("[%s] already exist", key))
}

func DBError(c echo.Context, msg string) error {
	return Fail(c, fmt.Sprintf("db error, %s", msg))
}

func NotFound(c echo.Context) error {
	return Fail(c, "not found")
}

func Response(c echo.Context, err error, data ...interface{}) error {
	if err != nil {
		return Fail(c, err.Error())
	}
	return OK(c, data...)
}
