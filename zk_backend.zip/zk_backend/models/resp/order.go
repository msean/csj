package resp

import (
	"application/models"
	"time"
)

type (
	OrderRemarkRsp struct {
		RemarkTime time.Time `json:"remark_time"`
		Remark     string    `json:"string"`
	}

	OrderRsp struct {
		OrderID         int64     `json:"order_id" xlsx:"订单ID"`
		CustomerOrderID string    `json:"customer_order_id" xlsx:"客户订单号"`
		Customer        string    `json:"customer_name" xlsx:"客户名称"`
		Phone           string    `json:"phone" xlsx:"手机号码"`
		Province        string    `json:"province" xlsx:"省份"`
		Area            string    `json:"area" xlsx:"地区 from:xj_area"`
		Product         string    `json:"product" xlsx:"产品名称"`
		Isp             int64     `json:"isp" xlsx:"运营商 from:xj_isp"`
		ImportPrice     float64   `json:"import_price" xlsx:"进价"`
		OrderStatus     uint      `json:"order_status" xlsx:"状态 from:xj_order"`
		CurrentChannel  string    `json:"current_channel" xlsx:"当前渠道"`
		Created         time.Time `json:"created" xlsx:"创建时间"`
		Take            string    `json:"take" xlsx:"耗时"`
		VoucherType     uint      `json:"voucher_type" xlsx:"凭证类型 from:xj_vouchertype"`
		Remark          string    `json:"remark" xlsx:"备注"`
		ManualRemark    string    `json:"manual_remark" xlsx:"手工备注"`
		BackStatus      uint      `json:"back_status" xlsx:"回调状态"`
		FaceValue       uint      `json:"face_value" xlsx:"面值"`
		HasReturned     int       `json:"has_returned"`
		FinishTime      time.Time `json:"finish_time" xlsx:"完成时间"`
		SalasPrice      float64   `json:"salas_price" xlsx:"售价"`
		BackUrl         string    `json:"back_url" xlsx:"回调地址"`
		BackTime        string    `json:"back_time" xlsx:"回调时间"`
		BackTimes       int       `json:"back_times" xlsx:"回调次数"`
		FeedBack        string    `json:"feed_back" xlsx:"下游返回"`
		CallbackMsg     string    `json:"callback_msg"`
		RequestInfo     string    `json:"request_info"`
		Voucher         string    `json:"voucher" xlsx:"凭证"`
	}
	ChannelOrderRsp struct {
		ID           int64                 `json:"id" xlsx:"渠道订单ID"`
		Customer     string                `json:"customer_name" xlsx:"客户名称"`
		ChannelName  string                `json:"channel_name" xlsx:"渠道名称"`
		OrderID      int64                 `json:"order_id" xlsx:"订单ID"`
		Phone        string                `json:"phone" xlsx:"手机号码"`
		Area         string                `json:"area" xlsx:"地区 from:xj_area"`
		Product      string                `json:"product_name" xlsx:"产品名称"`
		Isp          int64                 `json:"isp" xlsx:"运营商 from:xj_isp"`
		OrderStatus  uint                  `json:"order_status" xlsx:"订单状态 from:xj_order""`
		FaceValue    int                   `json:"face_value" xlsx:"面值"`
		CustomerTime time.Time             `json:"customer_time" xlsx:"客户下单时间"`
		Created      time.Time             `json:"created" xlsx:"创建时间"`
		Take         string                `json:"take" xlsx:"耗时"`
		VoucherType  uint                  `json:"voucher_type" xlsx:"凭证类型 from:xj_vouchertype"`
		Remark       []models.RemarkRecord `json:"remark" xlsx:"备注"`
		Province     string                `json:"province" xlsx:"省份"`
		Voucher      string                `json:"voucher" xlsx:"凭证"`
	}
	ReturnOrderRsp struct {
		Created         time.Time `json:"created" xlsx:"创建时间"`
		ID              int64     `json:"id" xlsx:"返销订单ID"`
		OrderID         int64     `json:"order_id" xlsx:"平台订单ID"`
		CustomerOrderID string    `json:"customer_order_id" xlsx:"客户订单ID"`
		CustomerName    string    `json:"customer_name" xlsx:"客户名称"`
		ChannelOrderID  int64     `json:"channel_order_id" xlsx:"渠道订单ID"`
		Area            string    `json:"area" xlsx:"地区"`
		ChannelName     string    `json:"channel_name" xlsx:"渠道名称"`
		Phone           string    `json:"phone" xlsx:"手机号码"`
		Product         string    `json:"product_name" xlsx:"产品名称"`
		Isp             int64     `json:"isp" xlsx:"运营商 from:xj_isp"`
		FaceValue       int       `json:"face_value" xlsx:"面值"`
		OrderTime       time.Time `json:"order_time" xlsx:"下单时间"`
		Type            int       `json:"type"`
		Voucher         uint      `json:"voucher" xlsx:"凭证类型 from:xj_vouchertype"`
		Remark          string    `json:"remark" xlsx:"备注"`
	}
	ClientOrderSubmitResult struct {
		SubmitOrder string
		Code        int    // 1 成功 2 失败 3 请求异常
		Err         string // 请求异常的原因
	}
	ClientOrderCallbackResult struct {
		ChannelOrder models.ChannelOrder
		Cert         string // 凭证
		Status       int
	}
	ClientOrderQryResult struct {
		Status     int
		Cert       string // 凭证
		ChannelMsg string
	}
	ClientFinanceResult struct {
		Amount       float64
		CreditAmount float64
		Status       int
		Msg          string
	}
)
