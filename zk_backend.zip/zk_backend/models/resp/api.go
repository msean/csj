package resp

type (
	OrderResult struct {
		Code      int     `json:"nRtn" xml:"nRtn"`
		OrderID   string  `json:"szOrderId" xml:"szOrderId"`
		Balance   float64 `json:"fBalance" xml:"fBalance"`
		SalePrice float64 `json:"fSalePrice" xml:"fCredit"` // 该笔订单结算金额
		CodeMsg   string  `json:"szRtnCode" xml:"szRtnCode"`
	}
	BalanceResult struct {
		Code    int     `json:"nRtn" xml:"nRtn"`
		Agent   string  `json:"szAgentId" xml:"szAgentId"`
		Balance float64 `json:"fBalance" xml:"fBalance"`
		Credit  float32 `json:"fCredit" xml:"fCredit"`
		CodeMsg string  `json:"szRtnCode" xml:"szRtnCode"`
	}
	OrderQryResult struct {
		Code       int     `json:"nRtn" xml:"nRtn"`
		OrderID    string  `json:"szOrderId" xml:"szOrderId"`
		SalasPrice float64 `json:"fSalePrice" xml:"fSalePrice"`
		CodeMsg    string  `json:"szRtnCode" xml:"szRtnCode"`
		Msg        string  `json:"szRtnMsg" xml:"szRtnMsg"` // 备注字段如有凭证，此参数返回充值凭证
	}
	CallBack struct {
		CustomerID string  `json:"szAgentId" form:"szAgentId"`
		OrderID    string  `json:"szOrderId" form:"szOrderId"`
		Phone      string  `json:"szPhoneNum" form:"szPhoneNum"`
		FaceValue  int     `json:"nDemo" form:"nDemo"`
		SalePrice  float64 `json:"fSalePrice" form:"fSalePrice"`
		Code       int     `json:"nFlag" form:"nFlag"`
		Msg        string  `json:"szRtnMsg" form:"szRtnMsg"`
		Sign       string  `json:"szVerifyString" form:"szVerifyString"`
	}
)
