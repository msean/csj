package resp

import "time"

type DelayListRsp struct {
	ID        int64     `json:"id"`
	Type      int       `json:"type"`
	Remark    string    `json:"remark"`
	ExecTime  time.Time `json:"exec_time"`
	CreatedBy string    `json:"created_by"`
	Status    int       `json:"status"`
}
