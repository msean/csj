package resp

type (
	ChannelProductDetailRsp struct {
		ID             int64  `json:"id" xlsx:"ID"`
		ChannelID      int64  `json:"channel_id" xlsx:"渠道ID"`
		ChannelName    string `json:"channel_name" form:"channel_name" xlsx:"渠道"`
		Online         uint   `json:"online" form:"online" xlsx:"上架状态 (1:关 2:开)"`
		VoucherType    uint   `json:"voucher_type" form:"voucher_type" xlsx:"凭证 from:xj_vouchertype"`
		ProductCode    string `json:"product_code" form:"product_code" xlsx:"产品编码"`
		ProductName    string `json:"product_name" form:"product_name" xlsx:"产品名称"`
		ProductIsp     string `json:"product_isp" form:"product_isp" xlsx:"运营商 from:xj_isp"`
		ProductBigType uint   `json:"product_big_type" form:"product_big_type" xlsx:"大类 from:xj_bigtype"`
		ProductPrice   string `json:"product_price" form:"product_price" xlsx:"产品价格"`
		ActualPrice    string `json:"actual_price" form:"actual_price" xlsx:"原价"`
		ActualDiscount string `json:"actual_discount" form:"actual_discount" xlsx:"-"`
		OrderPrice     string `json:"order_price" form:"order_price" xlsx:"排序价格"`
		OrderDiscount  string `json:"order_discount" form:"order_discount" xlsx:"-"`
		Pcode          string `json:"pcode" form:"pcode" xlsx:"参数"`
	}
)
