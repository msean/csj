package resp

type (
	CustomerFinanceDayStatisticRsp struct {
		Date             string `json:"date" xlsx:"日期"`
		MobileFaceValue  string `json:"mobile_count" xlsx:"移动跑量"`
		MobileSales      string `json:"mobile_amount" xlsx:"移动实际金额"`
		UnicomFaceValue  string `json:"unicom_count" xlsx:"联通跑量"`
		UnicomSales      string `json:"unicom_amount" xlsx:"联通实际金额"`
		TelecomFaceValue string `json:"telecom_count" xlsx:"电信跑量"`
		TelecomSales     string `json:"telecom_amount" xlsx:"电信实际金额"`
		TotalCount       string `json:"total_count" xlsx:"总计跑量"`
		TotalSales       string `json:"total_amount" xlsx:"总计实际金额"`
		RechargeAmount   string `json:"recharge_amount" xlsx:"加款金额"`
		OtherAmount      string `json:"other_amount" xlsx:"其他加款金额"`
		Balance          string `json:"balance" xlsx:"实际余额"`
		ReOrderAmount    string `json:"re_order_amount" xlsx:"返销金额"`
		CustomerName     string `json:"customer_name" xlsx:"客户"`
	}
	OrderOrderAnalysisData struct {
		Count            int     `json:"count"`
		PurchasePrice    float64 `json:"purchase_price"`
		TotalSalesPrice  float64 `json:"total_sales_price"`
		TotalProfit      float64 `json:"total_profit"`
		ProfitRate       string  `json:"profit_rate"`
		FaceValue        int     `json:"face_value"`
		TotalFaceValue   int     `json:"total_face_value"`
		SuccessFaceValue int     `json:"success_face_value"`
	}
	OrderAnalysisItem struct {
		CustomerID   int64  `json:"customer_id"`
		CustomerName string `json:"customer_name"`
		ChannelID    int64  `json:"channel_id"`
		ChannelName  string `json:"channel_name"`
		OrderOrderAnalysisData
	}
	CustomerOrderAnalysisRsp struct {
		Total OrderOrderAnalysisData `json:"total"`
		Items []*OrderAnalysisItem   `json:"items"`
	}
	ChannelOrderAnalysisRsp struct {
		Total OrderOrderAnalysisData `json:"total"`
		Items []*OrderAnalysisItem   `json:"items"`
	}
	SuccessRateItem struct {
		TotalCount   int     `json:"total_count"`
		SuccessCount int     `json:"success_count"`
		FailCount    int     `json:"fail_count"`
		HandelCount  int     `json:"handle_count"`
		SuccessRate  float64 `json:"success_rate"`
		FaceValue    int     `json:"face_value"`
		SalesPrice   float64 `json:"sales_price"`
		Profit       float64 `json:"profit"`
	}
	CustomerOrderSuccessRateRsp struct {
		ObjectID int64           `json:"-"`
		Name     string          `json:"name"`
		Total    SuccessRateItem `json:"total"`
		Mobile   SuccessRateItem `json:"mobile"`
		Unicom   SuccessRateItem `json:"unicom"`
		Telecom  SuccessRateItem `json:"telecom"`
	}
)
