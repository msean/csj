package models

import (
	"fmt"
)

type (
	Channel struct {
		Bean          `xorm:"extends" xlsx:"-"`
		Name          string         `xorm:"'name' varchar(60) comment('全称')" json:"name" xlsx:"全称"`
		ShortName     string         `xorm:"'short_name' varchar(40) comment('简称')" json:"short_name" xlsx:"简称"`
		ApiID         string         `xorm:"'api_id'  varchar(256) comment('ApiID')" json:"api_id" xlsx:"ApiID"`
		ApiKey        string         `xorm:"'api_key' varchar(3096) comment('ApiKey')" json:"api_key"  xlsx:"ApiKey"`
		SubmitUrl     string         `xorm:"'submit_url' varchar(256)  comment('提交地址')"  json:"submit_url" xlsx:"提交地址"`
		QueryUrl      string         `xorm:"'query_url' varchar(256)  comment('查单地址')" json:"query_url" xlsx:"查单地址"`
		BalanceUrl    string         `xorm:"'balance_url' varchar(256)  comment('余额地址')" json:"balance_url"  xlsx:"余额地址"`
		BackUrl       string         `xorm:"'back_url' varchar(256)  comment('回调地址')" json:"back_url" xlsx:"回调地址"`
		Online        uint           `xorm:"'online' default 2 comment('上架状态 1 下架 2 上架')" json:"online" xlsx:"状态 (1:下架 2:上架)"`
		Balance       float32        `xorm:"'balance' DECIMAL(15,4) comment('余额')"  json:"balance" xlsx:"余额"`
		Msg           string         `xorm:"'msg' comment('渠道信息')"  json:"msg" xlsx:"渠道信息"`
		Detail        string         `xorm:"'detail'  varchar(256) comment('详情')" json:"detail" xlsx:"详情"`
		TemplateName  string         `xorm:"'template_name' varchar(128) comment('模版')" json:"template_name" xlsx:"模版"`
		WarnBalance   int            `xorm:"'warn_balance' default 2000 comment('余额预警')" json:"warn_balance"  xlsx:"余额预警"`
		StuckLimit    uint           `xorm:"'stuck_limit' comment('卡单阀值，-1隐藏-2余额汇总不统计')"  json:"stuck_limit" xlsx:"卡单阈值"`
		Sort          int            `xorm:"'sort' default 1 comment('排序   -1 删除  0提示关闭')"   json:"sort" xlsx:"排序"`
		LimitConfig   []ChannelLimit `xorm:"'limit_config' text comment('线程设置')" json:"thread_config"  xlsx:"线程参数"`
		ManualProcess uint           `xorm:"'manual_process' default 1 varchar(1024) comment('人工处理 1 不需要 2 需要')" json:"manual_process"  xlsx:"-"`
		Etcone        string         `xorm:"'etcone' varchar(1024) comment('etcone')" json:"etc_one"  xlsx:"-"`
		Etctwo        string         `xorm:"'etctwo' varchar(1024) comment('etctwo')" json:"etc_two"  xlsx:"-"`
		Etcthr        string         `xorm:"'etcthr' varchar(1024) comment('etcthr')" json:"etc_three" xlsx:"-"`
	}
	ChannelLimit struct {
		Type           uint `json:"type"`           // 1、下单   2、查单   3余额
		Available      bool `json:"avalible"`       // 是否生效
		ThreadCount    uint `json:"thread_count"`   // 线程数
		FrequencyLimit uint `json:"frequece_limit"` // 单位：毫秒
		CountLimit     uint `json:"count_limit"`    // 取单条数限制
		EndTLimit      uint `json:"end_limit"`      // 多少秒前
		StartLimit     uint `json:"start_limit"`    // 多少天内
	}
	ChannelProduct struct {
		Bean        `xorm:"extends"`
		ChannelID   int64   `xorm:"'channel_id' varchar(40) comment('渠道ID')" json:"channel_id"`
		Online      uint    `xorm:"'online' default 2 comment('开关 1 关 2开')" json:"online"`
		VoucherType uint    `xorm:"'voucher_type' default 1 comment('凭证类型')" json:"voucher_type"` // 凭证
		ProductCode string  `xorm:"'product_code' default 1 comment('产品编码')" json:"product_code"` // 产品编码
		Remark      string  `xorm:"'remark' varchar(1024)"`                                       // 备注
		ActualPrice float64 `xorm:"'actual_price' DECIMAL(15,4)" json:"actual_price" `            // 实际价格
		OrderPrice  float64 `xorm:"'order_price' DECIMAL(15,4)" json:"order_price"`               // 排序价格
		Pcode       string  `xorm:"'pcode' comment('产品参数')"  varchar(1024)" json:"pcode"`
	}
	ChannelGroup struct {
		Bean     `xorm:"extends"`
		Code     string            `xorm:"'code' varchar(255) comment('编码')" json:"code"`
		Name     string            `xorm:"'name' varchar(255) comment('名称')" json:"name"`
		SortType int               `xorm:"'sort_type'  comment('类型')" json:"sort_type"`
		Rels     []ChannelGroupRel `xorm:"'rels' text comment('渠道ID')" json:"rels"`
	}
	ChannelGroupRel struct {
		Percent   uint  `json:"percent"`
		ChannelID int64 `json:"channel_id"`
	}
)

func (u Channel) TableName() string {
	return "xj_channel"
}

func (ChannelProduct) TableName() string {
	return "xj_channelproduct"
}

func (ChannelGroup) TableName() string {
	return "xj_channelgroup"
}

func (Channel) LimitDefault() []ChannelLimit {
	return []ChannelLimit{
		{
			Type:           1,
			Available:      true,
			ThreadCount:    15,
			FrequencyLimit: 200,
		},
		{
			Type:           2,
			Available:      true,
			ThreadCount:    2,
			FrequencyLimit: 30,
			CountLimit:     1000, // 1000条
			StartLimit:     2,    // 单位 天
			EndTLimit:      300,  //
		},
		{
			Type:           3,
			Available:      true,
			FrequencyLimit: 35,
		},
	}
}

func (channel Channel) GetByType(_type int) (limit ChannelLimit, err error) {
	if _type != 1 && _type != 2 && _type != 3 {
		err = fmt.Errorf("unexpect type")
		return
	}
	var find bool
	for _, _limit := range channel.LimitConfig {
		if _limit.Type == uint(_type) {
			limit = _limit
			find = true
			return
		}
	}
	if !find {
		err = fmt.Errorf("not found")
	}
	return
}
