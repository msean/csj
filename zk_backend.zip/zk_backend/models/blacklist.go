package models

import "time"

type Blacklist struct {
	Bean   `xorm:"extends"`
	Phone  string `xorm:"'phone' varchar(255) comment('号码')" json:"phone" xlsx:"手机号码"`
	Type   uint   `xorm:"'type'  comment('类型')" json:"type" xlsx:"类型 (2:临时 1:永久)"`
	Remark string `xorm:"'remark' varchar(255) comment('备注')" json:"remark" xlsx:"备注"`
}

type WhiteList struct {
	Bean   `xorm:"extends"`
	IP     string `xorm:"'ip' varchar(255) comment('IP')" json:"phone" xlsx:"ip"`
	Remark string `xorm:"'remark' varchar(255) comment('备注')" json:"remark" xlsx:"备注"`
}

func (Blacklist) TableName() string { return "xj_blacklist" }

func (WhiteList) TableName() string { return "xj_whitelist" }

type WhiteListExport struct {
	ID      int64     `json:"id" xlsx:"ID"`
	IP      string    `son:"phone" xlsx:"IP"`
	Remark  string    `json:"remark" xlsx:"备注"`
	Created time.Time `json:"created" xlsx:"加入时间"`
}
