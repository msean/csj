package models

type Download struct {
	Bean     `xorm:"extends"`
	HashKey  string `xorm:"'hash_key' index notnull" json:"key"` // hash值
	Filename string `xorm:"'filename' notnull" json:"filename"`  // 文件名
}

func (Download) TableName() string {
	return "xj_download"
}
