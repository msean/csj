package models

type Menu struct {
	Bean      `xorm:"extends"`
	MenuName  string `xorm:"notnull 'menu_name'"` // 菜单名称
	MenuType  int8   `xorm:"menu_type"`           // 菜单类型 (目录/菜单/按钮)
	MenuOrder int    `xorm:"menu_order"`          // 显示顺序
	ParentId  int64  `xorm:"parent_id"`           // 上级ID
	OpenType  int8   `xorm:"open_type"`           // 打开方式 (页签/新窗口)
	Url       string `xorm:"url"`                 // 请求地址
	Method    string `xorm:"method"`              // 操作类型
	Visible   bool   `xorm:"visible"`             // 菜单状态
	Icon      string `xorm:"icon"`                // 菜单图标
	Remark    string `xorm:"remark"`              // 备注
	// Permission string `xorm:"permission"` // 权限标识
	// Creator    string    `xorm:"creator"`    // 创建者
	// Operator   string    `xorm:"operator"`   // 操作者
	// CreatedAt  time.Time `gorm:"column:created_at;type:datetime;not null;default:CURRENT_TIMESTAMP"`
	// UpdatedAt  time.Time `gorm:"column:updated_at;type:datetime;not null;default:CURRENT_TIMESTAMP"`
	// RequestUrl string `xorm:"request_url"` // 页面地址
	// Weights        int    `xorm:"weights"`        // 权重
	// Classification string `xorm:"classification"` // 菜单分类（S查看 E更新 D删除）
}

func (r *Menu) TableName() string {
	return "a_menu"
}
