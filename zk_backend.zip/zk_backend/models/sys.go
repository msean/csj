package models

type (
	SysArgConfig struct {
		Bean   `xorm:"extends" xlsx:"-"`
		Name   string `xorm:"'config_name' varchar(128) comment('参数名称')" xlsx:"参数名称" json:"name"`
		Key    string `xorm:"'config_key' varchar(128) comment('参数键名')" xlsx:"参数键名" json:"key"`
		Value  string `xorm:"'config_value' varchar(2048) comment('参数键值')" xlsx:"参数键值" json:"value"`
		Typ    uint   `xorm:"'config_type' comment('系统内置（1是 2否')" xlsx:"系统内置 (1:是 2:否)" json:"type"`
		Remark string `xorm:"'remark' varchar(512) comment('Remark')" xlsx:"备注" json:"remark"`
	}
	SysDictType struct {
		Bean       `xorm:"extends" xlsx:"-"`
		Name       string        `xorm:"'dict_name' varchar(128) comment('字典名称')" json:"name" form:"name" xlsx:"字典名称"`
		Type       string        `xorm:"'dict_type' varchar(128)  comment('字典类型')" json:"type" form:"type" xlsx:"字典类型"`
		Status     uint          `xorm:"'status' default 1 comment('状态（1正常 2停用）')" json:"status" form:"status" xlsx:"状态 (1:正常 2:停用)"`
		Remark     string        `xorm:"'remark' varchar(512) comment('备注')" json:"remark" form:"remark" xlsx:"备注"`
		EffectType uint          `xorm:"'effect_type' default 2 comment('实际作用的类型 1 字符串 2 数字')" json:"effect_type" form:"effect_type"`
		Data       []SysDictData `xorm:"-" json:"data"`
	}
	SysDictData struct {
		Bean      `xorm:"extends" xlsx:"-"`
		Sort      uint   `xorm:"'dict_sort' comment('字典排序')" json:"sort" form:"sort" xlsx:"字典排序"`
		Label     string `xorm:"'dict_label' varchar(128)  comment('字典标签')" json:"label" form:"label" xlsx:"字典标签"`
		Value     string `xorm:"'dict_value' varchar(128)  comment('字典键值')" json:"value" form:"value" xlsx:"字典键值"`
		TypeID    int64  `xorm:"'type_id' varchar(128)  comment('字典类型')" json:"type" form:"type" xlsx:"字典类型"`
		Status    uint   `xorm:"'status'  comment('状态（1正常 2停用）')" json:"status" form:"status" xlsx:"状态"`
		CssClass  string `xorm:"'css_class' varchar(512) comment('样式属性（其他样式扩展）')"  json:"css_class" xlsx:"-"`
		ListClass string `xorm:"'list_class' varchar(512) comment('表格回显样式')" json:"list_class" form:"list_class" xlsx:"-"`
		Remark    string `xorm:"'remark' varchar(1024) comment('备注')" json:"remark" form:"remark" xlsx:"备注"`
		IsDefault string `xorm:"'is_default' default 'N' comment('是否默认（Y是 N否')" json:"is_default" form:"is_default" xlsx:"是否默认 (Y:是 N:否)"`
	}
)

func (SysArgConfig) TableName() string {
	return "sys_config"
}

func (SysDictType) TableName() string {
	return "sys_dict_type"
}

func (SysDictData) TableName() string {
	return "sys_dict_data"
}
