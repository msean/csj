package models

type (
	AreaSuspend struct {
		Bean    `xorm:"extends"`
		ApplyID int64 `xorm:"'apply_id'  comment('渠道ID/客户ID')" json:"apply_id"`
		Type    uint  `xorm:"'type' comment('1 客户 2 渠道')" json:"type"`
		Isp     int64 `xorm:"'isp'  comment('运营商')" json:"isp"`
		Area    int64 `xorm:"'area' varchar(20) comment('地区')" json:"area"`
	}
)

func (AreaSuspend) TableName() string {
	return "xj_suspend"
}
