package models

type (
	FinanceDay struct {
		Bean        `xorm:"extends"`
		IsCustomer  bool    `xorm:"'is_customer'" json:"is_customer"`       // 是否是客户数据（OwnerID: Y-客户ID, N-渠道ID）
		OwnerID     int64   `xorm:"'owner_id'" json:"owner_id"`             // 客户/渠道ID
		Name        string  `xorm:"'name'" json:"name"`                     // 名称
		Balance     float32 `xorm:"'balance' DECIMAL(15,4)" json:"balance"` // 余额
		FinanceDate string  `xorm:"finance_date" json:"finance_date"`       // 日期
		Remark      string  `xorm:"'remark'" json:"remark"`                 // 备注
	}
)

func (FinanceDay) TableName() string {
	return "xj_finance_day"
}

func (FinanceDay) TableNameCH() string {
	return "每日余额表"
}
