package models

type (
	Product struct {
		Bean        `xorm:"extends" xlsx:"-"`
		Code        string  `xorm:"'code' varchar(255)  comment('产品编号')" json:"code" form:"code" xlsx:"编码"` // 产品编码规则由 ISP + areaCode + money(4位数组成 不足补0)
		Name        string  `xorm:"'name' varchar(255)  comment('名称')" json:"name" form:"name" xlsx:"名称"`
		Title       string  `xorm:"'title' varchar(255) comment('标题')" json:"title" form:"title" xlsx:"-"`
		ChargeType  uint    `xorm:"'charge_type' default 1 comment('产品充值方式，1：直充，  2,任意面值')" json:"change_type" form:"change_type" xlsx:"-"`
		Detail      string  `xorm:"'detail' varchar(2000)  comment('详情')" json:"detail" form:"detail" xlsx:"-"`
		BigType     uint    `xorm:"'big_type' comment('产品类型')" json:"big_type" form:"big_type" xlsx:"大类 from:xj_bigtype"`
		SmallType   uint    `xorm:"'small_type'  comment('小类   月卡  季卡等')" json:"small_type" form:"small_type" xlsx:"-"`
		Isp         uint    `xorm:"'isp'  comment('运营商')" json:"isp" form:"isp" xlsx:"运营商 from:xj_isp"`
		FaceValue   int     `xorm:"'face_value'  comment('面值')" json:"face_value" form:"face_value" xlsx:"面值"`
		Price       float64 `xorm:"'price' DECIMAL(15,4) comment('price')" json:"price" form:"price" xlsx:"原价"`
		Online      uint    `xorm:"'online' default 2  comment('开关 1关  2开')" json:"online" form:"online" xlsx:"是否上架 (1:关 2:开)"`
		Area        uint    `xorm:"'area'  comment('area')" json:"area" form:"area" xlsx:"地区"`
		VoucherType uint    `xorm:"'voucher_type'  comment('voucher_type')" json:"voucher_type" form:"voucher_type" xlsx:"凭证类型 from:xj_vouchertype"`
	}
)

func (Product) TableName() string {
	return "xj_baseproduct"
}

type ProductExport struct {
	Bean      `xorm:"extends" xlsx:"-"`
	Code      string  `xorm:"'code' varchar(255)  comment('产品编号')" json:"code" form:"code" xlsx:"编码"` // 产品编码规则由 ISP + areaCode + money(4位数组成 不足补0)
	BigType   uint    `xorm:"'big_type' comment('产品类型')" json:"big_type" form:"big_type" xlsx:"分类 from:xj_bigtype"`
	Name      string  `xorm:"'name' varchar(255)  comment('名称')" json:"name" form:"name" xlsx:"名称"`
	FaceValue int     `xorm:"'face_value'  comment('面值')" json:"face_value" form:"face_value" xlsx:"面值"`
	Price     float64 `xorm:"'price' DECIMAL(15,4) comment('price')" json:"price" form:"price" xlsx:"原价"`
	Isp       uint    `xorm:"'isp'  comment('运营商')" json:"isp" form:"isp" xlsx:"运营商 from:xj_isp"`
	Online    uint    `xorm:"'online' default 2  comment('开关 1关  2开')" json:"online" form:"online" xlsx:"状态 (1:下架 2:上架)"`
	Area      uint    `xorm:"'area'  comment('area')" json:"area" form:"area"`
	AreaName  string  `xlsx:"地区"`
}
