package models

type (
	CustomerDayFinanceStatic struct {
		Bean             `xorm:"extends"`
		Date             string  `xorm:"'date' varchar(255)  comment('日期')"`
		CustomerID       int64   `xorm:"'customer_id'  comment('客户ID')"`
		MobileFaceValue  float64 `xorm:"'mobile_count'  comment('移动跑量')"`
		MobileSales      float64 `xorm:"'mobile_amount' DECIMAL(15,4) comment('移动跑量实际金额')"`
		UnicomFaceValue  float64 `xorm:"'unicom_count' comment('联通跑量')"`
		UnicomSales      float64 `xorm:"'unicom_amount' DECIMAL(15,4) comment('联通跑量实际金额')"`
		TelecomFaceValue float64 `xorm:"'telecom_count'  comment('电信跑量')"`
		TelecomSales     float64 `xorm:"'telecom_amount' DECIMAL(15,4) comment('电信跑量实际金额')"`
		RechargeAmount   float64 `xorm:"'recharge_amount' DECIMAL(15,4) comment('加款金额')"`
		OtherAmount      float64 `xorm:"'other_amount' DECIMAL(15,4) comment('其他加款金额')"`
		Balance          float64 `xorm:"'balance' DECIMAL(15,4) comment('实际余额')"`
		ReOrderAmount    float64 `xorm:"'re_order_amount' DECIMAL(15,4) comment('实际余额')"`
	}
	CustomerOrderStatistic struct {
		Date           string  `xorm:"'date'"`
		Isp            int     `xorm:"'isp'"`
		TotalFaceValue int     `xorm:"'total_face_value'"`
		TotalSales     float64 `xorm:"'total_sales'"`
		CustomerID     int64   `xorm:"'customer_id'"`
	}
	FinanceDayStatistic struct {
		Date         string  `xorm:"'date'"`
		Amount       float64 `xorm:"'amount'"`
		CustomerID   int64   `xorm:"'customer_id'"`
		BusinessType int     `xorm:"'business_type'"`
	}
	// FinanceDayStatistic struct {
	// 	RechargeAmount        float64 `xorm:"'recharge_amount'"`
	// 	SpecialRechargeAmount float64 `xorm:"'other_amount'"`
	// 	Balance               float64 `xorm:"'balance' "`
	// 	ReOrderAmount         float64 `xorm:"'re_order_amount'"`
	// }
)

func (CustomerDayFinanceStatic) TableName() string {
	return "xj_customer_day_finance_s"
}
