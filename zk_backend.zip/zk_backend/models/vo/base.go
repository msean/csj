package vo

type (
	FindListParams struct {
		Page      int    `json:"page" form:"page"`
		PageSize  int    `json:"page_size" form:"page_size"`
		StartTime string `json:"start_time" form:"start_time"`
		EndTime   string `json:"end_time" form:"end_time"`
	}
	DeleteParams struct {
		IDList []int64 `json:"id_list" form:"id_list"`
	}
	ExportContainParams struct {
		IDList []int64 `json:"id_list" form:"id_list"`
	}
	IntRange struct {
		Max int `json:"max" form:"max"`
		Min int `json:"min" form:"min"`
	}
)

type LogDetail struct {
	Url      string `json:"url"`
	Method   string `json:"method"`
	FuncName string `json:"func_name"`
	Req      string `json:"req"`
	Res      string `json:"res"`
}

func InitPage(vo *FindListParams) {
	if vo.Page <= 0 {
		vo.Page = 1
	}
	if vo.PageSize <= 0 {
		vo.PageSize = 5
	}
}
