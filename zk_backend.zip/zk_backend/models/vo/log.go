package vo

import "time"

type LogLoginQueryParams struct {
	Account string         `json:"account" form:"account"`
	Ip      string         `json:"ip" form:"ip"`
	Success int8           `json:"success" form:"success"`
	Base    FindListParams `json:"base" form:"base"`
}

type LogLoginVo struct {
	ID       int64  `json:"id" xlsx:"访问编号"`                  // 日志编号
	Account  string `json:"account" xlsx:"登录名称"`             // 登录账号
	Ip       string `json:"ip" xlsx:"登录地址"`                  // 登录IP地址
	Location string `json:"location" xlsx:"登录地点"`            // 登录地点
	Browser  string `json:"browser" xlsx:"浏览器"`              // 浏览器类型
	Os       string `json:"os" xlsx:"操作系统"`                  // 操作系统
	Success  bool   `json:"success" xlsx:"登录状态 from:status"` // 是否登录成功
	Detail   string `json:"detail" xlsx:"操作信息"`              // 详情
	Created  string `json:"created" xlsx:"登录时间"`             // 登陆时间
}

type QueryLogLoginRes struct {
	Count int64         `json:"count"`
	Data  []*LogLoginVo `json:"data"`
}

type LogOpQueryParams struct {
	Module   int            `json:"module_option" form:"module_option"`
	OpType   int            `json:"operator_option" form:"operator_option"`
	Operator string         `json:"operator" form:"operator"`
	Success  int8           `json:"status_option" form:"status_option"`
	Base     FindListParams `json:"base" form:"base"`
}

type LogOpVo struct {
	ID       int64  `json:"id" xlsx:"日志编号"`                       // 主键id
	Module   uint   `json:"module" xlsx:"系统模块 from:module"`       // 模块
	OpType   uint   `json:"op_type" xlsx:"操作类型 from:log_op_type"` // 操作类型
	Operator string `json:"operator" xlsx:"操作人员"`                 // 操作者
	Company  string `json:"company" xlsx:"公司"`                    // 公司
	Ip       string `json:"ip" xlsx:"主机"`                         // 主机
	Location string `json:"location" xlsx:"操作地点"`                 // 操作地点
	Url      string `json:"url"`                                  // 请求地址
	Method   string `json:"method"`                               // 方法
	Func     string `json:"func"`                                 // 函数
	Req      string `json:"req"`                                  // 请求参数
	Res      string `json:"res"`                                  // 返回结果
	Success  bool   `json:"success" xlsx:"操作状态 from:bool"`        // 操作结果
	Detail   string `json:"detail"`                               // 详情
	Created  string `json:"created" xlsx:"操作时间"`                  // 操作时间
}

type QueryLogOpRes struct {
	Count int64      `json:"count"`
	Data  []*LogOpVo `json:"data"`
}

type LogRequestData struct {
	Module  uint   `json:"module"`
	OpType  uint   `json:"op_type"`
	Func    string `json:"func"`
	Success bool   `json:"success"`
}

type LogRemove struct {
	TableType  uint      `json:"table_type"`
	Count      uint32    `json:"count"`
	Success    bool      `json:"success"`
	IntervalMs uint64    `json:"interval_ms"`
	StartTime  time.Time `json:"start_time"`
	EndTime    time.Time `json:"end_time"`
	Remark     string    `json:"remark"`
}

type LogRemoveQueryParams struct {
	TableType uint           `json:"table_type" form:"table_type"`
	Operator  string         `json:"operator" form:"operator"`
	Base      FindListParams `json:"base" form:"base"`
}

type LogRemoveVo struct {
	ID         int64     `json:"id"`          // 主键id
	Created    time.Time `json:"created"`     // 执行时间
	TableName  string    `json:"table_name"`  // 表名
	IntervalMs uint64    `json:"interval_ms"` // 间隔时间-毫秒
	Count      uint32    `json:"count"`       // 记录数
	Success    bool      `json:"success"`     // 是否操作成功
	StartTime  time.Time `json:"start_time"`  // 开始时间
	EndTime    time.Time `json:"end_time"`    // 结束时间
	Operator   string    `json:"operator"`    // 操作人
	Remark     string    `json:"remark"`      // 备注
}

type QueryLogRemoveRes struct {
	Count int64          `json:"count"`
	Data  []*LogRemoveVo `json:"data"`
}
