package vo

import (
	"application/models"
	"application/utils"
)

type (
	ChannelCreateParams struct {
		models.Channel
		Name          string  `json:"name" form:"name"`
		ShortName     string  `json:"short_name" form:"short_name"`
		ApiID         string  `json:"api_id" form:"api_id"`
		ApiKey        string  `json:"api_key" form:"api_key"`
		SubmitUrl     string  `json:"submit_url" form:"submit_url"`
		QueryUrl      string  `json:"query_url" form:"query_url"`
		BalanceUrl    string  `json:"balance_url" form:"balance_url"`
		BackUrl       string  `json:"back_url" form:"back_url"`
		Online        int     `json:"online" form:"online"`
		Balance       float32 `json:"balance" form:"balance"`
		Detail        string  `json:"detail" form:"detail"`
		TemplateName  string  `json:"template_name" form:"template_name"`
		WarnBalance   int     `json:"warn_balance" form:"warn_balance"`
		Sort          int     `json:"sort" form:"sort"`
		ThreadDetail  string  `json:"thread_detail" form:"thread_detail"`
		Etcone        string  `json:"etc_one" form:"etc_one"`
		Etctwo        string  `json:"etc_two" form:"etc_two"`
		Etcthr        string  `json:"etc_three" form:"etc_three"`
		ManualProcess uint    `json:"manual_process"  form:"manual_process"`
		StuckLimit    int     `json:"stuck_limit" form:"stuck_limit"`
	}
	ChannelUpdateParams struct {
		ID            int64   `json:"id" form:"id" validate:"required"`
		Name          string  `json:"name" form:"name" validate:"required"`
		ShortName     string  `json:"short_name" form:"short_name"`
		ApiID         string  `json:"api_id" form:"api_id"`
		ApiKey        string  `json:"api_key" form:"api_key"`
		SubmitUrl     string  `json:"submit_url" form:"submit_url"`
		QueryUrl      string  `json:"query_url" form:"query_url"`
		BalanceUrl    string  `json:"balance_url" form:"balance_url"`
		BackUrl       string  `json:"back_url" form:"back_url"`
		Online        int     `json:"online" form:"online"`
		Balance       float32 `json:"balance" form:"balance"`
		Detail        string  `json:"detail" form:"detail"`
		TemplateName  string  `json:"template_name" form:"template_name"`
		WarnBalance   int     `json:"warn_balance" form:"warn_balance"`
		Sort          int     `json:"sort" form:"sort"`
		ThreadDetail  string  `json:"thread_detail" form:"thread_detail"`
		Etcone        string  `json:"etc_one" form:"etc_one"`
		Etctwo        string  `json:"etc_two" form:"etc_two"`
		Etcthr        string  `json:"etc_three" form:"etc_three"`
		ManualProcess uint    `json:"manual_process"  form:"manual_process"`
		StuckLimit    int     `json:"stuck_limit" form:"stuck_limit"`
	}
	ChannelListParams struct {
		Base           utils.LimitCond `json:"base"`
		CodeSearch     string          `json:"code_search" form:"code_search"`
		NameSearch     string          `json:"name_search" form:"name_search"`
		StatusChoice   int             `json:"status_choice" form:"status_choice"`
		TemplateSearch string          `json:"template_search" form:"template_search"`
		IDList         []int64         `json:"id_list" form:"id_list"`
	}
	ChannelThreadUpdateParams struct {
		ID           int64                 `json:"id" form:"id" validate:"required"`
		ThreadConfig []models.ChannelLimit `json:"thread_config" form:"thread_config"`
	}
)

type (
	ChannelProductCreateProParams struct {
		ProductCode string `json:"product_code"`
		Pcode       string `json:"pcode"`
	}
	ChannelProdCreateParams struct {
		ChannelID   int64                           `json:"channel_id" form:"channel_id"`
		ProductList []ChannelProductCreateProParams `json:"product_code_list" form:"product_code_list"` // 产品参数 这个在创建渠道产品的时候不会修改原有的渠道
		Online      uint                            `json:"online" form:"online"`
		Discount    ChannelProdDisCountParams       `json:"discount" form:"discount"`
		VoucherType uint                            `json:"voucher_type" form:"voucher_type"`
	}
	ChannelProdDisCountParams struct {
		Type  int64   `json:"type" form:"type"` // 1 原价 X  2 原价 + 3: 原价- 4 原价 /  5 指定价格
		Value float64 `json:"value" form:"value"`
	}
	ChannelProdUpdateParams struct {
		ID             int64                     `json:"id" form:"id"`
		Online         uint                      `json:"online" form:"online"`
		ActualDiscount ChannelProdDisCountParams `json:"actual_discount" form:"actual_discount"`
		OrderDiscount  ChannelProdDisCountParams `json:"order_discount" form:"order_discount"`
		VoucherType    uint                      `json:"voucher_type" form:"voucher_type"`
		Remark         string                    `json:"remark" form:"remark"`
		EffectTime     string                    `json:"effect_time" form:"effect_time"`
	}
	ChannelProdUpdatePcodeParams struct {
		ID    int64  `json:"id" form:"id"`
		Pcode string `json:"pcode" form:"pcode"`
	}
	ChannelProdListParams struct {
		Base                   utils.LimitCond `json:"base"`
		ChannelSearch          uint64          `json:"channel_search" form:"channel_search"`
		ProductAreaSearch      int64           `json:"area_search" form:"area_search"`
		ProductNameSearch      string          `json:"product_name_search" form:"product_name_search"`
		ProductBigTypeSearch   int64           `json:"product_big_type_search" form:"product_big_type_search"`
		ProductSmallTypeSearch int64           `json:"product_small_type_search" form:"product_small_type_search"`
		FaceValueLower         int             `json:"face_value_lower" form:"face_value_lower"`
		FaceValueUpper         int             `json:"face_value_upper" form:"face_value_upper"`
		ProductIspSearch       int             `json:"isp_search" form:"isp_search"`
		VoucherType            uint            `json:"voucher_type" form:"voucher_type"`
		StatusChoice           uint            `json:"status_choice" form:"status_choice"`
		IDList                 []int64         `json:"id_list" form:"id_list"`
	}
	ChannelProdBatchOprParams struct {
		IDList  []int64 `json:"id_list" form:"id_list"`
		OprType uint    `json:"oper_type" form:"oper_type"`
		ChannelProdUpdateParams
	}
)

type (
	ChannelGroupCreateParams struct {
		Code        string  `json:"code" form:"code"`
		Name        string  `json:"name" form:"name"`
		SortType    int     `json:"sort_type" form:"sort_type"`
		ChannelList []int64 `json:"channel_list" form:"channel_list"`
	}
	ChannelGroupRelParams struct {
		Percent   uint  `json:"percent"`
		ChannelID int64 `json:"channel_id"`
	}
	ChannelGroupUpdateParams struct {
		ID   int64                   `json:"id" form:"id"`
		Name string                  `json:"name" form:"name"`
		Rels []ChannelGroupRelParams `json:"rels"`
	}
	ChannelGroupListParams struct {
		Base           utils.LimitCond `json:"base"`
		CodeSearch     string          `json:"code_search" form:"code_search"`
		NameSearch     string          `json:"name_search" form:"name_search"`
		SortTypeChoice uint            `json:"sort_type_choice" form:"sort_type_choice"`
	}
)

func (param ChannelProdDisCountParams) Calculate(price float64) (_f float64) {
	switch param.Type {
	case 1:
		_f = price * param.Value
	case 2:
		_f = price + param.Value
	case 3:
		_f = price - param.Value
	case 4:
		if param.Value != 0 {
			_f = price / param.Value
		}
	case 5:
		_f = param.Value
	}

	_f = utils.FloatReserve(_f, 4)

	return
}
