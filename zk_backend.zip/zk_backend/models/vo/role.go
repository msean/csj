package vo

type RoleQueryParam struct {
	RoleName    string         `json:"role_name" form:"role_name"`
	Available   int            `json:"available" form:"available"`
	ReverseSort bool           `json:"reverse_sort" form:"reverse_sort"`
	OrderSort   int            `json:"order_sort" form:"order_sort"` // -1:不排序; 0:降序; 1:升序
	Base        FindListParams `json:"base" form:"base"`
}

type RoleParams struct {
	Id        int64  `json:"id" form:"id"`
	RoleName  string `json:"role_name" form:"role_name"`
	RoleOrder int    `json:"role_order" form:"role_order"`
	Available bool   `json:"available" form:"available"`
	Menus     string `json:"menus" form:"menus"`
	Remark    string `json:"remark" form:"remark"`
	IsClient  bool   `json:"is_client" form:"is_client"`
}

type RoleVo struct {
	Id        int64  `json:"id" xlsx:"角色编号"`
	RoleName  string `json:"role_name" xlsx:"角色名称"`
	RoleOrder int    `json:"role_order" xlsx:"显示顺序"`
	Available bool   `json:"available" xlsx:"角色状态 from:status"`
	Menus     string `json:"menus"`
	Remark    string `json:"remark"`
	IsClient  bool   `json:"is_client" xlsx:"是否为客户角色 from:bool"`
	Created   string `json:"created" xlsx:"创建时间"`
	Updated   string `json:"updated"`
}

type QueryRoleRes struct {
	Count int64     `json:"count"`
	Roles []*RoleVo `json:"roles"`
}

/*type RolesVo struct {
	Id   int64  `json:"id"`
	Name string `json:"name"`
}*/
