package vo

import (
	"application/utils"
	"time"
)

type FinanceDayQueryParams struct {
	IsCustomer bool           `json:"is_customer" form:"is_customer"` // 是否是客户数据（OwnerID: Y-客户ID, N-渠道ID）
	OwnerID    int64          `json:"owner_id" form:"owner_id"`       // 客户/渠道ID
	Base       FindListParams `json:"base" form:"base"`
}

type FinanceDayVo struct {
	ID          int64     `json:"id" xlsx:"ID from:customer_finance"`      // ID
	IsCustomer  bool      `json:"is_customer" xlsx:"类型 from:finance_type"` // 是否是客户数据（OwnerID: Y-客户ID, N-渠道ID）
	OwnerID     int64     `json:"owner_id"`                                // 客户/渠道ID
	Name        string    `json:"name" xlsx:"名称"`                          // 名称
	Balance     float32   `json:"balance" xlsx:"余额"`                       // 余额
	FinanceDate string    `json:"finance_date" xlsx:"日期"`                  // 日期
	Remark      string    `json:"remark" xlsx:"备注"`                        // 备注
	Created     time.Time `json:"created" xlsx:"创建日期"`                     // 创建时间
}

type FinanceDayQueryRes struct {
	Count   int64           `json:"count" `   // 总数
	Records []*FinanceDayVo `json:"records" ` // 记录
}

type FinanceMonthQueryParams struct {
	CustomerID int64     `json:"customer_id" form:"customer_id"` // 客户ID
	StartTime  time.Time `json:"start_time" form:"start_time"`   // 开始时间
	EndTime    time.Time `json:"end_time" form:"end_time"`       // 结束时间
}

type FinanceCustomerStatistics struct {
	FirstBalance float64 `json:"first_balance" ` // 开始时间余额
	LastBalance  float64 `json:"last_balance" `  // 结束时间余额
	AddAmount    float64 `json:"add_amount" `    // 起止时间内加款金额
}

type FinanceOrderStatistics struct {
	Transaction float64 `json:"transaction" ` // 交易金额
	Count       uint    `json:"count" `       // 成功订单数
	Amount      float64 `json:"amount" `      // 成功订单金额
	Value       int     `json:"value" `       // 成功订单面值
	BelayBack   float64 `json:"belay_back" `  // 延递费
	Back        float64 `json:"back" `        // 上期退款金额
}

type FinanceMonthQueryRes struct {
	Customer *FinanceCustomerStatistics `json:"customer"`
	Order    *FinanceOrderStatistics    `json:"order"`
}

type (
	CustomerFinanceDayStatisticReq struct {
		Base       utils.PageLimitCond `json:"base"`
		CustomerID int64               `json:"customer_id" form:"customer_id"` // 客户ID
		StartDate  string              `json:"start_date" form:"start_date"`   // 开始日期
		EndDate    string              `json:"end_date" form:"start_date"`     // 结束日期
		QryTotal   int                 `json:"qry_total" form:"qry_total"`     // 结束日期
	}
	CustomerFinanceDayStatisticManualReq struct {
		CustomerID int64  `json:"customer_id" form:"customer_id"` // 客户ID
		Date       string `json:"date" form:"date"`               // 客户ID
	}
)
