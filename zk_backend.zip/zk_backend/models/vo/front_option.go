package vo

type Option struct {
	Value int    `json:"value"`
	Title string `json:"title"`
}
