package vo

import (
	"application/utils"
)

type (
	SysArgCreateParams struct {
		Name   string `json:"name" form:"name" validate:"required"`
		Key    string `json:"key" form:"key" validate:"required"`
		Value  string `json:"value" form:"value" validate:"required"`
		Typ    uint   `json:"type" form:"type"`
		Remark string `json:"remark" form:"remark"`
	}
	SysArgListParams struct {
		Base       utils.LimitCond `json:"base" form:"base"`
		NameSearch string          `json:"name_search" form:"name_search"`
		TypeSearch uint            `json:"type_search" form:"type_search"`
		KeySearch  string          `json:"key_search" form:"key_search"`
		IDList     []int64         `json:"id_list" form:"id_list"`
	}
	SysArgUpdateParams struct {
		ID     int64  `json:"id" form:"id"`
		Name   string `json:"name" form:"name" validate:"required"`
		Key    string `json:"key" form:"key" validate:"required"`
		Value  string `json:"value" form:"value" validate:"required"`
		Typ    uint   `json:"type" form:"type"`
		Remark string `json:"remark" form:"remark"`
	}
)
