package vo

import "application/utils"

type (
	AreaSuspendCreateParam struct {
		ChannelList  []int64 `json:"channel_list" form:"channel_list"`
		CustomerList []int64 `json:"customer_list" form:"customer_list"`
		IspCode      int64   `json:"isp_code" form:"isp_code"`
		AreaList     []int64 `json:"area_list" form:"area_code"`
	}
	AreaSuspendListParam struct {
		Base       utils.LimitCond `json:"base"`
		AreaSearch int             `json:"area_search" form:"area_search"`
		IspSearch  int             `json:"isp_search" form:"isp_search"`
		TypeChoice int             `json:"type_choice" form:"type_choice"`
	}
)

type (
	AreaSectionCreateParam struct {
		Province string `json:"province" form:"province"`
		Area     string `json:"area" form:"area"`
		Section  string `json:"section" form:"section"`
		Isp      int    `json:"isp" form:"isp"`
		Remark   string `json:"remark" form:"remark"`
	}
	AreaSectionUpdateParam struct {
		ID       int64  `json:"id" form:"id"`
		Province string `json:"province" form:"province"`
		Area     string `json:"area" form:"area"`
		Isp      int    `json:"isp" form:"isp"`
		Remark   string `json:"remark" form:"remark"`
	}
	AreaSectionListParam struct {
		Base           utils.LimitCond `json:"base" form:"base"`
		IDList         []int64         `json:"id_list" form:"id"`
		SectionSearch  string          `json:"section" form:"section_search"`
		ProvinceSearch string          `json:"province" form:"province_search"`
		AreaSearch     string          `json:"area" form:"area_search"`
		IspChoice      int             `json:"isp" form:"isp_choice"`
		OrderBy        string          `json:"order_by" form:"order_by"`
	}
)

type (
	BlacklistCreateParams struct {
		Phones string `json:"phones" form:"phones"`
		Type   int    `json:"type" form:"type"`
		Remark string `json:"remark" form:"remark"`
	}
	BlacklistParams struct {
		Base         utils.LimitCond `json:"base" form:"base"`
		PhoneSearch  string          `json:"phone_search" form:"phone_search"`
		RemarkSearch string          `json:"remark_search" form:"remark"`
		TypeChoice   int             `json:"type_choice" form:"type_choice"`
		IDList       []int64         `json:"id_list" form:"id_list"`
	}
	BlacklistUpdateParams struct {
		ID     int64  `json:"id" form:"id"`
		Phone  string `json:"phone" form:"phone"`
		Type   int    `json:"type" form:"type"`
		Remark string `json:"remark" form:"remark"`
	}
	UpdateBlacklistPhoneLimitParams struct {
		Count int `json:"count"`
	}
)

type (
	AnnouncementCreateParams struct {
		Title   string `json:"title" form:"title"`
		Content string `json:"content" form:"content"`
		Remark  string `json:"remark" form:"remark"`
	}
	AnnouncementListParams struct {
		Base        utils.LimitCond `json:"base" form:"base"`
		TitleSearch string          `json:"title_search" form:"title_search"`
	}
	AnnouncementUpdateParams struct {
		ID      int64  `json:"id" form:"id"`
		Title   string `json:"title" form:"title"`
		Content string `json:"content" form:"content"`
		Remark  string `json:"remark" form:"remark"`
	}
	AnnouncementPublishParams struct {
		ID int64 `json:"id" form:"id"`
	}
)

// 数据删除
type (
	DataDeleteStartParams struct {
		TimePicker utils.TimeLimitCond `json:"time_picker" form:"time_picker"`
		TableOpt   int                 `json:"table_option" form:"table"`
		StatusOpt  int                 `json:"status_option" form:"type"`
		Interval   int                 `json:"interval" form:"type"`
	}
)

// 白名单
type (
	WhiteListPageParam struct {
		Base         utils.LimitCondAlternative `json:"base" form:"base"`
		IDList       []int64                    `json:"id_list" form:"id_list"`
		IpSearch     string                     `json:"ip_search" form:"ip_search"`
		RemarkSearch string                     `json:"remark_search" form:"type"`
	}
	WhiteListCreateParam struct {
		TimePicker utils.TimeLimitCond `json:"time_picker" form:"time_picker"`
		IpList     string              `json:"ip_list" form:"ip_list"`
		Remark     string              `json:"remark" form:"remark"`
	}
	WhiteListUpdateParam struct {
		TimePicker utils.TimeLimitCond `json:"time_picker" form:"time_picker"`
		Ip         string              `json:"ip" form:"ip_list"`
		Remark     string              `json:"remark" form:"remark"`
		ID         int64               `json:"id" form:"id"`
	}
)

// 定时任务
type (
	CrontabListParam struct {
		Base          utils.LimitCond `json:"time_picker" form:"time_picker"`
		TypeChoice    int             `json:"type_choice" form:"type_choice"`
		StatusChoice  int             `json:"status_choice" form:"status_choice"`
		JobNameSearch string          `json:"job_name_search" form:"job_name_search"`
		WithNoTotal   bool
		IDList        []int64
	}
	CrontabLogListParam struct {
		Base          utils.LimitCondAlternative `json:"time_picker" form:"time_picker"`
		TypeChoice    int                        `json:"type_choice" form:"type_choice"`
		JobNameSearch string                     `json:"job_name_search" form:"job_name_search"`
	}
	CrontabExecOnceParam struct {
		ID int64 `json:"id" form:"id"`
	}
	CrontabUpdateParam struct {
		ID     int64  `json:"id" form:"id"`
		Spec   string `json:"spec" form:"spec"`
		Status int    `json:"status" form:"status"`
		// Strategy int    `json:"strategy" form:"strategy"` // 1 立刻执行 2 执行一次 // 放弃执行
	}
	CrontabExportParam struct {
		IDList []int64 `json:"id_list" form:"id_list"`
	}
	CrontabLogExportParam struct {
		IDList []int64 `json:"id_list" form:"id_list"`
	}
)
