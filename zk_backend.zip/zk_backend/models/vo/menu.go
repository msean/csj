package vo

type MenuParams struct {
	Id        int64  `json:"id" form:"id"`
	MenuName  string `json:"menu_name" form:"menu_name"`
	MenuType  int8   `json:"menu_type" form:"menu_type"`
	MenuOrder int    `json:"menu_order" form:"menu_order"`
	ParentId  int64  `json:"parent_id" form:"parent_id"`
	OpenType  int8   `json:"open_type" form:"open_type"`
	Url       string `json:"url" form:"url"`
	Method    string `json:"method" form:"method"`
	Visible   bool   `json:"visible" form:"visible"`
	Icon      string `json:"icon" form:"icon"`
	Remark    string `json:"remark" form:"remark"`
}

type MenuVo struct {
	Id         int64     `json:"id"`
	ParentId   int64     `json:"parent_id"`
	MenuName   string    `json:"menu_name"`
	MenuType   int8      `json:"menu_type"`
	Order      int       `json:"order"`
	OpenType   int8      `json:"open_type"`
	Url        string    `json:"url"`
	Method     string    `json:"method"`
	Visible    bool      `json:"visible"`
	Permission string    `json:"permission"`
	Icon       string    `json:"icon"`
	Remark     string    `json:"remark"`
	Created    string    `json:"created"`
	Updated    string    `json:"updated"`
	Children   []*MenuVo `json:"children"`
	// Pages          string    `json:"pages"`
	// Classification string    `json:"classification"`
}
