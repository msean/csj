package vo

import (
	"application/utils"
	"time"
)

type (
	OrderListParam struct {
		Base                 utils.LimitCond `json:"base"`
		CustomerChoice       int64           `json:"customer_choice"`
		CurrentChannelChoice int64           `json:"current_channel_choice"`
		CustomerOrderSearch  string          `json:"customer_order_search"`
		OrderIDSearch        string          `json:"order_id_search"`
		PhoneSearch          string          `json:"phone_search"`
		BigTypeSearch        int64           `json:"big_type_search"`
		SmallTypeSearch      int64           `json:"small_type_search"`
		IspSearch            int64           `json:"isp_search"`
		FaceValueLower       int             `json:"face_value_lower"`
		FaceValueUpper       int             `json:"face_value_upper"`
		AreaChoice           int             `json:"area_Choice"`
		RemarkSearch         string          `json:"remark_search"`
		ManualRemarkSearch   string          `json:"manual_remark_search"`
		StatusChoice         int             `json:"status_choice"`
		BackStatusChoice     int             `json:"back_status_choice"`
		BackTimeStart        time.Time       `json:"back_time_start"`
		BackTimeEnd          time.Time       `json:"back_time_end"`
		IsSlowChoice         int             `json:"is_slow_choice"`
		IDList               []int64         `json:"id_list"`
		IsReturnChoice       int             `json:"is_return"`
		InStatusChoice       []int           `json:"in_status_choice"`
		NoWithCount          bool            `json:"with_count"` // 不需要查询total count
	}
	OrderReturnParam struct {
		IDList []int64 `json:"id_list"`
	}
	OrderUpdateManualRemarkParam struct {
		ID     int64  `json:"id"`
		Remark string `json:"remark"`
	}
	OrderReDispatcherParam struct {
		IDList []int64 `json:"id_list"`
	}
	OrderNotifyParam struct {
		IDList []int64 `json:"id_list"`
	}
)

type (
	ChannelOrderListParam struct {
		Base            utils.LimitCond `json:"base"`
		CustomerChoice  int64           `json:"customer_choice"`
		ChannelChoice   int64           `json:"channel_choice"`
		OrderIDSearch   string          `json:"order_id_search"`
		PhoneSearch     string          `json:"phone_search"`
		BigTypeSearch   int64           `json:"big_type_search"`
		SmallTypeSearch int64           `json:"small_type_search"`
		IspChoice       int64           `json:"isp_search"`
		AreaChoice      int             `json:"area_Choice"`
		RemarkSearch    string          `json:"remark_search"`
		FaceValueLower  int             `json:"face_value_lower"`
		FaceValueUpper  int             `json:"face_value_upper"`
		StatusChoice    int             `json:"status_choice"`
		BackTimeStart   time.Time       `json:"back_time_start"`
		BackTimeEnd     time.Time       `json:"back_time_end"`
		IDList          []int64         `json:"id_list"`
		InStatusChoice  []int           `json:"in_status_choice"`
		SrcID           int64           `json:"src_id"`
		NoWithCount     bool            `json:"with_count"` // 不需要查询total count
	}
	ChannelOrderManualSuccessItem struct {
		ChannelOrderID int64  `json:"channel_order_id"`
		Remark         string `json:"remark"`
	}
	ChannelOrderManualSuccessParam struct {
		Items []ChannelOrderManualSuccessItem `json:"items"`
	}
	ChannelOrderUpdateIspParam struct {
		OrderID        int64 `json:"order_id"`
		ChannelOrderID int64 `json:"channel_order_id"`
		Isp            int   `json:"isp"`
	}
	ChannelOrderUpdateRemarkParam struct {
		ID     int64  `json:"id"`
		Remark string `json:"remark"`
	}
	ChannelOrderModifyFailParam struct {
		Items []ChannelOrderManualSuccessItem `json:"items"`
	}
	ChannelOrderAdjustArg struct {
		OrderID        int64 `json:"order_id"`
		ChannelOrderID int64 `json:"channel_order_id"`
	}
	ChannelOrderAdjustParam struct {
		ChannelOrders      []ChannelOrderAdjustArg `json:"channel_orders"`
		AdjustChannels     []int64                 `json:"adjust_channels"`
		AdjustChannelGroup int64                   `json:"adjust_channel_group"`
	}
	ChannelOrderQueryParam struct {
		ChannelOrderID int64 `json:"channel_order_id"`
	}
	ChannelOrderQueryRsp struct {
		Result string `json:"result"`
	}
	ChannelOrderNextParam struct {
		ChannelOrderID int64 `json:"channel_order_id"`
	}
)

type (
	ReturnOrderListParam struct {
		utils.LimitCond
		Base                 utils.LimitCond `json:"base"`
		TimeSearchType       uint            `json:"time_search_type"`
		CustomerChoice       int64           `json:"customer_choice"`
		ChannelChoice        int64           `json:"current_channel_choice"`
		OrderIDSearch        string          `json:"order_id_search"`
		CustomerOrderSearch  string          `json:"customer_order_search"`
		ChannelOrderIDSearch string          `json:"channel_order_id_search"`
		CustomerIDSearch     string          `json:"customer_id_search"`
		PhoneSearch          string          `json:"phone_search"`
		IspChoice            int             `json:"isp_choice"`
		AreaChoice           int             `json:"area_choice"`
		TypeChoice           int             `json:"type_choice"`
		IDList               []int64         `json:"id_list"`
	}
)

type (
	CustomerOrderAnalysisReq struct {
		Base               utils.LimitCond     `json:"base"`
		CallBackTimePicker utils.TimeLimitCond `json:"callback_time_picker"`
		CustomerID         int64               `json:"customer_choice"`
		Isp                int                 `json:"isp_choice"`
		GroupType          int                 `json:"group_type_choice"`
		ChannelID          int                 `json:"channel_choice"`
		ProductType        int                 `json:"product_type"`
		OrderStatus        int                 `json:"status_choice"`
		FaceValueRange     IntRange            `json:"face_value_range"`
		Province           int                 `json:"province_choice"`
		OrderBy            string              `json:"order_by"`
	}
	CustomerOrderSuccessRateReq struct {
		Base               utils.LimitCond     `json:"base"`
		CallBackTimePicker utils.TimeLimitCond `json:"callback_time_picker"`
		CustomerID         int64               `json:"customer_choice"`
		GroupType          int                 `json:"group_type_choice"`
		ChannelID          int                 `json:"channel_choice"`
		FaceValueRange     IntRange            `json:"face_value_range"`
		Province           int                 `json:"province_choice"`
	}
)
