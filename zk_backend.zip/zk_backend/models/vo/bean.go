package vo

type AdminlogVo struct {
	Id        int64  `json:"id"`
	Method    string `json:"method"`
	Url       string `json:"url"`
	Params    string `json:"params"`
	Name      string `json:"name"`
	UserName  string `json:"user_name"`
	Ip        string `json:"ip"`
	UserAgent string `json:"user_agent"`
	CreateBy  int64  `json:"create_by"`
	Created   string `json:"created"`
}
