package vo

import "application/utils"

type UserQueryParams struct {
	Ids         []int64        `json:"ids" form:"ids"`
	UserName    string         `json:"user_name" form:"user_name"`
	PhoneNumber string         `json:"phone_number" form:"phone_number"`
	Available   int            `json:"available" form:"available"`
	ReverseSort bool           `json:"reverse_sort" form:"reverse_sort"`
	IsClient    int8           `json:"is_client" form:"is_client"` // 0: all, 1: client
	Base        FindListParams `json:"base" form:"base"`
}

type UserParams struct {
	Id          int64  `json:"id" form:"id"`
	Account     string `json:"account" form:"account"`
	UserName    string `json:"user_name" form:"user_name"`
	PhoneNumber string `json:"phone_number" form:"phone_number"`
	Email       string `json:"email" form:"email"`
	Company     string `json:"company" form:"company"`
	Password    string `json:"password" form:"password"`
	Position    int8   `json:"position" form:"position"`
	Sex         int8   `json:"sex" form:"sex"`
	Available   bool   `json:"available" form:"available"`
	Role        int64  `json:"'role'" form:"role"`
	Remark      string `json:"remark" form:"remark"`
}

type UserGoogleQRCodeVo struct {
	Code       string `json:"code" form:"code"`
	CodeBase64 string `json:"code_base64" form:"code_base64"`
}

type UserVo struct {
	Id           int64               `json:"id"`
	Account      string              `json:"account" xlsx:"登陆名称"`
	UserName     string              `json:"user_name" xlsx:"用户名称"`
	PhoneNumber  string              `json:"phone_number" xlsx:"手机"`
	Email        string              `json:"email"`
	Company      string              `json:"company" xlsx:"公司"`
	Position     int8                `json:"position"`
	Sex          int8                `json:"sex"`
	Available    bool                `json:"available"`
	Role         int64               `json:"role"`
	IsClient     bool                `json:"is_client"`
	Remark       string              `json:"remark"`
	GoogleQRCode *UserGoogleQRCodeVo `json:"google_qr_code"`
	CustomerID   int64               `json:"customer_id"`
	Balance      float64             `json:"balance"`
	TotalBalance float64             `json:"total_balance"`
	Credit       float64             `json:"credit"`
	Created      string              `json:"created" xlsx:"创建时间"`
	Updated      string              `json:"updated"`
	// ParentId    int64  `json:"parent_id"`
	// LoginIp     string     `json:"login_ip"`
	// LoginDate   string     `json:"login_date"`
	// Roles       []int64    `json:"roles"`
	// RolesMap    []*RolesVo `json:"roles_map"`
}

type QueryRoleUserParams struct {
	RoleID        int64          `json:"role_id" form:"role_id"`               // 角色ID
	Account       string         `json:"account" form:"account"`               // 账号
	PhoneNumber   string         `json:"phone_number" form:"phone_number"`     // 手机号码
	ExcludeRole   bool           `json:"exclude_role" form:"exclude_role"`     // 排除指定角色
	ExcludeClient bool           `json:"exclude_client" form:"exclude_client"` // 排除客户类型
	Base          FindListParams `json:"base" form:"base"`
}

type QueryRoleUserRes struct {
	Count int64     `json:"count"`
	Users []*UserVo `json:"users"`
}

/*type UserMeVo struct {
	Id          int64  `json:"id"`
	ParentId    int64  `json:"parent_id"`
	LoginName   string `json:"login_name"`
	UserName    string `json:"user_name"`
	Email       string `json:"email"`
	Phonenumber string `json:"phonenumber"`
	LoginIp     string `json:"login_ip"`
	LoginDate   string `json:"login_date"`
}*/

/*type UserVo struct {
	Id          int64      `json:"id"`
	ParentId    int64      `json:"parent_id"`
	LoginName   string     `json:"login_name"`
	UserName    string     `json:"user_name"`
	Email       string     `json:"email"`
	Phonenumber string     `json:"phonenumber"`
	Status      string     `json:"status"`
	LoginIp     string     `json:"login_ip"`
	LoginDate   string     `json:"login_date"`
	Remark      string     `json:"remark"`
	Created     string     `json:"created"`
	Updated     string     `json:"updated"`
	Roles       []int64    `json:"roles"`
	RolesMap    []*RolesVo `json:"roles_map"`
}*/

type (
	ListOnlineUserReq struct {
		Base           utils.LimitCond `json:"base" form:"base"`
		LocationSearch string          `json:"location_search"`
		AccountSearch  string          `json:"account_search"`
		OrderBy        string          `json:"order_by"`
	}
	ForceQuitReq struct {
		Tokens []string `json:"tokens"`
	}
)
