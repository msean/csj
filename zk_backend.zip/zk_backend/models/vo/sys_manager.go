package vo

import (
	"application/utils"
)

type (
	SysDictTypeCreateParams struct {
		Name       string `json:"name" form:"name"`
		Type       string `json:"type" form:"type"`
		Status     int64  `json:"status" form:"status"`
		Remark     string `json:"remark" form:"remark"`
		EffectType uint   `json:"effect_type" form:"effect_type"`
	}
	SysDictTypeListParams struct {
		Base         utils.LimitCond `json:"base" form:"base"`
		NameSearch   string          `json:"name_search" form:"name_search"`
		TypeSearch   string          `json:"type_search" form:"type_search"`
		StatusChoice uint            `json:"status_choice" form:"status_choice"`
		LoadData     bool            `json:"load_data" form:"load_data"`
		IDList       []int64         `json:"id_list" form:"id_list"`
		EffectType   uint            `json:"effect_type" form:"effect_type"`
	}
	SysDictUpdateEffectTypeParams struct {
		ID         int64 `json:"id" form:"id"`
		EffectType uint  `json:"effect_type" form:"effect_type"`
	}
	SysDictTypeUpdateParams struct {
		ID         int64  `json:"id" form:"id"`
		Name       string `json:"name" form:"name"`
		Type       string `json:"type" form:"type"`
		Status     int64  `json:"status" form:"status"`
		Remark     string `json:"remark" form:"remark"`
		EffectType uint   `json:"effect_type" form:"effect_type"`
	}
	SysDictDataCreateParams struct {
		Sort      uint   `json:"sort" form:"sort"`
		Label     string `json:"label" form:"label"`
		Value     string `json:"value" form:"value"`
		TypeID    int64  `json:"type" form:"type"`
		Status    int64  `json:"status" form:"status"`
		CssClass  string `json:"css_class" form:"css_class"`
		ListClass string `json:"list_class" form:"list_class"`
		Remark    string `json:"remark" form:"remark"`
		IsDefault string `json:"is_default" form:"is_default"`
	}
	SysDictDataListParams struct {
		Base         utils.LimitCond `json:"base" form:"base"`
		LabelSearch  string          `json:"label_search" form:"label_search"`
		NameSearch   string          `json:"name_search" form:"name_search"`
		StatusChoice uint            `json:"status_choice" form:"status_choice"`
		IDList       []int64         `json:"id_list" form:"id_list"`
		TypeSearch   string          `json:"type_search" form:"type_search"`
	}
	SysDictDataUpdateParams struct {
		ID        int64  `json:"id" form:"id"`
		Sort      uint   `json:"sort" form:"sort"`
		Label     string `json:"label" form:"label"`
		Value     string `json:"value" form:"value"`
		Status    uint   `json:"status" form:"status"`
		CssClass  string `json:"css_class" form:"css_class"`
		ListClass string `json:"list_class" form:"list_class"`
		Remark    string `json:"remark" form:"remark"`
		IsDefault string `json:"is_default" form:"is_default"`
	}
)

func (params *SysDictTypeCreateParams) Mutate() {
	if params.Status == 0 {
		params.Status = 1
	}
}

func (params *SysDictDataCreateParams) Mutate() {
	if params.Status == 0 {
		params.Status = 1
	}
}
