package vo

import (
	"application/utils"
	"time"
)

type (
	DelayTaskListParams struct {
		Base           utils.LimitCond     `json:"base" form:"base"`
		TypeSearch     int                 `json:"type_search" form:"type"`
		StatusSearch   int                 `json:"status_search" form:"status"`
		ExecTimePicker utils.TimeLimitCond `json:"exec_time_picker"`
	}
	DelayTaskUpdateParams struct {
		ID       int64     `json:"id" form:"id"`
		Status   int       `json:"status" form:"status"`
		ExecTime time.Time `json:"exec_time_picker"`
		Remark   string    `json:"remark"`
	}
)
