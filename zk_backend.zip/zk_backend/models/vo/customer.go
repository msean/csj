package vo

import (
	"time"
)

type CustomerQueryParam struct {
	Id        int64          `json:"id" form:"id"`
	Name      string         `json:"name" form:"name"`
	Available int            `json:"available" form:"available" `
	Base      FindListParams `json:"base" form:"base"`
}

type CustomerVo struct {
	ID                int64     `json:"id" xlsx:"ID"`                                   // 客户ID
	UserID            int64     `json:"user_id"`                                        // 用户ID
	Account           string    `json:"account" xlsx:"账号"`                              // 账号
	ApiKey            string    `json:"api_key"`                                        // 密钥
	Name              string    `json:"name" xlsx:"名称"`                                 // 名称
	ShortName         string    `json:"short_name" xlsx:"简称"`                           // 简称
	Balance           float64   `json:"balance" xlsx:"余额"`                              // 余额
	TotalBalance      float64   `json:"total_balance" xlsx:"实际余额"`                      // 实际余额
	RechargeAmount    float64   `json:"recharge_amount" xlsx:"充值中金额"`                   // 充值金额
	PayAmount         float64   `json:"pay_amount" xlsx:"充值中折扣后金额"`                     // 实际支付金额（折扣后的充值金额）
	Credit            float64   `json:"credit" xlsx:"授信"`                               // 授信
	WarnBalance       float32   `json:"warn_balance" xlsx:"预警余额"`                       // 预警余额
	Timeout           uint      `json:"timeout" xlsx:"超时时间（秒）"`                         // 超时时间
	SlowTimeout       uint      `json:"slow_timeout" xlsx:"慢充超时时间（分钟）"`                 // 慢充超时时间
	SlowRechargeFlag  bool      `json:"slow_recharge_flag" xlsx:"慢充开关 from:switch"`     // 慢充开关
	SlowCycleFlag     bool      `json:"slow_cycle_flag" xlsx:"慢充单循环 from:switch"`       // 慢充循环开关
	AllProductFlag    bool      `json:"all_product_flag" xlsx:"查询全部产品编码 from:switch"`   // 查询全部产品编码
	OperatorQueryFlag bool      `json:"operator_query_flag" xlsx:"运营商查询开关 from:switch"` // 运营商查询开关
	SwitchCheckFlag   bool      `json:"switch_check_flag" xlsx:"携号转网检测 from:switch"`    // 携号转网检测开关
	AreaFlag          bool      `json:"area_flag" xlsx:"区域维护开关 from:switch"`            // 区域维护开关
	ApiFlag           bool      `json:"api_flag" xlsx:"接口开关 from:switch"`               // 接口开关
	RechargeFlag      bool      `json:"recharge_flag" xlsx:"充值开关 from:switch"`          // 充值开关
	Detail            string    `json:"detail" xlsx:"详情"`                               // 详情
	RepeatTimeout     uint      `json:"repeat_timeout"`                                 // 重复号码屏蔽时间
	Extra             string    `json:"extra"`                                          // 备用
	MaxOrder          uint      `json:"max_order"`                                      // 接单阈值
	MaxPendingOrder   uint      `json:"max_pending_order"`                              // 卡单阈值
	CallbackType      uint8     `json:"callback_type"`                                  // 回调方式
	Ip                string    `json:"ip"`                                             // ip
	Available         bool      `json:"available"`                                      // 是否可用
	Created           time.Time `json:"created" xlsx:"创建时间"`                            // 创建时间
}

type CustomerQueryRes struct {
	Warning              bool          `json:"warning"`                // 预警音开关
	TotalBalance         float64       `json:"total_balance"`          // 总余额
	TotalRechargeBalance float64       `json:"total_recharge_balance"` // 总充值中金额
	Count                int64         `json:"count" `                 // 总数
	Customers            []*CustomerVo `json:"customers"`              // 客户列表
	// Customers []*models.Customer `json:"customers"` // 客户列表
}

type CustomerParam struct {
	Id              int64   `json:"id" form:"id"`                               // ID
	Account         string  `json:"account" form:"account"`                     // 账号
	Name            string  `json:"name" form:"name"`                           // 名称
	Ip              string  `json:"ip" form:"ip"`                               // ip
	Password        string  `json:"password" form:"password"`                   // 密码
	Email           string  `json:"email" form:"email"`                         // 邮箱
	PhoneNumber     string  `json:"phone_number" form:"phone_number"`           // 手机号
	ApiKey          string  `json:"api_key" form:"api_key"`                     // 密钥
	Extra           string  `json:"extra" form:"extra"`                         // 备用
	Detail          string  `json:"detail" form:"detail"`                       // 详情
	ShortName       string  `json:"short_name" form:"short_name"`               // 简称
	Credit          float64 `json:"credit" form:"credit"`                       // 授信
	WarnBalance     float32 `json:"warn_balance" form:"warn_balance"`           // 预警余额
	CallbackType    uint8   `json:"callback_type" form:"callback_type"`         // 回调方式
	RepeatTimeout   uint    `json:"repeat_timeout" form:"repeat_timeout"`       // 重复号码屏蔽时间
	MaxOrder        uint    `json:"max_order" form:"max_order"`                 // 接单阈值
	MaxPendingOrder uint    `json:"max_pending_order" form:"max_pending_order"` // 卡单阈值
	Available       bool    `json:"available" form:"available"`                 // 是否可用
}

type CustomerTimeoutParam struct {
	Id          int64 `json:"id" form:"id"`                     // ID
	Timeout     uint  `json:"timeout" form:"timeout"`           // 超时时间
	SlowTimeout uint  `json:"slow_timeout" form:"slow_timeout"` // 慢充超时时间
}

type CustomerFlagParam struct {
	Id                int64 `json:"id" form:"id"`                                   // ID
	SlowRechargeFlag  bool  `json:"slow_recharge_flag" form:"slow_recharge_flag"`   // 慢充开关
	SlowCycleFlag     bool  `json:"slow_cycle_flag" form:"slow_cycle_flag"`         // 慢充循环开关
	AllProductFlag    bool  `json:"all_product_flag" form:"all_product_flag"`       // 查询全部产品编码
	OperatorQueryFlag bool  `json:"operator_query_flag" form:"operator_query_flag"` // 运营商查询开关
	SwitchCheckFlag   bool  `json:"switch_check_flag" form:"switch_check_flag"`     // 携号转网检测开关
	AreaFlag          bool  `json:"area_flag" form:"area_flag"`                     // 区域维护开关
	ApiFlag           bool  `json:"api_flag" form:"api_flag"`                       // 接口开关
	RechargeFlag      bool  `json:"recharge_flag" form:"recharge_flag"`             // 充值开关
}

type CustomerUpdateParam struct {
	Base    *CustomerParam
	Timeout *CustomerTimeoutParam
	Flag    *CustomerFlagParam
	ApiKey  string
}

type CustomerProductParam struct {
	// ID               int64   `json:"id" form:"id"`                                 // 客户产品ID
	// CustomerID       int64   `json:"customer_id" form:"customer_id"`               // 客户ID
	// Codes            []int64 `json:"codes" form:"codes"`                           // 编码-基础产品（Product-BaseID）
	ChannelGroupID   int64   `json:"channel_group_id" form:"channel_group_id"`     // 渠道组ID
	ChannelIDs       []int64 `json:"channel_ids" form:"channel_ids"`               // 渠道ID
	FirstChannelIds  []int64 `json:"first_channel_ids" form:"first_channel_ids"`   // 先走渠道列表
	SecondChannelIds []int64 `json:"second_channel_ids" form:"second_channel_ids"` // 后走渠道列表
	ForbidChannelIds []int64 `json:"forbid_channel_ids" form:"forbid_channel_ids"` // 禁止渠道列表
	Cert             uint8   `json:"cert" form:"cert"`                             // 凭证
	TaxType          uint8   `json:"tax_type" form:"tax_type"`                     // 含税类型
	CalType          uint8   `json:"cal_type" form:"cal_type"`                     // 计算方式
	CalValue         float64 `json:"cal_value" form:"cal_value"`                   // 计算金额
	Available        int8    `json:"available" form:"available"`                   // 开关
	BackMoney        float64 `json:"back_money" form:"back_money"`                 // 后返
	AvailableTick    int64   `json:"available_tick" form:"available_tick"`         // 产品生效时间(0-立即生效)
	Remark           string  `json:"remark" form:"remark"`                         // 产品生效时间(0-立即生效)
}

type CustomerProductCreateParam struct {
	CustomerID int64   `json:"customer_id" form:"customer_id"` // 客户ID
	Codes      []int64 `json:"codes" form:"codes"`             // 编码-基础产品（Product-BaseID）
	CustomerProductParam
}

type CustomerProductQueryParam struct {
	CustomerIds     []int64        `json:"customer_ids" form:"customer_ids"`           // 客户
	Areas           []int          `json:"areas" form:"areas"`                         // 区域
	Name            string         `json:"name" form:"name"`                           // 产品名称
	Type            string         `json:"type" form:"type"`                           // 产品类型-大类
	SubType         string         `json:"sub_type" form:"sub_type"`                   // 产品类型-小类
	Isp             int            `json:"isp" form:"isp"`                             // 运营商
	ValueMin        float32        `json:"value_min" form:"value_min"`                 // 面值-最小值
	ValueMax        float32        `json:"value_max" form:"value_max"`                 // 面值-最大值
	Cert            int8           `json:"cert" form:"cert"`                           // 凭证
	Available       int            `json:"available" form:"available"`                 // 开关状态
	ChannelGroupID  int64          `json:"channel_group_id" form:"channel_group_id"`   // 渠道组ID
	FirstChannelID  int64          `json:"first_channel_id" form:"first_channel_id"`   // 先走渠道列表
	SecondChannelID int64          `json:"second_channel_id" form:"second_channel_id"` // 后走渠道列表
	ForbidChannelID int64          `json:"forbid_channel_id" form:"forbid_channel_id"` // 禁止渠道列表
	NeedChannelData bool           `json:"need_channel_data" form:"need_channel_data"` // 是否需要渠道数据
	Base            FindListParams `json:"base" form:"base"`
}

type CustomerProductChannelVo struct {
	ID   int64  `json:"id"`
	Name string `json:"name"`
}

type CustomerProductVo struct {
	ID               int64   `json:"id"`                                                             //  产品ID
	CustomerID       int64   `json:"customer_id" xlsx:"ID"`                                          // 客户ID
	CustomerName     string  `json:"customer_name" xlsx:"客户"`                                        // 客户
	Name             string  `json:"name" xlsx:"名称"`                                                 // 名称
	Cert             uint8   `json:"cert" xlsx:"凭证 from:customer_product_cert"`                      // 凭证
	CalType          uint8   `json:"cal_type"`                                                       // 计算方式
	CalValue         float64 `json:"cal_value"`                                                      // 计算金额
	SalePrice        float64 `json:"sale_price" xlsx:"售价"`                                           // 实际售价
	BackMoney        float64 `json:"back_money" xlsx:"可赔"`                                           // 后返
	Discount         float64 `json:"discount" xlsx:"折扣"`                                             // 折扣（百分比）
	ChannelGroupID   int64   `json:"channel_group_id" xlsx:"渠道组 from:customer_channel_group"`        // 渠道组ID
	ChannelIds       []int64 `json:"channel_ids" xlsx:"渠道 from:customer_channel type:list"`          // 渠道ID
	FirstChannelIds  []int64 `json:"first_channel_ids" xlsx:"先走渠道 from:customer_channel type:list"`  // 先走渠道列表
	SecondChannelIds []int64 `json:"second_channel_ids" xlsx:"后走渠道 from:customer_channel type:list"` // 后走渠道列表
	ForbidChannelIds []int64 `json:"forbid_channel_ids" xlsx:"禁止渠道 from:customer_channel type:list"` // 禁止渠道列表
	TaxType          uint8   `json:"tax_type"`                                                       // 含税类型
	AvailableTick    int64   `json:"available_tick"`                                                 // 产品生效时间(0-立即生效)
	Available        bool    `json:"available" xlsx:"开关 from:switch"`                                // 开关
	ProductCode      string  `json:"product_code" xlsx:"编码"`                                         // 基础产品-编码（Product-Code）
	ProductPrice     float64 `json:"product_price" xlsx:"原价"`                                        // 基础产品-原价（Product-Price）
	ProductSubType   uint    `json:"product_sub_type"`                                               // 基础产品-类型-小类（Product-SmallType）
	ProductValue     int     `json:"product_value"`                                                  // 基础产品-面值（Product-FaceValue）
	ProductType      uint    `json:"product_type"  xlsx:"产品类型 from:customer_product_type"`           // 基础产品-类型-大类（Product-BigType）
	ProductIsp       uint    `json:"product_isp"`                                                    // 基础产品-运营商（Product-Isp）
	ProductArea      uint    `json:"product_area"`                                                   // 基础产品-地区（Product-Area）
}

type CustomerProductQueryRes struct {
	Count         int64                       `json:"count" `         // 总数
	Products      []*CustomerProductVo        `json:"products"`       // 客户产品列表
	Channels      []*CustomerProductChannelVo `json:"channels"`       // 渠道数据
	ChannelGroups []*CustomerProductChannelVo `json:"channel_groups"` // 渠道组数据
}

type CustomerFinanceParam struct {
	CustomerID      int64   `json:"customer_id" form:"customer_id"`             // 客户ID
	Bank            string  `json:"bank" form:"bank"`                           // 银行
	Amount          float64 `json:"amount" form:"amount"`                       // 操作金额
	RechargeAmount  float64 `json:"recharge_amount" form:"recharge_amount"`     // 充值金额
	Remark          string  `json:"remark" form:"remark"`                       // 备注
	OrderID         string  `json:"order_id" form:"order_id"`                   // 订单号
	IsRecharging    bool    `json:"is_recharging" form:"is_recharging"`         // 是否充值中
	IsFinish        bool    `json:"is_finish " form:"is_finish"`                // 是否修改充值中数据
	Type            int     `json:"type" form:"type"`                           // 加款类型
	CustomerOrderID string  `json:"customer_order_id" form:"customer_order_id"` // 操作人/客户订单号
}

type CustomerFinanceQueryParam struct {
	CustomerID    int64          `json:"customer_id" form:"customer_id"`     // 客户
	OrderID       string         `json:"order_id" form:"order_id"`           // 订单号
	BusinessType  int8           `json:"business_type" form:"business_type"` // 业务类型
	Base          FindListParams `json:"base" form:"base"`
	CustomerOrder string         `json:"customer_order" form:"customer_order"`
}

type CustomerFinanceVo struct {
	ID            int64     `json:"id"`                                              // ID
	CustomerID    int64     `json:"customer_id"`                                     // 客户ID
	CustomerName  string    `json:"customer_name" xlsx:"客户"`                         // 客户名
	OrderID       string    `json:"order_id" json:"order_id"  xlsx:"订单号"`            // 订单号
	CustomerOrder string    `json:"customer_order" xlsx:"客户订单号/加款人"`                 // 客户订单号/加款人(暂时忽略)
	BusinessType  uint8     `json:"business_type" xlsx:"业务类型 from:customer_finance"` // 业务类型
	Amount        float64   `json:"amount" xlsx:"金额"`                                // 操作金额
	Balance       float64   `json:"balance" xlsx:"加后余额"`                             // 当前余额
	TotalBalance  float64   `json:"total_balance" xlsx:"加后实际余额"`                     // 实际余额
	Bank          string    `json:"bank" xlsx:"银行"`                                  // 银行
	Remark        string    `json:"remark" xlsx:"备注"`                                // 备注
	Created       time.Time `json:"created" xlsx:"生成时间"`
	Updated       time.Time `json:"updated" xlsx:"更新时间"` // 创建时间
}

type CustomerFinanceQueryRes struct {
	Count   int64                `json:"count" `  // 总数
	Records []*CustomerFinanceVo `json:"records"` // 财务记录
}

type CustomerOtherVo struct {
	CustomerID  int64  `json:"customer_id"`  // 客户ID
	CustomerKey string `json:"customer_key"` // 客户Key
	IPWhitelist string `json:"ip_whitelist"` // IP白名单
	OrderURL    string `json:"order_url"`    // 下单地址
	CheckURL    string `json:"check_url"`    // 查单地址
	BalanceURL  string `json:"balance_url"`  // 余额地址
}
