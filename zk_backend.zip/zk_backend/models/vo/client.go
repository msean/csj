package vo

type (
	ClientRechargeInfo struct {
		PhoneNumber   string `json:"phone_number" form:"phone_number"`       // 手机号码
		Value         int    `json:"value" form:"value"`                     // 面值
		Operator      string `json:"operator" form:"operator"`               // 运营商
		ProductCode   string `json:"product_code" form:"product_code"`       // 产品编码
		AreaByProduct bool   `json:"area_by_product" form:"area_by_product"` // 充值中心 是否根据产品编码指定地区
		Province      string `json:"province" form:"province"`               // 充值中心 是否根据产品编码指定地区
		Area          string `json:"area" form:"area"`                       // 充值中心 是否根据产品编码指定地区
	}
	ClientRechargeParam struct {
		CustomerID int64                `json:"customer_id"`
		Body       []ClientRechargeInfo `json:"body"`
		Type       int64                `json:"type"` // 1单充  2多充  3 充值中心 通过选择产品来充值
	}
	ClientRechargeRsp struct {
		ClientRechargeInfo
		CustomerOrderID string `json:"customer_order_id"`
		SubmitResult    string `json:"submit_result"`
	}
)
