package vo

import (
	"application/utils"
)

type (
	ProductListParams struct {
		Base            utils.LimitCond `json:"base"`
		CodeSearch      string          `json:"code_search" form:"code_search"`
		BigTypeSearch   int64           `json:"big_type_search" form:"big_type_search"`
		SmallTypeSearch int64           `json:"small_type_search" form:"small_type_search"`
		NameSearch      string          `json:"name_search" form:"name_search"`
		FaceValueLower  int             `json:"face_value_lower" form:"face_value_lower"`
		FaceValueUpper  int             `json:"face_value_upper" form:"face_value_upper"`
		IspSearch       []int           `json:"isp_search" form:"isp_search"`
		AreaSearch      []int           `json:"area_search" form:"area_search"`
		OrderBy         string          `json:"order_by" form:"order_by"`
		StatusChoice    uint            `json:"status_choice" form:"status_choice"`
		IDList          []int64         `json:"id_list" form:"id_list"`
		WithNoCount     bool
	}
	ProductCreateParams struct {
		Code       string  `json:"code" form:"code" validate:"required"`
		Name       string  `json:"name" form:"name"`
		Title      string  `json:"title" form:"title"`
		ChargeType uint    `json:"change_type" form:"change_type"`
		Detail     string  `json:"detail" form:"detail"`
		BigType    uint    `json:"big_type" form:"big_type"`
		SmallType  uint    `json:"small_type" form:"small_type"`
		Isp        uint    `json:"isp" form:"isp"`
		FaceValue  int     `json:"face_value" form:"face_value"`
		Price      float32 `json:"price" form:"price"`
		Online     uint    `json:"online" form:"online"`
		Area       uint    `json:"area" form:"area"`
	}
	ProductUpdateParams struct {
		Code      string  `json:"code" form:"code"`
		ID        int64   `json:"id" form:"id"`
		Name      string  `json:"name" form:"name" validate:"required"`
		Title     string  `json:"title" form:"title"`
		BigType   uint    `json:"big_type" form:"big_type"`
		SmallType uint    `json:"small_type" form:"small_type"`
		Isp       uint    `json:"isp" form:"isp"`
		FaceValue int     `json:"face_value" form:"face_value" validate:"required"`
		Price     float32 `json:"price" form:"price" validate:"required"`
		Online    uint    `json:"online" form:"online"`
		Area      uint    `json:"area" form:"area"`
		Detail    string  `json:"detail" form:"detail"`
	}
	ProductCheckParams struct {
		Field string `json:"field"`
		Value string `json:"value"`
	}
)
