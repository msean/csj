package vo

type MenuTreeVo struct {
	Id       int64         `json:"id"`
	Name     string        `json:"name"`
	Order    int           `json:"order"`
	Icon     string        `json:"icon"`
	MenuType int8          `json:"menu_type"`
	Url      string        `json:"url"`
	Children []*MenuTreeVo `json:"children"`
}

type RoleTreeVo struct {
	Id       int64         `json:"id"`
	Name     string        `json:"name"`
	Children []*RoleTreeVo `json:"children"`
}
