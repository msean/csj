package api

import "application/utils"

type (
	QueryBalanceParams struct {
		SzAgentID      string `json:"szAgentId"  form:"szAgentId"`          // 客户ID
		SzVerifyString string `json:"szVerifyString" form:"szVerifyString"` // 签名
		SzFormat       string `json:"szFormat" form:"szFormat"`             // 结果返回格式 Json/xml json为默认
	}
)

func (p *QueryBalanceParams) ValidSign(szKey string) bool {
	sign := utils.Md5KvArray([][2]any{
		{"szAgentId", p.SzAgentID},
		{"szKey", szKey},
	}, "&")
	return sign == p.SzVerifyString
}
