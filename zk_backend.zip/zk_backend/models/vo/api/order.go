package api

import (
	"application/common/logger"
	_constant "application/constant"
	"application/utils"
	"encoding/json"
	"fmt"
	"time"

	"go.uber.org/zap"
)

type (
	CreateOrderParams struct {
		SzAgentID      string `json:"szAgentId"  form:"szAgentId"`          // 客户ID
		SzOrderId      string `json:"szOrderId" form:"szOrderId"`           // 订单平台
		SzPhoneNum     string `json:"szPhoneNum" form:"szPhoneNum"`         // 充值号码/QQ/加油卡号
		NMoney         int    `json:"nMoney" form:"nMoney"`                 // 充值金额 单位：元/M/产品原价
		NSortType      int    `json:"nSortType" form:"nSortType"`           // 运营编码
		NProductClass  int    `json:"nProductClass" form:"nProductClass"`   // 固定值 1
		NProductType   string `json:"nProductType" form:"nProductType"`     // 固定值 1
		SzProductId    string `json:"szProductId" form:"szProductId"`       // 产品编号
		SzTimeStamp    string `json:"szTimeStamp" form:"szTimeStamp"`       // 时间戳，用于判断过期时间、与服务时间间隔1分钟有效
		SzVerifyString string `json:"szVerifyString" form:"szVerifyString"` // 签名
		SzNotifyUrl    string `json:"szNotifyUrl" form:"szNotifyUrl"`       // 完成结果回调通知地址(不参与签名)
		SzFormat       string `json:"szFormat" form:"szFormat"`             // 结果返回格式 Json/xml json为默认
		ThirdPhone     string `json:"thirdphone" form:"thirdphone"`         // 充值用户手机号，中石油必传
		Params         string `json:"params" form:"params"`                 // 中石油必传：{"cardName":姓名","cardId":"身份证号"} 电费充值必传{"province": "北京","area": "北京","cardId":"南方电网必传身份证号"}
	}
	QryOrderParams struct {
		SzAgentID      string `json:"szAgentId"  form:"szAgentId"`          // 客户ID
		SzOrderId      string `json:"szOrderId" form:"szOrderId"`           // 订单平台
		SzVerifyString string `json:"szVerifyString" form:"szVerifyString"` // 签名
		SzFormat       string `json:"szFormat" form:"szFormat"`             // 结果返回格式 Json/xml json为默认
	}
	OrderStuckQueryParams struct {
		CustomerID int64 `json:"customer_id"`
		ChannelID  int64 `json:"channel_id"`
		Type       int64 `json:"type"` // 1 customer_id 2 channel_id
	}
)

func (p *CreateOrderParams) ValidSign(szKey string) bool {
	sign := utils.Md5KvArray([][2]any{
		{"szAgentId", p.SzAgentID},
		{"szOrderId", p.SzOrderId},
		{"szPhoneNum", p.SzPhoneNum},
		{"nMoney", p.NMoney},
		{"nSortType", p.NSortType},
		{"nProductClass", p.NProductClass},
		{"nProductType", p.NProductType},
		{"szTimeStamp", p.SzTimeStamp},
		{"szKey", szKey},
	}, "&")
	return sign == p.SzVerifyString
}

// Check 参数校验
func (p *CreateOrderParams) Check() (ocm _constant.ApiCodeMsg) {
	extraParams := p.ParseParams()

	// 时间格式验证
	layout := "2006-01-02 15:04:05"
	orderTime, err := time.Parse(layout, p.SzTimeStamp)
	if err != nil {
		return _constant.NewParamsApiCodeMsg("时间戳格式错误,格式: yyyy-MM-dd HH:mm:ss")
	}

	// 时间参数验证
	if time.Now().Add(-60 * time.Second).After(orderTime) {
		return _constant.NewApiOrderTimeOverOrStuckMsg("时间戳间隔超过1分钟")
	}

	// 手机号验证
	if p.NProductType == "1" && !utils.ValidPhone(p.SzPhoneNum) {
		return _constant.NewApiCodeMsg(_constant.ApiOrderPhoneErr)
	}

	// 中石油必须传
	if p.NSortType == int(_constant.IspPetro) {
		if utils.IsBlankString(p.ThirdPhone) {
			return _constant.NewParamsApiCodeMsg("Thirdphone Must not be empty")
		}

		for _, key := range []string{"cardName", "cardId"} {
			if m := p.ParamsCheck(key, extraParams); !utils.IsBlankString(m) {
				return _constant.NewParamsApiCodeMsg(m)
			}
		}
	}

	// 电费充值必传
	if p.NSortType == int(_constant.IspStateGrid) || p.NSortType == int(_constant.IspSouthGrid) {
		for _, key := range []string{"province", "area", "cardId"} {
			if m := p.ParamsCheck(key, extraParams); !utils.IsBlankString(m) {
				return _constant.NewParamsApiCodeMsg(m)
			}
		}
	}
	return
}

func (p *CreateOrderParams) ParseParams() map[string]any {
	exParams := make(map[string]any)
	if len(p.Params) > 0 {
		err := json.Unmarshal([]byte(p.Params), &exParams)
		if err != nil {
			logger.Log.Error("Error parsing JSON", zap.String("params", p.Params), zap.Error(err))
		}
	}
	return exParams
}

func (p *CreateOrderParams) ParamsCheck(key string, params map[string]any) (msg string) {
	if _, ok := params[key]; !ok {
		msg = fmt.Sprintf("Params Must contains %s", key)
	}
	return
}

func (p *QryOrderParams) ValidSign(szKey string) bool {
	sign := utils.Md5KvArray([][2]any{
		{"szAgentId", p.SzAgentID},
		{"szOrderId", p.SzOrderId},
		{"szKey", szKey},
	}, "&")
	return sign == p.SzVerifyString
}
