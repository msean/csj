package models

import "time"

type (
	LogLogin struct {
		Bean `xorm:"extends"`
		//ID       int64     `xorm:"'id' pk autoincr"` // 主键id
		Account  string `xorm:"'account'"`  // 登录账号
		Ip       string `xorm:"'ip'"`       // 登录IP地址
		Location string `xorm:"'location'"` // 登录地点
		Browser  string `xorm:"'browser'"`  // 浏览器类型
		Os       string `xorm:"'os'"`       // 操作系统
		Success  bool   `xorm:"'success'"`  // 是否登录成功
		Detail   string `xorm:"'detail'"`   // 详情
	}

	LogOp struct {
		Bean `xorm:"extends"`
		// ID       int64     `xorm:"'id' pk autoincr"` // 主键id
		Module   uint   `xorm:"'module'"`      // 模块
		OpType   uint   `xorm:"'op_type'"`     // 操作类型
		Operator string `xorm:"'operator'"`    // 操作者
		Company  string `xorm:"'company'"`     // 公司
		Ip       string `xorm:"'ip'"`          // 主机
		Location string `xorm:"'location'"`    // 操作地点
		Url      string `xorm:"'url'"`         // 请求地址
		Method   string `xorm:"'method'"`      // 方法
		Func     string `xorm:"'func'"`        // 函数
		Req      string `xorm:"'req' text"`    // 请求参数
		Res      string `xorm:"'res' text "`   // 返回值
		Success  bool   `xorm:"'success'"`     // 操作结果
		Detail   string `xorm:"'detail' text"` // 详情
		// Created  time.Time `xorm:"created"`       // 操作时间
	}

	LogRemove struct {
		Bean       `xorm:"extends"`
		TableType  uint      `xorm:"'table_type'"`  // 表类型
		Count      uint32    `xorm:"'count'"`       // 记录数
		IntervalMs uint64    `xorm:"'interval_ms'"` // 间隔时间-毫秒
		StartTime  time.Time `xorm:"'start_time'"`  // 开始时间
		EndTime    time.Time `xorm:"'end_time'"`    // 结束时间
		Operator   string    `xorm:"'operator'"`    // 操作人
		Success    bool      `xorm:"'success'"`     // 是否操作成功
		Remark     string    `xorm:"'remark'"`      // 备注
	}
)

func (LogLogin) TableName() string {
	return "a_log_login"
}

func (LogLogin) TableNameCH() string {
	return "登陆日志表"
}

func (LogOp) TableName() string {
	return "a_log_op"
}

func (LogOp) TableNameCH() string {
	return "操作日志表"
}

func (LogRemove) TableName() string {
	return "a_log_remove"
}

func (LogRemove) TableNameCH() string {
	return "数据删除日志表"
}
