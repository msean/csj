package models

import "time"

type DelayTask struct {
	Bean     `xorm:"extends"`
	Table    string    `xorm:"'table'`
	Pk       string    `xorm:"'pk'`
	Sql      string    `xorm:"'sql' TEXT"`
	ExecTime time.Time `xorm:"'exec_time'`
	Remark   string    `xorm:"'remark'`
	Status   int       `xorm:"'status'` // 1 作废 2 已经执行 3 未执行
}

func (DelayTask) TableName() string {
	return "xj_delay_task"
}

func (delay *DelayTask) Mutate() {
	delay.Status = 3
}

type ExportDelayTask struct {
	ID        int64     `json:"id" xlsx:"ID"`
	Type      string    `json:"type" xlsx:"类型"`
	Remark    string    `json:"remark" xlsx:"备注"`
	ExecTime  time.Time `json:"exec_time" xlsx:"执行时间"`
	CreatedBy string    `json:"created_by" xlsx:"创建者"`
	Status    string    `json:"status" xlsx:"状态"`
}
