package models

type (
	AreaSection struct {
		Bean     `xorm:"extends"`
		Section  string `xorm:"'section' varchar(64) index comment('号段')" json:"section" xlsx:"号段"`
		Area     string `xorm:"'area' varchar(32) index comment('地区')" json:"area" xlsx:"地区"`
		Remark   string `xorm:"'remark' varchar(255) index comment('备注')" json:"remark" xlsx:"备注"`
		Isp      int    `xorm:"'isp' index comment('运营商')"  json:"isp" xlsx:"运营商 from:xj_isp"`
		Province string `xorm:"'province' varchar(32) index comment('省份')" json:"province" xlsx:"运营商 from:省份"`
	}
)

func (AreaSection) TableName() string {
	return "xj_area_section"
}
