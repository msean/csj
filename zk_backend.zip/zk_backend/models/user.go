package models

import "time"

type User struct {
	Bean        `xorm:"extends"`
	Account     string `xorm:"'account' index unique notnull"` // 账号
	Username    string `xorm:"'user_name' unique notnull"`     // 用户昵称
	PhoneNumber string `xorm:"'phone_number' notnull"`         // 手机号码
	Email       string `xorm:"'email' notnull"`                // 用户邮箱
	Company     string `xorm:"'company' notnull"`              // 公司
	Password    string `xorm:"'password' notnull"`             // 密码
	GoogleCode  string `xorm:"'google_code' notnull"`          // google验证码
	Position    int8   `xorm:"'position' notnull"`             // 岗位
	Sex         int8   `xorm:"'sex'"`                          // 性别
	Available   bool   `xorm:"default(true) 'available'"`      // 是否可用
	Role        int64  `xorm:"'role' notnull"`                 // 角色
	IsClient    bool   `xorm:"'is_client'"`                    // 是否为客户
	IsSuper     bool   `xorm:"'is_super'"`                     // 是否为超级权限角色
	CustomerID  int64  `xorm:"'customer_id'"`                  // 客户ID
	Remark      string `xorm:"'remark'"`                       // 备注
}

type (
	OnlineUser struct {
		Token      string    `xorm:"'token' pk" json:"token"`
		Account    string    `xorm:"'account'" json:"account"`
		Host       string    `xorm:"'host'" json:"host"`
		Location   string    `xorm:"'location'" json:"location"`
		Browser    string    `xorm:"'browser'" json:"browser"`
		Status     string    `xorm:"'status'" json:"status"`
		Os         string    `xorm:"'os'" json:"os"` // 操作系统
		LoginTime  time.Time `xorm:"'login_time'" json:"login_time"`
		LatestView time.Time `xorm:"'latest_view'" json:"latest_view"`
		ExpiredAt  time.Time `xorm:"'expired_at'"  json:"expired_at"`
	}
)

func (User) TableName() string {
	return "a_user"
}

func (User) TableNameCH() string {
	return "用户表"
}

func (OnlineUser) TableName() string {
	return "xj_online_user"
}
