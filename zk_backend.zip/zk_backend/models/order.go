package models

import (
	"application/constant"
	"application/models/logic"
	"fmt"
	"time"
)

type (
	OrderCustomerProdField struct {
		SalePrice   float64 `xorm:"'sale_price' DECIMAL(15,4) comment('售价')"`
		VoucherType uint    `xorm:"'voucher_type' comment('凭证类型')"`
		CustomerID  int64   `xorm:"'customer_id' index comment('customer_id')"`
		TaxType     uint8   `xorm:"'tax'  comment('含税')"`
		BackMoney   float64 `xorm:"'back_money' DECIMAL(15,4) comment('后返')"`
		Isp         int     `xorm:"'isp' comment('运营商')"`
		Voucher     string  `xorm:"'voucher' varchar(3096) comment('凭证信息')"`
	}
	OrderProductField struct {
		Price       float64 `xorm:"'price' DECIMAL(15,4) comment('市场价')"`
		FaceValue   int     `xorm:"'face_value' comment('面值')"`
		BigType     int64   `xorm:"'big_type' varchar(20) comment('大类类型')"`
		SmallType   int64   `xorm:"'small_type' varchar(40) comment('小类类型')"`
		ProductCode string  `xorm:"'product_code' comment('产品编码')"`
	}
	OrderBackNotifyField struct {
		CurrentBackStatus uint        `xorm:"'current_back_status'  comment('当前的回调状态')"`
		CurrentBackTime   time.Time   `xorm:"'current_back_time'  comment('当前的回调时间')"`
		BackStatus        []uint      `xorm:"'back_status' comment('回调状态1失败2成功')"`
		BackTime          []time.Time `xorm:"'back_time' comment('回调时间')"`
		BackMsg           []string    `xorm:"'back_msg' comment('回调信息')"`
	}
	Order struct {
		BeanShard              `xorm:"extends"`
		OrderCustomerProdField `xorm:"extends"`
		OrderProductField      `xorm:"extends"`
		OrderBackNotifyField   `xorm:"extends"`
		CurrentChannelID       int64     `xorm:"'current_channel_id' comment('当前渠道')"`
		InPrice                float64   `xorm:"'in_price' DECIMAL(15,4) comment('进价')"`
		CustomerOrderID        string    `xorm:"'customer_order_id' index varchar(60) comment('customer_order_id')"`
		Phone                  string    `xorm:"'phone' varchar(40) comment('phone')"`
		Province               string    `xorm:"'province' varchar(20) comment('province')"`
		Area                   string    `xorm:"'area' varchar(40) comment('area')"`
		Name                   string    `xorm:"'name' varchar(255) comment('name')"`
		Status                 uint      `xorm:"'status'  index comment('订单状态 0 1 2  10成功 11失败')"`
		PayStatus              uint      `xorm:"'pay_status'  comment('付款状态')"`
		Rnum                   uint      `xorm:"'rnum' comment('rnum')"`
		FinishTime             time.Time `xorm:"'finish_time' comment('完成时间')"`
		Remark                 string    `xorm:"'remark' varchar(255) comment('备注')"`
		BackUrl                string    `xorm:"'back_url' varchar(255) comment('客户回调地址')"`
		ThirdPhone             string    `xorm:"'third_phone' varchar(40) comment('第三方手机号')"`
		Source                 uint      `xorm:"'source' varchar(40) comment('订单来源0无结果订单补充1成功订单补充')"`
		ManualRemark           string    `xorm:"'manual_remark' text comment('人工备注')"`
		IsSlow                 uint      `xorm:"'is_slow'  comment('是否是慢充订单  1 是 2 否')"`
		HasReturned            uint      `xorm:"'has_returned' index comment('是否已经申请了退单 2 ')"`
	}
	ChannelOrder struct {
		BeanShard              `xorm:"extends"`
		OrderCustomerProdField `xorm:"extends"`
		OrderProductField      `xorm:"extends"`
		OrderBackNotifyField   `xorm:"extends"`
		InPrice                float64        `xorm:"'in_price' DECIMAL(15,4) comment('进价')"`
		CustomerOrderID        string         `xorm:"'customer_order_id' varchar(60) comment('customer_order_id')"`
		Phone                  string         `xorm:"'phone' varchar(40) comment('phone')"`
		Province               string         `xorm:"'province' varchar(20) comment('province')"`
		Area                   string         `xorm:"'area' varchar(40) comment('area')"`
		ChannelID              int64          `xorm:"'channel_id' index comment('渠道ID')"`
		OrderID                int64          `xorm:"'order_id' comment('主订单')"`
		Pcode                  string         `xorm:"'pcode' varchar(40) comment('pcode')"`
		FinishTime             time.Time      `xorm:"'finish_time' comment('完成时间')"`
		Remark                 []RemarkRecord `xorm:"'remark' text comment('remark')"`
		ThirdPhone             string         `xorm:"'third_phone' varchar(20) comment('third_phone')"`
		Source                 uint           `xorm:"'source' comment('2存疑订单重提')"`
		OrderTime              time.Time      `xorm:"'order_time' comment('订单时间')"`
		Status                 uint           `xorm:"'status' index comment('订单状态 0 1 2  10成功 11失败')"` // 订单状态 ：成功 渠道充值成功订单  失败 渠道充值失败订单  存疑 使用LiFang模板会产生存疑状态订单, 初始化 未分发到渠道的订单。 处理中 渠道正在处理的订单
	}
	// 用于记录订单下发时候配置的渠道和渠道组/后台管理页面订单补充的渠道信息
	OrderChannelRecord struct {
		Bean             `xorm:"extends"`
		OrderID          int64               `xorm:"'order_id' index"  json:"order_id"`
		Type             uint                `xorm:"'type'" json:"type"`                             // 1 客户产品设置的渠道  2 补充渠道
		ChannelGroupID   int64               `xorm:"'channel_group_id'" json:"channel_group_id"`     // 渠道组ID
		ChannelIds       []int64             `xorm:"'channel_ids'" json:"channel_ids"`               // 渠道ID
		FirstChannelIds  []int64             `xorm:"'first_channel_ids'" json:"first_channel_ids"`   // 先走渠道列表
		SecondChannelIds []int64             `xorm:"'second_channel_ids'" json:"second_channel_ids"` // 后走渠道列表
		ForbidChannelIds []int64             `xorm:"'forbid_channel_ids'" json:"forbid_channel_ids"` // 禁止渠道列表
		ValidChannel     []logic.ChannelSort `xorm:"'valid_channels'" json:"valid_channel"`
	}
	OrderReturn struct {
		Bean            `xorm:"extends"`
		OrderID         int64     `xorm:"'order_id' comment('主订单')"`
		CustomerID      int64     `xorm:"'customer_id' comment('客户ID')"`
		CustomerOrderID string    `xorm:"'customer_order_id'  varchar(64)  comment('客户订单号')"`
		ChannelOrderID  int64     `xorm:"'channel_order_id'  comment('渠道订单号')"`
		Area            string    `xorm:"'area' varchar(40) comment('area')"`
		Phone           string    `xorm:"'phone' varchar(40) comment('phone')"`
		ChannelID       int64     `xorm:"'channel_id' comment('渠道ID')"`
		ProductCode     string    `xorm:"'pcode' comment('产品编码')"`
		BigType         int64     `xorm:"'big_type' varchar(20) comment('大类类型')"`
		Isp             int       `xorm:"'isp' comment('运营商')"`
		FaceValue       int       `xorm:"'face_value' comment('面值')"`
		InPrice         float64   `xorm:"'in_price' DECIMAL(15,4) comment('进价')"`
		SalePrice       float64   `xorm:"'sale_price' DECIMAL(15,4) comment('售价')"`
		OrderTime       time.Time `xorm:"'order_time' comment('订单创建时间')"`
		VoucherType     uint      `xorm:"'voucher_type' comment('凭证类型')"`
		Remark          string    `xorm:"'remark' comment('备注')"`
		Type            uint      `xorm:"'type' comment('返销类型 1客户返销 2渠道后成功 3渠道后失败')"`
	}
	RemarkRecord struct {
		RemarkTime time.Time `json:"remark_time"`
		Remark     string    `json:"remark"`
	}
	OrderStuckInfo struct {
		Type             int // 1 订单  2 渠道订单
		OrderID          int64
		ChannelID        int64
		CustomerID       int64
		CurrentStatus    int
		OrderTime        time.Time
		ChannelOrderTime time.Time
		ChannelOrderID   int64
	}
	CustomerOrderDateMapper struct {
		CustomerOrderID string    `xorm:"'customer_order_id' index comment('客户订单')"`
		Date            time.Time `xorm:"'date' comment('日期')"`
	}
)

func (Order) TableName() string {
	return "xj_order"
}

func (CustomerOrderDateMapper) TableName() string {
	return "xj_customer_order_date"
}

func (order Order) SetIndex() string {
	return fmt.Sprintf(`ALTER TABLE %s
ADD INDEX idx_created (created),
ADD INDEX idx_created_status (created, status);`, order.TableName())
}

func (ChannelOrder) TableName() string {
	return "xj_channelorder"
}

func (channelOrder ChannelOrder) SetIndex() string {
	return fmt.Sprintf(`ALTER TABLE %s
ADD INDEX idx_created (created),
ADD INDEX idx_created_status (created, status);`, channelOrder.TableName())
}

func (OrderReturn) TableName() string {
	return "xj_order_return"
}

func (OrderChannelRecord) TableName() string {
	return "xj_order_channel"
}

func (o *Order) Mutate() {
	if o.Area == "" {
		o.Area = "全国"
	}

	if o.Province == "" {
		o.Province = "全国"
	}
	if o.Status == 0 {
		o.Status = constant.OrderStatusInit
	}
	if o.CurrentBackStatus == 0 {
		o.CurrentBackStatus = constant.OrderNotifyInit
	}
}

func (o *Order) SetIsp(isp int) {
	o.Isp = isp
}

func (o *Order) SetArea(province, area string) {
	o.Province = province
	o.Area = area
}

func (o *Order) SetByParams(customerOrderID, phone, name, thirdPhone, backUrl string) {
	o.CustomerOrderID = customerOrderID
	o.Phone = phone
	o.Name = name
	o.ThirdPhone = thirdPhone
	o.BackUrl = backUrl
}

func (o *Order) SetByCustomer(customer Customer) {
	o.IsSlow = 1
	if customer.SlowRechargeFlag {
		o.IsSlow = 2
	}
}

func (o *OrderCustomerProdField) SetByCustomerProd(customerProd CustomerProduct) {
	o.SalePrice = customerProd.SalePrice
	o.CustomerID = customerProd.CustomerID
	o.TaxType = customerProd.TaxType
	o.BackMoney = customerProd.BackMoney
	o.VoucherType = uint(customerProd.Cert)
	o.Isp = int(customerProd.ProductIsp)
}

func (o *OrderProductField) SetByProduct(product Product) {
	o.Price = product.Price
	o.FaceValue = product.FaceValue
	o.BigType = int64(product.BigType)
	o.SmallType = int64(product.SmallType)
	o.ProductCode = product.Code
}

func NewChannelOrder(order Order, channelID int64, inPrice float64, pCode string) (channelOrder ChannelOrder) {
	channelOrder.OrderCustomerProdField = order.OrderCustomerProdField
	channelOrder.OrderProductField = order.OrderProductField
	channelOrder.InPrice = inPrice
	channelOrder.CustomerOrderID = order.CustomerOrderID
	channelOrder.Phone = order.Phone
	channelOrder.Province = order.Province
	channelOrder.Area = order.Area
	channelOrder.ChannelID = channelID
	channelOrder.OrderID = order.ID
	channelOrder.Pcode = pCode
	channelOrder.ThirdPhone = order.ThirdPhone
	channelOrder.OrderTime = order.Created
	channelOrder.Status = constant.OrderStatusInit
	channelOrder.CurrentBackStatus = constant.OrderNotifyInit
	return
}

func NewReturnOrderByChannel(channelOrder ChannelOrder, typ uint, channel Channel) OrderReturn {
	var remark string
	switch typ {
	case constant.ROrderTypeSuccess:
		remark = fmt.Sprintf("警告: 渠道订单%d失败后返回成功，渠道ID:%d %s,手机号：%s, 时间:%s",
			channelOrder.ID, channelOrder.ChannelID, channel.Name, channelOrder.Phone, time.Now())
	case constant.ROrderTypeFail:
		remark = fmt.Sprintf("警告: 渠道订单%d成功后返回失败，渠道ID:%d %s,手机号：%s, 时间:%s",
			channelOrder.ID, channelOrder.ChannelID, channel.Name, channelOrder.Phone, time.Now())
	}

	return OrderReturn{
		OrderID:         channelOrder.OrderID,
		CustomerID:      channelOrder.CustomerID,
		CustomerOrderID: channelOrder.CustomerOrderID,
		ChannelOrderID:  channelOrder.ID,
		Area:            channelOrder.Area,
		Phone:           channelOrder.Phone,
		ChannelID:       channelOrder.ChannelID,
		ProductCode:     channelOrder.ProductCode,
		BigType:         channelOrder.BigType,
		Isp:             channelOrder.Isp,
		FaceValue:       channelOrder.FaceValue,
		InPrice:         channelOrder.InPrice,
		SalePrice:       channelOrder.SalePrice,
		OrderTime:       channelOrder.OrderTime,
		VoucherType:     channelOrder.VoucherType,
		Type:            typ,
		Remark:          remark,
	}
}
