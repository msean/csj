package models

type Announcement struct {
	Bean    `xorm:"extends"`
	Title   string `xorm:"'title' varchar(255)" json:"title"`
	Content string `xorm:"'content' text" json:"content"`
	Remark  string `xorm:"'remark' text" json:"remark"`
	Status  int    `xorm:"'status' tinyint" json:"status"` // 0: 未发布，1: 已发布
}

func (a Announcement) TableName() string {
	return "xj_announcement"
}
