package models

import "time"

type Bean struct {
	ID       int64     `xorm:"'id' pk autoincr" json:"id" form:"id"`                    // 主键id
	CreateBy int64     `xorm:"'create_by'" json:"create_by" form:"create_by"`           // 创建者
	Created  time.Time `xorm:"created" json:"created" form:"created"`                   // 创建时间
	UpdateBy int64     `xorm:"'update_by'" json:"update_by" form:"update_by"`           // 更新者
	Updated  time.Time `xorm:"updated" json:"updated" form:"updated"`                   // 更新时间
	Deleted  time.Time `xorm:"deleted" json:"deleted" form:"deleted"`                   // 删除时间
	Version  int64     `xorm:"notnull version 'version'" json:"version" form:"version"` // 版本
}

type BeanShard struct {
	ID       int64     `xorm:"'id' pk" json:"id" form:"id"`
	SrcID    int64     `xorm:"'src_id' default 0" json:"src_id" form:"src_id"`          // 主键id
	CreateBy int64     `xorm:"'create_by'" json:"create_by" form:"create_by"`           // 创建者
	Created  time.Time `xorm:"created" json:"created" form:"created"`                   // 创建时间
	UpdateBy int64     `xorm:"'update_by'" json:"update_by" form:"update_by"`           // 更新者
	Updated  time.Time `xorm:"updated" json:"updated" form:"updated"`                   // 更新时间
	Deleted  time.Time `xorm:"deleted" json:"deleted" form:"deleted"`                   // 删除时间
	Version  int64     `xorm:"notnull version 'version'" json:"version" form:"version"` // 版本
}

func Add(id int64, bean *Bean) {
	bean.CreateBy = id
	bean.UpdateBy = id
}

func Edit(id int64, bean *Bean) {
	bean.UpdateBy = id
}
