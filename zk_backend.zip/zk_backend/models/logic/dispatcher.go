package logic

type (
	ChannelSort struct {
		Channels []int64
		SortType int
		Percent  []int
	}
)

func NewChannelSort() ChannelSort {
	return ChannelSort{
		Channels: []int64{},
		SortType: 0,
		Percent:  []int{},
	}
}
