package models

type Role struct {
	Bean      `xorm:"extends"`
	RoleName  string `xorm:"notnull unique 'role_name'"` // 角色名称
	RoleOrder int    `xorm:"notnull 'role_order'"`       // 显示顺序
	Available bool   `xorm:"default(true) 'available'"`  // 角色是否可用
	Menu      string `xorm:"'menu'"`                     // 可用菜单
	Remark    string `xorm:"'remark'"`                   // 备注
	IsClient  bool   `xorm:"'is_client'"`                // 是否为客户角色
	IsSuper   bool   `xorm:"'is_super'"`                 // 是否为超级权限角色
}

func (Role) TableName() string {
	return "a_role"
}

func (Role) TableNameCH() string {
	return "角色表"
}
