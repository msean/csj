package models

type Crontab struct {
	Bean    `xorm:"extends" xlsx:"-"`
	JobName string `xorm:"'job_name' varchar(128) comment('任务简称')" json:"job_name" xlsx:"任务简称"`
	Spec    string `xorm:"'spec' varchar(128) comment('时间格式')" json:"spec" xlsx:"时间格式"`
	Type    int    `xorm:"'type'" json:"type" xlsx:"任务分组"`                                // 系统 默认
	Status  int    `xorm:"'status' varchar(128) comment('时间格式')" json:"status" xlsx:"状态"` // 1 开 2 关
}

type CrontabLog struct {
	Bean      `xorm:"extends" xlsx:"-"`
	CrontabID int64  `xorm:"'crontab_id' varchar(128) comment('任务调度id')" json:"crontab_id" xlsx:"任务调度id"`
	Log       string `xorm:"'log' text comment('日志信息')" json:"info" xlsx:"日志信息"`
}

func (Crontab) TableName() string {
	return "xj_crontab_job"
}

func (CrontabLog) TableName() string {
	return "xj_crontab_log"
}
