package models

type TemplateDescription struct {
	ID          int64  `xorm:"'id' pk autoincr" json:"id"`
	Template    string `xorm:"'template'" json:"template"`
	Description string `xorm:"'desc'" json:"remark"`
}

func (TemplateDescription) TableName() string { return "xj_template_description" }
