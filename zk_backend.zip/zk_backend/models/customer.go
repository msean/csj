package models

import "fmt"

type (
	Customer struct {
		Bean    `xorm:"extends"`
		UserID  int64  `xorm:"'user_id' unique notnull" json:"user_id"` // 用户ID
		Account string `xorm:"'account' index notnull" json:"account"`  // 账号
		Name    string `xorm:"'name' varchar(60)" json:"name"`          // 名称
		// Password          string  `xorm:"'password'" json:"password"`                             // 密码
		// Email             string  `xorm:"'email'" json:"email"`                                   // 邮箱
		// PhoneNumber       string  `xorm:"'phone_number'" json:"phone_number"`                     // 手机号
		Ip     string `xorm:"'ip'" json:"ip"`           // ip
		ApiKey string `xorm:"'api_key'" json:"api_key"` // 密钥
		// IPWhitelist       string  `xorm:"'ip_whitelist'" json:"ip_whitelist"`                     // IP白名单(0.0.0.0;127.0.0.1)
		Extra             string  `xorm:"'extra'" json:"extra"`                                   // 备用
		Detail            string  `xorm:"'detail'" json:"detail"`                                 // 详情
		ShortName         string  `xorm:"'short_name' varchar(60)" json:"short_name"`             // 简称
		CallbackType      uint8   `xorm:"callback_type" json:"callback_type"`                     // 回调方式
		MaxOrder          uint    `xorm:"'max_order'" json:"max_order"`                           // 接单阈值
		MaxPendingOrder   uint    `xorm:"'max_pending_order'" json:"max_pending_order"`           // 卡单阈值
		RepeatTimeout     uint    `xorm:"repeat_timeout" json:"repeat_timeout"`                   // 重复号码屏蔽时间
		Balance           float64 `xorm:"'balance' DECIMAL(15,4)" json:"balance"`                 // 实际余额
		TotalBalance      float64 `xorm:"'total_balance' DECIMAL(15,4)" json:"total_balance"`     // 余额
		RechargeAmount    float64 `xorm:"'recharge_amount' DECIMAL(15,4)" json:"recharge_amount"` // 充值金额
		PayAmount         float64 `xorm:"'pay_amount' DECIMAL(15,4)" json:"pay_amount"`           // 实际支付金额（折扣后的充值金额）
		Credit            float64 `xorm:"'credit' DECIMAL(15,4)" json:"credit"`                   // 授信
		WarnBalance       float32 `xorm:"'warn_balance' DECIMAL(15,4)" json:"warn_balance"`       // 预警余额
		Timeout           uint    `xorm:"'timeout' default 600" json:"timeout"`                   // 超时时间
		SlowTimeout       uint    `xorm:"'slow_timeout' default 4320" json:"slow_timeout"`        // 慢充超时时间
		SlowRechargeFlag  bool    `xorm:"'slow_recharge_flag'" json:"slow_recharge_flag"`         // 慢充开关
		SlowCycleFlag     bool    `xorm:"'slow_cycle_flag'" json:"slow_cycle_flag"`               // 慢充循环开关
		AllProductFlag    bool    `xorm:"'all_product_flag'" json:"all_product_flag"`             // 查询全部产品编码
		OperatorQueryFlag bool    `xorm:"'operator_query_flag'" json:"operator_query_flag"`       // 运营商查询开关
		SwitchCheckFlag   bool    `xorm:"'switch_check_flag'" json:"switch_check_flag"`           // 携号转网检测开关
		AreaFlag          bool    `xorm:"'area_flag'" json:"area_flag"`                           // 区域维护开关
		ApiFlag           bool    `xorm:"'api_flag' default 1" json:"api_flag"`                   // 接口开关
		RechargeFlag      bool    `xorm:"'recharge_flag' default 1" json:"recharge_flag"`         // 充值开关
		Available         bool    `xorm:"available" json:"available"`                             // 是否可用

		Etcone string `xorm:"'etc_one' varchar(1000) " json:"etc_one"` // todo: ?????
		Etctwo string `xorm:"'etc_two' varchar(1000) " json:"etc_two"` // todo: ?????
		Etcthr string `xorm:"'etc_thr' varchar(1000) " json:"etc_thr"` // todo: ?????
	}

	CustomerProduct struct {
		Bean             `xorm:"extends"`
		CustomerID       int64   `xorm:"'customer_id' index(customer_code) unique(customer_code)" json:"customer_id"` // 客户ID
		CustomerName     string  `xorm:"'customer_name'" json:"customer_name"`                                        // 客户名
		Name             string  `xorm:"'name' varchar(60)" json:"name"`                                              // 名称
		CalType          uint8   `xorm:"'cal_type'" json:"cal_type"`                                                  // 计算方式
		CalValue         float64 `xorm:"'cal_value'" json:"cal_value"`                                                // 计算金额
		Cert             uint8   `xorm:"'cert'" json:"cert"`                                                          // 凭证
		SalePrice        float64 `xorm:"'sale_price' DECIMAL(15,4)" json:"sale_price"`                                // 实际售价
		BackMoney        float64 `xorm:"'back_money' DECIMAL(15,4)" json:"back_money"`                                // 后返
		Discount         float64 `xorm:"'discount'" json:"discount"`                                                  // 折扣（百分比）
		ChannelGroupID   int64   `xorm:"'channel_group_id'" json:"channel_group_id"`                                  // 渠道组ID
		ChannelIds       []int64 `xorm:"'channel_ids'" json:"channel_ids"`                                            // 渠道ID
		FirstChannelIds  []int64 `xorm:"'first_channel_ids'" json:"first_channel_ids"`                                // 先走渠道列表
		SecondChannelIds []int64 `xorm:"'second_channel_ids'" json:"second_channel_ids"`                              // 后走渠道列表
		ForbidChannelIds []int64 `xorm:"'forbid_channel_ids'" json:"forbid_channel_ids"`                              // 禁止渠道列表
		TaxType          uint8   `xorm:"'tax_type'" json:"tax_type"`                                                  // 含税类型
		Available        bool    `xorm:"'available' default 1" json:"available"`                                      // 开关
		AvailableTick    int64   `xorm:"'available_tick' default 0" json:"available_tick"`                            // 产品生效时间(0-立即生效)

		Code           int64   `xorm:"'code' index(customer_code) unique(customer_code) " json:"code"` // 编码ID（Product-BaseID）
		ProductCode    string  `xorm:"'product_code'" json:"product_code"`                             // 基础产品-编码（Product-Code）
		ProductPrice   float64 `xorm:"'product_price'" json:"product_price"`                           // 基础产品-原价（Product-Price）
		ProductValue   int     `xorm:"'product_value'" json:"product_value"`                           // 基础产品-面值（Product-FaceValue）
		ProductArea    uint    `xorm:"'product_area'" json:"product_area"`                             // 基础产品-地区（Product-Area）
		ProductType    uint    `xorm:"'product_type'" json:"product_type"`                             // 基础产品-类型-大类（Product-BigType）
		ProductSubType uint    `xorm:"'product_sub_type'" json:"product_sub_type"`                     // 基础产品-类型-小类（Product-SmallType）
		ProductIsp     uint    `xorm:"'product_isp'" json:"product_isp"`                               // 基础产品-运营商（Product-Isp）
	}

	CustomerFinance struct {
		Bean          `xorm:"extends"`
		CustomerID    int64   `xorm:"'customer_id' index" json:"customer_id"`     // 客户ID
		CustomerName  string  `xorm:"-" json:"customer_name"`                     // 客户名
		OrderID       string  `xorm:"'order_id' index"  json:"order_id"`          // 订单号
		CustomerOrder string  `xorm:"'customer_order'" json:"customer_order"`     // 客户订单号/加款人(暂时忽略)
		BusinessType  uint8   `xorm:"'business_type' index" json:"business_type"` // 业务类型
		Amount        float64 `xorm:"'amount' DECIMAL(15,4)" json:"amount"`       // 操作金额
		Balance       float64 `xorm:"'balance'" json:"balance"`                   // 当前余额
		TotalBalance  float64 `xorm:"'total_balance'" json:"total_balance"`       // 实际余额
		Bank          string  `xorm:"'bank'" json:"bank"`                         // 银行
		Remark        string  `xorm:"'remark'" json:"remark"`                     // 备注
		Finish        uint8   `xorm:"'finish'" json:"finish"`                     // 扣款是否是否成功
	}

	CustomerUser struct {
		Customer `xorm:"extends"`
		User     `xorm:"extends"`
	}
)

func (Customer) TableName() string {
	return "xj_customer"
}

func (Customer) TableNameCH() string {
	return "客户表"
}

func (CustomerProduct) TableName() string {
	return "xj_customer_product"
}

func (CustomerProduct) TableNameCH() string {
	return "客户产品表"
}

func (CustomerFinance) TableName() string {
	return "xj_customer_finance"
}

func (CustomerFinance) TableNameCH() string {
	return "客户财务表"
}

func (CustomerUser) TableName() string {
	return "xj_customer"
}

func (CustomerFinance) AddIndex() string {
	return "xj_customer"
}

func (finance CustomerFinance) DropIndex() string {
	return fmt.Sprintf(`DROP INDEX xj_customer_finance ON %s;`, finance.TableName())
}
