package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"errors"
)

type RoleDao struct {
}

func NewDaoRole() *RoleDao {
	return &RoleDao{}
}

func (m *RoleDao) InsertBean(by int64, bean *models.Role) error {
	s := daos.Mysql.NewSession()
	defer s.Close()

	models.Add(by, &bean.Bean)
	_, err := s.Insert(bean)
	if err != nil {
		return err
	}

	return nil
}

func (m *RoleDao) UpdateBean(by int64, bean *models.Role) error {
	s := daos.Mysql.NewSession()
	defer s.Close()

	models.Edit(by, &bean.Bean)
	_, err := s.ID(bean.ID).AllCols().Update(bean)
	if err != nil {
		return err
	}

	return nil
}

func (m *RoleDao) GetBeanById(id int64) (*models.Role, error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	bean := &models.Role{}
	has, err := s.ID(id).Get(bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return bean, nil
}

func (m *RoleDao) FindBeanByNameOrOrder(name string, order int) (*models.Role, error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	res := make([]*models.Role, 0)
	err := s.Where("role_name = ? or role_order = ?", name, order).Find(&res)
	if err != nil {
		return nil, err
	}

	if len(res) <= 0 {
		return nil, nil
	}

	return res[0], nil
}

func (m *RoleDao) DeleteBeanByIds(ids []int64) (int64, error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	count, err := s.In("id", ids).Unscoped().Delete(&models.Role{})
	if err != nil {
		return 0, err
	}

	return count, err
}

func (m *RoleDao) QuerySuperRole() (*models.Role, error) {
	res := make([]*models.Role, 0)

	session := daos.Mysql.NewSession()
	defer session.Close()

	err := session.Where("is_super = ?", true).Find(&res)
	if err != nil {
		return nil, err
	}

	if len(res) <= 0 {
		return nil, nil
	}

	return res[0], nil
}

func (m *RoleDao) QueryRole(params vo.RoleQueryParam) (int64, []*models.Role, error) {

	db := daos.Mysql.NewSession()
	defer db.Close()

	db = db.Where("is_super = ?", false)
	if params.Base.PageSize > 0 {
		db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	}

	if params.RoleName != "" {
		db = db.Where("role_name like ?", "%"+params.RoleName+"%")
	}

	if params.Available >= 0 {
		db = db.Where("available = ?", params.Available)
	}

	if params.Base.StartTime != "" {
		db = db.Where("created >= ?", params.Base.StartTime)
	}

	if params.Base.EndTime != "" {
		db = db.Where("created <= ?", params.Base.EndTime)
	}

	if params.ReverseSort {
		db = db.OrderBy("id desc")
	}

	if params.OrderSort >= 0 {
		if params.OrderSort == 0 {
			db = db.OrderBy("role_order desc")
		} else {
			db = db.OrderBy("role_order")
		}
	}

	res := make([]*models.Role, 0)
	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}

func (m *RoleDao) FindRoleByIds(ids []int64, visible bool) ([]*models.Role, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	list := make([]*models.Role, 0)
	if ids != nil {
		db.Where("id in ?", ids)
	}

	if visible {
		db.Where("available = ?", visible)
	}

	err := db.Find(&list)
	if err != nil {
		return nil, err
	}

	return list, nil
}

func (m *RoleDao) FindClientRole() (*models.Role, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	res := make([]*models.Role, 0)
	err := db.Where("is_client = ?", true).Limit(1).Find(&res)
	if err != nil {
		return nil, err
	}

	if len(res) == 0 {
		return nil, errors.New("can't find client role")
	}

	return res[0], nil
}

/*
func (m *RoleDao) DeleteBeanById(id int64) error {
	_, err := daos.Mysql.ID(id).Delete(&models.Role{})
	return err
}

func (m *RoleDao) FindRoleIdsByUserId(userId int64) (list []int64) {
	sql := `
			SELECT
			r.id as id
		FROM
			a_user AS u,
			a_role AS r,
			a_user_role AS ur
		WHERE
			u.status = "0"
			AND r.status = "0"
			AND ur.user_id = u.id
			AND ur.role_id = r.id
			and u.id = %d
`
	sql = fmt.Sprintf(sql, userId)
	v, err := daos.Mysql.QueryString(sql)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("FindRoleIdsByUserId 失败 [%d]", userId), zap.Error(err))
		return
	}
	list = make([]int64, 0)
	for _, m := range v {
		id := m["id"]
		atoi, err := strconv.Atoi(id)
		if err != nil {
			continue
		}
		list = append(list, int64(atoi))
	}
	return
}

func (m *RoleDao) FindRoleIdsByRoleId(roleId int64) (list []int64) {
	sql := `
			SELECT
			r.id as id
		FROM
			a_user AS u,
			a_role AS r,
			a_user_role AS ur
		WHERE
			u.status = "0"
			AND r.status = "0"
			AND ur.user_id = u.id
			AND ur.role_id = r.id
			and r.id = %d
`
	sql = fmt.Sprintf(sql, roleId)
	v, err := daos.Mysql.QueryString(sql)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("FindRoleIdsByRoleId failed, [%d]", roleId), zap.Error(err))
		return
	}
	list = make([]int64, 0)
	for _, m := range v {
		id := m["id"]
		atoi, err := strconv.Atoi(id)
		if err != nil {
			continue
		}
		list = append(list, int64(atoi))
	}
	return
}

func (m *RoleDao) DeleteUserRoleByUserId(userId int64) {
	daos.Mysql.Where("user_id = ?", userId).Delete(&models.UserRole{})
}

func (m *RoleDao) DeleteUserRoleByRoleId(userId int64) {
	daos.Mysql.Where("role_id = ?", userId).Delete(&models.UserRole{})
}

func (m *RoleDao) InsertUserRole(userRole *models.UserRole) error {
	count, err := daos.Mysql.Insert(userRole)
	if err != nil {
		return err
	}
	if 0 == count {
		return errors.New("新增0条")
	}
	return nil
}*/
