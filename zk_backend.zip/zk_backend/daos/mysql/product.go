package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
)

type ProductDao struct {
}

func NewProductDao() *ProductDao {
	return &ProductDao{}
}

func (dao *ProductDao) FromCode(code string) (product models.Product, has bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.NewWhereCond("code", code).Cond(session).Get(&product)
	return
}

func (dao *ProductDao) FromIDlist(idList []int64) (products []models.Product, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	err = utils.Find(session, &products, utils.NewInCond("id", idList))
	return
}

func (dao *ProductDao) List(params vo.ProductListParams) (products []models.Product, total int64, err error) {
	products = make([]models.Product, 0)
	conds := []utils.Cond{}

	if !utils.IsBlankString(params.CodeSearch) {
		conds = append(conds, utils.NewWhereCond("code", params.CodeSearch))
	}
	if params.BigTypeSearch != 0 {
		conds = append(conds, utils.NewWhereCond("big_type", params.BigTypeSearch))
	}
	if params.SmallTypeSearch != 0 {
		conds = append(conds, utils.NewWhereCond("small_type", params.SmallTypeSearch))
	}
	if params.NameSearch != "" {
		conds = append(conds, utils.NewWhereLikeCond("name", params.NameSearch, utils.LikeTypeBetween))
	}
	if params.FaceValueLower != 0 || params.FaceValueUpper != 0 {
		conds = append(conds,
			utils.NewCmpCond("face_value", "<=", params.FaceValueUpper),
			utils.NewCmpCond("face_value", ">=", params.FaceValueLower),
		)
	}
	if len(params.IspSearch) > 0 {
		_s := utils.RemoveIntSliceElement(params.IspSearch, 0)
		if len(_s) > 0 {
			conds = append(conds, utils.NewInCond("isp", _s))
		}
	}

	if len(params.AreaSearch) > 0 {
		_s := utils.RemoveIntSliceElement(params.AreaSearch, -1)
		if len(_s) > 0 {
			conds = append(conds, utils.NewInCond("area", _s))
		}
	}
	if params.OrderBy != "" {
		conds = append(conds, utils.NewOrderByCond(params.OrderBy))
	}

	if params.StatusChoice != 0 {
		conds = append(conds, utils.NewWhereCond("online", params.StatusChoice))
	}

	tl, pl := utils.MutateLimitCond(params.Base)
	conds = append(conds, tl)

	session := daos.Mysql.NewSession()
	defer session.Close()

	if !params.WithNoCount {
		if total, err = utils.TotalByConds(session, new(models.Product), conds...); err != nil {
			return
		}
	}

	conds = append(conds, pl)
	err = utils.Find(session, &products, conds...)
	return
}

func (dao *ProductDao) FromCodes(codes []string) (productMap map[string]models.Product, err error) {
	productMap = make(map[string]models.Product)
	var products []models.Product

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &products, utils.NewInCond("code", codes)); err != nil {
		return
	}
	for _, product := range products {
		productMap[product.Code] = product
	}
	return
}

func (dao *ProductDao) GetBeanById(id int64) (*models.Product, error) {
	bean := models.Product{}
	has, err := daos.Mysql.ID(id).Get(&bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return &bean, nil
}

func (dao *ProductDao) CheckField(field, value string) (has bool, err error) {
	var product models.Product

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.Get(session, &product, utils.NewWhereCond(field, value))
	return
}
