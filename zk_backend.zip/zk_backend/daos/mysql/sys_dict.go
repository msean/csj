package mysql

import (
	"application/common/logger"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"fmt"

	"github.com/go-xorm/xorm"
	"go.uber.org/zap"
)

type (
	SysDictDao struct {
	}
)

func NewSysDictDao() *SysDictDao {
	return &SysDictDao{}
}

func (dao *SysDictDao) DataByType(typ string) (objs []models.SysDictData, err error) {
	var sysDictType models.SysDictType
	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.Get(session, &sysDictType, utils.NewWhereCond("dict_type", typ))
	if err != nil {
		return
	}
	if !has {
		err = fmt.Errorf("该类型不存在")
		return
	}
	err = utils.Find(session, &objs, utils.NewWhereCond("type_id", sysDictType.ID))
	return
}

func (dao *SysDictDao) TypeDataMap(typeIDList []int64) (_m map[int64][]models.SysDictData, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var dictDatas []models.SysDictData
	_m = make(map[int64][]models.SysDictData, 0)
	if err = utils.Find(session, &dictDatas, utils.NewInCond("type_id", typeIDList)); err != nil {
		return
	}
	for _, dictData := range dictDatas {
		_m[dictData.TypeID] = append(_m[dictData.TypeID], dictData)
	}
	return
}

// TypesDataMap
// dataM
func (dao *SysDictDao) TypesDataMap(types ...string) (dataM map[string]map[string]models.SysDictData, err error) {
	var dictTypeList []models.SysDictType

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &dictTypeList, utils.NewInCond("dict_type", types)); err != nil {
		return
	}

	dictTypeIDM := make(map[int64]string)
	dictTypeIDList := []int64{}
	for _, dictType := range dictTypeList {
		dictTypeIDList = append(dictTypeIDList, dictType.ID)
		dictTypeIDM[dictType.ID] = dictType.Type
	}

	dataM = make(map[string]map[string]models.SysDictData)
	var dictDatas []models.SysDictData

	if err = utils.Find(session, &dictDatas, utils.NewInCond("type_id", dictTypeIDList)); err != nil {
		return
	}

	for _, obj := range dictDatas {
		// dataM[dictTypeIDM[obj.ID]][obj.Value] = obj
		if _, ok := dataM[dictTypeIDM[obj.TypeID]]; ok {
			dataM[dictTypeIDM[obj.TypeID]][obj.Value] = obj
		} else {
			dataM[dictTypeIDM[obj.TypeID]] = map[string]models.SysDictData{
				obj.Value: obj,
			}
		}
	}
	return
}

func (dao *SysDictDao) ListType(params vo.SysDictTypeListParams) (objs []*models.SysDictType, total int64, err error) {
	objs = make([]*models.SysDictType, 0)
	conds := []utils.Cond{}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if !utils.IsBlankString(params.NameSearch) {
		conds = append(conds, utils.NewWhereLikeCond("dict_name", params.NameSearch, utils.LikeTypeBetween))
	}
	if !utils.IsBlankString(params.TypeSearch) {
		conds = append(conds, utils.NewWhereLikeCond("dict_type", params.TypeSearch, utils.LikeTypeBetween))
	}
	if params.StatusChoice != 0 {
		conds = append(conds, utils.NewWhereCond("status", params.StatusChoice))
	}

	if len(params.IDList) != 0 {
		conds = append(conds, utils.NewInCond("id", params.IDList))
	}

	timeLimit, pageLimit := utils.MutateLimitCond(params.Base)
	conds = append(conds, timeLimit)
	total, err = utils.TotalByConds(session, new(models.SysDictType), conds...)
	if err != nil {
		return
	}

	conds = append(conds, pageLimit)
	err = utils.Find(session, &objs, conds...)
	return
}

func (dao *SysDictDao) ListTypeData(params vo.SysDictDataListParams) (objs []models.SysDictData, total int64, err error) {
	objs = make([]models.SysDictData, 0)
	conds := []utils.Cond{}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if !utils.IsBlankString(params.LabelSearch) {
		conds = append(conds, utils.NewWhereCond("dict_label", params.LabelSearch))
	}
	if !utils.IsBlankString(params.NameSearch) {
		var sysDictType models.SysDictType
		if _, err = utils.NewWhereCond("dict_type", params.NameSearch).Cond(session).Get(&sysDictType); err != nil {
			return
		}
		conds = append(conds, utils.NewWhereCond("type_id", sysDictType.ID))
	}

	if len(params.IDList) != 0 {
		conds = append(conds, utils.NewInCond("id", params.IDList))
	}

	if params.StatusChoice != 0 {
		conds = append(conds, utils.NewWhereCond("status", params.StatusChoice))
	}

	timeLimit, pageLimit := utils.MutateLimitCond(params.Base)
	conds = append(conds, timeLimit)
	if total, err = utils.TotalByConds(session, new(models.SysDictData), conds...); err != nil {
		return
	}

	conds = append(conds, pageLimit)
	err = utils.Find(session, &objs, conds...)
	return
}

// DataValueLabelMapper map[dict_type][dict_value][dict_label]
func (dao *SysDictDao) DataValueLabelMapper() (_m map[string]map[string]string) {
	_m = make(map[string]map[string]string)
	var dictTypeList []models.SysDictType
	var err error

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &dictTypeList); err != nil {
		return
	}

	dictTypeIDM := make(map[int64]string)
	for _, dictType := range dictTypeList {
		dictTypeIDM[dictType.ID] = dictType.Type
	}

	var dictDatas []models.SysDictData
	if err = utils.Find(session, &dictDatas); err != nil {
		return
	}
	for _, obj := range dictDatas {
		if typeDataM, ok := _m[dictTypeIDM[obj.TypeID]]; ok {
			typeDataM[obj.Value] = obj.Label
		} else {
			_m[dictTypeIDM[obj.TypeID]] = map[string]string{
				obj.Value: obj.Label,
			}
		}
	}
	return
}

func (dao *SysDictDao) DataByTypeAndValue(dictType string, value int64) (object models.SysDictData, has bool, err error) {
	var sysDictType models.SysDictType

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.NewWhereCond("dict_type", dictType).Cond(session).Get(&sysDictType)
	if !has {
		err = fmt.Errorf("type not found")
	}
	if err != nil {
		return
	}
	has, err = utils.Get(session, &object, utils.NewWhereCond("type_id", sysDictType.ID), utils.NewWhereCond("dict_value", value))
	return
}

func (dao *SysDictDao) DataByTypeLabel(dictType, label string) (object models.SysDictData, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [DataByType]", zap.String("dictType", dictType), zap.Error(err))
		}
	}()
	var objects []models.SysDictData
	if objects, err = dao.DataByType(dictType); err != nil {
		return
	}

	for _, _object := range objects {
		if _object.Label == label {
			object = _object
			return
		}
	}

	return
}

func CreateDictTypeWithData(session *xorm.Session, dictType models.SysDictType) error {
	defer session.Close()

	if err := session.Begin(); err != nil {
		return err
	}

	existingDictType := models.SysDictType{}
	has, err := session.Where("dict_type = ?", dictType.Type).Get(&existingDictType)
	if err != nil {
		session.Rollback()
		return err
	}

	if !has {
		if _, err := session.Insert(&dictType); err != nil {
			session.Rollback()
			return err
		}
	} else {
		dictType.ID = existingDictType.ID
	}

	for _, data := range dictType.Data {
		existingData := models.SysDictData{}
		hasData, err := session.Where("dict_label = ? AND type_id = ?", data.Label, dictType.ID).Get(&existingData)
		if err != nil {
			session.Rollback()
			return err
		}

		if !hasData {
			data.TypeID = dictType.ID
			if _, err := session.Insert(&data); err != nil {
				session.Rollback()
				return err
			}
		}
	}

	return session.Commit()
}
