package mysql

import (
	"application/models"

	"github.com/go-xorm/xorm"
)

type (
	OrderDao struct{}
	// OrderStuckInfo struct {
	// 	Type             int // 1 订单  2 渠道订单
	// 	OrderID          int64
	// 	ChannelID        int64
	// 	CustomerID       int64
	// 	CurrentStatus    int
	// 	OrderTime        time.Time
	// 	ChannelOrderTime time.Time
	// 	ChannelOrderID   int64
	// }
)

func NewOrderDao() *OrderDao {
	return &OrderDao{}
}

// func (dao *OrderDao) List(params vo.OrderListParam) (orders []models.Order, total int64, err error) {
// 	conds := []utils.Cond{}

// 	if params.CustomerChoice != 0 {
// 		conds = append(conds, utils.NewWhereCond("customer_id", params.CustomerChoice))
// 	}
// 	if params.CurrentChannelChoice != 0 {
// 		conds = append(conds, utils.NewWhereCond("current_channel_id", params.CurrentChannelChoice))
// 	}
// 	if !utils.IsBlankString(params.CustomerOrderSearch) {
// 		conds = append(conds, utils.NewWhereLikeCond("customer_order_id", params.CustomerOrderSearch, utils.LikeTypeBetween))
// 	}
// 	if !utils.IsBlankString(params.OrderIDSearch) {
// 		conds = append(conds, utils.NewWhereLikeCond("id", params.OrderIDSearch, utils.LikeTypeBetween))
// 	}
// 	if !utils.IsBlankString(params.PhoneSearch) {
// 		conds = append(conds, utils.NewWhereLikeCond("phone", params.PhoneSearch, utils.LikeTypeBetween))
// 	}
// 	if params.BigTypeSearch != 0 {
// 		conds = append(conds, utils.NewWhereCond("big_type", params.BigTypeSearch))
// 	}
// 	if params.SmallTypeSearch != 0 {
// 		conds = append(conds, utils.NewWhereCond("small_type", params.SmallTypeSearch))
// 	}
// 	if params.IspSearch != 0 {
// 		conds = append(conds, utils.NewWhereCond("isp", params.IspSearch))
// 	}
// 	if params.FaceValueLower > 0 {
// 		conds = append(conds, utils.NewCmpCond("face_value", ">=", params.FaceValueLower))
// 	}
// 	if params.FaceValueUpper > 0 {
// 		conds = append(conds, utils.NewCmpCond("face_value", "<=", params.FaceValueUpper))
// 	}
// 	if params.AreaChoice >= 0 {
// 		areaCode := constant.AreaCodeStringM[params.AreaChoice]
// 		if !utils.IsBlankString(areaCode) {
// 			conds = append(conds, utils.NewWhereCond("area", areaCode))
// 		}
// 	}
// 	if !utils.IsBlankString(params.RemarkSearch) {
// 		conds = append(conds, utils.NewWhereLikeCond("remark", params.RemarkSearch, utils.LikeTypeBetween))
// 	}
// 	if !utils.IsBlankString(params.ManualRemarkSearch) {
// 		conds = append(conds, utils.NewWhereLikeCond("manual_remark", params.RemarkSearch, utils.LikeTypeBetween))
// 	}
// 	if params.StatusChoice != 0 {
// 		if params.StatusChoice == constant.OrderStatusNoResult {
// 			inStatus := []int{
// 				constant.OrderStatusInit,
// 				constant.OrderStatusHandle,
// 				constant.OrderStatusSuspect,
// 			}
// 			conds = append(conds, utils.NewInCond("status", inStatus))
// 		} else {
// 			conds = append(conds, utils.NewWhereCond("status", params.StatusChoice))
// 		}
// 	}
// 	if params.BackStatusChoice != 0 {
// 		conds = append(conds, utils.NewWhereCond("current_back_status", params.BackStatusChoice))
// 	}
// 	if !params.BackTimeStart.IsZero() {
// 		conds = append(conds, utils.NewCmpCond("back_time", ">=", params.BackTimeStart))
// 	}
// 	if !params.BackTimeEnd.IsZero() {
// 		conds = append(conds, utils.NewCmpCond("back_time", "<=", params.BackTimeEnd))
// 	}
// 	if params.IsSlowChoice != 0 {
// 		conds = append(conds, utils.NewWhereCond("is_slow", params.IsSlowChoice))
// 		// 慢充订单只显示初始化和处理中的订单
// 		inStatus := []int{
// 			constant.OrderStatusInit,
// 			constant.OrderStatusHandle,
// 		}
// 		conds = append(conds, utils.NewInCond("status", inStatus))
// 	}
// 	if len(params.IDList) != 0 {
// 		conds = append(conds, utils.NewInCond("id", params.IDList))
// 	}

// 	tl, pl := utils.MutateLimitCond(params.Base)
// 	conds = append(conds, tl)

// 	session := daos.Mysql.NewSession()
// 	defer session.Close()

// 	if !params.NoWithCount {
// 		if total, err = utils.TotalByConds(session, new(models.Order), conds...); err != nil {
// 			return
// 		}
// 	}

// 	conds = append(conds, pl, utils.NewOrderByCond("created desc"))
// 	err = utils.Find(session, &orders, conds...)
// 	return
// }

// select clientid,comid,count(*) num,status from xj_order
// 		where inittime between DATE_SUB(NOW(),INTERVAL IFNULL(${hour},48) HOUR)
// 		and DATE_SUB(NOW(),INTERVAL IFNULL(${second},0) SECOND)
// 		and status &lt; 10
// 		GROUP BY status,clientid,comid order by num desc

// func (dao *OrderDao) CustomerStuckQry(session *xorm.Session, statuses ...int) (orderStuckList []models.OrderStuckInfo, err error) {

// 	end := time.Now().Add(-48 * time.Hour)
// 	start := time.Now().AddDate(0, -2, 0)
// 	var orders []models.Order
// 	orders, _, _ = OrderPartition.List(vo.OrderListParam{
// 		Base: utils.LimitCond{
// 			StartTime: start,
// 			EndTime:   end,
// 		},
// 		InStatusChoice: statuses,
// 		NoWithCount:    true,
// 	})
// 	for _, order := range orders {
// 		orderStuckList = append(orderStuckList, models.OrderStuckInfo{
// 			Type:          1,
// 			OrderID:       order.ID,
// 			CustomerID:    order.CustomerID,
// 			CurrentStatus: int(order.Status),
// 			OrderTime:     order.Created,
// 		})
// 	}
// 	return
// }

// select channelid,comid,count(*) num,status from xj_channelorder
// 		where inittime between DATE_SUB(NOW(),INTERVAL IFNULL(${hour},48) HOUR)
// 		and DATE_SUB(NOW(),INTERVAL IFNULL(${second},0) SECOND)
// 		and status &lt; 10
// 		GROUP BY status,channelid,comid
// 		UNION
// 		select channelid,comid,count(*) num,status from xj_channelorder
// 		where finishtime between DATE_SUB(NOW(),INTERVAL IFNULL(${minute},2) MINUTE)
// 		and DATE_SUB(NOW(),INTERVAL 0 SECOND)
// 		and status = 11
// 		GROUP BY status,channelid,comid  order by num desc

// func (dao *OrderDao) ChannelStuckQry(session *xorm.Session, statuses ...int) (orderStuckList []models.OrderStuckInfo, err error) {
// 	start := time.Now().Add(-48 * time.Hour)
// 	end := time.Now().AddDate(0, -2, 0)
// 	var channelOrders []models.ChannelOrder
// 	// 执行查询
// 	if err = utils.Find(session, &channelOrders, utils.NewCmpCond("created", "<=", start), utils.NewCmpCond("created", ">=", end), utils.NewInCond("status", statuses)); err != nil {
// 		return
// 	}
// 	for _, order := range channelOrders {
// 		orderStuckList = append(orderStuckList, models.OrderStuckInfo{
// 			OrderID:          order.OrderID,
// 			CustomerID:       order.CustomerID,
// 			CurrentStatus:    int(order.Status),
// 			OrderTime:        order.OrderTime,
// 			ChannelOrderTime: order.Created,
// 			ChannelID:        order.ChannelID,
// 			ChannelOrderID:   order.ID,
// 			Type:             2,
// 		})
// 	}

// 	return
// }

// func (dao *OrderDao) UpdateReturn(session *xorm.Session, IDList []int64) (affect int64, err error) {

// 	conds := []utils.Cond{
// 		utils.NewInCond("id", IDList),
// 		utils.NewWhereCond("has_returned", 1),
// 		utils.NewWhereCond("is_slow", 2),
// 	}

// 	return utils.Update(session.Table(models.Order{}.TableName()), map[string]any{"has_returned": 2}, conds...)
// }

// func (dao *OrderDao) UpdateCurrentChannel(session *xorm.Session, orderID int64, channelID int64, inPrice float64) (err error) {
// 	_, err = utils.Update(session.Table(models.Order{}.TableName()), map[string]any{
// 		"current_channel_id": channelID,
// 		"status":             constant.OrderStatusHandle,
// 		"in_price":           inPrice,
// 	}, utils.NewInCond("id", orderID))
// 	return
// }

// func (dao *OrderDao) UpdateIsp(session *xorm.Session, id int64, isp int) (err error) {
// 	conds := []utils.Cond{
// 		utils.IDCond(id),
// 		utils.NewWhereCond("status", 1),
// 	}
// 	_, err = utils.Update(session.Table(models.Order{}.TableName()), map[string]interface{}{"isp": isp}, conds...)
// 	return
// }

// func (dao *OrderDao) UpdateRemark(session *xorm.Session, id int64, manualRemark string) (err error) {
// 	var orderModel models.Order
// 	var has bool
// 	has, err = utils.IDCond(id).Cond(session.Table(models.Order{}.TableName())).Get(&orderModel)
// 	if !has {
// 		return errors.New("record not found")
// 	}

// 	if err != nil {
// 		return
// 	}
// 	_, err = utils.Update(session.Table(models.Order{}.TableName()), map[string]interface{}{"manual_remark": fmt.Sprintf("%s <%s>", manualRemark, time.Now().Format("06-01-02 15:04:05"))}, utils.IDCond(id))
// 	return
// }

// func (dao *OrderDao) ModifyStatus(session *xorm.Session, order models.Order, status int64, extra map[string]any) (err error) {
// 	updates := map[string]interface{}{
// 		"status": status,
// 	}

// 	if len(extra) != 0 {
// 		for k, v := range extra {
// 			value := v
// 			if k == "remark" {
// 				if utils.IsBlankString(order.Remark) {
// 					value = fmt.Sprintf("%s:%s", time.Now().Format("2006-01-02 15:04:05"), v)
// 				} else {
// 					value = fmt.Sprintf("%s;%s:%s", order.Remark, time.Now().Format("2006-01-02 15:04:05"), v)
// 				}

// 			}
// 			updates[k] = value
// 		}
// 	}

// 	_, err = utils.Update(session.Table(models.Order{}.TableName()), updates, utils.IDCond(order.ID))
// 	return
// }

// func (dao *OrderDao) FromID(session *xorm.Session, id int64) (order models.Order, has bool, err error) {
// 	has, err = utils.Get(session.Table(models.Order{}.TableName()), &order, utils.IDCond(id))
// 	return
// }

// func (dao *OrderDao) FromCustomerOrderID(session *xorm.Session, customerOrderID string) (order models.Order, has bool, err error) {
// 	has, err = utils.Get(session.Table(models.Order{}.TableName()), &order, utils.NewWhereCond("customer_order_id", customerOrderID))
// 	return
// }

func (dao *OrderDao) RecordChannelInfo(session *xorm.Session, orderChannel models.OrderChannelRecord) (err error) {
	_, err = session.Insert(&orderChannel)
	return
}

// func (dao *OrderDao) UpdateCallback(session *xorm.Session,
// 	order models.Order,
// 	channelOrder models.ChannelOrder,
// 	callbackStatus uint,
// 	callbackMsg string) (err error) {
// 	order.BackStatus = append(order.BackStatus, callbackStatus)
// 	order.BackMsg = append(order.BackMsg, callbackMsg)
// 	order.BackTime = append(order.BackTime, time.Now())
// 	order.CurrentBackStatus = callbackStatus
// 	order.CurrentBackTime = time.Now()

// 	// 将切片转换成 JSON 字符串
// 	backStatusJSON, _ := json.Marshal(order.BackStatus)
// 	backMsgJSON, _ := json.Marshal(order.BackMsg)
// 	backTimeJSON, _ := json.Marshal(order.BackTime)

// 	_, err = session.Table(models.Order{}.TableName()).Where("id = ?", order.ID).Update(map[string]any{
// 		"back_status":         string(backStatusJSON),
// 		"back_msg":            string(backMsgJSON),
// 		"back_time":           string(backTimeJSON),
// 		"current_back_status": callbackStatus,
// 		"current_back_time":   order.CurrentBackTime,
// 	})

// 	if channelOrder.ID != 0 {
// 		channelOrder.BackStatus = append(channelOrder.BackStatus, callbackStatus)
// 		channelOrder.BackMsg = append(channelOrder.BackMsg, callbackMsg)
// 		channelOrder.BackTime = append(channelOrder.BackTime, time.Now())
// 		channelOrder.CurrentBackStatus = callbackStatus
// 		channelOrder.CurrentBackTime = time.Now()

// 		_, err = session.Table(models.ChannelOrder{}.TableName()).Where("id = ?", channelOrder.ID).Update(map[string]any{
// 			"back_status":         string(backStatusJSON),
// 			"back_msg":            string(backMsgJSON),
// 			"back_time":           string(backTimeJSON),
// 			"current_back_status": callbackStatus,
// 			"current_back_time":   channelOrder.CurrentBackTime,
// 		})
// 	}
// 	return
// }

// func (dao *OrderDao) Create(session *xorm.Session, order *models.Order) (affect int64, err error) {
// 	return utils.Create(session, order)
// }

// func (dao *OrderDao) GetPhoneLatest(phone string) (order models.Order, has bool, err error) {

// 	session := daos.Mysql.NewSession()
// 	defer session.Close()

// 	has, err = utils.Get(session, &order, utils.NewWhereCond("phone", phone), utils.NewOrderByCond("created desc"))
// 	return
// }

// func (dao *OrderDao) ReplaceProductCode(productCode string,
// 	orderID int64,
// 	province,
// 	area string) (err error) {

// 	session := daos.Mysql.NewSession()
// 	defer session.Close()

// 	_, err = utils.Update(session.Table(models.Order{}.TableName()), map[string]any{
// 		"product_code": productCode,
// 		"area":         area,
// 		"province":     province,
// 	}, utils.IDCond(orderID))
// 	return
// }

// func (dao *OrderDao) Update(session *xorm.Session, order models.Order, extra map[string]any) (err error) {
// 	if len(extra) == 0 {
// 		return
// 	}

// 	updates := make(map[string]any)
// 	for k, v := range extra {
// 		value := v
// 		if k == "remark" {
// 			if utils.IsBlankString(order.Remark) {
// 				value = fmt.Sprintf("%s:%s", time.Now().Format("2006-01-02 15:04:05"), v)
// 			} else {
// 				value = fmt.Sprintf("%s;%s:%s", order.Remark, time.Now().Format("2006-01-02 15:04:05"), v)
// 			}

// 		}
// 		updates[k] = value
// 	}

// 	_, err = utils.Update(session.Table(models.Order{}.TableName()), updates, utils.IDCond(order.ID))
// 	return
// }

// func (dao *OrderDao) FromIDList(session *xorm.Session, idList []int64) (orderMapper map[int64]models.Order, err error) {
// 	orderMapper = make(map[int64]models.Order)
// 	var orders []models.Order
// 	utils.Find(session.Table(models.Order{}.TableName()),
// 		&orders,
// 		utils.NewInCond("id", idList))
// 	for _, order := range orders {
// 		orderMapper[order.ID] = order
// 	}
// 	return
// }
