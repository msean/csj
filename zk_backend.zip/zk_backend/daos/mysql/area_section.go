package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"fmt"
)

type AreaSectionDao struct {
}

func NewAreaSectionDao() *AreaSectionDao {
	return &AreaSectionDao{}
}

func (dao *AreaSectionDao) List(param vo.AreaSectionListParam) (objects []models.AreaSection, total int64, err error) {
	objects = make([]models.AreaSection, 0)

	conds := []utils.Cond{}

	if !utils.IsBlankString(param.AreaSearch) {
		conds = append(conds, utils.NewWhereLikeCond("area", param.AreaSearch, utils.LikeTypeBetween))
	}

	if !utils.IsBlankString(param.ProvinceSearch) {
		conds = append(conds, utils.NewWhereLikeCond("province", param.ProvinceSearch, utils.LikeTypeBetween))
	}

	if !utils.IsBlankString(param.SectionSearch) {
		conds = append(conds, utils.NewWhereLikeCond("section", param.SectionSearch, utils.LikeTypeBetween))
	}

	if param.IspChoice != 0 {
		conds = append(conds, utils.NewWhereCond("isp", param.IspChoice))
	}

	if !utils.IsBlankString(param.OrderBy) {
		conds = append(conds, utils.NewOrderByCond(param.OrderBy))
	}

	tl, pl := utils.MutateLimitCond(param.Base)
	conds = append(conds, tl)

	session := daos.Mysql.NewSession()
	defer session.Close()

	if total, err = utils.TotalByConds(session, new(models.AreaSection), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &objects, conds...)
	return
}

func (dao *AreaSectionDao) Match(phone string) (object models.AreaSection, has bool, err error) {
	if len(phone) < 7 {
		err = fmt.Errorf("phone number is too short")
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	// 截取手机号前7位
	section := phone[:7]
	has, err = session.Where("section = ?", section).Get(&object)
	if err != nil {
		return
	}
	return
}
