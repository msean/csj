package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"fmt"

	"github.com/go-xorm/xorm"
)

type CustomerDao struct {
}

func NewCustomer() *CustomerDao {
	return &CustomerDao{}
}

func (d *CustomerDao) FromIDList(idList []int64) (customerMap map[int64]models.Customer, err error) {
	customerMap = make(map[int64]models.Customer)
	var customers []models.Customer

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.NewInCond("id", idList).Cond(session).Find(&customers); err != nil {
		return
	}
	for _, channel := range customers {
		customerMap[channel.ID] = channel
	}
	return
}

func (d *CustomerDao) FromID(customerID int64) (customer models.Customer, has bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, customerID, &customer)
	return
}

func (d *CustomerDao) ListAll() (customers []models.Customer, err error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	err = db.Find(&customers)
	return
}

func (d *CustomerDao) FromUserID(userID int64) (customer models.Customer, has bool, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.Get(session, &customer, utils.NewWhereCond("user_id", userID))
	return
}

func (d *CustomerDao) GetBeanById(id int64) (*models.Customer, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	bean := models.Customer{}
	has, err := db.ID(id).Get(&bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("customer not found")
	}

	return &bean, nil
}

func (d *CustomerDao) InsertBean(db *xorm.Session, by int64, bean *models.Customer) (err error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	models.Add(by, &bean.Bean)
	if db != nil {
		_, err = db.Insert(bean)
	} else {
		_, err = s.Insert(bean)
	}
	if err != nil {
		return err
	}

	return nil
}

func (d *CustomerDao) UpdateBean(db *xorm.Session, by int64, bean *models.Customer) (err error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	models.Edit(by, &bean.Bean)
	if db != nil {
		_, err = db.ID(bean.ID).AllCols().Update(bean)
	} else {
		_, err = s.ID(bean.ID).AllCols().Update(bean)
	}

	if err != nil {
		return err
	}

	return nil
}

func (d *CustomerDao) DeleteBeanByIds(db *xorm.Session, ids []int64) (count int64, err error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	if db != nil {
		count, err = db.In("id", ids).Delete(&models.Customer{})
		// count, err = db.In("id", ids).Unscoped().Delete(&models.Customer{})
	} else {
		count, err = s.In("id", ids).Delete(&models.Customer{})
		// count, err = daos.Mysql.In("id", ids).Unscoped().Delete(&models.Customer{})
	}

	if err != nil {
		return 0, err
	}

	return count, err
}

func (d *CustomerDao) QueryCustomer(params vo.CustomerQueryParam) (int64, []*models.Customer, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	if params.Id > 0 {
		db = db.Where("id like ?", fmt.Sprintf("%%%d%%", params.Id))
	}

	if params.Name != "" {
		db = db.Where("name like ?", "%"+params.Name+"%")
	}

	if params.Available >= 0 {
		db = db.Where("available = ?", params.Available)
	}

	if params.Base.StartTime != "" {
		db = db.Where("created >= ?", params.Base.StartTime)
	}

	if params.Base.EndTime != "" {
		db = db.Where("created <= ?", params.Base.EndTime)
	}

	res := make([]*models.Customer, 0)
	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}

func (d *CustomerDao) _QueryCustomer(params vo.CustomerQueryParam) (int64, []*models.CustomerUser, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	curTable := models.Customer{}.TableName()
	joinTable := models.User{}.TableName()
	/*db := daos.Mysql.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize).
	  Join("INNER", joinTable, fmt.Sprintf("%s.id = %s.user_id", joinTable, curTable))*/
	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	db = db.SQL(fmt.Sprintf("select %s.*, %s.* from %s, %s where %s.id = %s.user_id", joinTable, curTable, joinTable, curTable, joinTable, curTable))
	//engine.SQL("select user.*, group.name from user, group where user.group_id = group.id").Find(&users)
	if params.Id > 0 {
		db = db.Where("id = ?", params.Id)
	}

	if params.Name != "" {
		db = db.Where("name like ?", "%"+params.Name+"%")
	}

	if params.Available >= 0 {
		db = db.Where("available = ?", params.Available)
	}

	if params.Base.StartTime != "" {
		db = db.Where(fmt.Sprintf("%s.created >= ?", curTable), params.Base.StartTime)
	}

	if params.Base.EndTime != "" {
		db = db.Where(fmt.Sprintf("%s.created <= ?", curTable), params.Base.EndTime)
	}

	res := make([]*models.CustomerUser, 0)
	count, err := db.Count(&res)
	err = db.Find(&res)
	// count := int64(len(res))
	// count, err := db.FindAndCount(&res)
	// count, err := db.SQL("select a_user.*, xj_customer.* from a_user, xj_customer where a_user.id = xj_customer.user_id").FindAndCount(&res)
	// count, err := db.Table(curTable).Join("INNER", joinTable, fmt.Sprintf("%s.id = %s.user_id", joinTable, curTable)).FindAndCount(&res)

	/*if err != nil {
	  return 0, nil, err
	}*/
	if len(res) <= 0 {
		return count, nil, err
	}

	return count, res, nil
}

func (d *CustomerDao) QueryUserByIds(ids []int64) ([]int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	objs := make([]*models.Customer, 0)
	err := db.In("id", ids).Find(&objs)
	if err != nil {
		return nil, err
	}

	res := make([]int64, 0)
	for _, obj := range objs {
		res = append(res, obj.UserID)
	}

	return res, nil
}

func (d *CustomerDao) Sum() ([]float64, error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	sums, err := session.Sums(models.Customer{}, "balance", "recharge_amount")
	if err != nil {
		return nil, err
	}

	return sums, nil
}
