package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
)

type AnnouncementDao struct{}

func NewAnnouncementDao() *AnnouncementDao {
	return &AnnouncementDao{}
}

func (dao *AnnouncementDao) Create(announcement models.Announcement) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	_, err = daos.CreateObjs(session, &announcement)
	return
}

func (dao *AnnouncementDao) List(params vo.AnnouncementListParams) (rsp []models.Announcement, total int64, err error) {
	rsp = make([]models.Announcement, 0)

	conds := []utils.Cond{}

	if !utils.IsBlankString(params.TitleSearch) {
		conds = append(conds, utils.NewWhereLikeCond("title", params.TitleSearch, utils.LikeTypeBetween))
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	tl, pl := utils.MutateLimitCond(params.Base)
	conds = append(conds, tl)

	if total, err = utils.TotalByConds(session, new(models.Announcement), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &rsp, conds...)
	return
}
