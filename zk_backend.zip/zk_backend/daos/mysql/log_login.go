package mysql

import (
	"application/constant"
	"application/daos"
	"application/models"
	"application/models/vo"
)

type LogLoginDao struct {
}

func NewDaoLogLogin() *LogLoginDao {
	return &LogLoginDao{}
}

func (d *LogLoginDao) InsertBean(bean *models.LogLogin) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	count, err := db.Insert(bean)
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (d *LogLoginDao) QueryLogs(params vo.LogLoginQueryParams) (int64, []*models.LogLogin, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	res := make([]*models.LogLogin, 0)
	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	db = db.Where("account != ?", constant.USER_SUPER_ACCOUNT)
	if params.Account != "" {
		db = db.Where("account = ?", params.Account)
	}

	if params.Ip != "" {
		db = db.Where("ip = ?", params.Ip)
	}

	if params.Success >= 0 {
		db = db.Where("success = ?", params.Success)
	}

	if "" != params.Base.StartTime {
		db = db.Where("created >= ?", params.Base.StartTime)
	}

	if "" != params.Base.EndTime {
		db = db.Where("created <= ?", params.Base.EndTime)
	}

	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}

func (d *LogLoginDao) DeleteBeanByIds(ids []int64) (count int64, err error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	if ids == nil || len(ids) == 0 {
		count, err = db.Delete(&models.LogLogin{})
	} else {
		count, err = db.In("id", ids).Delete(&models.LogLogin{})
	}

	if err != nil {
		return 0, err
	}

	return count, nil
}
