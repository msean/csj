package mysql

type (
	ChannelOrderDao struct{}
)

func NewChannelOrderDao() *ChannelOrderDao {
	return &ChannelOrderDao{}
}

// func (dao *ChannelOrderDao) List(params vo.ChannelOrderListParam) (orders []models.ChannelOrder, total int64, err error) {
// 	conds := []utils.Cond{}
// 	if params.CustomerChoice != 0 {
// 		conds = append(conds, utils.NewWhereCond("customer_id", params.CustomerChoice))
// 	}
// 	if params.ChannelChoice != 0 {
// 		conds = append(conds, utils.NewWhereCond("channel_id", params.ChannelChoice))
// 	}
// 	if !utils.IsBlankString(params.OrderIDSearch) {
// 		conds = append(conds, utils.NewWhereCond("order_id", params.OrderIDSearch))
// 	}
// 	if !utils.IsBlankString(params.PhoneSearch) {
// 		conds = append(conds, utils.NewWhereCond("phone", params.PhoneSearch))
// 	}
// 	if params.IspChoice != 0 {
// 		conds = append(conds, utils.NewWhereCond("isp", params.IspChoice))
// 	}
// 	if params.BigTypeSearch != 0 {
// 		conds = append(conds, utils.NewWhereCond("big_type", params.BigTypeSearch))
// 	}
// 	if params.SmallTypeSearch != 0 {
// 		conds = append(conds, utils.NewWhereCond("small_type", params.SmallTypeSearch))
// 	}

// 	if params.FaceValueLower > 0 {
// 		conds = append(conds, utils.NewCmpCond("face_value", ">=", params.FaceValueLower))
// 	}
// 	if params.FaceValueUpper > 0 {
// 		conds = append(conds, utils.NewCmpCond("face_value", "<=", params.FaceValueUpper))
// 	}
// 	if params.AreaChoice >= 0 {
// 		areaCode := constant.AreaCodeStringM[params.AreaChoice]
// 		if !utils.IsBlankString(areaCode) {
// 			conds = append(conds, utils.NewWhereCond("area", areaCode))
// 		}
// 	}
// 	if !utils.IsBlankString(params.RemarkSearch) {
// 		conds = append(conds, utils.NewWhereLikeCond("remark", params.RemarkSearch, utils.LikeTypeBetween))
// 	}
// 	if len(params.IDList) != 0 {
// 		conds = append(conds, utils.NewInCond("id", params.IDList))
// 	}
// 	if params.StatusChoice != 0 {
// 		if params.StatusChoice == constant.OrderStatusNoResult {
// 			inStatus := []int{
// 				constant.OrderStatusInit,
// 				constant.OrderStatusHandle,
// 				constant.OrderStatusSuspect,
// 			}
// 			conds = append(conds, utils.NewInCond("status", inStatus))
// 		} else {
// 			conds = append(conds, utils.NewWhereCond("status", params.StatusChoice))
// 		}
// 	}
// 	if !params.BackTimeStart.IsZero() {
// 		conds = append(conds, utils.NewCmpCond("current_back_time", ">=", params.BackTimeStart.Local()))
// 	}
// 	if !params.BackTimeEnd.IsZero() {
// 		conds = append(conds, utils.NewCmpCond("current_back_time", "<=", params.BackTimeEnd.Local()))
// 	}

// 	if params.Base.StartTime.IsZero() {
// 		params.Base.StartTime = time.Now().AddDate(0, -6, 0)
// 	}
// 	tl, pl := utils.MutateLimitCond(params.Base)
// 	conds = append(conds, tl)

// 	session := daos.Mysql.NewSession()
// 	defer session.Close()

// 	if total, err = utils.TotalByConds(session, new(models.ChannelOrder), conds...); err != nil {
// 		return
// 	}

// 	conds = append(conds, pl, utils.NewOrderByCond("created desc"))
// 	err = utils.Find(session, &orders, conds...)
// 	return
// }

// func (dao *ChannelOrderDao) UpdateIsp(session *xorm.Session, id int64, isp int) (err error) {
// 	conds := []utils.Cond{
// 		utils.IDCond(id),
// 		utils.NewWhereCond("status", 0),
// 	}
// 	updates := map[string]any{"isp": isp}
// 	_, err = utils.Update(session.Table(models.ChannelOrder{}.TableName()), updates, conds...)
// 	return
// }

// func (dao *ChannelOrderDao) UpdateRemark(session *xorm.Session, id int64, Remark string) (err error) {
// 	var orderModel models.ChannelOrder
// 	var has bool
// 	has, err = utils.IDCond(id).Cond(session.Table(models.ChannelOrder{}.TableName())).Get(&orderModel)
// 	if !has {
// 		return errors.New("record not found")
// 	}

// 	if err != nil {
// 		return
// 	}

// 	remark := append(orderModel.Remark, models.RemarkRecord{
// 		RemarkTime: time.Now(),
// 		Remark:     Remark,
// 	})
// 	_, err = utils.Update(session.Table(models.ChannelOrder{}.TableName()), map[string]any{"remark": remark}, utils.IDCond(id))
// 	return
// }

// func (dao *ChannelOrderDao) ModifyStatus(session *xorm.Session, channelOrder models.ChannelOrder, status int64, extra map[string]any) (err error) {
// 	updates := map[string]interface{}{
// 		"status": status,
// 	}

// 	if len(extra) != 0 {
// 		for k, v := range extra {
// 			value := v
// 			if k == "remark" {
// 				if remarkV, ok := v.(string); ok {
// 					remarkValue := append(channelOrder.Remark, models.RemarkRecord{
// 						RemarkTime: time.Now(),
// 						Remark:     remarkV,
// 					})
// 					if value, err = json.Marshal(remarkValue); err != nil {
// 						return
// 					}
// 				}
// 			}
// 			updates[k] = value
// 		}
// 	}
// 	_, err = utils.Update(session.Table(models.ChannelOrder{}.TableName()), updates, utils.IDCond(channelOrder.ID))
// 	return
// }

// func (dao *ChannelOrderDao) FromID(session *xorm.Session, id int64) (channelOrder models.ChannelOrder, has bool, err error) {
// 	has, err = utils.Get(session.Table(models.ChannelOrder{}.TableName()), &channelOrder, utils.IDCond(id))
// 	return
// }

// // toModifyOrder 是否需要去改变订单状态，当是最后一个渠道而且分发失败的时候需要更改订单的状态
// func (dao *ChannelOrderDao) Fail(session *xorm.Session,
// 	channelOrder models.ChannelOrder,
// 	extraChannelOrderUpdate map[string]any,
// 	extraOrderUpdate map[string]any,
// 	toModifyOrder bool) (err error) {

// 	if len(extraChannelOrderUpdate) != 0 {
// 		extraChannelOrderUpdate["finish_time"] = time.Now().Local()
// 	} else {
// 		extraChannelOrderUpdate = map[string]any{
// 			"finish_time": time.Now().Local(),
// 		}
// 	}
// 	extraChannelOrderUpdate["finish_time"] = time.Now().Local()
// 	if err = dao.ModifyStatus(session, channelOrder, constant.OrderStatusFail, extraChannelOrderUpdate); err != nil {
// 		return
// 	}

// 	if !toModifyOrder {
// 		return
// 	}

// 	if len(extraOrderUpdate) != 0 {
// 		extraOrderUpdate["finish_time"] = time.Now().Local()
// 	} else {
// 		extraOrderUpdate = map[string]any{
// 			"finish_time": time.Now().Local(),
// 		}
// 	}
// 	// var has bool
// 	// var order models.Order
// 	// order, has, err = Order.FromID(session, channelOrder.OrderID)
// 	// if !has {
// 	// 	err = errors.New("record not found")
// 	// }
// 	// if err != nil || order.Status == constant.OrderStatusFail {
// 	// 	return
// 	// }
// 	OrderPartition.ModifyStatus(session, models.Order{BeanShard: models.BeanShard{
// 		ID: channelOrder.OrderID,
// 	}}, constant.OrderStatusFail, extraOrderUpdate)
// 	return
// }

// func (dao *ChannelOrderDao) Success(session *xorm.Session,
// 	channelOrder models.ChannelOrder,
// 	extraChannelOrderUpdate map[string]any,
// 	extraOrderUpdate map[string]any,
// ) (err error) {

// 	if len(extraChannelOrderUpdate) != 0 {
// 		extraChannelOrderUpdate["finish_time"] = time.Now().Local()
// 	} else {
// 		extraChannelOrderUpdate = map[string]any{
// 			"finish_time": time.Now().Local(),
// 		}
// 	}
// 	if err = ChannelOrder.ModifyStatus(session, channelOrder, constant.OrderStatusSuccess, extraChannelOrderUpdate); err != nil {
// 		return
// 	}

// 	// var has bool
// 	// var order models.Order
// 	// order, has, err = Order.FromID(session, channelOrder.OrderID)
// 	// if !has {
// 	// 	err = errors.New("record not found")
// 	// }
// 	// if err != nil || order.Status == constant.OrderStatusSuccess {
// 	// 	return
// 	// }

// 	if len(extraOrderUpdate) != 0 {
// 		extraOrderUpdate["finish_time"] = time.Now().Local()
// 	} else {
// 		extraOrderUpdate = map[string]any{
// 			"finish_time": time.Now().Local(),
// 		}
// 	}
// 	OrderPartition.ModifyStatus(session, models.Order{
// 		BeanShard: models.BeanShard{
// 			ID: channelOrder.OrderID,
// 		},
// 	}, constant.OrderStatusSuccess, extraOrderUpdate)
// 	return
// }

// func (dao *ChannelOrderDao) Create(session *xorm.Session, channelOrder *models.ChannelOrder) (err error) {
// 	_, err = utils.Create(session, channelOrder)
// 	return
// }

// func (dao *ChannelOrderDao) UpdateFields(session *xorm.Session, channelOrderID int64, fields map[string]any) (err error) {
// 	_, err = utils.Update(session.Table(models.ChannelOrder{}.TableName()), fields, utils.IDCond(channelOrderID))
// 	return
// }
