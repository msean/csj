package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"

	"github.com/go-xorm/xorm"
)

type UserDao struct {
}

func NewDaoUser() *UserDao {
	return &UserDao{}
}

func (m *UserDao) InsertBean(db *xorm.Session, by int64, bean *models.User) (err error) {
	models.Add(by, &bean.Bean)
	if db != nil {
		_, err = db.Insert(bean)
	} else {
		s := daos.Mysql.NewSession()
		defer s.Close()

		_, err = s.Insert(bean)
	}

	if err != nil {
		return err
	}

	return nil
}

func (m *UserDao) UpdateBean(db *xorm.Session, by int64, bean *models.User) (err error) {
	models.Edit(by, &bean.Bean)
	if db != nil {
		_, err = db.ID(bean.ID).AllCols().Update(bean)
	} else {
		s := daos.Mysql.NewSession()
		defer s.Close()

		_, err = s.ID(bean.ID).AllCols().Update(bean)
	}

	if err != nil {
		return err
	}

	return nil
}

func (m *UserDao) DeleteBeanByIds(db *xorm.Session, ids []int64, fromCustomer bool) (count int64, err error) {
	// client user only edit by customer api
	if db != nil {
		count, err = db.In("id", ids).Where("is_client = ?", fromCustomer).Unscoped().Delete(&models.User{})
	} else {
		s := daos.Mysql.NewSession()
		defer s.Close()

		count, err = s.In("id", ids).Where("is_client = ?", fromCustomer).Unscoped().Delete(&models.User{})
		// count, err := daos.Mysql.In("id", ids).Delete(&models.User{})
	}

	if err != nil {
		return 0, err
	}

	return count, err
}

func (m *UserDao) GetBeanById(id int64) (*models.User, error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	bean := &models.User{}
	has, err := s.ID(id).Get(bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return bean, nil
}

func (m *UserDao) GetBeanByAccount(account string) (*models.User, error) {
	s := daos.Mysql.NewSession()
	// logger.Log.Info(fmt.Sprintf("_________debug-GetBeanByAccount: s = %+v", s))
	// logger.Log.Info(fmt.Sprintf("_________debug-GetBeanByAccount: s = %+v, statement = %+v", s))
	defer func() {
		// logger.Log.Info(fmt.Sprintf("_________debug-GetBeanByAccount: close session, s = %+v", s))
		s.Close()
	}()

	bean := &models.User{}
	//has, err := daos.Mysql.Where("account = ?", account).Get(bean)
	has, err := s.Where("account = ?", account).Get(bean)
	// logger.Log.Info(fmt.Sprintf("_________debug-GetBeanByAccount: read, s = %+v", s))

	if err != nil {
		return nil, err
	}

	if !has {
		return nil, nil
	}

	return bean, nil
}

func (m *UserDao) QueryUsers(params vo.UserQueryParams) (int64, []*models.User, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	list := make([]*models.User, 0)
	db = db.Where("is_super = ?", false)
	if params.Base.PageSize > 0 {
		db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	}

	if len(params.Ids) > 0 {
		db = db.In("id", params.Ids)
	}

	if params.UserName != "" {
		db = db.Where("user_name like ?", "%"+params.UserName+"%")
	}

	if params.PhoneNumber != "" {
		db = db.Where("phone_number like ?", "%"+params.PhoneNumber+"%")
	}

	if params.Available >= 0 {
		db = db.Where("available = ?", params.Available)
	}

	if "" != params.Base.StartTime {
		db = db.Where("created >= ?", params.Base.StartTime)
	}

	if "" != params.Base.EndTime {
		db = db.Where("created <= ?", params.Base.EndTime)
	}

	if params.IsClient > 0 {
		db = db.Where("is_client = ?", params.IsClient)
	}

	if params.ReverseSort {
		db = db.OrderBy("id desc")
	}

	count, err := db.FindAndCount(&list)
	if err != nil {
		return 0, nil, err
	}

	return count, list, err
}

func (m *UserDao) UpdateRole(userIDs []int64, roleID int64) (int64, error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	count, err := s.Table((&models.User{}).TableName()).In("id", userIDs).Update(map[string]int64{"role": roleID})
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (m *UserDao) QueryByRole(params vo.QueryRoleUserParams) (count int64, res []*models.User, err error) {
	s := daos.Mysql.NewSession()
	defer s.Close()

	db := s.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	db = db.Where("is_super = ?", false)
	if params.ExcludeRole {
		db = db.Where("role != ?", params.RoleID)
	} else {
		db = db.Where("role = ?", params.RoleID)
	}

	if params.ExcludeClient {
		db = db.Where("is_client != ?", true)
	}

	if params.Account != "" {
		db = db.Where("account like ?", "%"+params.Account+"%")
	}

	if params.PhoneNumber != "" {
		db = db.Where("phone_number like ?", "%"+params.PhoneNumber+"%")
	}

	count, err = db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}

func (dao *UserDao) UserMapper(userList []int64) (mapper map[int64]models.User, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	mapper = make(map[int64]models.User)

	var users []models.User
	if err = utils.Find(session, &users, utils.NewInCond("id", userList)); err != nil {
		return
	}

	for _, user := range users {
		mapper[user.ID] = user
	}
	return
}

//
/*
func (m *UserDao) FindAllUser() (list []*models.User, err error) {
	err = daos.Mysql.Where("status = ?", "0").Find(&list)
	return
}

func (m *UserDao) DeleteBeanById(id int64) error {
	_, err := daos.Mysql.ID(id).Delete(&models.User{})
	return err
}

func (m *UserDao) FindUserByIds(ids []int64, param *vo.FindListParams) (int64, []*models.User, error) {
	list := make([]*models.User, 0)
	db := daos.Mysql.Limit(param.PageSize, (param.Page-1)*param.PageSize)
	if nil != ids {
		db.In("id", ids)
	}
	if "" != param.StartTime {
		db.Where("created >= ?", param.StartTime)
	}
	if "" != param.EndTime {
		db.Where("created <= ?", param.EndTime)
	}
	count, err := db.FindAndCount(&list)
	if err != nil {
		return 0, nil, err
	}
	return count, list, err
}

func (m *UserDao) FindUserIdsBySuperiorId(userId int64) (list []int64) {
	sql := `
			SELECT
				id
			FROM
				a_user
			WHERE
				id = ?
				OR superior_ids LIKE '%,?,%'
				OR superior_ids LIKE '?,%'
				OR superior_ids LIKE '%,?'
`
	sql = strings.ReplaceAll(sql, "?", fmt.Sprintf("%d", userId))
	v, err := daos.Mysql.QueryString(sql)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("FindUserIdsBySuperiorId 失败 [%d]", userId), zap.Error(err))
		return
	}
	list = make([]int64, 0)
	for _, m := range v {
		id := m["id"]
		atoi, err := strconv.Atoi(id)
		if err != nil {
			continue
		}
		list = append(list, int64(atoi))
	}
	return
}*/
