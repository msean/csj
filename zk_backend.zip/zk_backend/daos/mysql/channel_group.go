package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"encoding/json"

	"github.com/go-xorm/xorm"
)

type ChannelGroupDao struct {
}

func NewChannelGroupDao() *ChannelGroupDao {
	return &ChannelGroupDao{}
}

func (dao *ChannelGroupDao) Update(session *xorm.Session, id int64, name string, rels []models.ChannelGroupRel) (err error) {
	var relsByte []byte
	if relsByte, err = json.Marshal(rels); err != nil {
		return
	}
	// var channelGroup models.ChannelGroup
	_, err = session.Table(models.ChannelGroup{}.TableName()).Where("id = ?", id).Update(map[string]any{
		"name": name,
		"rels": string(relsByte),
	})
	// channelGroup.Name = name
	// channelGroup.ID = id
	// channelGroup.Rels = rels
	// _, err = daos.UpdateColsWithVersion(daos.Mysql.NewSession(), &channelGroup, "name", "rels")
	return
}

func (dao *ChannelGroupDao) List(params vo.ChannelGroupListParams) (channelGroups []models.ChannelGroup, total int64, err error) {
	conds := []utils.Cond{}

	if !utils.IsBlankString(params.CodeSearch) {
		conds = append(conds, utils.NewWhereLikeCond("code", params.CodeSearch, utils.LikeTypeBetween))
	}

	if !utils.IsBlankString(params.NameSearch) {
		conds = append(conds, utils.NewWhereLikeCond("name", params.NameSearch, utils.LikeTypeBetween))
	}

	if params.SortTypeChoice != 0 {
		conds = append(conds, utils.NewWhereCond("sort_type", params.NameSearch))
	}

	tl, pl := utils.MutateLimitCond(params.Base)
	conds = append(conds, tl)

	session := daos.Mysql.NewSession()
	defer session.Close()

	if total, err = utils.TotalByConds(session, new(models.ChannelGroup), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &channelGroups, conds...)
	return
}

func (dao *ChannelGroupDao) FromID(groupID int64) (channelGroup models.ChannelGroup, has bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.Get(session, &channelGroup, utils.IDCond(groupID))
	return
}
