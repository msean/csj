package mysql

import (
	"application/common/logger"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"fmt"
	"strings"

	"github.com/go-xorm/xorm"
	"go.uber.org/zap"
)

type ChannelProdDao struct {
}

func NewChannelProdDao() *ChannelProdDao {
	return &ChannelProdDao{}
}

func (dao *ChannelProdDao) ListByChannelID(channelID int64) (channelProds []models.ChannelProduct, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	err = utils.Find(session, &channelProds, utils.NewWhereCond("channel_id", channelID))
	return
}

func (dao *ChannelProdDao) UpdatePcode(id int64, pcode string) (err error) {
	var channelProd models.ChannelProduct
	channelProd.ID = id
	channelProd.Pcode = pcode

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.UpdateColsWithVersion(session, &channelProd, "pcode")
	return
}

func (dao *ChannelProdDao) FromIDList(IDlist []int64) (channelProds []models.ChannelProduct, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	err = utils.Find(session, &channelProds, utils.NewInCond("id", IDlist))
	return
}

func (dao *ChannelProdDao) ListOnlineChannelProd(channelIDlist []int64, productCodes []string) (channelProductM map[int64]map[string]models.ChannelProduct, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelDao] [ValidFromChannelList]", zap.Int64s("channelList", channelIDlist), zap.Error(err))
		}
	}()

	if len(channelIDlist) == 0 || len(productCodes) == 0 {
		return
	}
	var channelProds []models.ChannelProduct
	channelProductM = make(map[int64]map[string]models.ChannelProduct)
	conds := []utils.Cond{
		utils.NewWhereCond("online", 2),
		utils.NewInCond("channel_id", channelIDlist),
		utils.NewInCond("product_code", productCodes),
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &channelProds, conds...); err != nil {
		return
	}

	for _, channelProd := range channelProds {
		if _channelProdMap, ok := channelProductM[channelProd.ChannelID]; ok {
			_channelProdMap[channelProd.ProductCode] = channelProd
		} else {
			channelProductM[channelProd.ChannelID] = map[string]models.ChannelProduct{
				channelProd.ProductCode: channelProd,
			}
		}
	}
	return
}

func (dao *ChannelProdDao) BatchOnlineSet(session *xorm.Session, idList []int64, online uint) (err error) {
	_, err = session.Table(models.ChannelProduct{}.TableName()).In("id", idList).Update(map[string]interface{}{
		"online": online,
	})
	return
}

func (dao *ChannelProdDao) ScheduleUpdateSql(id int64, params vo.ChannelProdUpdateParams, productMap map[string]models.Product, channelIDCode map[int64]string) string {
	var updateFields strings.Builder
	var remarkPart string

	if params.Remark != "" {
		remarkPart = fmt.Sprintf(", remark = '%s'", params.Remark)
	}

	if params.VoucherType != 0 {
		updateFields.WriteString(fmt.Sprintf("voucher_type = %d, ", params.VoucherType))
	}
	if params.Online != 0 {
		updateFields.WriteString(fmt.Sprintf("online = %d, ", params.Online))
	}
	if params.ActualDiscount.Value > 0 {
		actualPrice := params.ActualDiscount.Calculate(productMap[channelIDCode[id]].Price)
		updateFields.WriteString(fmt.Sprintf("actual_price = %f, ", actualPrice))
	}
	if params.OrderDiscount.Value > 0 {
		orderPrice := params.OrderDiscount.Calculate(productMap[channelIDCode[id]].Price)
		updateFields.WriteString(fmt.Sprintf("order_price = %f, ", orderPrice))
	}

	updateString := strings.TrimSuffix(updateFields.String(), ", ")
	if len(updateString) == 0 && remarkPart == "" {
		return ""
	}

	sql := fmt.Sprintf(`UPDATE xj_channelproduct SET %s%s WHERE id = %d`, updateString, remarkPart, id)

	return sql
}

func (dao *ChannelProdDao) List(params vo.ChannelProdListParams) (channelProds []models.ChannelProduct, total int64, err error) {
	conds := []utils.Cond{}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if params.ChannelSearch != 0 {
		conds = append(conds, utils.NewWhereCond("channel_id", params.ChannelSearch))
	}

	if params.ProductAreaSearch >= 0 || !utils.IsBlankString(params.ProductNameSearch) || params.ProductBigTypeSearch != 0 ||
		params.ProductSmallTypeSearch != 0 || params.FaceValueLower > 0 || params.FaceValueUpper > 0 || params.ProductIspSearch > 0 {
		p := vo.ProductListParams{
			AreaSearch:      []int{int(params.ProductAreaSearch)},
			NameSearch:      params.ProductNameSearch,
			BigTypeSearch:   params.ProductBigTypeSearch,
			SmallTypeSearch: params.ProductSmallTypeSearch,
			FaceValueLower:  params.FaceValueLower,
			FaceValueUpper:  params.FaceValueUpper,
			IspSearch:       []int{params.ProductIspSearch},
			WithNoCount:     true,
		}
		var products []models.Product
		if products, _, err = Product.List(p); err != nil {
			return
		}
		var productCodes []string
		for _, product := range products {
			productCodes = append(productCodes, product.Code)
		}

		if len(productCodes) == 0 {
			return
		}
		conds = append(conds, utils.NewInCond("product_code", productCodes))
	}

	if len(params.IDList) > 0 {
		conds = append(conds, utils.NewInCond("id", params.IDList))
	}

	if params.VoucherType != 0 {
		conds = append(conds, utils.NewWhereCond("voucher_type", params.VoucherType))
	}

	if params.StatusChoice != 0 {
		conds = append(conds, utils.NewWhereCond("online", params.StatusChoice))
	}

	tl, pl := utils.MutateLimitCond(params.Base)
	conds = append(conds, tl)
	if total, err = utils.TotalByConds(session, new(models.ChannelProduct), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &channelProds, conds...)
	return
}
