package mysql

import (
	"application/constant"
	"application/daos"
	"application/models"
	"application/models/vo"
	"errors"
)

type LogRemoveDao struct {
}

func NewDaoLogRemove() *LogRemoveDao {
	return &LogRemoveDao{}
}

func (d *LogRemoveDao) InsertBean(bean *models.LogRemove) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	count, err := db.Insert(bean)
	err = errors.New("ss")
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (d *LogRemoveDao) QueryLogs(params vo.LogRemoveQueryParams) (int64, []*models.LogRemove, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	res := make([]*models.LogRemove, 0)
	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	db = db.Where("operator != ?", constant.USER_SUPER_NAME)
	if params.TableType > 0 {
		db = db.Where("table_type = ?", params.TableType)
	}

	if params.Operator != "" {
		db = db.Where("operator = ?", params.Operator)
	}

	if params.Base.StartTime != "" {
		db = db.Where("created >= ?", params.Base.StartTime)
	}

	if params.Base.EndTime != "" {
		db = db.Where("created <= ?", params.Base.EndTime)
	}

	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}
