package mysql

import (
	"application/constant"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
)

type (
	ReturnOrderDao struct{}
)

func NewReturnOrderDao() *ReturnOrderDao {
	return &ReturnOrderDao{}
}

func (dao *ReturnOrderDao) List(params vo.ReturnOrderListParam) (orders []models.OrderReturn, total int64, err error) {
	conds := []utils.Cond{}
	if params.CustomerChoice != 0 {
		conds = append(conds, utils.NewWhereCond("customer_id", params.CustomerChoice))
	}
	if params.ChannelChoice != 0 {
		conds = append(conds, utils.NewWhereCond("channel_id", params.ChannelChoice))
	}
	if !utils.IsBlankString(params.OrderIDSearch) {
		conds = append(conds, utils.NewWhereLikeCond("order_id", params.OrderIDSearch, utils.LikeTypeBetween))
	}
	if !utils.IsBlankString(params.ChannelOrderIDSearch) {
		conds = append(conds, utils.NewWhereLikeCond("channel_order_id", params.ChannelOrderIDSearch, utils.LikeTypeBetween))
	}
	if !utils.IsBlankString(params.PhoneSearch) {
		conds = append(conds, utils.NewWhereLikeCond("phone", params.PhoneSearch, utils.LikeTypeBetween))
	}
	if !utils.IsBlankString(params.CustomerIDSearch) {
		conds = append(conds, utils.NewWhereLikeCond("customer_id", params.CustomerIDSearch, utils.LikeTypeBetween))
	}
	if params.AreaChoice >= 0 {
		areaCode := constant.AreaCodeStringM[params.AreaChoice]
		if !utils.IsBlankString(areaCode) {
			conds = append(conds, utils.NewWhereCond("area", areaCode))
		}
	}
	if params.IspChoice != 0 {
		conds = append(conds, utils.NewWhereCond("isp", params.IspChoice))
	}
	if params.TypeChoice != 0 {
		conds = append(conds, utils.NewWhereCond("type", params.TypeChoice))
	}
	if !utils.IsBlankString(params.CustomerOrderSearch) {
		conds = append(conds, utils.NewWhereLikeCond("customer_order_id", params.CustomerOrderSearch, utils.LikeTypeBetween))
	}

	tl, pl := utils.MutateLimitCond(params.Base)
	switch params.TimeSearchType {
	case 2:
		if !tl.StartTime.IsZero() {
			conds = append(conds, utils.NewCmpCond("order_time", ">=", tl.StartTime.Local()))
		}
		if !tl.EndTime.IsZero() {
			conds = append(conds, utils.NewCmpCond("order_time", "<=", tl.EndTime.Local()))
		}
	default:
		conds = append(conds, tl)
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if total, err = utils.TotalByConds(session, new(models.OrderReturn), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &orders, conds...)
	return
}
