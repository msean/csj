package mysql

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"

	"github.com/go-xorm/xorm"
	"go.uber.org/zap"
)

type SysArgConfigDao struct {
}

func NewSysArgConfigDao() *SysArgConfigDao {
	return &SysArgConfigDao{}
}

func (dao *SysArgConfigDao) FromKey(session *xorm.Session, key string) (sysConf models.SysArgConfig, has bool, err error) {
	has, err = utils.Get(session, &sysConf, utils.NewWhereCond("config_key", key))
	return

}

func (dao *SysArgConfigDao) FromIDList(IDList []int64) (sysCfgList []models.SysArgConfig, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &sysCfgList, utils.NewInCond("id", IDList)); err != nil {
		logger.Log.Error("[SysConfigDao] [FromIDList]", zap.Int64s("idList", IDList), zap.Error(err))
	}
	return
}

func (dao *SysArgConfigDao) FromKeys(keys []string) (sysConfM map[string]models.SysArgConfig, err error) {
	sysConfM = make(map[string]models.SysArgConfig)
	var sysConfigs []models.SysArgConfig

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &sysConfigs, utils.NewInCond("config_key", keys)); err != nil {
		logger.Log.Error("[SysConfigDao] [FromKeys]", zap.Strings("keys", keys), zap.Error(err))
	}
	for _, conf := range sysConfigs {
		sysConfM[conf.Key] = conf
	}
	return
}

func (dao *SysArgConfigDao) List(params vo.SysArgListParams) (objs []models.SysArgConfig, total int64, err error) {
	objs = make([]models.SysArgConfig, 0)
	conds := []utils.Cond{}

	if !utils.IsBlankString(params.NameSearch) {
		conds = append(conds, utils.NewWhereLikeCond("config_name", params.NameSearch, utils.LikeTypeBetween))
	}
	if params.TypeSearch != 0 {
		conds = append(conds, utils.NewWhereCond("config_type", params.TypeSearch))
	}
	if !utils.IsBlankString(params.KeySearch) {
		conds = append(conds, utils.NewWhereLikeCond("config_key", params.KeySearch, utils.LikeTypeBetween))
	}

	if len(params.IDList) > 0 {
		conds = append(conds, utils.NewInCond("id", params.IDList))
	}

	timeLimit, pageLimit := utils.MutateLimitCond(params.Base)
	conds = append(conds, timeLimit)

	session := daos.Mysql.NewSession()
	defer session.Close()

	total, err = utils.TotalByConds(session, new(models.SysArgConfig), conds...)
	if err != nil {
		return
	}

	conds = append(conds, pageLimit)
	err = utils.Find(session, &objs, conds...)
	return
}

func InitSysConf() (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	var has bool
	has, err = daos.Exist(session, &models.SysArgConfig{}, 0, map[string]any{
		"config_key": constant.SysConfBlackListLimit,
	})
	if err != nil {
		return
	}
	if !has {
		if _, err = daos.CreateObjs(session, models.SysArgConfig{
			Name:   "手机号码失败订单超过都少次加入临时黑名单",
			Key:    constant.SysConfBlackListLimit,
			Value:  utils.Violent2String(5),
			Typ:    1,
			Remark: "",
		}); err != nil {
			return
		}
	}
	return
}
