package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"errors"
)

type FinanceDayDAO struct {
}

func NewFinanceDayDAO() *FinanceDayDAO {
	return &FinanceDayDAO{}
}

func (d *FinanceDayDAO) InsertBean(by int64, bean *models.FinanceDay) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Add(by, &bean.Bean)
	_, err := db.Insert(bean)
	if err != nil {
		return err
	}

	return nil
}

func (d *FinanceDayDAO) UpdateBean(by int64, bean *models.FinanceDay) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Edit(by, &bean.Bean)
	_, err := db.ID(bean.ID).AllCols().Update(bean)
	if err != nil {
		return err
	}

	return nil
}

func (d *FinanceDayDAO) GetBeanById(id int64) (*models.FinanceDay, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	bean := &models.FinanceDay{}
	has, err := db.ID(id).Get(bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return bean, nil
}

func (d *FinanceDayDAO) DeleteBeanByIds(ids []int64) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	count, err := db.In("id", ids).Delete(&models.FinanceDay{})
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (d *FinanceDayDAO) QueryBeans(params vo.FinanceDayQueryParams) (int64, []*models.FinanceDay, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	db = db.Where("is_customer = ?", params.IsCustomer)

	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	if params.OwnerID > 0 {
		db = db.Where("owner_id = ?", params.OwnerID)
	}

	if params.Base.StartTime != "" {
		db = db.Where("finance_date >= ?", params.Base.StartTime)
	}

	if params.Base.EndTime != "" {
		db = db.Where("finance_date <= ?", params.Base.EndTime)
	}

	res := make([]*models.FinanceDay, 0)
	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}
