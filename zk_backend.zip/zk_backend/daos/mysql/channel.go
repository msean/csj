package mysql

import (
	"application/conf"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"fmt"

	"github.com/go-xorm/xorm"
)

type ChannelDao struct {
}

func NewChannelDao() *ChannelDao {
	return &ChannelDao{}
}

func (dao *ChannelDao) UpdateLimitConfig(session *xorm.Session, id int64, limitConf []models.ChannelLimit) (err error) {
	var channel models.Channel
	var has bool
	if has, err = daos.ObjDetailByID(session, id, &channel); err != nil {
		return
	}
	if !has {
		return fmt.Errorf("object not found")
	}
	channel.LimitConfig = limitConf
	_, err = daos.UpdateColsWithVersion(session, &channel, "limit_config")
	return
}

// func (dao *ChannelDao) ListOnlineChannel(channelList, excepts []int64) (channels []models.Channel, err error) {
// 	conds := []utils.Cond{
// 		utils.NewInCond("id", channelList),
// 		utils.NewWhereCond("online", 2),
// 	}
// 	session := daos.Mysql.NewSession()

// 	if len(excepts) != 0 {
// 		session = daos.Mysql.NewSession().NotIn("id", excepts)
// 	}
// 	err = utils.Find(session, &channels, conds...)
// 	return
// }

func (dao *ChannelDao) ListByParams(params vo.ChannelListParams) (channels []models.Channel, total int64, err error) {
	channels = make([]models.Channel, 0)
	conds := []utils.Cond{}

	if !utils.IsBlankString(params.CodeSearch) {
		conds = append(conds, utils.NewWhereLikeCond("id", params.CodeSearch, utils.LikeTypeBetween))
	}

	if !utils.IsBlankString(params.NameSearch) {
		conds = append(conds, utils.NewWhereLikeCond("name", params.NameSearch, utils.LikeTypeBetween))
	}

	if params.StatusChoice != 0 {
		conds = append(conds, utils.NewWhereCond("online", params.StatusChoice))
	}

	if len(params.IDList) > 0 {
		conds = append(conds, utils.NewInCond("id", params.IDList))
	}

	if !utils.IsBlankString(params.TemplateSearch) {
		conds = append(conds, utils.NewWhereCond("template_name", params.TemplateSearch))
	}

	tl, pl := utils.MutateLimitCond(params.Base)
	conds = append(conds, tl)

	session := daos.Mysql.NewSession()
	defer session.Close()

	if total, err = utils.TotalByConds(session, new(models.Channel), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &channels, conds...)
	return
}

func (dao *ChannelDao) FromIDList(idList []int64) (channelMap map[int64]models.Channel, err error) {
	channelMap = make(map[int64]models.Channel)
	var channels []models.Channel

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.NewInCond("id", idList).Cond(session).Find(&channels); err != nil {
		return
	}
	for _, channel := range channels {
		channelMap[channel.ID] = channel
	}
	return
}

func (dao *ChannelDao) All() (channels []models.Channel, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	err = session.Find(&channels)
	return
}

func (dao *ChannelDao) GetBeanById(id int64) (channel *models.Channel, err error) {
	bean := &models.Channel{}
	has, err := daos.Mysql.ID(id).Get(bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return bean, nil
}

func (dao *ChannelDao) FromID(id int64) (channel models.Channel, has bool, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &channel)
	return
}

func (dao *ChannelDao) Create(channel *models.Channel) (err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = session.Begin(); err != nil {
		return
	}
	if _, err = daos.CreateObjs(session, channel); err != nil {
		session.Rollback()
		return
	}
	channel.BackUrl = fmt.Sprintf("%s/%d", conf.Config().Url.CallbackPrefix, channel.ID)
	if _, err = daos.UpdateColsWithVersion(session, channel, "back_url"); err != nil {
		session.Rollback()
		return
	}
	return session.Commit()
}
