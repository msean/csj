package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
)

type BlacklistDao struct {
}

func NewBlackListDao() *BlacklistDao {
	return &BlacklistDao{}
}

func (dao *BlacklistDao) List(params vo.BlacklistParams) (blList []models.Blacklist, total int64, err error) {
	blList = make([]models.Blacklist, 0)

	conds := []utils.Cond{}

	if !utils.IsBlankString(params.PhoneSearch) {
		conds = append(conds, utils.NewWhereLikeCond("phone", params.PhoneSearch, utils.LikeTypeBetween))
	}

	if !utils.IsBlankString(params.RemarkSearch) {
		conds = append(conds, utils.NewWhereLikeCond("remark", params.RemarkSearch, utils.LikeTypeBetween))
	}

	if params.TypeChoice != 0 {
		conds = append(conds, utils.NewWhereCond("type", params.TypeChoice))
	}

	tl, pl := utils.MutateLimitCond(params.Base)
	conds = append(conds, tl)

	session := daos.Mysql.NewSession()
	defer session.Close()

	if total, err = utils.TotalByConds(session, new(models.Blacklist), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &blList, conds...)
	return
}

func (dao *BlacklistDao) Exist(phone string) (yes bool, err error) {
	var blacklist models.Blacklist
	conds := []utils.Cond{
		utils.NewWhereCond("phone", phone),
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	return utils.Get(session, &blacklist, conds...)
}

func (dao *BlacklistDao) LoadAll() (objects []models.Blacklist, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	err = utils.Find(session, &objects)
	return
}

func (dao *BlacklistDao) FromIDList(idList []int64) (blacklist []models.Blacklist, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &blacklist, utils.NewInCond("id", idList)); err != nil {
		return
	}

	return
}

func (dao *BlacklistDao) NotInPhones(phones []string) (notInPhones map[string]bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	var existBlacklist []models.Blacklist
	existPhoneMapper := make(map[string]bool)
	notInPhones = make(map[string]bool)

	err = session.In("phone", phones).Find(&existBlacklist)
	for _, phone := range existBlacklist {
		existPhoneMapper[phone.Phone] = true
	}

	for _, phone := range phones {
		if _, ok := existPhoneMapper[phone]; !ok {
			notInPhones[phone] = true
		}
	}

	return
}
