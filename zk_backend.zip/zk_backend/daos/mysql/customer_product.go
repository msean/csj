package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"fmt"

	"github.com/go-xorm/xorm"
)

type CustomerProductDao struct {
}

func NewCustomerProduct() *CustomerProductDao {
	return &CustomerProductDao{}
}

func (d *CustomerProductDao) FromCustomerAndPro(customerID int64, productCode string) (customerProd models.CustomerProduct, has bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.Get(session, &customerProd, utils.NewWhereCond("customer_id", customerID), utils.NewWhereCond("product_code", productCode))
	return
}

func (d *CustomerProductDao) FromIDList(idList []int64) (customerProdList []models.CustomerProduct, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	err = utils.Find(session, &customerProdList, utils.NewInCond("id", idList))
	return
}

func (d *CustomerProductDao) AllMapperByCustomer(customerID int64) (customerProdMapper map[string]models.CustomerProduct, err error) {
	customerProdMapper = make(map[string]models.CustomerProduct)
	var customerProds []models.CustomerProduct

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &customerProds, utils.NewWhereCond("customer_id", customerID)); err != nil {
		return
	}
	for _, product := range customerProds {
		customerProdMapper[product.ProductCode] = product
	}
	return
}

func (d *CustomerProductDao) GetBeanById(id int64) (*models.CustomerProduct, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	bean := models.CustomerProduct{}
	has, err := db.ID(id).Get(&bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return &bean, nil
}

func (d *CustomerProductDao) InsertBean(by int64, bean *models.CustomerProduct) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Add(by, &bean.Bean)
	_, err := db.Insert(bean)
	if err != nil {
		return err
	}

	return nil
}

func (d *CustomerProductDao) UpdateBean(by int64, bean *models.CustomerProduct) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Edit(by, &bean.Bean)
	_, err := db.ID(bean.ID).AllCols().Update(bean)
	if err != nil {
		return err
	}

	return nil
}

func (d *CustomerProductDao) UpdateCustomerNameByID(db *xorm.Session, customerID int64, customerName string) (int64, error) {
	if db == nil {
		db = daos.Mysql.NewSession()
		defer db.Close()
	}

	tb := models.CustomerProduct{}.TableName()
	return db.Table(tb).Where("customer_id = ?", customerID).Update(map[string]interface{}{"customer_name": customerName})
}

func (d *CustomerProductDao) DeleteBeanByIds(ids []int64) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	count, err := db.In("id", ids).Unscoped().Delete(&models.CustomerProduct{})
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (d *CustomerProductDao) QueryCustomerProduct(params vo.CustomerProductQueryParam) (int64, []*models.CustomerProduct, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	curTb := models.CustomerProduct{}.TableName()
	joinTb := models.Customer{}.TableName()
	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	db = db.Join("INNER", joinTb, fmt.Sprintf("%s.id = %s.customer_id", joinTb, curTb))
	if len(params.CustomerIds) > 0 {
		db = db.In("customer_id", params.CustomerIds)
	}

	if params.Cert >= 0 {
		db = db.Where("cert = ?", params.Cert)
	}

	if params.Available >= 0 {
		db = db.Where(fmt.Sprintf("%s.available = ?", curTb), params.Available)
		// db = db.Where("available = ?", params.Available)
	}

	if params.ChannelGroupID > 0 {
		db = db.Where("channel_group_id = ?", params.ChannelGroupID)
	}

	if params.FirstChannelID > 0 {
		db = utils.FindFromArrayCond{Key: "first_channel_ids", Value: params.FirstChannelID}.Cond(db)
	}

	if params.SecondChannelID > 0 {
		db = utils.FindFromArrayCond{Key: "second_channel_ids", Value: params.SecondChannelID}.Cond(db)
	}

	if params.ForbidChannelID > 0 {
		db = utils.FindFromArrayCond{Key: "forbid_channel_ids", Value: params.ForbidChannelID}.Cond(db)
	}

	if len(params.Areas) > 0 {
		db = db.In("product_area", params.Areas)
	}

	if params.Name != "" {
		db = db.Where(fmt.Sprintf("%s.name like ?", curTb), "%"+params.Name+"%")

	}

	if params.Type != "" {
		db = db.Where("product_type = ?", params.Type)
	}

	if params.SubType != "" {
		db = db.Where("product_sub_type = ?", params.SubType)
	}

	if params.Isp >= 0 {
		db = db.Where("product_isp = ?", params.Isp)
	}

	if params.ValueMin > 0 {
		db = db.Where("product_value >= ?", params.ValueMin)
	}

	if params.ValueMax > 0 {
		db = db.Where("product_value <= ?", params.ValueMax)
	}

	res := make([]*models.CustomerProduct, 0)
	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}

/*func (d *CustomerProductDao) QueryCustomerProduct(params vo.CustomerProductQueryParam) (int64, []*models.CustomerProduct, error) {
	db := daos.Mysql.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	if params.CustomerID > 0 {
		db = db.Where("customer_id = ?", params.CustomerID)
	}

	if params.Cert >= 0 {
		db = db.Where("cert = ?", params.Cert)
	}

	if params.Available >= 0 {
		db = db.Where("available = ?", params.Available)
	}

	if params.ChannelGroupID > 0 {
		db = db.Where("channel_group_id = ?", params.ChannelGroupID)
	}

	if params.FirstChannelID > 0 {
		db = utils.FindFromArrayCond{Key: "first_channel_ids", Value: params.FirstChannelID}.Cond(db)
	}

	if params.SecondChannelID > 0 {
		db = utils.FindFromArrayCond{Key: "second_channel_ids", Value: params.SecondChannelID}.Cond(db)
	}

	if params.ForbidChannelID > 0 {
		db = utils.FindFromArrayCond{Key: "forbid_channel_ids", Value: params.ForbidChannelID}.Cond(db)
	}

	curTb := models.CustomerProduct{}.TableName()
	joinTb := models.Product{}.TableName()
	db = db.Join("INNER", joinTb, fmt.Sprintf("%s.id = %s.code", joinTb, curTb))

	if params.Area >= 0 {
		db = db.Where(fmt.Sprintf("%s.area = ? ", joinTb), params.Area)
	}

	if params.Name != "" {
		db = db.Where(fmt.Sprintf("%s.name like ? ", joinTb), "%"+params.Name+"%")
	}

	if params.Type != "" {
		db = db.Where(fmt.Sprintf("%s.big_type = ? ", joinTb), params.Type)
	}

	if params.SubType != "" {
		db = db.Where(fmt.Sprintf("%s.small_type = ? ", joinTb), params.SubType)
	}

	if params.Isp >= 0 {
		db = db.Where(fmt.Sprintf("%s.isp = ?", joinTb), params.Isp)
	}

	if params.ValueMin > 0 {
		db = db.Where(fmt.Sprintf("%s.face_value >= ?", joinTb), params.ValueMin)
	}

	if params.ValueMax > 0 {
		db = db.Where(fmt.Sprintf("%s.face_value <= ?", joinTb), params.ValueMax)
	}

	res := make([]*models.CustomerProduct, 0)
	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}*/

func (d *CustomerProductDao) BatchUpdate(by int64, productIDs []int64, param vo.CustomerProductParam) (int64, error) {
	return 0, nil
}

func (d *CustomerProductDao) BatchSwitch(productIDs []int64, available bool) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	count, err := db.Table((&models.CustomerProduct{}).TableName()).In("id", productIDs).Update(
		map[string]bool{"available": available})

	if err != nil {
		return 0, err
	}

	return count, nil
}

/*func (dao *CustomerProductDao) FromCustmerAndPro(customerID int64, productCode string) (cusProduct models.CustomerProduct, err error) {
	conds := []utils.Cond{
		utils.NewWhereCond("clientid", customerID),
		utils.NewWhereCond("product_code", productCode),
	}
	if err = utils.Find(daos.Mysql.NewSession(), &cusProduct, conds...); err != nil {
		logger.Log.Error("[CustomerProductDao] [FromCustmerAndPro]", zap.Int64("customerID", customerID), zap.String("productCode", productCode), zap.Error(err))
	}
	return
}*/
