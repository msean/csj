package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"fmt"

	"github.com/go-xorm/xorm"
)

type CustomerFinanceDao struct {
}

func NewCustomerFinance() *CustomerFinanceDao {
	return &CustomerFinanceDao{}
}

func (d *CustomerFinanceDao) GetBeanById(id int64) (*models.CustomerFinance, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	bean := models.CustomerFinance{}
	has, err := db.ID(id).Get(&bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return &bean, nil
}

func (d *CustomerFinanceDao) InsertBean(session *xorm.Session, by int64, bean *models.CustomerFinance) error {
	models.Add(by, &bean.Bean)
	_, err := session.Insert(bean)
	if err != nil {
		return err
	}

	return nil
}

func (d *CustomerFinanceDao) UpdateBean(by int64, bean *models.CustomerFinance) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Edit(by, &bean.Bean)
	_, err := db.ID(bean.ID).AllCols().Update(bean)
	if err != nil {
		return err
	}

	return nil
}

func (d *CustomerFinanceDao) FromCustomerOrderIDAndType(customerOrderID string, _type int) (records []models.CustomerFinance, err error) {
	conds := []utils.Cond{
		utils.NewWhereCond("customer_order", customerOrderID),
		utils.NewWhereCond("business_type", _type),
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	err = utils.Find(session, &records, conds...)
	return
}

func (d *CustomerFinanceDao) Query(params vo.CustomerFinanceQueryParam) (int64, []*models.CustomerFinance, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	curTb := models.CustomerFinance{}.TableName()
	joinTb := models.Customer{}.TableName()
	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	db = db.Join("INNER", joinTb, fmt.Sprintf("%s.id = %s.customer_id", joinTb, curTb))
	if params.CustomerID > 0 {
		db = db.Where("customer_id=?", params.CustomerID)
	}

	if params.OrderID != "" {
		db = db.Where("order_id like ?", "%"+params.OrderID+"%")
	}

	if params.CustomerOrder != "" {
		db = db.Where("customer_order=?", params.CustomerOrder)
	}

	if params.BusinessType >= 0 {
		db = db.Where("business_type=?", params.BusinessType)
	}

	if params.Base.StartTime != "" {
		db = db.Where(fmt.Sprintf("%s.created >= ?", curTb), params.Base.StartTime)
	}

	if params.Base.EndTime != "" {
		db = db.Where(fmt.Sprintf("%s.created <= ?", curTb), params.Base.EndTime)
	}

	res := make([]*models.CustomerFinance, 0)
	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}

func (d *CustomerFinanceDao) QueryBalance(params vo.FinanceMonthQueryParams) ([]float64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	objs := make([]*models.CustomerFinance, 0)
	err := db.Where("customer_id = ? ", params.CustomerID).
		Where("created >= ?", params.StartTime).
		Where("created <= ?", params.EndTime).
		Cols("balance").Find(&objs)

	if err != nil {
		return nil, err
	}

	if len(objs) == 0 {
		return []float64{0, 0}, nil
	}

	return []float64{objs[0].Balance, objs[len(objs)-1].Balance}, nil
}

func (d *CustomerFinanceDao) SumByBusinessType(params vo.FinanceMonthQueryParams, businessType []uint8) (float64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	obj := new(models.CustomerFinance)
	sum, err := db.Where("customer_id = ? ", params.CustomerID).
		Where("created >= ?", params.StartTime).
		Where("created <= ?", params.EndTime).
		In("business_type", businessType).Sum(obj, "amount")

	if err != nil {
		return 0, err
	}

	return sum, nil
}

/*func (d *CustomerFinanceDao) DeleteBeanByIds(ids []int64) (int64, error) {
	count, err := daos.Mysql.In("id", ids).Delete(&models.CustomerFinance{})
	if err != nil {
		return 0, err
	}

	return count, nil
}*/
