package partition

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/go-xorm/xorm"
	"go.uber.org/zap"
)

type (
	OrderPartition struct {
		PartitionRule
	}
)

func (p *OrderPartition) Create(session *xorm.Session, order *models.Order) (err error) {

	var orderID int64
	if orderID, err = p.NewID(session); err != nil {
		return
	}

	var table string
	if table, err = p.FindTableByID(orderID); err != nil {
		return
	}

	order.ID = orderID
	_, err = daos.CreateObjs(session.Table(table), order)
	return
}

func (p *OrderPartition) FromID(session *xorm.Session, id int64) (order models.Order, has bool, err error) {
	var table string
	if table, err = p.FindTableByID(id); err != nil {
		return
	}
	has, err = utils.Get(session.Table(table), &order, utils.IDCond(id))
	return
}

func (p *OrderPartition) SyncObj() any {
	return &models.Order{}
}

func (p *OrderPartition) SchedulerTable() (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	now := time.Now()

	if p.Sync(session, now, p.SyncObj()); err != nil {
		logger.Log.Error("SchedulerTable1", zap.Error(err))
		return
	}
	if p.Sync(session, p.NextDate(now), p.SyncObj()); err != nil {
		logger.Log.Error("SchedulerTable1", zap.Error(err))
	}
	return
}

func (p *OrderPartition) List(params vo.OrderListParam) (orders []models.Order, total int64, err error) {
	var conds []string
	var args []interface{}

	if !params.Base.StartTime.IsZero() {
		conds = append(conds, "created >=?")
		args = append(args, params.Base.StartTime)
	}
	if !params.Base.EndTime.IsZero() {
		conds = append(conds, "created <=?")
		args = append(args, params.Base.EndTime)
	}

	if params.CustomerChoice != 0 {
		conds = append(conds, "customer_id = ?")
		args = append(args, params.CustomerChoice)
	}
	if params.CurrentChannelChoice != 0 {
		conds = append(conds, "current_channel_id = ?")
		args = append(args, params.CurrentChannelChoice)
	}
	if params.CustomerOrderSearch != "" {
		conds = append(conds, "customer_order_id LIKE ?")
		args = append(args, "%"+params.CustomerOrderSearch+"%")
	}
	if params.OrderIDSearch != "" {
		conds = append(conds, "id LIKE ?")
		args = append(args, "%"+params.OrderIDSearch+"%")
	}
	if params.IsReturnChoice != 0 {
		conds = append(conds, "has_returned = ?")
		args = append(args, params.IsReturnChoice)
	}
	if params.PhoneSearch != "" {
		conds = append(conds, "phone LIKE ?")
		args = append(args, "%"+params.PhoneSearch+"%")
	}
	if params.BigTypeSearch != 0 {
		conds = append(conds, "big_type = ?")
		args = append(args, params.BigTypeSearch)
	}
	if params.SmallTypeSearch != 0 {
		conds = append(conds, "small_type = ?")
		args = append(args, params.SmallTypeSearch)
	}
	if params.IspSearch != 0 {
		conds = append(conds, "isp = ?")
		args = append(args, params.IspSearch)
	}
	if params.FaceValueLower > 0 {
		conds = append(conds, "face_value >= ?")
		args = append(args, params.FaceValueLower)
	}
	if params.FaceValueUpper > 0 {
		conds = append(conds, "face_value <= ?")
		args = append(args, params.FaceValueUpper)
	}
	if params.AreaChoice >= 0 {
		areaCode := constant.AreaCodeStringM[params.AreaChoice]
		if areaCode != "" {
			conds = append(conds, "area = ?")
			args = append(args, areaCode)
		}
	}
	if params.RemarkSearch != "" {
		conds = append(conds, "remark LIKE ?")
		args = append(args, "%"+params.RemarkSearch+"%")
	}
	if params.ManualRemarkSearch != "" {
		conds = append(conds, "manual_remark LIKE ?")
		args = append(args, "%"+params.ManualRemarkSearch+"%")
	}
	if params.StatusChoice != 0 {
		if params.StatusChoice == constant.OrderStatusNoResult {
			conds = append(conds, "status IN (?, ?, ?)")
			args = append(args, constant.OrderStatusInit, constant.OrderStatusHandle, constant.OrderStatusSuspect)
		} else {
			conds = append(conds, "status = ?")
			args = append(args, params.StatusChoice)
		}
	}
	if params.BackStatusChoice != 0 {
		conds = append(conds, "current_back_status = ?")
		args = append(args, params.BackStatusChoice)
	}
	if !params.BackTimeStart.IsZero() {
		conds = append(conds, "current_back_time >= ?")
		args = append(args, params.BackTimeStart)
	}
	if !params.BackTimeEnd.IsZero() {
		conds = append(conds, "current_back_time <= ?")
		args = append(args, params.BackTimeEnd)
	}
	if params.IsSlowChoice != 0 {
		conds = append(conds, "is_slow = ?")
		args = append(args, params.IsSlowChoice)
		conds = append(conds, "status IN (?, ?)")
		args = append(args, constant.OrderStatusInit, constant.OrderStatusHandle)
	}
	if len(params.IDList) != 0 {
		ids := strings.Trim(strings.Join(strings.Fields(fmt.Sprint(params.IDList)), ","), "[]")
		conds = append(conds, fmt.Sprintf("id IN (%s)", ids))
	}

	if len(params.InStatusChoice) > 0 {
		placeholders := strings.Repeat("?,", len(params.InStatusChoice))
		placeholders = placeholders[:len(placeholders)-1]
		conds = append(conds, fmt.Sprintf("status IN (%s)", placeholders))
		for _, status := range params.InStatusChoice {
			args = append(args, status)
		}
	}
	// 获取分区表列表
	session := daos.Mysql.NewSession()
	defer session.Close()

	var tables []string
	tables, err = p.GetTablesByDateRange(session, params.Base.StartTime, params.Base.EndTime)
	if err != nil {
		return
	}
	if len(tables) == 0 {
		return nil, 0, nil
	}

	// 构造 UNION ALL 查询
	unionQueries := []string{}
	finalArgs := []interface{}{}
	for _, table := range tables {
		tableQuery := fmt.Sprintf("SELECT * FROM %s", table)

		if len(conds) > 0 {
			tableQuery += " WHERE " + strings.Join(conds, " AND ")
		}

		unionQueries = append(unionQueries, tableQuery)
		finalArgs = append(finalArgs, args...)
	}

	unionSQL := strings.Join(unionQueries, " UNION ALL ")

	if !params.NoWithCount {
		countSQL := fmt.Sprintf("SELECT COUNT(*) FROM (%s) AS total_count", unionSQL)
		if _, err = session.SQL(countSQL, finalArgs...).Get(&total); err != nil {
			return
		}
	}

	if params.Base.PageNum != 0 {
		if params.Base.PageSize == 0 {
			params.Base.PageSize = 10
		}

		unionSQL += " ORDER BY created DESC LIMIT ? OFFSET ?"
		finalArgs = append(finalArgs, params.Base.PageSize, params.Base.PageSize*(params.Base.PageNum-1))
	}

	if err = session.SQL(unionSQL, finalArgs...).Find(&orders); err != nil {
		return
	}

	return
}

func (p *OrderPartition) CustomerStuckQry(session *xorm.Session, statuses ...int) (orderStuckList []models.OrderStuckInfo, err error) {

	end := time.Now().Add(-48 * time.Hour)
	start := time.Now().AddDate(0, -1, 0)
	var orders []models.Order
	orders, _, _ = p.List(vo.OrderListParam{
		Base: utils.LimitCond{
			StartTime: start,
			EndTime:   end,
		},
		InStatusChoice: statuses,
		NoWithCount:    true,
	})
	for _, order := range orders {
		orderStuckList = append(orderStuckList, models.OrderStuckInfo{
			Type:          1,
			OrderID:       order.ID,
			CustomerID:    order.CustomerID,
			CurrentStatus: int(order.Status),
			OrderTime:     order.Created,
		})
	}
	return
}

func (p *OrderPartition) UpdateReturn(session *xorm.Session, IDList []int64) (affect int64, err error) {

	for _, id := range IDList {
		conds := []utils.Cond{
			utils.NewWhereCond("id", id),
			utils.NewWhereCond("has_returned", 1),
			utils.NewWhereCond("is_slow", 2),
		}

		var table string
		if table, err = p.FindTableByID(id); err == nil {
			if _, err = utils.Update(session.Table(table), map[string]any{"has_returned": 2}, conds...); err == nil {
				affect += 1
			}
		}
	}
	return
}

func (p *OrderPartition) UnscopeDelete(orderID int64, customerOrderID string, withCustomerOrderMapper bool) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	var table string
	if table, err = p.FindTableByID(orderID); err != nil {
		return
	}
	_, err = session.Exec(fmt.Sprintf("DELETE FROM %s WHERE id = ?", table), orderID)
	if err != nil {
		return err
	}

	if withCustomerOrderMapper {
		_, err = session.Exec(fmt.Sprintf("DELETE FROM %s WHERE customer_order_id = ?", models.CustomerOrderDateMapper{}.TableName()), customerOrderID)

	}
	return
}

func (p *OrderPartition) UpdateCurrentChannel(session *xorm.Session, orderID int64, channelID int64, inPrice float64) (err error) {
	var table string
	if table, err = p.FindTableByID(orderID); err != nil {
		return
	}
	_, err = utils.Update(session.Table(table), map[string]any{
		"current_channel_id": channelID,
		"status":             constant.OrderStatusHandle,
		"in_price":           inPrice,
	}, utils.NewInCond("id", orderID))
	return
}

func (p *OrderPartition) UpdateIsp(session *xorm.Session, id int64, isp int) (err error) {
	var table string
	if table, err = p.FindTableByID(id); err != nil {
		return
	}
	conds := []utils.Cond{
		utils.IDCond(id),
		utils.NewWhereCond("status", 1),
	}
	_, err = utils.Update(session.Table(table), map[string]interface{}{"isp": isp}, conds...)
	return
}

func (p *OrderPartition) UpdateRemark(session *xorm.Session, id int64, manualRemark string) (err error) {
	var orderModel models.Order
	var has bool
	var table string
	if table, err = p.FindTableByID(id); err != nil {
		return
	}
	has, err = utils.IDCond(id).Cond(session.Table(table)).Get(&orderModel)
	if !has {
		return errors.New("record not found")
	}

	if err != nil {
		return
	}
	_, err = utils.Update(session.Table(table), map[string]interface{}{"manual_remark": fmt.Sprintf("%s <%s>", manualRemark, time.Now().Format("06-01-02 15:04:05"))}, utils.IDCond(id))
	return
}

func (p *OrderPartition) ModifyStatus(session *xorm.Session, order models.Order, status int64, extra map[string]any) (err error) {
	var table string
	if table, err = p.FindTableByID(order.ID); err != nil {
		return
	}

	updates := map[string]interface{}{
		"status": status,
	}
	if len(extra) != 0 {
		for k, v := range extra {
			value := v
			if k == "remark" {
				if utils.IsBlankString(order.Remark) {
					value = fmt.Sprintf("%s:%s", time.Now().Format("2006-01-02 15:04:05"), v)
				} else {
					value = fmt.Sprintf("%s;%s:%s", order.Remark, time.Now().Format("2006-01-02 15:04:05"), v)
				}

			}
			updates[k] = value
		}
	}

	_, err = utils.Update(session.Table(table), updates, utils.IDCond(order.ID))
	return
}

func (p *OrderPartition) GetPhoneLatest(phone string, start time.Time) (order models.Order, has bool, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var orders []models.Order
	orders, _, err = p.List(vo.OrderListParam{
		Base: utils.LimitCond{
			StartTime: start,
		},
		PhoneSearch: phone,
		NoWithCount: true,
	})

	if err != nil {
		return
	}

	if len(orders) > 0 {
		order = orders[0]
		has = true
	}

	// has, err = utils.Get(session, &order, utils.NewWhereCond("phone", phone), utils.NewOrderByCond("created desc"))
	return
}

func (p *OrderPartition) ReplaceProductCode(productCode string,
	orderID int64,
	province,
	area string) (err error) {

	var table string
	if table, err = p.FindTableByID(orderID); err != nil {
		return
	}
	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = utils.Update(session.Table(table), map[string]any{
		"product_code": productCode,
		"area":         area,
		"province":     province,
	}, utils.IDCond(orderID))
	return
}

func (p *OrderPartition) Update(session *xorm.Session, order models.Order, extra map[string]any) (err error) {
	if len(extra) == 0 {
		return
	}

	var table string
	if table, err = p.FindTableByID(order.ID); err != nil {
		return
	}

	updates := make(map[string]any)
	for k, v := range extra {
		value := v
		if k == "remark" {
			if utils.IsBlankString(order.Remark) {
				value = fmt.Sprintf("%s:%s", time.Now().Format("2006-01-02 15:04:05"), v)
			} else {
				value = fmt.Sprintf("%s;%s:%s", order.Remark, time.Now().Format("2006-01-02 15:04:05"), v)
			}

		}
		updates[k] = value
	}

	_, err = utils.Update(session.Table(table), updates, utils.IDCond(order.ID))
	return
}

func (p *OrderPartition) UpdateCallback(session *xorm.Session,
	order models.Order,
	channelOrder models.ChannelOrder,
	callbackStatus uint,
	callbackMsg string) (err error) {
	var table string
	if table, err = p.FindTableByID(order.ID); err != nil {
		return
	}
	order.BackStatus = append(order.BackStatus, callbackStatus)
	order.BackMsg = append(order.BackMsg, callbackMsg)
	order.BackTime = append(order.BackTime, time.Now())
	order.CurrentBackStatus = callbackStatus
	order.CurrentBackTime = time.Now()

	// 将切片转换成 JSON 字符串
	backStatusJSON, _ := json.Marshal(order.BackStatus)
	backMsgJSON, _ := json.Marshal(order.BackMsg)
	backTimeJSON, _ := json.Marshal(order.BackTime)

	_, err = session.Table(table).Where("id = ?", order.ID).Update(map[string]any{
		"back_status":         string(backStatusJSON),
		"back_msg":            string(backMsgJSON),
		"back_time":           string(backTimeJSON),
		"current_back_status": callbackStatus,
		"current_back_time":   order.CurrentBackTime,
	})

	if channelOrder.ID != 0 {
		channelOrder.BackStatus = append(channelOrder.BackStatus, callbackStatus)
		channelOrder.BackMsg = append(channelOrder.BackMsg, callbackMsg)
		channelOrder.BackTime = append(channelOrder.BackTime, time.Now())
		channelOrder.CurrentBackStatus = callbackStatus
		channelOrder.CurrentBackTime = time.Now()

		_, err = session.Table(table).Where("id = ?", channelOrder.ID).Update(map[string]any{
			"back_status":         string(backStatusJSON),
			"back_msg":            string(backMsgJSON),
			"back_time":           string(backTimeJSON),
			"current_back_status": callbackStatus,
			"current_back_time":   channelOrder.CurrentBackTime,
		})
	}
	return
}

func (p *OrderPartition) FromIDList(session *xorm.Session, idList []int64) (orderMapper map[int64]models.Order, err error) {
	orderMapper = make(map[int64]models.Order)
	for _, id := range idList {
		var table string
		if table, err = p.FindTableByID(id); err != nil {
			continue
		}
		var order models.Order
		utils.Get(session.Table(table), &order, utils.NewInCond("id", idList))
	}
	// var orders []models.Order
	// utils.Find(session.Table(models.Order{}.TableName()),
	// 	&orders,
	// 	utils.NewInCond("id", idList))
	// for _, order := range orders {
	// 	orderMapper[order.ID] = order
	// }
	return
}

func (p *OrderPartition) FromCustomerOrderID(session *xorm.Session, customerOrderID string, start time.Time) (order models.Order, has bool, err error) {
	var result models.CustomerOrderDateMapper
	has, err = session.Table(result.TableName()).Where("customer_order_id = ?", customerOrderID).Get(&result)
	if err != nil {
		return
	}
	if has {
		var table string
		if table = p.TableNameByDate(result.Date); table == "" {
			err = fmt.Errorf("can not find record")
			return
		}
		has, err = session.Table(table).Where("customer_order_id = ?", customerOrderID).Get(&order)
		if err != nil {
			return
		}
	}
	// var orders []models.Order
	// orders, _, err = p.List(vo.OrderListParam{
	// 	Base: utils.LimitCond{
	// 		StartTime: start,
	// 	},
	// 	CustomerOrderSearch: customerOrderID,
	// 	NoWithCount:         true,
	// })

	// if err != nil {
	// 	return
	// }

	// if len(orders) > 0 {
	// 	order = orders[0]
	// 	has = true
	// 	return
	// }

	// has, err = utils.Get(session.Table(models.Order{}.TableName()), &order, utils.NewWhereCond("customer_order_id", customerOrderID))
	return
}
