package partition

import (
	"application/utils"
	"fmt"
	"strconv"
	"testing"
	"time"
)

func TestPartition(t *testing.T) {
	tests := []struct {
		name     string
		rules    PartitionRule
		date     time.Time
		expected string
	}{
		{
			name: "Test by Month Partition with Range 7",
			rules: PartitionRule{
				Type:        PartitionTypeMonth,
				Range:       7,
				TablePrefix: "xj_blacklist",
			},
			date:     time.Date(2025, time.September, 1, 0, 0, 0, 0, time.UTC),
			expected: "xj_blacklist_202508_202512", // 2025年9月
		},
		{
			name: "Test by Day Partition with Range 7",
			rules: PartitionRule{
				Type:        PartitionTypeDay,
				Range:       7,
				TablePrefix: "xj_blacklist",
			},
			date:     time.Date(2025, time.September, 2, 0, 0, 0, 0, time.UTC),
			expected: "xj_blacklist_20250901_20250907", // 2025年9月2日
		},
		{
			name: "Test by Day Partition with Range 7, end of month",
			rules: PartitionRule{
				Type:        PartitionTypeDay,
				Range:       7,
				TablePrefix: "xj_blacklist",
			},
			date:     time.Date(2025, time.September, 30, 0, 0, 0, 0, time.UTC),
			expected: "xj_blacklist_20250929_20250930", // 2025年9月30日
		},
		{
			name: "Test by Year Partition with Range 5",
			rules: PartitionRule{
				Type:        PartitionTypeYear,
				Range:       5,
				TablePrefix: "xj_blacklist",
			},
			date:     time.Date(2025, time.January, 1, 0, 0, 0, 0, time.UTC),
			expected: "xj_blacklist_2025_2030", // 2025年
		},
	}

	// Loop through each test case
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			actual := tt.rules.TableNameByDate(tt.date)
			if actual != tt.expected {
				t.Logf("actual: %s, expected: %s", actual, tt.expected)
			}
		})
	}
}

func TestSnowFlake(t *testing.T) {
	epoch := time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC)
	sf, err := utils.NewSnowflake(epoch, 1)
	fmt.Println(sf, err)
	id, err := sf.GenerateID()
	if err != nil {
		panic(err)
	}
	fmt.Println(id, strconv.FormatInt(id, 2))

	generatedTime := sf.ExtractTimeByID(id)
	fmt.Printf("Generated Time: %s\n", generatedTime.Format("2006-01-02 15:04:05.000"))
}
