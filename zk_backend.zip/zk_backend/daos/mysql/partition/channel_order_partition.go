package partition

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/go-xorm/xorm"
	"go.uber.org/zap"
)

type (
	ChannelOrderPartition struct {
		PartitionRule
	}
)

func (p *ChannelOrderPartition) SyncObj() any {
	return &models.ChannelOrder{}
}

func (p *ChannelOrderPartition) SchedulerTable() (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	now := time.Now()

	if p.Sync(session, now, p.SyncObj()); err != nil {
		logger.Log.Error("SchedulerTable1", zap.Error(err))
		return
	}
	if p.Sync(session, p.NextDate(now), p.SyncObj()); err != nil {
		logger.Log.Error("SchedulerTable1", zap.Error(err))
	}
	return
}
func (p *ChannelOrderPartition) List(params vo.ChannelOrderListParam) (orders []models.ChannelOrder, total int64, err error) {
	conds := []string{}
	args := []interface{}{}

	if !params.Base.StartTime.IsZero() {
		conds = append(conds, "created >=?")
		args = append(args, params.Base.StartTime)
	}
	if !params.Base.EndTime.IsZero() {
		conds = append(conds, "created <=?")
		args = append(args, params.Base.EndTime)
	}
	// 构造查询条件
	if params.CustomerChoice != 0 {
		conds = append(conds, "customer_id = ?")
		args = append(args, params.CustomerChoice)
	}
	if params.ChannelChoice != 0 {
		conds = append(conds, "channel_id = ?")
		args = append(args, params.ChannelChoice)
	}
	if params.SrcID != 0 {
		conds = append(conds, "id like ?")
		args = append(args, fmt.Sprintf("%%%d%%", params.SrcID))
	}
	if !utils.IsBlankString(params.OrderIDSearch) {
		conds = append(conds, "order_id = ?")
		args = append(args, params.OrderIDSearch)
	}
	if !utils.IsBlankString(params.PhoneSearch) {
		conds = append(conds, "phone = ?")
		args = append(args, params.PhoneSearch)
	}
	if params.IspChoice != 0 {
		conds = append(conds, "isp = ?")
		args = append(args, params.IspChoice)
	}
	if params.BigTypeSearch != 0 {
		conds = append(conds, "big_type = ?")
		args = append(args, params.BigTypeSearch)
	}
	if params.SmallTypeSearch != 0 {
		conds = append(conds, "small_type = ?")
		args = append(args, params.SmallTypeSearch)
	}
	if params.FaceValueLower > 0 {
		conds = append(conds, "face_value >= ?")
		args = append(args, params.FaceValueLower)
	}
	if params.FaceValueUpper > 0 {
		conds = append(conds, "face_value <= ?")
		args = append(args, params.FaceValueUpper)
	}
	if params.AreaChoice >= 0 {
		areaCode := constant.AreaCodeStringM[params.AreaChoice]
		if !utils.IsBlankString(areaCode) {
			conds = append(conds, "area = ?")
			args = append(args, areaCode)
		}
	}
	if !utils.IsBlankString(params.RemarkSearch) {
		conds = append(conds, "remark LIKE ?")
		args = append(args, fmt.Sprintf("%%%s%%", params.RemarkSearch))
	}
	if len(params.IDList) > 0 {
		idPlaceholders := strings.Repeat("?,", len(params.IDList))
		conds = append(conds, fmt.Sprintf("id IN (%s)", idPlaceholders[:len(idPlaceholders)-1]))
		args = append(args, utils.SliceToAny(params.IDList)...)
	}
	if params.StatusChoice != 0 {
		if params.StatusChoice == constant.OrderStatusNoResult {
			conds = append(conds, "status IN (?, ?, ?)")
			args = append(args, constant.OrderStatusInit, constant.OrderStatusHandle, constant.OrderStatusSuspect)
		} else {
			conds = append(conds, "status = ?")
			args = append(args, params.StatusChoice)
		}
	}
	if !params.BackTimeStart.IsZero() {
		conds = append(conds, "current_back_time >= ?")
		args = append(args, params.BackTimeStart.Local())
	}
	if !params.BackTimeEnd.IsZero() {
		conds = append(conds, "current_back_time <= ?")
		args = append(args, params.BackTimeEnd.Local())
	}

	if params.Base.StartTime.IsZero() {
		params.Base.StartTime = time.Now().AddDate(0, -6, 0)
	}

	if len(params.InStatusChoice) > 0 {
		placeholders := strings.Repeat("?,", len(params.InStatusChoice))
		placeholders = placeholders[:len(placeholders)-1]
		conds = append(conds, fmt.Sprintf("status IN (%s)", placeholders))
		for _, status := range params.InStatusChoice {
			args = append(args, status)
		}
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	var tables []string
	tables, err = p.GetTablesByDateRange(session, params.Base.StartTime, params.Base.EndTime)
	if err != nil {
		return
	}
	if len(tables) == 0 {
		return
	}

	unionQueries := []string{}
	allArgs := []interface{}{}
	for _, table := range tables {
		tableConds := append([]string(nil), conds...)
		tableArgs := append([]interface{}(nil), args...)

		query := fmt.Sprintf("SELECT * FROM %s", table)
		if len(tableConds) > 0 {
			query += " WHERE " + strings.Join(tableConds, " AND ")
		}
		unionQueries = append(unionQueries, query)
		allArgs = append(allArgs, tableArgs...)
	}

	unionSQL := strings.Join(unionQueries, " UNION ALL ")

	if !params.NoWithCount {
		countSQL := fmt.Sprintf("SELECT COUNT(*) FROM (%s) AS total_count", unionSQL)
		var has bool
		if has, err = session.SQL(countSQL, allArgs...).Get(&total); err != nil {
			return nil, 0, err
		}
		if !has {
			total = 0
		}
	}

	if params.Base.PageNum != 0 {
		if params.Base.PageSize == 0 {
			params.Base.PageSize = 10
		}

		unionSQL += " ORDER BY created DESC LIMIT ? OFFSET ?"
		allArgs = append(allArgs, params.Base.PageSize, params.Base.PageSize*(params.Base.PageNum-1))
	}

	if err := session.SQL(unionSQL, allArgs...).Find(&orders); err != nil {
		return nil, 0, err
	}

	return
}

func (p *ChannelOrderPartition) ChannelStuckQry(session *xorm.Session, statuses ...int) (orderStuckList []models.OrderStuckInfo, err error) {
	end := time.Now().Add(-48 * time.Hour)
	start := time.Now().AddDate(0, -1, 0)
	var channelOrders []models.ChannelOrder
	channelOrders, _, err = p.List(vo.ChannelOrderListParam{
		Base: utils.LimitCond{
			StartTime: start,
			EndTime:   end,
		},
		InStatusChoice: statuses,
		NoWithCount:    true,
	})
	if err != nil {
		return
	}
	for _, order := range channelOrders {
		orderStuckList = append(orderStuckList, models.OrderStuckInfo{
			OrderID:          order.OrderID,
			CustomerID:       order.CustomerID,
			CurrentStatus:    int(order.Status),
			OrderTime:        order.OrderTime,
			ChannelOrderTime: order.Created,
			ChannelID:        order.ChannelID,
			ChannelOrderID:   order.ID,
			Type:             2,
		})
	}

	return
}

func (dao *ChannelOrderPartition) UpdateIsp(session *xorm.Session, id int64, isp int) (err error) {
	var table string
	if table, err = dao.FindTableByID(id); err != nil {
		return
	}
	conds := []utils.Cond{
		utils.IDCond(id),
		utils.NewWhereCond("status", 0),
	}
	updates := map[string]any{"isp": isp}
	_, err = utils.Update(session.Table(table), updates, conds...)
	return
}

func (dao *ChannelOrderPartition) UpdateRemark(session *xorm.Session, id int64, Remark string) (err error) {
	var orderModel models.ChannelOrder
	var has bool
	var table string
	if table, err = dao.FindTableByID(id); err != nil {
		return
	}
	has, err = utils.IDCond(id).Cond(session.Table(table)).Get(&orderModel)
	if !has {
		return errors.New("record not found")
	}

	if err != nil {
		return
	}

	remark := append(orderModel.Remark, models.RemarkRecord{
		RemarkTime: time.Now(),
		Remark:     Remark,
	})
	_, err = utils.Update(session.Table(table), map[string]any{"remark": remark}, utils.IDCond(id))
	return
}

func (dao *ChannelOrderPartition) ModifyStatus(session *xorm.Session, channelOrder models.ChannelOrder, status int64, extra map[string]any) (err error) {
	updates := map[string]interface{}{
		"status": status,
	}

	if len(extra) != 0 {
		for k, v := range extra {
			value := v
			if k == "remark" {
				if remarkV, ok := v.(string); ok {
					remarkValue := append(channelOrder.Remark, models.RemarkRecord{
						RemarkTime: time.Now(),
						Remark:     remarkV,
					})
					if value, err = json.Marshal(remarkValue); err != nil {
						return
					}
				}
			}
			updates[k] = value
		}
	}
	var table string
	if table, err = dao.FindTableByID(channelOrder.ID); err != nil {
		return
	}
	_, err = utils.Update(session.Table(table), updates, utils.IDCond(channelOrder.ID))
	return
}

func (dao *ChannelOrderPartition) FromID(session *xorm.Session, id int64) (channelOrder models.ChannelOrder, has bool, err error) {
	var table string
	// if table, err = p.FindTableByID(id); err != nil {
	// 	return
	// }
	// var table string
	// var orders []models.ChannelOrder
	// orders, _, _ = dao.List(vo.ChannelOrderListParam{
	// 	Base: utils.LimitCond{
	// 		StartTime: time.Now().AddDate(0, -6, 0),
	// 	},
	// 	SrcID:       id,
	// 	NoWithCount: true,
	// })
	// if len(orders) == 0 {
	// 	err = fmt.Errorf("订单异常")
	// 	return
	// } else {
	// 	channelOrder = orders[0]
	// 	has = true
	// }

	if table, err = dao.FindTableByID(id); err != nil {
		return
	}
	has, err = utils.Get(session.Table(table), &channelOrder, utils.IDCond(id))
	return
}

// toModifyOrder 是否需要去改变订单状态，当是最后一个渠道而且分发失败的时候需要更改订单的状态
func (dao *ChannelOrderPartition) Fail(session *xorm.Session,
	channelOrder models.ChannelOrder,
	extraChannelOrderUpdate map[string]any,
	extraOrderUpdate map[string]any,
	toModifyOrder bool) (err error) {

	if len(extraChannelOrderUpdate) != 0 {
		extraChannelOrderUpdate["finish_time"] = time.Now().Local()
	} else {
		extraChannelOrderUpdate = map[string]any{
			"finish_time": time.Now().Local(),
		}
	}
	extraChannelOrderUpdate["finish_time"] = time.Now().Local()
	if err = dao.ModifyStatus(session, channelOrder, constant.OrderStatusFail, extraChannelOrderUpdate); err != nil {
		return
	}

	if !toModifyOrder {
		return
	}

	if len(extraOrderUpdate) != 0 {
		extraOrderUpdate["finish_time"] = time.Now().Local()
	} else {
		extraOrderUpdate = map[string]any{
			"finish_time": time.Now().Local(),
		}
	}
	GlobalOrderPartition.ModifyStatus(session,
		models.Order{BeanShard: models.BeanShard{
			ID: channelOrder.OrderID,
		}}, constant.OrderStatusFail, extraOrderUpdate)
	return
}

func (dao *ChannelOrderPartition) Success(session *xorm.Session,
	channelOrder models.ChannelOrder,
	extraChannelOrderUpdate map[string]any,
	extraOrderUpdate map[string]any,
) (err error) {

	if len(extraChannelOrderUpdate) != 0 {
		extraChannelOrderUpdate["finish_time"] = time.Now().Local()
	} else {
		extraChannelOrderUpdate = map[string]any{
			"finish_time": time.Now().Local(),
		}
	}
	if err = dao.ModifyStatus(session, channelOrder, constant.OrderStatusSuccess, extraChannelOrderUpdate); err != nil {
		return
	}

	if len(extraOrderUpdate) != 0 {
		extraOrderUpdate["finish_time"] = time.Now().Local()
	} else {
		extraOrderUpdate = map[string]any{
			"finish_time": time.Now().Local(),
		}
	}
	GlobalOrderPartition.ModifyStatus(session, models.Order{
		BeanShard: models.BeanShard{
			ID: channelOrder.OrderID,
		},
	}, constant.OrderStatusSuccess, extraOrderUpdate)
	return
}

func (dao *ChannelOrderPartition) Create(session *xorm.Session, channelOrder *models.ChannelOrder) (err error) {
	var table string
	if table, err = dao.FindTableByID(channelOrder.ID); err != nil {
		return
	}
	_, err = utils.Create(session.Table(table), channelOrder)
	return
}

func (dao *ChannelOrderPartition) UpdateFields(session *xorm.Session, channelOrderID int64, fields map[string]any) (err error) {
	var table string
	if table, err = dao.FindTableByID(channelOrderID); err != nil {
		return
	}
	_, err = utils.Update(session.Table(table), fields, utils.IDCond(channelOrderID))
	return
}

func (dao *ChannelOrderPartition) UnscopeDelete(channelOrderID int64) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	var table string
	if table, err = dao.FindTableByID(channelOrderID); err != nil {
		return
	}
	_, err = session.Exec(fmt.Sprintf("DELETE FROM %s WHERE id = ?", table), channelOrderID)
	if err != nil {
		return err
	}
	return
}
