package partition

import (
	"application/common/logger"
	"application/daos"
	"application/models"
	"application/utils"
	"fmt"
	"strings"
	"time"

	"github.com/go-xorm/xorm"
	"go.uber.org/zap"
)

var (
	PartitionTypeYear  = 1 // 按照年分
	PartitionTypeMonth = 2 // 按照月份
	PartitionTypeDay   = 3 // 按照日分
)

type (
	SyncObjInterface interface {
		SyncObj() any
	}
	IDGeneratorInterface interface {
		GenerateID() (int64, error)
		ExtractTimeByID(int64) time.Time
	}
)

var (
	OrderPartitionRule        OrderPartition
	ChannelOrderPartitionRule = PartitionRule{
		Type:        PartitionTypeDay,
		Range:       8,
		TablePrefix: models.ChannelOrder{}.TableName(),
	}
)

var (
	GlobalOrderPartition        OrderPartition
	GlobalChannelOrderPartition ChannelOrderPartition
)

type (
	PartitionRule struct {
		Type        int //  年 / 月 /日
		Range       int //  几天
		TablePrefix string
		IDGenerator IDGeneratorInterface
	}
)

func (p PartitionRule) TableNameByDate(date time.Time) string {
	switch p.Type {
	case PartitionTypeYear:
		div := date.Year() / p.Range
		return fmt.Sprintf("%s_%d_%d", p.TablePrefix, div*p.Range, (div+1)*p.Range)

	case PartitionTypeMonth:
		year := date.Year()
		month := date.Month()

		div := (int(month) - 1) / p.Range
		startMonth := div*p.Range + 1
		endMonth := (div + 1) * p.Range

		if endMonth > 12 {
			endMonth = 12
		}

		return fmt.Sprintf("%s_%d%02d_%d%02d", p.TablePrefix, year, startMonth, year, endMonth)

	case PartitionTypeDay:
		year, month, day := date.Year(), date.Month(), date.Day()

		div := (day - 1) / p.Range
		startDay := div*p.Range + 1
		endDay := (div + 1) * p.Range

		monthDays := utils.MonthDays(year, int(month))

		if endDay > monthDays {
			endDay = monthDays
		}

		return fmt.Sprintf("%s_%d%02d%02d_%d%02d%02d", p.TablePrefix, year, month, startDay, year, month, endDay)
	}

	return ""
}

func (p PartitionRule) NextDate(date time.Time) time.Time {
	switch p.Type {
	case PartitionTypeYear:
		return date.AddDate(p.Range, 0, 0)

	case PartitionTypeMonth:
		return date.AddDate(0, p.Range, 0)

	case PartitionTypeDay:
		return date.AddDate(0, 0, p.Range)
	}

	return date
}

func (p PartitionRule) PkIncreaseTable() string {
	return fmt.Sprintf("auto_increase_%s", p.TablePrefix)
}

func (p PartitionRule) ProcedureFuncName() string {
	return fmt.Sprintf("procedure_func_%s", p.TablePrefix)
}

func (p PartitionRule) NewID(session *xorm.Session) (newID int64, err error) {

	// _, err := session.Exec(fmt.Sprintf("CALL %s(@new_id)", p.ProcedureFuncName()))

	// if err != nil {
	// 	return 0, fmt.Errorf("failed to generate order ID: %w", err)
	// }

	// session.SQL("SELECT @new_id").Get(&newOrderID)
	// if err != nil {
	// 	return 0, fmt.Errorf("failed to query new_id: %w", err)
	// }

	// spew.Dump(">>>>>>>>>>GenerateID", newOrderID, err)

	// err = daos.RawMysql.QueryRow(fmt.Sprintf("CALL %s(@new_id)", p.ProcedureFuncName())).Scan(&newID)
	// if err != nil {
	// 	return 0, fmt.Errorf("failed to generate order ID: %w", err)
	// }

	// spew.Dump(">>>>>>>>>>newOrderID", newID)
	// return SnakeFlake.GenerateID()
	return p.IDGenerator.GenerateID()
}

func (p PartitionRule) FindTableByID(id int64) (string, error) {
	// idStr := fmt.Sprintf("%d", id)

	// if len(idStr) < 8 {
	// 	return "", fmt.Errorf("invalid ID: %d", id)
	// }

	// dateStr := idStr[:8]
	// generatedTime := p.IDGenerator.ExtractTimeByID(id)
	// date, err := time.Parse("20060102", dateStr)
	// if err != nil {
	// 	return "", fmt.Errorf("failed to parse date from ID: %w", err)
	// }

	tableName := p.TableNameByDate(p.IDGenerator.ExtractTimeByID(id))
	return tableName, nil
}

// func (p PartitionRule) InitProcedure(session *xorm.Session) (err error) {
// 	createTableSQL := fmt.Sprintf(
// 		`CREATE TABLE IF NOT EXISTS %s (
// 	    	id_date DATE NOT NULL PRIMARY KEY,
// 	    	current_number INT NOT NULL
// 		);`, p.PkIncreaseTable(),
// 	)
// 	if _, err = session.Exec(createTableSQL); err != nil {
// 		return
// 	}

// 	logger.Log.Info("InitProcedure success",
// 		zap.String("procedureTable", p.PkIncreaseTable()))

// 	var count int
// 	var has bool
// 	if has, err = session.SQL(fmt.Sprintf(
// 		`SELECT COUNT(*)
// 			FROM information_schema.ROUTINES
// 			WHERE ROUTINE_SCHEMA = DATABASE()
// 			AND ROUTINE_NAME = '%s'
// 			AND ROUTINE_TYPE = 'PROCEDURE'`, p.ProcedureFuncName()),
// 	).Get(&count); err != nil {
// 		return
// 	}
// 	if !has || count == 0 {
// 		createProcSQL := fmt.Sprintf(
// 			`
// 			CREATE PROCEDURE %s(out new_id BIGINT)
// 			BEGIN
// 				DECLARE today_date CHAR(8);
// 				DECLARE sequence_number INT;

// 				SET today_date = DATE_FORMAT(CURDATE(), '%%Y%%m%%d');
// 				INSERT INTO %s (id_date, current_number)
// 				VALUES (CURDATE(), 1)
// 				ON DUPLICATE KEY UPDATE current_number = current_number + 1;

// 				SELECT current_number INTO sequence_number
// 				FROM %s
// 				WHERE id_date = CURDATE();

// 				SET new_id = CONCAT(today_date, LPAD(sequence_number, 4, '0'));
// 			END;
// 			`, p.ProcedureFuncName(), p.PkIncreaseTable(), p.PkIncreaseTable())

// 		if _, err = session.Exec(createProcSQL); err != nil {
// 			logger.Log.Error("CREATE PROCEDURE", zap.Error(err))
// 			return
// 		}
// 	}
// 	return nil
// }

func (p *PartitionRule) GetTablesByDateRange(session *xorm.Session, startTime, endTime time.Time) ([]string, error) {
	var tables []string

	for date := startTime; !date.After(endTime); date = p.NextDate(date) {
		tables = append(tables, p.TableNameByDate(date))
	}

	query := fmt.Sprintf(
		"SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('%s')",
		strings.Join(tables, "','"),
	)

	var existingTables []string
	if err := session.SQL(query).Find(&existingTables); err != nil {
		return nil, fmt.Errorf("error checking table existence: %w", err)
	}

	return existingTables, nil
}

func (p *PartitionRule) Sync(session *xorm.Session, date time.Time, obj any) (err error) {
	return session.Table(p.TableNameByDate(date)).Sync2(obj)
}

func (p *PartitionRule) BatchCreateTableName(session *xorm.Session, startTime, endTime time.Time, syncObj SyncObjInterface) error {
	for date := startTime; !date.After(endTime); date = p.NextDate(date) {
		tableName := p.TableNameByDate(date)

		exists, err := session.IsTableExist(tableName)
		if err != nil {
			return fmt.Errorf("failed to check if table %s exists: %w", tableName, err)
		}

		if !exists {
			p.Sync(session, date, syncObj.SyncObj())
		}
		_, err = session.Exec(fmt.Sprintf("DELETE FROM %s", tableName))
		if err != nil {
			return fmt.Errorf("failed to delete data from table %s: %w", tableName, err)
		}
	}
	return nil
}

func Daily() {
	var err error
	if err = GlobalOrderPartition.SchedulerTable(); err != nil {
		logger.Log.Error("GlobalOrderPartition Daily", zap.Error(err))
	}
	if err = GlobalChannelOrderPartition.SchedulerTable(); err != nil {
		logger.Log.Error("GlobalChannelOrderPartition Daily", zap.Error(err))
	}
}

func StartUp() {
	var err error
	epoch := time.Date(2023, 1, 1, 0, 0, 0, 0, time.UTC)
	var snakeForOrder *utils.Snowflake
	if snakeForOrder, err = utils.NewSnowflake(epoch, 1); err != nil {
		panic(err)
	}

	var snakeForChannelOrder *utils.Snowflake
	if snakeForChannelOrder, err = utils.NewSnowflake(epoch, 1); err != nil {
		panic(err)
	}
	GlobalOrderPartition = OrderPartition{
		PartitionRule: PartitionRule{
			Type:        PartitionTypeDay,
			Range:       8,
			TablePrefix: models.Order{}.TableName(),
			IDGenerator: snakeForOrder,
		},
	}
	GlobalChannelOrderPartition = ChannelOrderPartition{
		PartitionRule: PartitionRule{
			Type:        PartitionTypeDay,
			Range:       8,
			TablePrefix: models.ChannelOrder{}.TableName(),
			IDGenerator: snakeForChannelOrder,
		},
	}
	session := daos.Mysql.NewSession()
	defer session.Close()
	if err = GlobalOrderPartition.SchedulerTable(); err != nil {
		panic(err)
	}
	if err = GlobalChannelOrderPartition.SchedulerTable(); err != nil {
		panic(err)
	}
}

func MigrateOrderData(session *xorm.Session) error {

	batchSize := 1000

	offset := 0
	for {
		var orders []models.Order
		if err := session.Table(models.Order{}.TableName()).
			Limit(batchSize, offset).OrderBy("created desc").
			Find(&orders); err != nil {
			return fmt.Errorf("failed to fetch orders: %w", err)
		}

		if len(orders) == 0 {
			break
		}

		start := orders[len(orders)-1].Created
		end := orders[0].Created

		if err := GlobalOrderPartition.BatchCreateTableName(session, start, end, &GlobalOrderPartition); err != nil {
			return fmt.Errorf("failed to create tables: %w", err)
		}

		orderGroups := make(map[string][]models.Order)
		for _, order := range orders {
			tableName := GlobalOrderPartition.TableNameByDate(order.Created)
			order.SrcID = order.ID
			_id := fmt.Sprintf("%s%d", order.Created.Format("20060102"), order.ID)
			if convertErr := utils.ConvertInt64FromString(_id, &order.ID); convertErr != nil {
				logger.Log.Error("ConvertInt64FromString",
					zap.Int64("orderID", order.ID))
			}

			orderGroups[tableName] = append(orderGroups[tableName], order)
		}

		for tableName, groupOrders := range orderGroups {
			if len(groupOrders) == 0 {
				continue
			}

			if _, err := session.Table(tableName).Insert(&groupOrders); err != nil {
				return fmt.Errorf("failed to batch insert data into %s: %w", tableName, err)
			}
		}

		offset += batchSize
	}
	return nil
}

func MigrateChannelOrderData(session *xorm.Session) error {

	batchSize := 1000
	offset := 0

	for {

		var orders []models.ChannelOrder
		if err := session.Table(models.ChannelOrder{}.TableName()).
			Limit(batchSize, offset).OrderBy("created desc").
			Find(&orders); err != nil {
			return fmt.Errorf("failed to fetch orders: %w", err)
		}

		if len(orders) == 0 {
			break
		}

		start := orders[len(orders)-1].Created
		end := orders[0].Created
		if err := GlobalChannelOrderPartition.BatchCreateTableName(session, start, end, &GlobalChannelOrderPartition); err != nil {
			return fmt.Errorf("failed to create tables: %w", err)
		}

		orderGroups := make(map[string][]models.ChannelOrder)
		for _, order := range orders {
			tableName := GlobalChannelOrderPartition.TableNameByDate(order.Created)
			_id := fmt.Sprintf("%s%d", order.Created.Format("20060102"), order.ID)
			order.SrcID = order.ID
			if convertErr := utils.ConvertInt64FromString(_id, &order.ID); convertErr != nil {
				logger.Log.Error("ConvertInt64FromString",
					zap.Int64("orderID", order.ID))
			}

			orderGroups[tableName] = append(orderGroups[tableName], order)
		}

		for tableName, groupOrders := range orderGroups {
			if len(groupOrders) == 0 {
				continue
			}

			if _, err := session.Table(tableName).Insert(&groupOrders); err != nil {
				return fmt.Errorf("failed to batch insert data into %s: %w", tableName, err)
			}
		}

		offset += batchSize
	}
	return nil
}
