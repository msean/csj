package mysql

import (
	"application/constant"
	"application/daos"
	"application/models"
	"application/models/vo"
)

type LogOpDao struct {
}

func NewDaoLogOp() *LogOpDao {
	return &LogOpDao{}
}

func (d *LogOpDao) InsertBean(bean *models.LogOp) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	count, err := db.Insert(bean)
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (d *LogOpDao) QueryLogs(params vo.LogOpQueryParams) (int64, []*models.LogOp, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	res := make([]*models.LogOp, 0)
	db = db.Limit(params.Base.PageSize, (params.Base.Page-1)*params.Base.PageSize)
	db = db.Where("operator != ?", constant.USER_SUPER_NAME)
	if params.Module > 0 {
		db = db.Where("module = ?", params.Module)
	}

	if params.OpType > 0 {
		db = db.Where("op_type = ?", params.OpType)
	}

	if params.Operator != "" {
		db = db.Where("operator = ?", params.Operator)
	}

	if params.Success >= 0 {
		db = db.Where("success = ?", params.Success)
	}

	if params.Base.StartTime != "" {
		db = db.Where("created >= ?", params.Base.StartTime)
	}

	if params.Base.EndTime != "" {
		db = db.Where("created <= ?", params.Base.EndTime)
	}

	count, err := db.FindAndCount(&res)
	if err != nil {
		return 0, nil, err
	}

	return count, res, nil
}
