package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
)

type AreaSuspendDao struct {
}

func NewAreaSuspendDao() *AreaSuspendDao {
	return &AreaSuspendDao{}
}

func (dao *AreaSuspendDao) List(params vo.AreaSuspendListParam) (objs []models.AreaSuspend, total int64, err error) {
	conds := []utils.Cond{}

	if params.AreaSearch >= 0 {
		conds = append(conds, utils.NewWhereCond("area", params.AreaSearch))
	}

	if params.IspSearch != 0 {
		conds = append(conds, utils.NewWhereCond("isp", params.IspSearch))
	}

	if params.TypeChoice != 0 {
		conds = append(conds, utils.NewWhereCond("type", params.TypeChoice))
	}

	tl, pl := utils.MutateLimitCond(params.Base)
	conds = append(conds, tl)

	session := daos.Mysql.NewSession()
	defer session.Close()

	if total, err = utils.TotalByConds(session, new(models.AreaSuspend), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &objs, conds...)
	return
}

func (srv *AreaSuspendDao) InSuspend(cid, isp, typ, area int64) (yes bool, err error) {
	var areaSuspendModel models.AreaSuspend
	conds := []utils.Cond{
		utils.NewWhereCond("apply_id", cid),
		utils.NewWhereCond("type", typ),
		utils.NewWhereCond("isp", isp),
		utils.NewWhereCond("area", area),
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	return utils.Get(session, &areaSuspendModel, conds...)
}

func (srv *AreaSuspendDao) All() (objects []models.AreaSuspend, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	err = utils.Find(session, &objects)
	return
}
