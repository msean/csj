package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"application/utils/jwt_auth"
	"fmt"
	"strings"
	"time"
)

type OnlineUserDao struct{}

func NewOnlineUserDao() *OnlineUserDao {
	return &OnlineUserDao{}
}

func (dao *OnlineUserDao) Login(onlineUser models.OnlineUser) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	token := onlineUser.Token

	var claims *jwt_auth.JWTClaims
	if claims, err = jwt_auth.ParseToken(token); err != nil {
		return
	}

	onlineUser.ExpiredAt = time.Unix(claims.ExpiresAt, 0)

	session.Insert(&onlineUser)
	return
}

func (dao *OnlineUserDao) Logout(token string) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	session.Unscoped().Where("token=?", token).Delete(&models.OnlineUser{})
	return
}

func (dao *OnlineUserDao) RefreshLatestView(token string) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = session.Table(models.OnlineUser{}.TableName()).Where("token=?", token).Update(map[string]any{
		"latest_view": time.Now(),
	})
	return
}

func (dao *OnlineUserDao) List(param vo.ListOnlineUserReq) (onlineUser []models.OnlineUser, total int64, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	if _, err = session.Unscoped().Where("expired_at<=?", time.Now()).Delete(&models.OnlineUser{}); err != nil {
		return
	}

	var conditions []utils.Cond

	if !utils.IsBlankString(param.AccountSearch) {
		conditions = append(conditions, utils.NewWhereLikeCond("account", param.AccountSearch, utils.LikeTypeBetween))
	}
	if !utils.IsBlankString(param.LocationSearch) {
		conditions = append(conditions, utils.NewWhereLikeCond("location", param.LocationSearch, utils.LikeTypeBetween))
	}
	if !utils.IsBlankString(param.OrderBy) {
		conditions = append(conditions, utils.NewOrderByCond(param.OrderBy))
	}

	var forceQuitTokens []string
	forceQuitTokens, err = dao.ForceQuitList()

	conditions = append(conditions, utils.NewNotInCond("token", utils.StringSliceToAny(forceQuitTokens)))
	conditions = append(conditions, utils.NewOrderByCond("login_time desc"))

	tl, pl := utils.MutateLimitCond(param.Base)
	conditions = append(conditions, tl)
	conditions = append(conditions, pl)

	if total, err = utils.TotalByConds(session, new(models.OnlineUser), conditions...); err != nil {
		return
	}
	err = utils.Find(session, &onlineUser, conditions...)
	return
}

func (dao *OnlineUserDao) ForceQuit(tokens []string) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	// session.Table(models.OnlineUser{}.TableName()).Where("token=?", token).Update(map[string]any{
	// 	"status": "2",
	// })
	if _, err = session.In("token", tokens).Delete(&models.OnlineUser{}); err != nil {
		return
	}
	var claims *jwt_auth.JWTClaims
	for _, t := range tokens {
		if claims, err = jwt_auth.ParseToken(t); err != nil {
			continue
		}
		daos.Rc.Set(dao.ForceQuitKey(t), "", time.Until(time.Unix(claims.ExpiresAt, 0)))
	}

	return
}

func (dao *OnlineUserDao) ForceQuitList() (tokens []string, err error) {
	pattern := "zk:force_quit_user:*"
	iter := daos.Rc.Scan(0, pattern, 100).Iterator()
	for iter.Next() {
		tokens = append(tokens, iter.Val())
	}
	err = iter.Err()
	return
}

func (dao *OnlineUserDao) InForceQuitList(token string) (in bool, err error) {
	if strings.HasPrefix(token, "Bearer") {
		token = strings.TrimSpace(token[len("Bearer"):])
	}
	key := dao.ForceQuitKey(token)
	in, err = daos.Rc.Exists(key).Result()
	return
}

func (dao *OnlineUserDao) ForceQuitKey(token string) string {
	return fmt.Sprintf("zk:force_quit_user:%s", token)
}
