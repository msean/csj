package mysql

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/daos/mysql/statistic"
	"application/models"
	"application/utils"
	"fmt"

	"go.uber.org/zap"
)

var (
	User            = NewDaoUser()
	Menu            = NewDaoMenu()
	Role            = NewDaoRole()
	Adminlog        = NewDaoAdminlog()
	Blacklist       = NewBlackListDao()
	Customer        = NewCustomer()
	CustomerProduct = NewCustomerProduct()
	CustomerFinance = NewCustomerFinance()
	FinanceDay      = NewFinanceDayDAO()
	Product         = NewProductDao()
	Channel         = NewChannelDao()
	SysArgConfig    = NewSysArgConfigDao()
	Order           = NewOrderDao()
	ChannelOrder    = NewChannelOrderDao()
	ReturnOrder     = NewReturnOrderDao()
	SysDict         = NewSysDictDao()
	ChannelProd     = NewChannelProdDao()
	ChannelGroup    = NewChannelGroupDao()
	LogLogin        = NewDaoLogLogin()
	LogOp           = NewDaoLogOp()
	LogRemove       = NewDaoLogRemove()
	AreaSuspend     = NewAreaSuspendDao()
	AreaSection     = NewAreaSectionDao()
	Download        = NewDownloadDAO()
	StatisticDao    = statistic.NewStatisticDao()
	OnlineUser      = NewOnlineUserDao()
	Announcement    = NewAnnouncementDao()
)

func Migrate() {

	logger.Log.Info("================= start migrate db table ================")
	daos.Mysql.Sync2(
		&models.Product{},
		&models.SysDictType{},
		&models.SysDictData{},
		&models.SysArgConfig{},
		&models.Channel{},
		&models.ChannelProduct{},
		&models.ChannelGroup{},
		&models.AreaSuspend{},
		&models.AreaSection{},
		&models.Blacklist{},
		&models.WhiteList{},
		&models.Order{},
		&models.ChannelOrder{},
		&models.OrderChannelRecord{},
		&models.OrderReturn{},
		&models.Menu{},
		&models.Role{},
		&models.User{},
		&models.OnlineUser{},
		&models.LogLogin{},
		&models.LogOp{},
		&models.LogRemove{},
		&models.Customer{},
		&models.CustomerProduct{},
		&models.CustomerFinance{},
		&models.FinanceDay{},
		&models.Download{},
		&models.CustomerDayFinanceStatic{},
		&models.DelayTask{},
		&models.CustomerOrderDateMapper{},
		&models.Announcement{},
		&models.Crontab{},
		&models.CrontabLog{},
	)
	daos.Mysql.Exec(models.Order{}.SetIndex())
	daos.Mysql.Exec(models.ChannelOrder{}.SetIndex())
	daos.Mysql.Exec(models.CustomerFinance{}.DropIndex())
}

func MigrateOrderData() {
	session := daos.Mysql.NewSession()
	defer session.Close()
	var err error
	if err = partition.MigrateOrderData(session); err != nil {
		logger.Log.Error("MigrateOrderData", zap.Error(err))
	}
	if err = partition.MigrateChannelOrderData(session); err != nil {
		logger.Log.Error("MigrateChannelOrderData", zap.Error(err))
	}

}

func InitSysDict() (err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var ispDictData []models.SysDictData
	for k, v := range constant.IspStringM {
		ispDictData = append(ispDictData, models.SysDictData{
			Label: v, Value: fmt.Sprintf("%d", k), Status: 1, IsDefault: "Y",
		})
	}
	IspDict := models.SysDictType{Name: "运营商", Type: "xj_isp", Status: 1, EffectType: 2, Data: ispDictData}
	if err = CreateDictTypeWithData(session, IspDict); err != nil {
		return
	}

	var bigTypeData []models.SysDictData
	for k, v := range constant.BigTypeMapper {
		bigTypeData = append(bigTypeData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	BigTypeDict := models.SysDictType{Name: "产品大类", Type: "xj_bigtype", Status: 1, EffectType: 2, Data: bigTypeData}
	if err = CreateDictTypeWithData(session, BigTypeDict); err != nil {
		return
	}

	var smallTypeData []models.SysDictData
	for k, v := range constant.SmallTypeMapper {
		smallTypeData = append(smallTypeData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	SmallTypeDict := models.SysDictType{Name: "产品小类", Type: "xj_smalltype", Status: 1, EffectType: 2, Data: smallTypeData}
	if err = CreateDictTypeWithData(session, SmallTypeDict); err != nil {
		return
	}

	var areaData []models.SysDictData
	for k, v := range constant.AreaCodeM {
		areaData = append(areaData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	AreaDict := models.SysDictType{Name: "地区", Type: "xj_area", Status: 1, EffectType: 2, Data: areaData}
	if err = CreateDictTypeWithData(session, AreaDict); err != nil {
		return
	}

	var onlineData []models.SysDictData
	for k, v := range constant.OnlineMapper {
		onlineData = append(onlineData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}

	onlineDict := models.SysDictType{Name: "上下架", Type: "xj_online1", Status: 1, EffectType: 2, Data: onlineData}
	if err = CreateDictTypeWithData(session, onlineDict); err != nil {
		return
	}

	var orderStatusData []models.SysDictData
	for k, v := range constant.OrderStatusMapper {
		orderStatusData = append(orderStatusData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	orderStatusDict := models.SysDictType{Name: "订单状态", Type: "xj_order", Status: 1, EffectType: 2, Data: orderStatusData}
	if err = CreateDictTypeWithData(session, orderStatusDict); err != nil {
		return
	}

	var callbackStatusData []models.SysDictData
	for k, v := range constant.CallbackStatusMapper {
		callbackStatusData = append(callbackStatusData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	callbackStatusDict := models.SysDictType{Name: "回调状态", Type: "z_hdzt", Status: 1, EffectType: 2, Data: callbackStatusData}
	if err = CreateDictTypeWithData(session, callbackStatusDict); err != nil {
		return
	}

	var templateData []models.SysDictData
	for k, v := range constant.TemplateMapper {
		templateData = append(templateData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	templateDict := models.SysDictType{Name: "模板", Type: "xj_classes", Status: 1, EffectType: 1, Data: templateData}
	if err = CreateDictTypeWithData(session, templateDict); err != nil {
		return
	}

	var voucherData []models.SysDictData
	for k, v := range constant.VoucherTypeMapper {
		voucherData = append(voucherData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	voucherDict := models.SysDictType{Name: "凭证类型", Type: "xj_vouchertype", Status: 1, EffectType: 2, Data: voucherData}
	if err = CreateDictTypeWithData(session, voucherDict); err != nil {
		return
	}

	var blacklistData []models.SysDictData
	for k, v := range constant.BlacklistTypeMapper {
		blacklistData = append(blacklistData, models.SysDictData{
			Label: k, Value: utils.Violent2String(v), Status: 1, IsDefault: "Y",
		})
	}
	blacklistDict := models.SysDictType{Name: "黑名单类型", Type: "xj_black", Status: 1, EffectType: 2, Data: blacklistData}
	if err = CreateDictTypeWithData(session, blacklistDict); err != nil {
		return
	}
	return
}

func InitSuperAdmin() {
	superRole, err := Role.QuerySuperRole()
	if err != nil {
		logger.Log.Error("query super role error: " + err.Error())
		return
	}

	if superRole != nil {
		return
	}

	remark := "init super role"
	role := &models.Role{
		//RoleName:  "super",
		RoleName:  constant.ROLE_SUPER_NAME,
		RoleOrder: 0,
		Available: true,
		Remark:    remark,
		IsClient:  false,
		IsSuper:   true,
	}
	err = Role.InsertBean(0, role)
	if err != nil {
		logger.Log.Error("init super role error: " + err.Error())
		return
	}

	err = User.InsertBean(nil, 0, &models.User{
		// Account: "super",
		// Username:  "super_user",
		Account:   constant.USER_SUPER_ACCOUNT,
		Username:  constant.USER_SUPER_NAME,
		Password:  utils.MakePassword("qwe123a"),
		Available: true,
		Role:      role.ID,
		IsClient:  false,
		IsSuper:   true,
		Remark:    remark,
	})
	if err != nil {
		logger.Log.Error("init super user error: " + err.Error())
		return
	}

	logger.Log.Info("init super user success")
}
