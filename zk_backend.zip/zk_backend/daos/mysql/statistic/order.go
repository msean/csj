package statistic

import (
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/utils"
	"fmt"
	"strings"
)

func (dao *StatisticDao) OrderAnalysisGroup(param vo.CustomerOrderAnalysisReq, model string) (results []*resp.OrderAnalysisItem, err error) {
	results = make([]*resp.OrderAnalysisItem, 0)
	session := daos.Mysql.NewSession()
	defer session.Close()

	// 确定分表规则
	var partitionRule partition.PartitionRule
	switch model {
	case models.Order{}.TableName():
		partitionRule = partition.GlobalOrderPartition.PartitionRule
	case models.ChannelOrder{}.TableName():
		partitionRule = partition.GlobalChannelOrderPartition.PartitionRule
	default:
		return nil, fmt.Errorf("invalid model: %s", model)
	}

	// 获取时间范围内的表
	startTime := param.Base.StartTime
	endTime := param.Base.EndTime
	if startTime.IsZero() || endTime.IsZero() {
		return nil, fmt.Errorf("start time and end time must be provided")
	}

	tables, err := partitionRule.GetTablesByDateRange(session, startTime, endTime)
	if err != nil {
		return nil, fmt.Errorf("failed to get tables by date range: %w", err)
	}
	if len(tables) == 0 {
		return results, nil // 没有需要查询的表
	}

	// 构造查询
	queryParts := make([]string, 0)
	for _, table := range tables {
		query := fmt.Sprintf("SELECT * FROM %s WHERE 1=1", table)

		if !param.Base.StartTime.IsZero() {
			query += fmt.Sprintf(" AND created >= '%s'", param.Base.StartTime.Local().Format("2006-01-02 15:04:05"))
		}
		if !param.Base.EndTime.IsZero() {
			query += fmt.Sprintf(" AND created <= '%s'", param.Base.EndTime.Local().Format("2006-01-02 15:04:05"))
		}
		if param.CustomerID != 0 {
			query += fmt.Sprintf(" AND customer_id = %d", param.CustomerID)
		}
		if param.ChannelID != 0 {
			if param.GroupType == 1 || param.GroupType == 3 {
				query += fmt.Sprintf(" AND current_channel_id = %d", param.ChannelID)
			}
			if param.GroupType == 4 || param.GroupType == 5 {
				query += fmt.Sprintf(" AND channel_id = %d", param.ChannelID)
			}
		}
		if param.Isp != 0 {
			query += fmt.Sprintf(" AND isp = %d", param.Isp)
		}
		if param.ProductType != 0 {
			query += fmt.Sprintf(" AND big_type = %d", param.ProductType)
		}
		if param.Province != 0 {
			province := constant.AreaCodeStringM[param.Province]
			query += fmt.Sprintf(" AND province = '%s'", province)
		}
		if param.OrderStatus == constant.OrderStatusFail || param.OrderStatus == constant.OrderStatusSuccess {
			query += fmt.Sprintf(" AND status = %d", param.OrderStatus)
		} else {
			query += " AND status IN (102, 103)"
		}
		if param.FaceValueRange.Min > 0 {
			query += fmt.Sprintf(" AND face_value >= %d", param.FaceValueRange.Min)
		}
		if param.FaceValueRange.Max > 0 {
			query += fmt.Sprintf(" AND face_value <= %d", param.FaceValueRange.Max)
		}

		queryParts = append(queryParts, query)
	}

	// 将查询合并为 UNION ALL
	fullQuery := strings.Join(queryParts, " UNION ALL ")

	// 构造分组、聚合查询
	var groupBy, selectFields string
	switch param.GroupType {
	case 1:
		groupBy = "customer_id"
		selectFields = "customer_id"
	case 2:
		groupBy = "face_value"
		selectFields = "face_value"
	case 3:
		groupBy = "customer_id, face_value"
		selectFields = "customer_id, face_value"
	case 4:
		groupBy = "channel_id"
		selectFields = "channel_id"
	case 5:
		groupBy = "channel_id, face_value"
		selectFields = "channel_id, face_value"
	default:
		return nil, fmt.Errorf("invalid group type")
	}

	selectFields += `,
        SUM(face_value) as total_face_value,
        SUM(sale_price) as total_sale_price,
        SUM(in_price) as total_in_price,
        COUNT(*) as count,
        SUM(CASE WHEN status = 102 THEN sale_price ELSE 0 END) as success_sale_price,
        SUM(CASE WHEN status = 102 THEN in_price ELSE 0 END) as success_in_price,
        SUM(CASE WHEN status = 102 THEN face_value ELSE 0 END) as success_face_value
    `
	fullQuery = fmt.Sprintf("SELECT %s FROM (%s) as subquery GROUP BY %s", selectFields, fullQuery, groupBy)

	// 执行查询
	var rawResults []struct {
		ChannelID        int64   `xorm:"'channel_id'"`
		CustomerID       int64   `xorm:"'customer_id'"`
		FaceValue        int     `xorm:"'face_value'"`
		Count            int     `xorm:"'count'"`
		TotalFaceValue   int     `xorm:"'total_face_value'"`
		TotalSalePrice   float64 `xorm:"'total_sale_price'"`
		TotalInPrice     float64 `xorm:"'total_in_price'"`
		SuccessSalePrice float64 `xorm:"'success_sale_price'"`
		SuccessInPrice   float64 `xorm:"'success_in_price'"`
		SuccessFaceValue int     `xorm:"'success_face_value'"`
	}

	if err := session.SQL(fullQuery).Find(&rawResults); err != nil {
		return nil, fmt.Errorf("failed to fetch order analysis: %w", err)
	}

	// 处理结果
	for _, item := range rawResults {
		totalProfit := item.SuccessSalePrice - item.SuccessInPrice
		profitRate := utils.Float64SecurityDiv(totalProfit, float64(item.TotalFaceValue), 4)
		results = append(results, &resp.OrderAnalysisItem{
			ChannelID:  item.ChannelID,
			CustomerID: item.CustomerID,
			OrderOrderAnalysisData: resp.OrderOrderAnalysisData{
				FaceValue:        item.FaceValue,
				Count:            item.Count,
				PurchasePrice:    item.TotalInPrice,
				TotalProfit:      utils.FloatReserve(totalProfit, 2),
				TotalSalesPrice:  utils.FloatReserve(item.TotalSalePrice, 2),
				ProfitRate:       utils.FloatReserveString(profitRate, 2),
				SuccessFaceValue: item.SuccessFaceValue,
				TotalFaceValue:   item.TotalFaceValue,
			},
		})
	}

	return results, nil
}

type QueryResult struct {
	CustomerID int64   `xorm:"'customer_id'"`
	ChannelID  int64   `xorm:"'channel_id'"`
	ISP        int     `xorm:"'isp'"`
	Status     int     `xorm:"'status'"`
	Count      int     `xorm:"'count'"`
	FaceValue  int     `xorm:"'total_face_value'"`
	SalePrice  float64 `xorm:"'total_sale_price'"`
	InPrice    float64 `xorm:"'total_in_price'"`
	FacePrice  int     `xorm:"'face_value'"`
}

func (dao *StatisticDao) SuccessRate(param vo.CustomerOrderSuccessRateReq) (result []*resp.CustomerOrderSuccessRateRsp, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	var tables []string
	switch param.GroupType {
	case 1, 3:
		tables, err = partition.GlobalOrderPartition.GetTablesByDateRange(session, param.Base.StartTime, param.Base.EndTime)
	case 2, 4:
		tables, err = partition.GlobalChannelOrderPartition.GetTablesByDateRange(session, param.Base.StartTime, param.Base.EndTime)
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get tables by date range: %w", err)
	}
	if len(tables) == 0 {
		return nil, fmt.Errorf("no tables found for the given date range")
	}

	var conditions []string
	var args []interface{}

	if !param.Base.StartTime.IsZero() {
		conditions = append(conditions, "created >= ?")
		args = append(args, param.Base.StartTime.Local())
	}
	if !param.Base.EndTime.IsZero() {
		conditions = append(conditions, "created <= ?")
		args = append(args, param.Base.EndTime.Local())
	}
	if !param.CallBackTimePicker.StartTime.IsZero() {
		conditions = append(conditions, "current_back_time >= ?")
		args = append(args, param.CallBackTimePicker.StartTime.Local())
	}
	if !param.CallBackTimePicker.EndTime.IsZero() {
		conditions = append(conditions, "current_back_time <= ?")
		args = append(args, param.CallBackTimePicker.EndTime.Local())
	}
	if (param.GroupType == 1 || param.GroupType == 3) && param.CustomerID != 0 {
		conditions = append(conditions, "customer_id = ?")
		args = append(args, param.CustomerID)
	}
	if param.Province != 0 {
		province := constant.AreaCodeStringM[param.Province]
		conditions = append(conditions, "province = ?")
		args = append(args, province)
	}
	if param.FaceValueRange.Min > 0 {
		conditions = append(conditions, "face_value >= ?")
		args = append(args, param.FaceValueRange.Min)
	}
	if param.FaceValueRange.Max > 0 {
		conditions = append(conditions, "face_value <= ?")
		args = append(args, param.FaceValueRange.Max)
	}
	if (param.GroupType == 2 || param.GroupType == 4) && param.ChannelID > 0 {
		conditions = append(conditions, "channel_id = ?")
		args = append(args, param.ChannelID)
	}

	conditions = append(conditions, "status IN (?, ?, ?)")
	args = append(args, constant.OrderStatusSuccess, constant.OrderStatusFail, constant.OrderStatusHandle)

	whereClause := ""
	if len(conditions) > 0 {
		whereClause = "WHERE " + strings.Join(conditions, " AND ")
	}

	var groupBy, selectFields string
	switch param.GroupType {
	case 1:
		groupBy = "customer_id, isp, status"
		selectFields = "customer_id, isp, status"
	case 2:
		groupBy = "channel_id, isp, status"
		selectFields = "channel_id, isp, status"
	case 3, 4:
		groupBy = "face_value, isp, status"
		selectFields = "face_value, isp, status"
	default:
		return nil, fmt.Errorf("invalid group type")
	}

	selectFields += `,
		SUM(face_value) as total_face_value,
		SUM(sale_price) as total_sale_price,
		SUM(in_price) as total_in_price,
		COUNT(*) as count`

	var subQueries []string
	for _, table := range tables {
		subQuery := fmt.Sprintf("SELECT * FROM %s", table)
		subQueries = append(subQueries, subQuery)
	}

	finalSQL := fmt.Sprintf(`
	SELECT %s 
	FROM (
		%s
	) AS merged_data
	%s
	GROUP BY %s
`, selectFields, strings.Join(subQueries, " UNION "), whereClause, groupBy)

	var finalArgs []any
	finalArgs = append(finalArgs, args...)

	var queryResults []QueryResult
	err = session.SQL(finalSQL, finalArgs...).Find(&queryResults)
	if err != nil {
		return nil, fmt.Errorf("query failed: %w", err)
	}

	for _, _rsp := range calculateSuccessRate(param.GroupType, queryResults) {
		result = append(result, &_rsp)
	}

	return result, nil
}

func calculateSuccessRate(groupType int, qryResults []QueryResult) map[int64]resp.CustomerOrderSuccessRateRsp {
	statsMap := make(map[int64]resp.CustomerOrderSuccessRateRsp)

	for _, result := range qryResults {
		var key int64
		switch groupType {
		case 1:
			key = result.CustomerID
		case 2:
			key = result.ChannelID
		case 3, 4:
			key = int64(result.FacePrice)
		}

		stats, exists := statsMap[key]
		if !exists {
			stats = resp.CustomerOrderSuccessRateRsp{
				ObjectID: key,
				Name:     utils.Violent2String(result.FacePrice),
			}
		}

		switch result.Status {
		case constant.OrderStatusSuccess:
			stats.Total.SuccessCount += result.Count
			stats.Total.SalesPrice += result.SalePrice
			stats.Total.Profit += (result.SalePrice - result.InPrice)
			stats.Total.FaceValue += result.FaceValue

			switch result.ISP {
			case int(constant.IspMobile):
				stats.Mobile.SuccessCount += result.Count
				stats.Mobile.SalesPrice += result.SalePrice
				stats.Mobile.Profit += (result.SalePrice - result.InPrice)
			case int(constant.IspUniCom):
				stats.Unicom.SuccessCount += result.Count
				stats.Unicom.SalesPrice += result.SalePrice
				stats.Unicom.Profit += (result.SalePrice - result.InPrice)
			case int(constant.IspTelCom):
				stats.Telecom.SuccessCount += result.Count
				stats.Telecom.SalesPrice += result.SalePrice
				stats.Telecom.Profit += (result.SalePrice - result.InPrice)
			}

		case constant.OrderStatusFail:
			stats.Total.FailCount += result.Count
			stats.Total.SalesPrice += result.SalePrice

			switch result.ISP {
			case int(constant.IspMobile):
				stats.Mobile.FailCount += result.Count
				stats.Mobile.SalesPrice += result.SalePrice
			case int(constant.IspUniCom):
				stats.Unicom.FailCount += result.Count
				stats.Unicom.SalesPrice += result.SalePrice
			case int(constant.IspTelCom):
				stats.Telecom.FailCount += result.Count
				stats.Telecom.SalesPrice += result.SalePrice
			}

		case constant.OrderStatusHandle:
			stats.Total.HandelCount += result.Count
			stats.Total.SalesPrice += result.SalePrice

			switch result.ISP {
			case int(constant.IspMobile):
				stats.Mobile.HandelCount += result.Count
				stats.Mobile.SalesPrice += result.SalePrice
			case int(constant.IspUniCom):
				stats.Unicom.HandelCount += result.Count
				stats.Unicom.SalesPrice += result.SalePrice
			case int(constant.IspTelCom):
				stats.Telecom.HandelCount += result.Count
				stats.Telecom.SalesPrice += result.SalePrice
			}
		}

		stats.Total.TotalCount += result.Count

		switch result.ISP {
		case int(constant.IspMobile):
			stats.Mobile.TotalCount += result.Count
			stats.Mobile.FaceValue += result.FaceValue
		case int(constant.IspUniCom):
			stats.Unicom.TotalCount += result.Count
			stats.Unicom.FaceValue += result.FaceValue
		case int(constant.IspTelCom):
			stats.Telecom.TotalCount += result.Count
			stats.Telecom.FaceValue += result.FaceValue
		}

		stats.Total.SuccessRate = utils.IntSecurityDiv(stats.Total.SuccessCount, stats.Total.TotalCount, 4)
		stats.Mobile.SuccessRate = utils.IntSecurityDiv(stats.Mobile.SuccessCount, stats.Mobile.TotalCount, 4)
		stats.Unicom.SuccessRate = utils.IntSecurityDiv(stats.Unicom.SuccessCount, stats.Unicom.TotalCount, 4)
		stats.Telecom.SuccessRate = utils.IntSecurityDiv(stats.Telecom.SuccessCount, stats.Telecom.TotalCount, 4)

		stats.Mobile.SalesPrice = utils.FloatReserve(stats.Mobile.SalesPrice, 2)
		stats.Mobile.Profit = utils.FloatReserve(stats.Mobile.Profit, 2)

		stats.Unicom.SalesPrice = utils.FloatReserve(stats.Unicom.SalesPrice, 2)
		stats.Unicom.Profit = utils.FloatReserve(stats.Unicom.Profit, 2)

		stats.Telecom.SalesPrice = utils.FloatReserve(stats.Telecom.SalesPrice, 2)
		stats.Telecom.Profit = utils.FloatReserve(stats.Telecom.Profit, 2)

		stats.Total.Profit = utils.FloatReserve(stats.Total.Profit, 2)
		stats.Total.SalesPrice = utils.FloatReserve(stats.Total.SalesPrice, 2)
		statsMap[key] = stats

	}
	return statsMap
}
