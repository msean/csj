package statistic

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
)

type StatisticDao struct {
}

func NewStatisticDao() *StatisticDao {
	return &StatisticDao{}
}

func (dao *StatisticDao) ListDayFinance(param vo.CustomerFinanceDayStatisticReq) (records []models.CustomerDayFinanceStatic, total int64, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	conditions := []utils.Cond{}

	if param.CustomerID != 0 {
		conditions = append(conditions, utils.NewWhereCond("customer_id", param.CustomerID))
	}

	if !utils.IsBlankString(param.StartDate) {
		conditions = append(conditions, utils.NewCmpCond("date", ">=", param.StartDate))
	}

	if !utils.IsBlankString(param.EndDate) {
		conditions = append(conditions, utils.NewCmpCond("date", "<=", param.EndDate))
	}

	conditions = append(conditions, param.Base.Mutate())

	if param.QryTotal >= 0 {
		if total, err = utils.TotalByConds(session, new(models.CustomerDayFinanceStatic), conditions...); err != nil {
			return
		}
	}

	err = utils.Find(session, &records, conditions...)
	return
}
