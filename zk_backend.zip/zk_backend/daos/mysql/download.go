package mysql

import (
	"application/daos"
	"application/models"
	"errors"
)

type DownloadDAO struct {
}

func NewDownloadDAO() *DownloadDAO {
	return &DownloadDAO{}
}

func (dao *DownloadDAO) InsertBean(by int64, bean *models.Download) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Add(by, &bean.Bean)
	_, err := db.Insert(bean)
	if err != nil {
		return err
	}

	return nil
}

func (dao *DownloadDAO) UpdateBean(by int64, bean *models.Download) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Edit(by, &bean.Bean)
	_, err := db.ID(bean.ID).AllCols().Update(bean)
	if err != nil {
		return err
	}
	return nil
}

func (dao *DownloadDAO) FindByKey(key string) (*models.Download, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	res := make([]*models.Download, 0)
	err := db.Where("hash_key = ? ", key).Find(&res)
	if err != nil {
		return nil, err
	}

	if len(res) == 0 {
		return nil, errors.New("not found")
	}

	return res[0], nil
}

/*
objs := make([]*models.Menu, 0)
	err := daos.Mysql.Where("parent_id = ?", parentID).Cols("id").Find(&objs)*/
