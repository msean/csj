package mysql

import (
	"application/daos"
	"application/models"
	"application/models/vo"
	"errors"
)

type BeanDao struct {
}

func NewDaoBean() *BeanDao {
	return &BeanDao{}
}

func (this *BeanDao) GetBeanById(id int64) (*models.Bean, error) {
	bean := &models.Bean{}
	has, err := daos.Mysql.ID(id).Get(bean)
	if err != nil {
		return nil, err
	}
	if !has {
		return nil, errors.New("数据不存在")
	}
	return bean, nil
}

func (this *BeanDao) UpdateBean(by int64, bean *models.Bean) error {
	models.Edit(by, bean)
	count, err := daos.Mysql.ID(bean.ID).AllCols().Update(bean)
	if err != nil {
		return err
	}
	if 0 == count {
		return errors.New("更新0条")
	}
	return nil
}

func (this *BeanDao) DeleteBeanById(id int64) error {
	_, err := daos.Mysql.ID(id).Delete(&models.Bean{})
	return err
}

func (this *BeanDao) InsertBean(by int64, bean *models.Bean) error {
	models.Add(by, bean)
	count, err := daos.Mysql.Insert(bean)
	if err != nil {
		return err
	}
	if 0 == count {
		return errors.New("新增0条")
	}
	return nil
}

func (this *BeanDao) FindDataByParam(filterWhere map[string]interface{}, filterIn map[string]interface{}, param *vo.FindListParams) (int64, []*models.Bean, error) {
	list := make([]*models.Bean, 0)
	db := daos.Mysql.Limit(param.PageSize, (param.Page-1)*param.PageSize)
	if nil != filterWhere {
		for key, val := range filterWhere {
			db.Where(key+" = ?", val)
		}
	}
	if nil != filterIn {
		for key, val := range filterIn {
			db.In(key, val)
		}
	}
	if "" != param.StartTime {
		db.Where("created >= ?", param.StartTime)
	}
	if "" != param.EndTime {
		db.Where("created <= ?", param.EndTime)
	}
	count, err := db.Desc("created").FindAndCount(&list)
	if err != nil {
		return 0, nil, err
	}
	return count, list, err
}

func (this *BeanDao) FindAll() ([]*models.Bean, error) {
	list := make([]*models.Bean, 0)

	session := daos.Mysql.NewSession()
	defer session.Close()

	err := session.Find(&list)
	if err != nil {
		return nil, err
	}
	return list, err
}
