package mysql

import (
	"application/common/logger"
	"application/daos"
	"application/models"
	"errors"
	"fmt"
	"strconv"

	"go.uber.org/zap"
)

type MenuDao struct {
}

func NewDaoMenu() *MenuDao {
	return &MenuDao{}
}

func (m *MenuDao) GetBeanById(id int64) (*models.Menu, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	bean := &models.Menu{}
	has, err := db.ID(id).Get(bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, errors.New("can't find")
	}

	return bean, nil
}

func (m *MenuDao) FindByNameOrOrder(parentId int64, name string, order int) (*models.Menu, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	res := make([]*models.Menu, 0)
	err := db.Where("parent_id = ? and (menu_name = ? or menu_order = ?)", parentId, name, order).Find(&res)
	if err != nil {
		return nil, err
	}

	if len(res) <= 0 {
		return nil, nil
	}

	return res[0], nil
}

func (m *MenuDao) UpdateBean(by int64, bean *models.Menu) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Edit(by, &bean.Bean)
	_, err := db.ID(bean.ID).AllCols().Update(bean)
	if err != nil {
		return err
	}

	return nil
}

func (m *MenuDao) InsertBean(by int64, bean *models.Menu) error {
	db := daos.Mysql.NewSession()
	defer db.Close()

	models.Add(by, &bean.Bean)
	_, err := db.Insert(bean)
	if err != nil {
		return err
	}

	return nil
}

func (m *MenuDao) DeleteBeanById(id int64) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	obj := &models.Menu{}
	count, err := db.Where("id = ? or parent_id = ? ", id, id).Unscoped().Delete(obj)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *MenuDao) DeleteByParents(ids []int64) (int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	count, err := db.In("parent_id", ids).Unscoped().Delete(&models.Menu{})
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (m *MenuDao) FindMenuByParent(parentID int64) ([]int64, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	objs := make([]*models.Menu, 0)
	err := db.Where("parent_id = ?", parentID).Cols("id").Find(&objs)
	if err != nil {
		return nil, err
	}

	res := make([]int64, 0, len(objs))
	for _, obj := range objs {
		res = append(res, obj.ID)
	}

	return res, nil
}

func (m *MenuDao) FindMenuIdsByUserId(userId int64) ([]int64, error) {
	sql := `
			SELECT
			m.id as id
		FROM
			a_user AS u,
			a_role AS r,
			a_menu AS m,
			a_role_menu AS rm,
			a_user_role AS ur
		WHERE
			u.status = "0"
			AND r.status = "0"
			AND ur.user_id = u.id
			AND ur.role_id = r.id
			AND rm.role_id = r.id
			AND rm.menu_id = m.id
			and u.id = %d
`
	sql = fmt.Sprintf(sql, userId)

	db := daos.Mysql.NewSession()
	defer db.Close()

	v, err := db.QueryString(sql)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("FindMenuIdsByUserId 失败 [%d]", userId), zap.Error(err))
		return nil, err
	}

	list := make([]int64, 0)
	for _, m := range v {
		id := m["id"]
		atoi, err := strconv.Atoi(id)
		if err != nil {
			continue
		}
		list = append(list, int64(atoi))
	}
	return list, nil
}

func (m *MenuDao) FindMenuByIds(ids []int64, visible bool, parentId int64) ([]*models.Menu, error) {
	list := make([]*models.Menu, 0)

	session := daos.Mysql.NewSession()
	defer session.Close()

	db := session.Asc("id")
	if visible {
		db.Where("visible = ?", visible)
	}
	if 0 != parentId {
		db.Where("parent_id = ?", parentId)
	}
	if nil != ids {
		db.In("id", ids)
	}
	err := db.Find(&list)
	return list, err
}

/*func (m *MenuDao) FindMenuIdsByRoleId(roleId int64) (list []int64) {
	sql := `
			SELECT
			m.id as id
		FROM
			a_role AS r,
			a_menu AS m,
			a_role_menu AS rm
		WHERE
			r.status = "0"
			AND rm.role_id = r.id
			AND rm.menu_id = m.id
			and r.id = %d
`
	sql = fmt.Sprintf(sql, roleId)

	db := daos.Mysql.NewSession()
	defer db.Close()

	v, err := db.QueryString(sql)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("FindMenuIdsByRoleId 失败 [%d]", roleId), zap.Error(err))
		return
	}
	list = make([]int64, 0)
	for _, m := range v {
		id := m["id"]
		atoi, err := strconv.Atoi(id)
		if err != nil {
			continue
		}
		list = append(list, int64(atoi))
	}
	return
}*/

func (m *MenuDao) GetBeanByMethodUrl(url string, method string) (*models.Menu, error) {
	db := daos.Mysql.NewSession()
	defer db.Close()

	bean := &models.Menu{}
	has, err := db.Where("url = ?", url).And("method = '' or method = ?", method).Get(bean)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, nil
	}

	return bean, nil
}

/*
list := make([]*models.Menu, 0)
	db := daos.Mysql.NewSession().Asc("id")
	if visible {
		db.Where("visible = ?", visible)
	}
	if 0 != parentId {
		db.Where("parent_id = ?", parentId)
	}
	if nil != ids {
		db.In("id", ids)
	}*/

// todo: check ==============================================================================================
// todo: check ==============================================================================================
/*func (m *MenuDao) InsertRoleMenu(userRole *models.RoleMenu) error {
	count, err := daos.Mysql.Insert(userRole)
	if err != nil {
		return err
	}
	if 0 == count {
		return errors.New("新增0条")
	}
	return nil
}

func (m *MenuDao) DeleteRoleMenuByRoleId(roleId int64) {
	daos.Mysql.Where("role_id = ?", roleId).Delete(&models.RoleMenu{})
}

func (m *MenuDao) DeleteRoleMenuByMenuId(menuId int64) {
	daos.Mysql.Where("menu_id = ?", menuId).Delete(&models.RoleMenu{})
}

func (m *MenuDao) FindMenuIdsByMenuId(menuId int64) (list []int64) {
	sql := `
			SELECT
			m.id as id
		FROM
			a_role AS r,
			a_menu AS m,
			a_role_menu AS rm
		WHERE
			 rm.role_id = r.id
			AND rm.menu_id = m.id
			and m.id = %d
			and r.id <> 1
`
	sql = fmt.Sprintf(sql, menuId)
	v, err := daos.Mysql.QueryString(sql)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("FindMenuIdsByMenuId 失败 [%d]", menuId), zap.Error(err))
		return
	}
	list = make([]int64, 0)
	for _, m := range v {
		id := m["id"]
		atoi, err := strconv.Atoi(id)
		if err != nil {
			continue
		}
		list = append(list, int64(atoi))
	}
	return
}*/
