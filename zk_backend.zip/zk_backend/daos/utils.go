package daos

import (
	"application/common/driver"
	"application/utils"
	"errors"
	"fmt"
	"log"
	"reflect"
	"time"

	"github.com/go-xorm/xorm"
	"gopkg.in/redis.v5"
)

var (
	Mysql *xorm.Engine
	Rc    *redis.Client
	Ldb   *driver.LevelDB
)

// SetLevelDB
func SetLevelDB(_leveldb *driver.LevelDB) {
	Ldb = _leveldb
}

// SetMysql
func SetMysql(e *xorm.Engine) {
	Mysql = e
	go func() {
		for {
			Mysql.Ping()
			time.Sleep(1 * time.Hour)
		}
	}()
}

// SetRedis
func SetRedis(_rc *redis.Client) {
	Rc = _rc
}

// Transaction
func Transaction(fs ...func(s *xorm.Session) error) error {
	session := Mysql.NewSession()
	session.Begin()
	for _, f := range fs {
		err := f(session)
		if err != nil {
			log.Println(err)
			session.Rollback()
			session.Clone()
			return err
		}
	}
	session.Commit()
	session.Clone()
	return nil
}

// CloseMySQL
func CloseMySQL() {
	Mysql.Close()
}

func CreateObjs(session *xorm.Session, obj ...any) (count int64, err error) {
	return utils.Create(session, obj...)
}

func ObjDetailByID(session *xorm.Session, id int64, obj any) (has bool, err error) {
	if reflect.TypeOf(obj).Kind() != reflect.Ptr {
		objValue := reflect.ValueOf(obj)
		if objValue.Kind() != reflect.Struct {
			return false, errors.New("obj must be a pointer to a struct")
		}
		newObj := reflect.New(objValue.Type())
		newObj.Elem().Set(objValue)
		obj = newObj.Interface()
	}
	has, err = utils.IDCond(id).Cond(session).Get(obj)
	return
}

func GetRecordByField(session *xorm.Session, tableName, obj any, conds ...utils.Cond) (has bool, err error) {
	if len(conds) == 0 {
		err = fmt.Errorf("unexpect query condition")
		return
	}
	session = session.Table(tableName)
	for _, where := range conds {
		session = where.Cond(session)
	}
	has, err = session.Get(obj)
	return
}

func ListByCondition(session *xorm.Session, tableName, obj any, conds ...utils.Cond) (err error) {
	if len(conds) == 0 {
		err = fmt.Errorf("unexpect query condition")
		return
	}
	session = session.Table(tableName)
	for _, where := range conds {
		session = where.Cond(session)
	}
	return session.Find(obj)
}

func DelObjs(session *xorm.Session, idList []int64, model any) (count int64, err error) {
	if len(idList) == 0 {
		return
	}
	if reflect.TypeOf(model).Kind() != reflect.Ptr {
		objValue := reflect.ValueOf(model)
		if objValue.Kind() != reflect.Struct {
			return 0, errors.New("obj must be a pointer to a struct ")
		}
		newObj := reflect.New(objValue.Type())
		newObj.Elem().Set(objValue)
		model = newObj.Interface()
	}

	count, err = session.In("id", idList).Delete(model)
	return
}

func UpdateObjWithVersion(session *xorm.Session, obj any, conds []utils.Cond, omitFields ...string) (count int64, err error) {
	if reflect.TypeOf(obj).Kind() != reflect.Ptr {
		objValue := reflect.ValueOf(obj)
		if objValue.Kind() != reflect.Struct {
			return 0, errors.New("obj must be a pointer to a struct")
		}
		newObj := reflect.New(objValue.Type())
		newObj.Elem().Set(objValue)
		obj = newObj.Interface()
	}

	objValue := reflect.ValueOf(obj).Elem()

	var tableName string
	var id int64
	tableNameMethod := objValue.MethodByName("TableName")
	if tableNameMethod.IsValid() {
		results := tableNameMethod.Call(nil)
		if len(results) > 0 {
			tableName = results[0].String()
		}
	} else {
		return 0, errors.New("obj does not have a TableName method")
	}

	idField := objValue.FieldByName("ID")
	if !idField.IsValid() || !idField.CanSet() {
		return 0, errors.New("obj does not have an ID field or cannot be set")
	}
	id = idField.Int()

	var version int64

	if _, err = utils.IDCond(id).Cond(session.Table(tableName)).Select("version").Get(&version); err != nil {
		return
	}

	versionField := objValue.FieldByName("Version")
	if !versionField.IsValid() || !versionField.CanSet() {
		return 0, errors.New("obj does not have a Version field or cannot be set")
	}

	versionField.SetInt(version)

	session = utils.IDCond(id).Cond(session)
	for _, cond := range conds {
		session = cond.Cond(session)
	}

	_, err = session.Omit(omitFields...).Update(obj)

	return
}

func UpdateColsWithVersion(session *xorm.Session, obj any, cols ...string) (count int64, err error) {
	if reflect.TypeOf(obj).Kind() != reflect.Ptr {
		objValue := reflect.ValueOf(obj)
		if objValue.Kind() != reflect.Struct {
			return 0, errors.New("obj must be a pointer to a struct")
		}
		newObj := reflect.New(objValue.Type())
		newObj.Elem().Set(objValue)
		obj = newObj.Interface()
	}

	objValue := reflect.ValueOf(obj).Elem()

	var tableName string
	var id int64
	tableNameMethod := objValue.MethodByName("TableName")
	if tableNameMethod.IsValid() {
		results := tableNameMethod.Call(nil)
		if len(results) > 0 {
			tableName = results[0].String()
		}
	} else {
		return 0, errors.New("obj does not have a TableName method")
	}

	idField := objValue.FieldByName("ID")
	if !idField.IsValid() || !idField.CanSet() {
		return 0, errors.New("obj does not have an ID field or cannot be set")
	}
	id = idField.Int()

	var version int64

	if _, err = utils.IDCond(id).Cond(session.Table(tableName)).Select("version").Get(&version); err != nil {
		return
	}

	versionField := objValue.FieldByName("Version")
	if !versionField.IsValid() || !versionField.CanSet() {
		return 0, errors.New("obj does not have a Version field or cannot be set")
	}

	versionField.SetInt(version)

	_, err = utils.IDCond(id).Cond(session).Cols(cols...).Update(obj)

	return
}

func Exist(session *xorm.Session, obj any, id int64, fieldValueMapper map[string]any) (yes bool, err error) {
	var has bool
	type Object struct {
		ID int64
	}

	conds := []utils.Cond{}
	for field, value := range fieldValueMapper {
		conds = append(conds, utils.NewWhereCond(field, value))
	}

	has, err = utils.Get(session, obj, conds...)
	if err != nil {
		return
	}

	if has && id == 0 {
		return true, nil
	}

	if has && id != 0 {
		if object, ok := obj.(*Object); ok {
			return object.ID == id, nil
		}
	}
	return
}
