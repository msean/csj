package redis

import (
	"application/common/logger"
	"application/daos"
	"fmt"
	"sync"
	"time"

	"go.uber.org/zap"
	"gopkg.in/redis.v5"
)

var lockMap = make(map[string]*sync.Mutex)

func BalanceQryCacheKey(customerID int64) string {
	return fmt.Sprintf("zk:balance_qry:%d", customerID)
}

func OrderQryCacheKey(orderID string, customerID int64) string {
	return fmt.Sprintf("zk:order_qry:%s:%d", orderID, customerID)
}

func getLock(key string) *sync.Mutex {
	if lockMap[key] == nil {
		lockMap[key] = &sync.Mutex{}
	}
	return lockMap[key]
}

func ApiFrequencyCheck(key string, limitInterval time.Duration) (limit bool, err error) {

	lock := getLock(key)
	lock.Lock()
	defer lock.Unlock()

	var latestViewUnix int64

	defer func() {
		if err != nil {
			logger.Log.Error("[ApiFrequencyCheck]", zap.String("key", key), zap.Int64("limitInterval", int64(limitInterval)), zap.Error(err))
		}
	}()

	defer func() {
		if err != nil {
			if err = daos.Rc.Set(key, latestViewUnix, limitInterval).Err(); err != nil {
				return
			}
		}
	}()

	now := time.Now()
	if latestViewUnix, err = daos.Rc.Get(key).Int64(); err != nil {
		if err == redis.Nil {
			err = nil
			latestViewUnix = now.Unix()
		}
		return
	}
	latestView := time.Unix(latestViewUnix, 0)
	if now.Sub(latestView) < limitInterval {
		limit = true
		return
	} else {
		latestViewUnix = time.Now().Unix()
	}
	return
}
