package _cpu

import "runtime"

// GroRuntimeMaxCpu
func GroRuntimeMaxCpu() {
	runtime.GOMAXPROCS(runtime.NumCPU())
}
