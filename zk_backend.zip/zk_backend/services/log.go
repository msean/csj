package services

import (
	"application/common/logger"
	"application/constant"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"fmt"
	"time"

	"github.com/labstack/echo"
	"github.com/tidwall/gjson"
)

type logService struct {
	Ctx  *echo.Context
	Uuid string
}

func NewServiceLog(ctx *echo.Context) *logService {
	bean := &logService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (s *logService) Login(account string, isSuccess bool, detail, token string) {
	ctx := *s.Ctx
	browser, os := utils.ParseAgent(ctx.Request().UserAgent())
	data := models.LogLogin{
		Account:  account,
		Ip:       ctx.RealIP(),
		Location: "",
		Browser:  browser,
		Os:       os,
		Success:  isSuccess,
		Detail:   detail,
	}
	count, err := mysql.LogLogin.InsertBean(&data)
	logger.Log.Info(fmt.Sprintf("login log: %+v, count: %d, err: %v", data, count, err))

	if isSuccess {
		onlineUser := models.OnlineUser{
			Account:    account,
			Host:       ctx.RealIP(),
			Location:   "",
			Browser:    browser,
			LoginTime:  time.Now(),
			LatestView: time.Now(),
			Token:      token,
			Status:     "1",
			Os:         os,
		}
		mysql.OnlineUser.Login(onlineUser)
	}
}

func (s *logService) QueryLoginLog(params vo.LogLoginQueryParams) (*vo.QueryLogLoginRes, error) {
	count, logs, err := mysql.NewDaoLogLogin().QueryLogs(params)
	if err != nil {
		return nil, err
	}

	res := make([]*vo.LogLoginVo, 0)
	for _, obj := range logs {
		data := vo.LogLoginVo{
			ID:       obj.ID,
			Account:  obj.Account,
			Ip:       obj.Ip,
			Location: obj.Location,
			Browser:  obj.Browser,
			Os:       obj.Os,
			Success:  obj.Success,
			Detail:   obj.Detail,
			Created:  utils.FormatTime(obj.Created),
		}

		res = append(res, &data)
	}

	return &vo.QueryLogLoginRes{
		Count: count,
		Data:  res,
	}, nil
}

func (s *logService) RemoveLoginLog(ids []int64) (int64, error) {
	count, err := mysql.LogLogin.DeleteBeanByIds(ids)
	if err != nil {
		return 0, errors.New("delete error, " + err.Error())
	}

	if count <= 0 {
		return 0, errors.New("invalid ids")
	}

	return count, nil
}

func (s *logService) Op(req *vo.LogRequestData, paramsStr string, resStr string) {
	ctx := *s.Ctx
	isSuccess := false
	code := gjson.Get(resStr, "code").Int()
	if code == 1000 {
		isSuccess = true
	}
	data := models.LogOp{
		Module:   req.Module,
		OpType:   uint(req.OpType),
		Operator: utils.Username(ctx),
		Company:  utils.Company(ctx),
		Ip:       ctx.RealIP(),
		Location: "",
		Url:      ctx.Request().URL.Path,
		Method:   ctx.Request().Method,
		Func:     req.Func,
		Req:      utils.RemoveSpace(paramsStr),
		Res:      resStr,
		Success:  isSuccess,
		Detail:   "",
	}

	count, err := mysql.LogOp.InsertBean(&data)
	logger.Log.Info(fmt.Sprintf("login op: %+v, count: %d, err: %v", data, count, err))
}

func (s *logService) QueryOpLog(params vo.LogOpQueryParams) (*vo.QueryLogOpRes, error) {
	count, logs, err := mysql.NewDaoLogOp().QueryLogs(params)
	if err != nil {
		return nil, err
	}

	res := make([]*vo.LogOpVo, 0)
	for _, obj := range logs {
		res = append(res, &vo.LogOpVo{
			ID:       obj.ID,
			Module:   obj.Module,
			OpType:   obj.OpType,
			Operator: obj.Operator,
			Company:  obj.Company,
			Ip:       obj.Ip,
			Location: obj.Location,
			Url:      obj.Url,
			Method:   obj.Method,
			Func:     obj.Func,
			Req:      obj.Req,
			Res:      obj.Res,
			Success:  obj.Success,
			Created:  utils.FormatTime(obj.Created),
		})
	}

	return &vo.QueryLogOpRes{
		Count: count,
		Data:  res,
	}, nil
}

func (s *logService) RemoveData(params vo.LogRemove) {
	data := models.LogRemove{
		TableType:  params.TableType,
		Count:      params.Count,
		IntervalMs: params.IntervalMs,
		StartTime:  params.StartTime,
		EndTime:    params.EndTime,
		Operator:   utils.Username(*s.Ctx),
		Success:    params.Success,
		Remark:     params.Remark,
	}
	count, err := mysql.LogRemove.InsertBean(&data)
	logger.Log.Info(fmt.Sprintf("remove log: %+v, count: %d, err: %v", data, count, err))
}

func (s *logService) QueryRemoveLog(params vo.LogRemoveQueryParams) (*vo.QueryLogRemoveRes, error) {
	count, logs, err := mysql.LogRemove.QueryLogs(params)
	if err != nil {
		return nil, err
	}

	res := make([]*vo.LogRemoveVo, 0)
	for _, obj := range logs {
		res = append(res, &vo.LogRemoveVo{
			ID:         obj.ID,
			Created:    obj.Created,
			TableName:  constant.GET_TABLE_NAME(obj.TableType),
			IntervalMs: obj.IntervalMs,
			Count:      obj.Count,
			Success:    obj.Success,
			StartTime:  obj.StartTime,
			EndTime:    obj.EndTime,
			Operator:   obj.Operator,
			Remark:     obj.Remark,
		})
	}

	return &vo.QueryLogRemoveRes{
		Count: count,
		Data:  res,
	}, nil
}
