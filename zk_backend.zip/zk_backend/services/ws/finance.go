package ws

import (
	"application/daos/mysql"
	"application/models"
	"encoding/json"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

type (
	FinanceWsMgr struct {
		lock               sync.Mutex
		customerConnMapper map[int64][]*websocket.Conn
		lastSentTime       sync.Map
		pendingData        sync.Map
		wsSrv              *WsSrv
		sendFrequency      time.Duration // 发送频率 单位 秒
	}
)

var FinanceWsManager *FinanceWsMgr

func NewFinanceMgr(ws *WsSrv) *FinanceWsMgr {
	bean := &FinanceWsMgr{
		customerConnMapper: make(map[int64][]*websocket.Conn),
		wsSrv:              ws,
		sendFrequency:      2 * time.Second,
	}
	FinanceWsManager = bean
	FinanceWsManager.StartAutoFlush()
	return bean
}

func (mgr *FinanceWsMgr) StartAutoFlush() {
	ticker := time.NewTicker(mgr.sendFrequency)
	go func() {
		for range ticker.C {
			mgr.FlushExpiredPendingData()
		}
	}()
}

func (mgr *FinanceWsMgr) AddConn(customerID int64, ws *websocket.Conn) {
	mgr.lock.Lock()
	defer mgr.lock.Unlock()

	if customerConnList, in := mgr.customerConnMapper[customerID]; in {
		customerConnList = append(customerConnList, ws)
		mgr.customerConnMapper[customerID] = customerConnList
	} else {
		mgr.customerConnMapper[customerID] = []*websocket.Conn{ws}
	}

	var customer models.Customer
	var has bool
	var err error
	// 由于需要查询客户的余额，以数据库为准
	customer, has, err = mysql.Customer.FromID(customerID)
	// has, err = cache.FromModelPk(customer.TableName(), cache.CustomerPk(customerID), &customer)
	if !has || err != nil {
		mgr.Delete(ws)
		return
	}

	go mgr.send(customerID, customer.Balance, customer.Credit)
}

func (mgr *FinanceWsMgr) Delete(ws *websocket.Conn) {
	mgr.lock.Lock()
	defer mgr.lock.Unlock()

	for customerID, customerConnList := range mgr.customerConnMapper {
		var updatedList []*websocket.Conn
		for _, conn := range customerConnList {
			if conn != ws {
				updatedList = append(updatedList, conn)
			}
		}
		mgr.customerConnMapper[customerID] = updatedList
	}
}

func (mgr *FinanceWsMgr) SendFinanceInfo(customerID int64, balance float64, credit float64) {
	now := time.Now()

	lastTime, ok := mgr.lastSentTime.Load(customerID)
	if ok && now.Sub(lastTime.(time.Time)) < mgr.sendFrequency {
		mgr.pendingData.Store(customerID, map[string]float64{
			"balance": balance,
			"credit":  credit,
		})
		return
	}

	mgr.send(customerID, balance, credit)
}

func (mgr *FinanceWsMgr) send(customerID int64, balance float64, credit float64) {
	mgr.lock.Lock()
	defer mgr.lock.Unlock()

	mgr.lastSentTime.Store(customerID, time.Now())

	if customerConns, ok := mgr.customerConnMapper[customerID]; ok {
		for _, wsConn := range customerConns {
			msg, err := json.Marshal(map[string]any{
				"module":  "finance",
				"balance": balance,
				"credit":  credit,
			})
			if err != nil {
				continue
			}
			mgr.wsSrv.SendToClient(wsConn, msg)
		}
	}
}

// 保证刷最后一条啊
func (mgr *FinanceWsMgr) FlushExpiredPendingData() {
	now := time.Now()

	mgr.lastSentTime.Range(func(customerID, lastTime interface{}) bool {
		if now.Sub(lastTime.(time.Time)) >= mgr.sendFrequency {
			if data, ok := mgr.pendingData.LoadAndDelete(customerID); ok {
				balance := data.(map[string]float64)["balance"]
				credit := data.(map[string]float64)["credit"]
				mgr.send(customerID.(int64), balance, credit)
			}
		}
		return true
	})
}
