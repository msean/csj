package ws

import (
	"application/common/logger"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"encoding/json"
	"fmt"

	"github.com/gorilla/websocket"
	"go.uber.org/zap"
)

type AnnouncementWs struct {
	conn   *websocket.Conn
	msg    WsMsg
	wsSrv  *WsSrv
	module string
}

func NewAnnouncement(conn *websocket.Conn, msg WsMsg, ws *WsSrv) *AnnouncementWs {
	return &AnnouncementWs{
		conn:   conn,
		msg:    msg,
		wsSrv:  ws,
		module: "announcement",
	}
}

func (ws *AnnouncementWs) Publish(params vo.AnnouncementPublishParams) (err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var announcement models.Announcement
	var has bool
	if has, err = daos.GetRecordByField(session, announcement.TableName(), &announcement, utils.IDCond(params.ID)); err != nil {
		return
	}

	if !has {
		return fmt.Errorf("record not found")
	}

	var msg []byte
	msg, err = json.Marshal(map[string]string{
		"module":  ws.msg.Module,
		"title":   announcement.Title,
		"content": announcement.Content,
	})
	if err != nil {
		return
	}
	ws.wsSrv.Broadcast(msg)
	return
}

func (ws *AnnouncementWs) Handle() (err error) {
	msg := ws.msg
	switch msg.Cmd {
	case "publish":
		var params vo.AnnouncementPublishParams
		if err = json.Unmarshal(msg.Data, &params); err != nil {
			logger.Log.Error("Announcement HandleMsg", zap.Any("msg", msg), zap.Error(err))
			return
		}
		ws.Publish(params)
	}
	return
}
