package ws

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/vo"
	"database/sql"
	"encoding/json"
	"fmt"
	"strconv"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"go.uber.org/zap"
)

type (
	DeleteDataWs struct {
		conn   *websocket.Conn
		msg    WsMsg
		wsSrv  *WsSrv
		module string
	}
	DeleteWsMgr struct {
		lock           sync.Mutex
		stopChanMapper map[*websocket.Conn]chan bool
		isPausedMapper map[*websocket.Conn]bool
	}
)

var DeleteManager *DeleteWsMgr

func NewDataDeleteWsMgr(ws *WsSrv) *DeleteWsMgr {
	bean := &DeleteWsMgr{
		stopChanMapper: make(map[*websocket.Conn]chan bool),
		isPausedMapper: make(map[*websocket.Conn]bool),
	}
	return bean
}

func NewDataDeleteWs(conn *websocket.Conn, msg WsMsg, ws *WsSrv) *DeleteDataWs {
	return &DeleteDataWs{
		conn:   conn,
		msg:    msg,
		wsSrv:  ws,
		module: "data_delete",
	}
}

func (ws *DeleteDataWs) Start(params vo.DataDeleteStartParams) error {
	clientID := ws.conn

	stopChan := make(chan bool)

	DeleteManager.lock.Lock()
	DeleteManager.stopChanMapper[clientID] = stopChan
	DeleteManager.isPausedMapper[clientID] = false
	DeleteManager.lock.Unlock()

	go func() {
		currentTime := params.TimePicker.StartTime
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()
		defer close(stopChan)

		for {
			select {
			case <-ticker.C:
				DeleteManager.lock.Lock()
				isPaused := DeleteManager.isPausedMapper[clientID]
				DeleteManager.lock.Unlock()
				if isPaused {
					continue
				}

				if currentTime.After(params.TimePicker.EndTime) || currentTime.Equal(params.TimePicker.EndTime) {
					ws.HandleStopTask()
					msg, err := json.Marshal(map[string]string{
						"module": ws.module,
						"msg":    "任务完成",
					})
					if err != nil {
						return
					}
					ws.wsSrv.SendToClient(clientID, msg)
					return
				}

				_endTime := currentTime.Add(time.Duration(params.Interval) * time.Second)
				deleteCount, err := ws.DeleteData(params.TableOpt, params.StatusOpt, currentTime, _endTime)

				if err != nil {
					msg, err := json.Marshal(map[string]string{
						"module": ws.module,
						"msg":    fmt.Sprintf("删除时间从%s到%s失败，原因: %s", currentTime.Format("2006-01-02 15:04:05"), _endTime.Format("2006-01-02 15:04:05"), err.Error()),
					})
					if err != nil {
						return
					}
					ws.wsSrv.SendToClient(clientID, msg)
					continue
				}

				msg, err := json.Marshal(map[string]string{
					"module": ws.module,
					"msg":    fmt.Sprintf("成功删除时间从%s到%s, 共%d 条记录", currentTime.Format("2006-01-02 15:04:05"), _endTime.Format("2006-01-02 15:04:05"), deleteCount),
				})
				if err != nil {
					return
				}
				ws.wsSrv.SendToClient(clientID, msg)

				currentTime = currentTime.Add(time.Duration(params.Interval) * time.Second)
			case <-stopChan:
				msg, err := json.Marshal(map[string]string{
					"module": ws.module,
					"msg":    "任务已手动停止",
				})
				if err != nil {
					return
				}
				ws.wsSrv.SendToClient(clientID, msg)
				ws.HandleStopTask()
				return
			}
		}
	}()
	return nil
}

func (ws *DeleteDataWs) Pause() {
	clientID := ws.conn
	DeleteManager.lock.Lock()
	defer DeleteManager.lock.Unlock()
	if _, exists := DeleteManager.isPausedMapper[clientID]; exists {
		DeleteManager.isPausedMapper[clientID] = true
		msg, err := json.Marshal(map[string]string{
			"module": ws.module,
			"msg":    "任务已手动停止",
		})
		if err != nil {
			return
		}
		ws.wsSrv.SendToClient(clientID, msg)
	}
}

func (ws *DeleteDataWs) Resume() {
	clientID := ws.conn
	DeleteManager.lock.Lock()
	defer DeleteManager.lock.Unlock()
	if _, exists := DeleteManager.isPausedMapper[clientID]; exists {
		DeleteManager.isPausedMapper[clientID] = false
		msg, err := json.Marshal(map[string]string{
			"module": ws.module,
			"msg":    "任务已恢复",
		})
		if err != nil {
			return
		}
		ws.wsSrv.SendToClient(clientID, msg)
	}
}

func (ws *DeleteDataWs) Stop() {
	ws.HandleStopTask()
}

func (ws *DeleteDataWs) HandleStopTask() {
	clientID := ws.conn
	DeleteManager.lock.Lock()
	defer DeleteManager.lock.Unlock()
	if stopChan, exists := DeleteManager.stopChanMapper[clientID]; exists {
		defer func() {
			if r := recover(); r != nil {
				logger.Log.Error("HandleStopTask", zap.Any("recover", r))
			}
		}()

		select {
		case stopChan <- true:
			delete(DeleteManager.stopChanMapper, clientID)
		default:
			logger.Log.Warn("HandleStopTask, stopChan 可能关闭")
		}
		delete(DeleteManager.stopChanMapper, clientID)
	}
	delete(DeleteManager.isPausedMapper, clientID)
}

func (ws *DeleteDataWs) DeleteData(tableOption, statusOption int, startTime, endTime time.Time) (affected int64, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	session.Begin()

	switch tableOption {
	case 1: // 客户订单表
		var customerOrderIDs []string
		var orderIDs []int64
		switch statusOption {
		case 1: // 失败
			var tables []string
			if tables, err = partition.GlobalOrderPartition.GetTablesByDateRange(session, startTime, endTime); err != nil {
				logger.Log.Error("DeleteDataWs DeleteData")
				session.Rollback()
				return 0, err
			}

			for _, table := range tables {
				_sqlQuery := fmt.Sprintf("SELECT customer_order_id, id FROM %s WHERE status = ? AND created BETWEEN ? AND ?", table)
				rows, err := session.Query(_sqlQuery, constant.OrderStatusFail, startTime, endTime)
				if err != nil {
					session.Rollback()
					return 0, err
				}

				for _, row := range rows {
					customerOrderIDs = append(customerOrderIDs, string(row["customer_order_id"]))
					orderID, _ := strconv.ParseInt(string(row["id"]), 10, 64)
					orderIDs = append(orderIDs, orderID)
				}

				_sqlDelete := fmt.Sprintf("DELETE FROM %s WHERE status = ? AND created BETWEEN ? AND ?", table)
				var result sql.Result
				result, err = session.Exec(_sqlDelete, constant.OrderStatusFail, startTime, endTime)
				rowsAffected, _ := result.RowsAffected()
				affected += rowsAffected
				if err != nil {
					session.Rollback()
					return 0, err
				}
			}

		case 2: // 所有
			var tables []string
			if tables, err = partition.GlobalOrderPartition.GetTablesByDateRange(session, startTime, endTime); err != nil {
				logger.Log.Error("DeleteDataWs DeleteData")
				session.Rollback()
				return
			}

			for _, table := range tables {
				_sqlQuery := fmt.Sprintf("SELECT customer_order_id, id FROM %s WHERE created BETWEEN ? AND ?", table)
				rows, err := session.Query(_sqlQuery, startTime, endTime)
				if err != nil {
					session.Rollback()
					return 0, err
				}

				for _, row := range rows {
					customerOrderIDs = append(customerOrderIDs, string(row["customer_order_id"]))
					orderID, _ := strconv.ParseInt(string(row["id"]), 10, 64)
					orderIDs = append(orderIDs, orderID)
				}

				_sql := fmt.Sprintf("DELETE FROM %s WHERE created BETWEEN ? AND ?", table)
				var result sql.Result
				result, err = session.Exec(_sql, startTime, endTime)
				if err != nil {
					session.Rollback()
					return 0, err
				}
				rowsAffected, _ := result.RowsAffected()
				affected += rowsAffected
			}
		}

		if len(customerOrderIDs) > 0 {
			_sqlDeleteCustomerOrderDateMapper := fmt.Sprintf("DELETE FROM %s WHERE customer_order_id IN (?)", models.CustomerOrderDateMapper{}.TableName())
			_, err = session.Exec(_sqlDeleteCustomerOrderDateMapper, customerOrderIDs)
			if err != nil {
				session.Rollback()
				return 0, err
			}
		}

		if len(orderIDs) > 0 {
			_sqlDeleteOrderChannelRecord := fmt.Sprintf("DELETE FROM %s WHERE order_id IN (?)", models.OrderChannelRecord{}.TableName())
			_, err = session.Exec(_sqlDeleteOrderChannelRecord, orderIDs)
			if err != nil {
				session.Rollback()
				return 0, err
			}
		}

		session.Commit()

	case 2: // 渠道订单表
		switch statusOption {
		case 1:
			var tables []string
			if tables, err = partition.GlobalChannelOrderPartition.GetTablesByDateRange(session, startTime, endTime); err != nil {
				logger.Log.Error("DeleteDataWs DeleteData")
				session.Rollback()
				return
			}
			for _, table := range tables {
				_sql := fmt.Sprintf("DELETE FROM %s WHERE status = ? AND created BETWEEN ? AND ?", table)
				var result sql.Result
				result, err = session.Exec(_sql, constant.OrderStatusFail, startTime, endTime)
				if err != nil {
					session.Rollback()
					return 0, err
				}

				rowsAffected, _ := result.RowsAffected()
				affected += rowsAffected
			}
			session.Commit()
		case 2:
			var tables []string
			if tables, err = partition.GlobalChannelOrderPartition.GetTablesByDateRange(session, startTime, endTime); err != nil {
				logger.Log.Error("DeleteDataWs DeleteData")
				session.Rollback()
				return
			}
			for _, table := range tables {
				_sql := fmt.Sprintf("DELETE FROM %s WHERE created BETWEEN ? AND ?", table)
				var result sql.Result
				result, err = session.Exec(_sql, startTime, endTime)
				if err != nil {
					session.Rollback()
					return 0, err
				}

				rowsAffected, _ := result.RowsAffected()
				affected += rowsAffected
			}
			session.Commit()
		}
	case 3: // 财务记录表
		switch statusOption {
		case 1:
			sql := fmt.Sprintf(`
	DELETE cf FROM %s cf
	JOIN (
	    SELECT order_id FROM %s 
	    WHERE business_type = 2 AND created BETWEEN ? AND ?
	) sub ON cf.order_id = sub.order_id
`, models.CustomerFinance{}.TableName(), models.CustomerFinance{}.TableName())
			result, err := session.Exec(sql, startTime, endTime)
			if err != nil {
				session.Rollback()
				return 0, err
			}
			affected, _ := result.RowsAffected()
			session.Commit()
			return affected, nil
		case 2:
			sql := fmt.Sprintf(`
	DELETE FROM %s 
	    WHERE business_type in (2, 3)  AND created BETWEEN ? AND ?
`, models.CustomerFinance{}.TableName())
			result, err := session.Exec(sql, startTime, endTime)
			if err != nil {
				session.Rollback()
				return 0, err
			}
			affected, _ := result.RowsAffected()
			session.Commit()
			return affected, nil
		}
	}

	return
}

func (ws *DeleteDataWs) Handle() (err error) {
	msg := ws.msg
	switch msg.Cmd {
	case "start":
		var params vo.DataDeleteStartParams
		if err = json.Unmarshal(msg.Data, &params); err != nil {
			logger.Log.Error("Announcement HandleMsg", zap.Any("msg", msg), zap.Error(err))
			return
		}
		ws.Start(params)
	case "pause":
		ws.Pause()
	case "resume":
		ws.Resume()
	case "stop":
		ws.Stop()
	}
	return
}
