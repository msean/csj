package ws

import (
	"application/utils"
	"encoding/json"
	"log"
	"net/http"
	"sync"

	"github.com/gorilla/websocket"
	"github.com/labstack/echo"
)

type (
	WsSrv struct {
		clients   map[*websocket.Conn]bool
		broadcast chan []byte
		lock      sync.Mutex
	}
	WsMsg struct {
		Module string          `json:"module"`
		Cmd    string          `json:"cmd"`
		Data   json.RawMessage `json:"data"`
	}
)

var WsServer *WsSrv
var upgrader = websocket.Upgrader{CheckOrigin: func(r *http.Request) bool { return true }}

func Init() {
	WsServer = NewWsSrv()
	go WsServer.Run()
}

func NewWsSrv() *WsSrv {
	srv := &WsSrv{
		clients:   make(map[*websocket.Conn]bool),
		broadcast: make(chan []byte),
	}
	DeleteManager = NewDataDeleteWsMgr(srv)
	FinanceWsManager = NewFinanceMgr(srv)
	return srv
}

func (srv *WsSrv) HandleWebSocket(ctx echo.Context) error {
	conn, err := upgrader.Upgrade(ctx.Response(), ctx.Request(), nil)
	if err != nil {
		log.Println("WebSocket 连接失败:", err)
		return err
	}
	defer conn.Close()

	srv.lock.Lock()
	srv.clients[conn] = true
	srv.lock.Unlock()

	customerID := utils.CustomerID(ctx)
	if customerID > 0 {
		FinanceWsManager.AddConn(customerID, conn)
	}

	for {
		var msg WsMsg
		err := conn.ReadJSON(&msg)
		if err != nil {
			srv.lock.Lock()
			delete(srv.clients, conn)
			if customerID > 0 {
				FinanceWsManager.Delete(conn)
			}

			srv.lock.Unlock()
			break
		}
		srv.HandleMsg(conn, msg)
	}

	return nil
}

func (hub *WsSrv) Run() {
	for {
		message := <-hub.broadcast
		hub.lock.Lock()
		for client := range hub.clients {
			if err := client.WriteMessage(websocket.TextMessage, message); err != nil {
				client.Close()
				delete(hub.clients, client)
			}
		}
		hub.lock.Unlock()
	}
}

func (srv *WsSrv) SendToClient(conn *websocket.Conn, msg []byte) {
	srv.lock.Lock()
	defer srv.lock.Unlock()

	if _, ok := srv.clients[conn]; ok {
		err := conn.WriteMessage(websocket.TextMessage, msg)
		if err != nil {
			conn.Close()
			delete(srv.clients, conn)
		}
	}
}

func (srv *WsSrv) Broadcast(msg []byte) {
	srv.broadcast <- msg
}

func (srv *WsSrv) HandleMsg(conn *websocket.Conn, msg WsMsg) {
	switch msg.Module {
	case "announcement":
		NewAnnouncement(conn, msg, srv).Handle()
	case "data_delete":
		NewDataDeleteWs(conn, msg, srv).Handle()
	}
}
