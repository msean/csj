package statistic

import (
	"testing"

	_ "github.com/go-sql-driver/mysql" // 引入 MySQL 驱动
)

func TestStatistic(t *testing.T) {
	// host := "154.91.84.12"
	// port := 13306
	// username := "root"
	// password := "E376CR4Ky?"
	// dbname := "go_admin"
	// dataSource := username + ":" + password + "@tcp(" + host + ":" + utils.Violent2String(port) + ")/" + dbname + "?charset=utf8mb4&parseTime=True&loc=Local"
	// engine, err := xorm.NewEngine("mysql", dataSource)
	// if err != nil {
	// 	t.Fatalf("Failed to create database engine: %v", err)
	// }
	// defer engine.Close()

	// start := time.Now().Add(-24 * time.Hour)
	// end := time.Now()

	// status := []int{10}

	// session := engine.NewSession()
	// defer session.Close()

	// results, err := new(CustomerDayFinanceSvc).Statistic(session, start, end, status)
	// if err != nil {
	// 	t.Fatalf("Statistic failed: %v", err)
	// }

	// spew.Dump(">>>>>>>>>>>results", results)
}
