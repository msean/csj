package statistic

import (
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/utils"
	"sort"
	"strings"

	"github.com/labstack/echo"
)

type (
	OrderAnalysisSvc struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewOrderAnalysisSvc(ctx *echo.Context) *OrderAnalysisSvc {
	return &OrderAnalysisSvc{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
}

func (s *OrderAnalysisSvc) CustomerOrderList(param vo.CustomerOrderAnalysisReq) (rsp resp.CustomerOrderAnalysisRsp, err error) {
	var items []*resp.OrderAnalysisItem
	if items, err = mysql.StatisticDao.OrderAnalysisGroup(param, models.Order{}.TableName()); err != nil {
		return
	}

	rsp.Items = items
	totalProfit := float64(0.0)
	var customerIDList []int64

	for _, item := range items {
		customerIDList = append(customerIDList, item.CustomerID)
	}

	customerMapper, _ := mysql.Customer.FromIDList(customerIDList)

	for _, item := range items {
		rsp.Total.Count += item.Count
		totalProfit += item.TotalProfit
		rsp.Total.TotalSalesPrice += item.TotalSalesPrice
		rsp.Total.TotalFaceValue += item.TotalFaceValue
		rsp.Total.PurchasePrice += item.PurchasePrice
		rsp.Total.SuccessFaceValue += item.SuccessFaceValue
		item.CustomerName = customerMapper[item.CustomerID].Name
	}

	rsp.Total.PurchasePrice = utils.FloatReserve(rsp.Total.PurchasePrice, 2)
	rsp.Total.TotalProfit = utils.FloatReserve(totalProfit, 2)
	rsp.Total.TotalSalesPrice = utils.FloatReserve(rsp.Total.TotalSalesPrice, 2)
	rsp.Total.ProfitRate = utils.FloatReserveString(utils.Float64SecurityDiv(totalProfit, float64(rsp.Total.TotalFaceValue), 4), 2)
	return
}

func (s *OrderAnalysisSvc) ChannelOrderList(param vo.CustomerOrderAnalysisReq) (rsp resp.ChannelOrderAnalysisRsp, err error) {
	var items []*resp.OrderAnalysisItem
	if items, err = mysql.StatisticDao.OrderAnalysisGroup(param, models.ChannelOrder{}.TableName()); err != nil {
		return
	}

	rsp.Items = items
	totalProfit := float64(0.0)
	var channelIDList []int64

	for _, item := range items {
		channelIDList = append(channelIDList, item.ChannelID)
	}

	channelMapper, _ := mysql.Channel.FromIDList(channelIDList)

	for _, item := range items {
		rsp.Total.Count += item.Count
		totalProfit += item.TotalProfit
		rsp.Total.TotalSalesPrice += item.TotalSalesPrice
		rsp.Total.TotalFaceValue += item.TotalFaceValue
		rsp.Total.PurchasePrice += item.PurchasePrice
		rsp.Total.SuccessFaceValue += item.SuccessFaceValue
		item.ChannelName = channelMapper[item.ChannelID].Name
	}

	rsp.Total.PurchasePrice = utils.FloatReserve(rsp.Total.PurchasePrice, 2)
	rsp.Total.TotalProfit = utils.FloatReserve(totalProfit, 2)
	rsp.Total.TotalSalesPrice = utils.FloatReserve(rsp.Total.TotalSalesPrice, 2)
	rsp.Total.ProfitRate = utils.FloatReserveString(utils.Float64SecurityDiv(totalProfit, float64(rsp.Total.TotalFaceValue), 4), 2)
	return
}

func (s *OrderAnalysisSvc) SuccessRate(param vo.CustomerOrderSuccessRateReq) (rsp []*resp.CustomerOrderSuccessRateRsp, err error) {
	rsp, err = mysql.StatisticDao.SuccessRate(param)

	switch param.GroupType {
	case 1:
		var channelIDList []int64
		var channelMapper map[int64]models.Customer
		for _, item := range rsp {
			channelIDList = append(channelIDList, item.ObjectID)
		}

		channelMapper, _ = mysql.Customer.FromIDList(channelIDList)
		for _, item := range rsp {
			item.Name = channelMapper[item.ObjectID].Name
		}
	case 2:
		var channelIDList []int64
		var channelMapper map[int64]models.Channel
		for _, item := range rsp {
			channelIDList = append(channelIDList, item.ObjectID)
		}
		channelMapper, _ = mysql.Channel.FromIDList(channelIDList)

		for _, item := range rsp {
			item.Name = channelMapper[item.ObjectID].Name
		}
	case 3, 4:
		sort.Slice(rsp, func(i, j int) bool {
			return strings.ToLower(rsp[i].Name) < strings.ToLower(rsp[j].Name)
		})
	}

	return
}
