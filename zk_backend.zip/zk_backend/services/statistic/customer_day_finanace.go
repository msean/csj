package statistic

import (
	"application/common/logger"
	"application/conf"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/utils"
	"fmt"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	CustomerDayFinanceSvc struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewCustomerDayFinanceSvc(ctx *echo.Context) *CustomerDayFinanceSvc {
	srv := &CustomerDayFinanceSvc{}
	if ctx != nil {
		srv.Uuid = utils.GetContextUUID(*ctx)
		srv.Ctx = ctx
	}
	return srv
}

func (s *CustomerDayFinanceSvc) List(param vo.CustomerFinanceDayStatisticReq) (rsp []resp.CustomerFinanceDayStatisticRsp, count int64, err error) {

	rsp = make([]resp.CustomerFinanceDayStatisticRsp, 0)

	var records []models.CustomerDayFinanceStatic
	records, count, err = mysql.StatisticDao.ListDayFinance(param)
	if err != nil {
		return
	}
	var customerIDList []int64

	for _, record := range records {
		customerIDList = append(customerIDList, record.CustomerID)
	}

	customerMapper, _ := mysql.Customer.FromIDList(customerIDList)

	for _, record := range records {
		rsp = append(rsp, s.ListCustomerFinanceDayRsp(record, customerMapper[record.CustomerID]))
	}
	return
}

func (s *CustomerDayFinanceSvc) Export(param vo.CustomerFinanceDayStatisticReq) (filePath string, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[BlacklistSvc] [Export]", zap.Any("param", param), zap.Error(err))
		}
	}()

	filePath = fmt.Sprintf("%d客户每日对账.xlsx", time.Now().Unix())
	var objects []resp.CustomerFinanceDayStatisticRsp
	if objects, _, err = s.List(param); err != nil {
		return
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objects, mysql.SysDict.DataValueLabelMapper())
	return
}

func (s *CustomerDayFinanceSvc) ListCustomerFinanceDayRsp(record models.CustomerDayFinanceStatic, customer models.Customer) (rsp resp.CustomerFinanceDayStatisticRsp) {
	return resp.CustomerFinanceDayStatisticRsp{
		Date:             record.Date,
		MobileFaceValue:  utils.Violent2String(record.MobileFaceValue),
		MobileSales:      utils.Violent2String(record.MobileSales),
		UnicomFaceValue:  utils.Violent2String(record.UnicomFaceValue),
		UnicomSales:      utils.Violent2String(record.UnicomSales),
		TelecomFaceValue: utils.Violent2String(record.TelecomFaceValue),
		TelecomSales:     utils.Violent2String(record.TelecomSales),
		TotalCount:       utils.Violent2String(record.MobileFaceValue + record.UnicomFaceValue + record.TelecomFaceValue),
		TotalSales:       utils.Violent2String(record.MobileSales + record.UnicomSales + record.TelecomSales),
		RechargeAmount:   utils.Violent2String(record.RechargeAmount),
		OtherAmount:      utils.Violent2String(record.OtherAmount),
		Balance:          utils.Violent2String(record.Balance),
		ReOrderAmount:    utils.Violent2String(record.ReOrderAmount),
		CustomerName:     customer.Name,
	}
}

// 凌晨20分统计 订单数据和加款金额/其他加款金额吧，防止订单状态
func (s *CustomerDayFinanceSvc) Statistic(date string, status []int) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	loc, _ := time.LoadLocation("Local")

	start, err := time.ParseInLocation("2006-01-02", date, loc)
	if err != nil {
		return fmt.Errorf("invalid date format: %v", err)
	}
	end := start.AddDate(0, 0, 1).Add(-time.Second) // 计算当天 23:59:59

	table := partition.GlobalOrderPartition.TableNameByDate(start)
	var orderStats []models.CustomerOrderStatistic
	if err = session.Table(table).
		Select("isp, customer_id, SUM(sale_price) AS total_sales, SUM(face_value) AS total_face_value").
		Where("created >= ? AND created <= ?", start, end).
		In("status", status).
		GroupBy("isp, customer_id").
		Find(&orderStats); err != nil {
		return fmt.Errorf("failed to fetch order statistics: %v", err)
	}

	var financeStats []models.FinanceDayStatistic
	if err = session.Table(models.CustomerFinance{}.TableName()).
		Select("SUM(amount) as amount,  customer_id, business_type").
		Where("created >= ? AND created <= ?", start, end).
		GroupBy("business_type, customer_id").
		Find(&financeStats); err != nil {
		return fmt.Errorf("failed to fetch finance statistics: %v", err)
	}

	customerFinanceMap := make(map[int64]*models.CustomerDayFinanceStatic)
	for _, stat := range orderStats {
		cf, exists := customerFinanceMap[stat.CustomerID]
		if !exists {
			cf = &models.CustomerDayFinanceStatic{
				Date:       date,
				CustomerID: stat.CustomerID,
			}
			customerFinanceMap[stat.CustomerID] = cf
		}

		switch stat.Isp {
		case 1:
			cf.MobileFaceValue += float64(stat.TotalFaceValue)
			cf.MobileSales += stat.TotalSales
		case 2:
			cf.UnicomFaceValue += float64(stat.TotalFaceValue)
			cf.UnicomSales += stat.TotalSales
		case 3:
			cf.TelecomFaceValue += float64(stat.TotalFaceValue)
			cf.TelecomSales += stat.TotalSales
		}
	}

	for _, stat := range financeStats {
		cf, exists := customerFinanceMap[stat.CustomerID]
		if !exists {
			cf = &models.CustomerDayFinanceStatic{
				Date:       date,
				CustomerID: stat.CustomerID,
			}
			customerFinanceMap[stat.CustomerID] = cf
		}

		switch stat.BusinessType {
		case 1:
			cf.RechargeAmount += stat.Amount
		case 4:
			cf.OtherAmount += stat.Amount
			cf.ReOrderAmount += stat.Amount
		case 5:
			cf.OtherAmount += stat.Amount
		}
	}

	for _, cf := range customerFinanceMap {
		var exist bool
		conds := []utils.Cond{
			utils.NewWhereCond("date", cf.Date),
			utils.NewWhereCond("customer_id", cf.CustomerID),
		}
		var storage models.CustomerDayFinanceStatic
		exist, err = daos.GetRecordByField(session, storage.TableName(), &storage, conds...)
		if exist {
			cf.ID = storage.ID
			updatesCols := []string{
				"mobile_count",
				"mobile_amount",
				"unicom_count",
				"unicom_amount",
				"telecom_count",
				"telecom_amount",
				"recharge_amount",
				"other_amount",
				"re_order_amount",
			}
			daos.UpdateColsWithVersion(session, cf, updatesCols...)
		} else {
			if _, err := session.Table(models.CustomerDayFinanceStatic{}.TableName()).Insert(cf); err != nil {
				return fmt.Errorf("failed to insert customer day finance static: %v", err)
			}
		}
	}
	return
}

// 凌晨统计实际余额
func (s *CustomerDayFinanceSvc) DayFinanceStatistic(date string) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	type CustomerBalance struct {
		CustomerID int64   `xorm:"'customer_id'"`
		Balance    float64 `xorm:"'balance'"`
	}
	var balanceStats []CustomerBalance
	if err = session.Table(models.Customer{}.TableName()).
		Select("balance, id as customer_id").
		Find(&balanceStats); err != nil {
		return fmt.Errorf("failed to fetch finance statistics: %v", err)
	}

	customerFinanceMap := make(map[int64]*models.CustomerDayFinanceStatic)

	for _, stat := range balanceStats {
		cf, exists := customerFinanceMap[stat.CustomerID]
		if !exists {
			cf = &models.CustomerDayFinanceStatic{
				Date:       date,
				CustomerID: stat.CustomerID,
			}
			customerFinanceMap[stat.CustomerID] = cf
		}
		cf.Balance = stat.Balance
	}

	for _, cf := range customerFinanceMap {
		var exist bool
		conds := []utils.Cond{
			utils.NewWhereCond("date", cf.Date),
			utils.NewWhereCond("customer_id", cf.CustomerID),
		}
		var storage models.CustomerDayFinanceStatic
		exist, err = daos.GetRecordByField(session, storage.TableName(), &storage, conds...)
		if exist {
			cf.ID = storage.ID
			updatesCols := []string{
				"balance",
			}
			daos.UpdateColsWithVersion(session, cf, updatesCols...)
		} else {
			if _, err := session.Table(models.CustomerDayFinanceStatic{}.TableName()).Insert(cf); err != nil {
				return fmt.Errorf("failed to insert customer day finance static: %v", err)
			}
		}
	}
	return
}
