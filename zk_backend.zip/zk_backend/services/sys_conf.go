package services

import (
	"application/common/logger"
	"application/conf"
	_constant "application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/services/cache"
	"application/utils"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type SysConfigSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewSysConfigSrv(ctx *echo.Context) *SysConfigSrv {
	bean := &SysConfigSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *SysConfigSrv) Create(params vo.SysArgCreateParams) (obj models.SysArgConfig, err error) {
	if err = copier.Copy(&obj, &params); err != nil {
		return
	}
	session := daos.Mysql.NewSession()
	defer session.Close()

	var exist bool
	if exist, err = daos.Exist(session, &models.SysArgConfig{}, 0, map[string]any{
		"config_key": params.Key,
	}); err != nil {
		return
	}

	if exist {
		err = fmt.Errorf("%s对应的配置已经存在", params.Key)
		return
	}

	_, err = daos.CreateObjs(session, &obj)
	return
}

func (srv *SysConfigSrv) Update(params vo.SysArgUpdateParams) (obj models.SysArgConfig, err error) {
	if err = copier.Copy(&obj, &params); err != nil {
		return
	}
	session := daos.Mysql.NewSession()
	defer session.Close()

	if _, err = daos.UpdateObjWithVersion(session, &obj, nil); err != nil {
		return
	}

	cache.UpdateCacheModelPk(models.SysArgConfig{}.TableName(), cache.SysConfigPk(params.Key), &models.SysArgConfig{}, true)
	return
}

func (srv *SysConfigSrv) Delete(params vo.DeleteParams) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	var sysCfgList []models.SysArgConfig
	if sysCfgList, err = mysql.SysArgConfig.FromIDList(params.IDList); err != nil {
		return
	}

	for _, sysCfg := range sysCfgList {
		if err = cache.DelCacheModelPk(models.SysArgConfig{}.TableName(), cache.SysConfigPk(sysCfg.Key)); err != nil {
			return
		}
	}

	_, err = daos.DelObjs(session, params.IDList, &models.SysArgConfig{})
	return
}

func (srv *SysConfigSrv) FormID(id int64) (obj models.SysArgConfig, has bool, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &obj)
	return
}

func (srv *SysConfigSrv) List(params vo.SysArgListParams) (objs []models.SysArgConfig, total int64, err error) {
	return mysql.SysArgConfig.List(params)
}

func (srv *SysConfigSrv) DataExport(params vo.SysArgListParams) (filePath string, err error) {
	filePath = fmt.Sprintf("%d参数数据.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d参数数据.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var objs []models.SysArgConfig
	if objs, _, err = mysql.SysArgConfig.List(params); err != nil {
		return
	}
	if len(objs) == 0 {
		objs = append(objs, models.SysArgConfig{})
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objs, nil)
	return
}

// InReconMaintenance 是否在对账维护时间
func (srv *SysConfigSrv) InReconMaintenance() (yes bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysConfigSrv] [InReconMaintenance]", zap.Error(err))
		}
	}()

	var sys models.SysArgConfig
	var has bool
	sys, has, err = cache.SysCfgFromKey(_constant.SysConfDzTimeKey)
	if err != nil {
		return
	}

	if !has {
		sys = models.SysArgConfig{
			Name:  _constant.SysConfDzTimeName,
			Key:   _constant.SysConfDzTimeKey,
			Value: fmt.Sprintf("%d", _constant.SysConfDzTimeValue),
			Typ:   _constant.SysConfDefault,
		}

		session := daos.Mysql.NewSession()
		defer session.Close()
		if _, err = daos.CreateObjs(session, &sys); err != nil {
			return
		}
	}

	var dzTime int
	if dzTime, err = strconv.Atoi(sys.Value); err != nil {
		return
	}

	now := time.Now()
	end1 := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, now.Location())
	start1 := end1.Add(-time.Duration(dzTime) * time.Millisecond)

	start2 := end1
	end2 := start2.Add(time.Duration(dzTime) * time.Millisecond)

	yes = (now.After(start1) && now.Before(end1)) || (now.After(start2) && now.Before(end2))
	return
}

// IspCheck ispCheck
func (srv *SysConfigSrv) IspCheck(phone string, isp _constant.Isp, order *models.Order) (oc _constant.ApiCodeMsg, province, area string, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[SysConfigSrv] [IspCheck]",
				zap.String("phone", phone),
				zap.Int64("isp", int64(isp)),
				zap.Error(err))
		}
	}()

	// var sysconfM map[string]models.SysArgConfig
	// if sysconfM, err = mysql.SysArgConfig.FromKeys([]string{_constant.SysConfIspKey, _constant.SysConfIspUrl, _constant.SysConfIspFlag}); err != nil {
	// 	return
	// }
	// ispApiKey := sysconfM[_constant.SysConfIspKey].Value
	// ispApiUrl := sysconfM[_constant.SysConfIspUrl].Value
	// ispApiFlag := sysconfM[_constant.SysConfIspFlag].Value
	var ispApiKeySysCfg models.SysArgConfig
	var ispApiUrlSysCfg models.SysArgConfig
	var ispApiFlagSysCfg models.SysArgConfig
	if ispApiKeySysCfg, _, err = cache.SysCfgFromKey(_constant.SysConfIspKey); err != nil {
		return
	}
	if ispApiUrlSysCfg, _, err = cache.SysCfgFromKey(_constant.SysConfIspUrl); err != nil {
		return
	}

	if ispApiFlagSysCfg, _, err = cache.SysCfgFromKey(_constant.SysConfIspFlag); err != nil {
		return
	}
	if !utils.IsBlankString(ispApiKeySysCfg.Value) && !utils.IsBlankString(ispApiUrlSysCfg.Value) {
		var body []byte
		type Result struct {
			Code   int `json:"code"`
			Result struct {
				NowISP  string `json:"Now_isp"`
				InitISP string `json:"Init_isp"`
				Area    string `json:"Area"`
			} `json:"result"`
		}
		if _, body, err = utils.NewRequest().Get().Url(ispApiUrlSysCfg.Value).Params(map[string]string{
			"mobile": phone,
			"apikey": ispApiKeySysCfg.Value,
		}).Timeout(5 * time.Second).Do(); err != nil {
			return
		}

		var r Result
		if err = json.Unmarshal(body, &r); err != nil {
			return
		}
		if utils.StringInSlice(r.Result.NowISP, []string{"移动", "联通", "电信"}) && isp.String() != r.Result.NowISP {
			logger.Log.Error("[SysConfigSrv] [IspCheck]", zap.String("nowIsp", r.Result.NowISP))
			oc = _constant.NewApiCodeMsg(_constant.ApiOrderIspCheckInconsistent)
			return
		}

		if utils.StringInSlice(r.Result.NowISP, []string{"移动", "联通", "电信"}) && isp.String() != r.Result.NowISP {
			oc = _constant.NewApiCodeMsg(_constant.ApiOrderIspCheckUnSupport)
			if ispApiFlagSysCfg.Value == "1" {
				go func() {
					NewBlacklistSvc(nil).Create(vo.BlacklistCreateParams{
						Phones: phone,
						Remark: "携号转网",
					})
				}()
			}
			return
		}

		areaProvinceSplits := strings.Split(r.Result.Area, "-")
		if len(areaProvinceSplits) > 2 {
			province = areaProvinceSplits[0]
			area = areaProvinceSplits[1]
		}
	}
	return
}
