package services

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models/vo"
	"fmt"
	"strconv"
	"strings"
)

type menuInfo struct {
	Key    string
	Parent int64
}
type cacheService struct {
	menuUrlMap      map[string]int64
	menuIdMap       map[int64]menuInfo
	roleMenus       map[int64]map[int64]bool // map[roleId] = {menuId: true(value unused)}
	menuTree        map[int64][]*vo.MenuVo   // map[roleId] = menuTree, roleID: fullTree
	customerWarning bool                     // 客户预警音开关
}

var gCacheService *cacheService

func (s *cacheService) getMenuUrlCacheKey(url string, method string) string {
	return fmt.Sprintf("%s_%s", url, method)
}

/*func (s *cacheService) getRoleMenuKey(roleId int64, menuId string) string {
	return fmt.Sprintf("%d_%s", roleId, menuId)
}*/

func (s *cacheService) initMenu() {
	menus, err := mysql.Menu.FindMenuByIds(nil, true, 0)
	if err != nil {
		logger.Log.Error("init menu cache failed, " + err.Error())
		return
	}

	s.menuUrlMap = make(map[string]int64)
	s.menuIdMap = make(map[int64]menuInfo)
	for _, menu := range menus {
		key := s.getMenuUrlCacheKey(menu.Url, menu.Method)
		s.menuUrlMap[key] = menu.ID
		s.menuIdMap[menu.ID] = menuInfo{Key: key, Parent: menu.ParentId}
	}

	s.menuTree = make(map[int64][]*vo.MenuVo)
	logger.Log.Info("init menu cache success")
}

func (s *cacheService) setRoleMenu(roleId int64, menus string) {
	menuMap := make(map[int64]bool)
	if menus != "" {
		for _, menuIdStr := range strings.Split(menus, ",") {
			menuId, _ := strconv.Atoi(menuIdStr)
			menuMap[int64(menuId)] = true
		}
	}

	s.roleMenus[roleId] = menuMap
}

func (s *cacheService) getRoleMenu(roleId int64) []int64 {
	menus := s.roleMenus[roleId]
	if menus == nil {
		return []int64{}
	}

	menuIds := make([]int64, 0)
	for menuID, _ := range menus {
		menuIds = append(menuIds, menuID)
	}

	return menuIds
}

func (s *cacheService) checkRoleMenu(roleId int64, menuId int64) bool {
	menus := s.roleMenus[roleId]
	if menus == nil {
		return false
	}

	_, ok := menus[menuId]
	return ok
}

func (s *cacheService) findUrlMenuId(url string, method string) int64 {
	key := s.getMenuUrlCacheKey(url, method)
	if menuId, ok := s.menuUrlMap[key]; ok {
		return menuId
	}

	key = s.getMenuUrlCacheKey(url, "")
	if menuId, ok := s.menuUrlMap[key]; ok {
		return menuId
	}

	index := strings.LastIndex(url, "/")
	if index > 0 {
		return s.findUrlMenuId(url[:index], method)
	}

	return 0
}

func (s *cacheService) initRoleMenu() {
	roles, err := mysql.Role.FindRoleByIds(nil, true)
	if err != nil {
		logger.Log.Error("init role menu cache failed, " + err.Error())
		return
	}

	s.roleMenus = make(map[int64]map[int64]bool)
	for _, role := range roles {
		s.setRoleMenu(role.ID, role.Menu)
	}

	logger.Log.Info("init role menu cache success")
}

func (s *cacheService) resetMenuTree(roleID int64) {
	if roleID <= 0 {
		s.menuTree = make(map[int64][]*vo.MenuVo)
	} else {
		delete(s.menuTree, roleID)
	}
}

func (s *cacheService) initCustomerWarning() {

	session := daos.Mysql.NewSession()
	defer session.Close()

	obj, has, err := mysql.SysArgConfig.FromKey(session, constant.SysConfCustomerWarning)
	if err != nil {
		logger.Log.Error("init customer warning cache failed, " + err.Error())
		return
	}

	if has {
		parseBool, _ := strconv.ParseBool(obj.Value)
		s.customerWarning = parseBool
	} else {
		s.customerWarning = false
	}

	logger.Log.Info(fmt.Sprintf("init customer warning cache success, %v", s.customerWarning))
}

func NewServiceCache() *cacheService {

	return gCacheService
}

func (s *cacheService) Init() {
	if gCacheService == nil {
		gCacheService = &cacheService{}
		gCacheService.initMenu()
		gCacheService.initRoleMenu()
		gCacheService.initCustomerWarning()
	}
}

func (s *cacheService) UpdateMenuUrl(id int64, parentId int64, url string, method string, isDelete bool) {
	s.resetMenuTree(0)
	delete(s.menuUrlMap, s.menuIdMap[id].Key)
	if isDelete {
		delete(s.menuIdMap, id)
	} else {
		key := s.getMenuUrlCacheKey(url, method)
		s.menuUrlMap[key] = id
		s.menuIdMap[id] = menuInfo{Key: key, Parent: parentId}
	}
}

func (s *cacheService) FindMenuByUrl(url string, method string) int64 {
	return s.findUrlMenuId(url, method)
}

func (s *cacheService) UpdateRoleMenu(roleId int64, menus string, isDelete bool) {
	s.resetMenuTree(roleId)
	if isDelete {
		delete(s.roleMenus, roleId)
	} else {
		s.setRoleMenu(roleId, menus)
	}
}

func (s *cacheService) UpdateCustomerWarning(isWarning bool) {
	gCacheService.customerWarning = isWarning
}

func (s *cacheService) CheckRoleMenu(roleId int64, menuId int64) bool {
	if menus, ok := s.roleMenus[roleId]; ok {
		if _, ok := menus[menuId]; ok {
			return true
		}

		for {
			info, ok := s.menuIdMap[menuId]
			if !ok || info.Parent <= 0 {
				// 已是最上层目录
				return false
			}

			// 检查是否有上级目录权限
			if _, ok := menus[info.Parent]; ok {
				return true
			}

			// 递归查找上级目录
			menuId = info.Parent
		}
	}

	return false
}

func (s *cacheService) FindMenuTree(roleID int64) []*vo.MenuVo {
	menuTree, ok := s.menuTree[roleID]
	if ok {
		return menuTree
	}

	return nil
}

func (s *cacheService) UpdateMenuTree(roleID int64, data []*vo.MenuVo) {
	s.menuTree[roleID] = data
}

func (s *cacheService) CustomerWarning() bool {
	return gCacheService.customerWarning
}

// 缓存用户菜单关系
/*func (s *cacheService) UserMenu() {
	userList, err := mysql.User.FindAllUser()
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] cache user menu failed", this.Uuid), zap.Error(err))
		return
	}
	m := make(map[string]struct{})
	for _, user := range userList {
		userId := user.ID
		list, err := mysql.Menu.FindMenuIdsByUserId(userId)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] find user menu failed", this.Uuid), zap.Error(err))
			return
		}

		for _, mid := range list {
			m[fmt.Sprintf("%d-%d", userId, mid)] = struct{}{}
		}
	}
	systemSetting.UserMenus = m
	logger.Log.Info(fmt.Sprintf("[%s] UserMenu 缓存完毕", this.Uuid))
}*/
