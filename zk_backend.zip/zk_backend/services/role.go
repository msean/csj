package services

import (
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"github.com/labstack/echo"
)

type roleService struct {
	Ctx  *echo.Context
	Uuid string
}

func (s *roleService) makeRole(role *models.Role, params *vo.RoleParams) *models.Role {
	role.RoleName = params.RoleName
	role.RoleOrder = params.RoleOrder
	role.Available = params.Available
	role.Menu = params.Menus
	role.Remark = params.Remark
	role.IsClient = params.IsClient
	return role
}

func (s *roleService) makeRoleVo(role *models.Role) *vo.RoleVo {
	bean := &vo.RoleVo{
		Id:        role.ID,
		RoleName:  role.RoleName,
		RoleOrder: role.RoleOrder,
		Available: role.Available,
		Menus:     role.Menu,
		Remark:    role.Remark,
		IsClient:  role.IsClient,
		Created:   utils.FormatTime(role.Created),
		Updated:   utils.FormatTime(role.Updated),
	}

	return bean
}

func NewServiceRole(ctx *echo.Context) *roleService {
	bean := &roleService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (s *roleService) CreateRole(params *vo.RoleParams) (*vo.RoleVo, error) {
	role := &models.Role{IsSuper: false}
	err := mysql.Role.InsertBean(utils.UserId(*s.Ctx), s.makeRole(role, params))
	if err != nil {
		return nil, errors.New("insert failed, " + err.Error())
	}

	NewServiceCache().UpdateRoleMenu(role.ID, role.Menu, false)
	return s.makeRoleVo(role), nil
}

func (s *roleService) UpdateRole(params *vo.RoleParams) (*vo.RoleVo, error) {
	role, err := mysql.Role.GetBeanById(params.Id)
	if err != nil {
		return nil, errors.New("query failed, " + err.Error())
	}

	err = mysql.Role.UpdateBean(utils.UserId(*s.Ctx), s.makeRole(role, params))
	if err != nil {
		return nil, errors.New("update failed, " + err.Error())
	}

	NewServiceCache().UpdateRoleMenu(role.ID, role.Menu, false)
	return s.makeRoleVo(role), nil
}

func (s *roleService) RemoveRole(roleIDs []int64) (int64, error) {
	count, err := mysql.Role.DeleteBeanByIds(roleIDs)
	if err != nil {
		return 0, errors.New("delete failed, " + err.Error())
	}

	if count <= 0 {
		return 0, errors.New("can't find")
	}

	for _, roleID := range roleIDs {
		NewServiceCache().UpdateRoleMenu(roleID, "", true)
	}

	return count, nil
}

func (s *roleService) QueryRole(params vo.RoleQueryParam) (*vo.QueryRoleRes, error) {
	count, roles, err := mysql.Role.QueryRole(params)
	if err != nil {
		return nil, err
	}

	/*if count <= 0 {
		return nil, errors.New("can't find")
	}*/

	res := make([]*vo.RoleVo, 0)
	if count > 0 {
		for _, role := range roles {
			res = append(res, s.makeRoleVo(role))
		}
	}

	return &vo.QueryRoleRes{
		Count: count,
		Roles: res,
	}, nil
}

/*func (s *roleService) EditRole(uid int64, params *vo.RoleParams) error {
	var (
		role *models.Role
		err  error
	)
	if 0 == params.Id {

	} else {
		role, err = mysql.Role.GetBeanById(params.Id)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("根据id查询角色 失败 [%d]", params.Id), zap.Error(err))
			return errors.New("查询角色异常")
		}
		role.RoleName = params.RoleName
		role.Status = params.Status
		role.Remark = params.Remark
		err = mysql.Role.UpdateBean(uid, role)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("修改角色 失败 [%s]", convertor.ToString(role)), zap.Error(err))
			return err
		}
		// 删除权限
		mysql.Menu.DeleteRoleMenuByRoleId(role.ID)
	}
	// 添加权限
	for _, menuId := range params.Menus {
		mysql.Menu.InsertRoleMenu(&models.RoleMenu{
			RoleId: role.ID,
			MenuId: menuId,
		})
	}
	// 刷新缓存
	NewServiceCache(s.Ctx).UserMenu()
	return nil
}*/

/*func (s *roleService) DeleteRoleByIds(ids []int64) error {
	for _, id := range ids {
		list := mysql.Role.FindRoleIdsByRoleId(id)
		if list != nil && 0 < len(list) {
			return errors.New(fmt.Sprintf("id为%d,的角色正在使用中，不可删除", id))
		}
		mysql.Role.DeleteBeanById(id)
		mysql.Role.DeleteUserRoleByRoleId(id)
		mysql.Menu.DeleteRoleMenuByRoleId(id)
	}
	return nil
}*/

/*func (s *roleService) GetRoleTree(userId int64, status string) ([]*vo.RoleTreeVo, error) {
	user, err := mysql.User.GetBeanById(userId)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("获取用户 失败 [%d]", userId), zap.Error(err))
		return nil, err
	}
	var menus []*models.Role
	if utils.IsAdmin(user) {
		menus, err = mysql.Role.FindRoleByIds(nil, status)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("获取角色列表 失败 [%d]", userId), zap.Error(err))
			return nil, err
		}
	} else {
		mids := mysql.Role.FindRoleIdsByUserId(userId)
		if 0 == len(mids) {
			return []*vo.RoleTreeVo{}, nil
		}
		menus, err = mysql.Role.FindRoleByIds(mids, status)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("获取角色列表 失败 [%d | %s]", userId, convertor.ToString(mids)), zap.Error(err))
			return nil, err
		}
	}

	// 找到最上级
	ids := s.findParentIds(menus)
	vos := make([]*vo.RoleTreeVo, 0)
	for _, id := range ids {
		tree := s.newTree(id, menus)
		vos = append(vos, tree...)
	}
	return make([]*vo.RoleTreeVo, 0), nil
}*/

/*func (s *roleService) findParentIds(menus []*models.Role) []int64 {
	parentIds := make(map[int64]struct{})
	ids := make(map[int64]struct{})
	for _, menu := range menus {
		_, has := parentIds[menu.ParentId]
		_, has2 := ids[menu.ParentId]
		if !has && !has2 {
			parentIds[menu.ParentId] = struct{}{}
		}
		ids[menu.ID] = struct{}{}
	}
	arr := make([]int64, 0)
	for k, _ := range parentIds {
		arr = append(arr, k)
	}
	return arr
	return make([]int64, 0)
}*/

/*
func (s *roleService) newTree(id int64, menus []*models.Role) []*vo.RoleTreeVo {
	tree := make([]*vo.RoleTreeVo, 0)
	for _, menu := range menus {
		if menu.ParentId == id {
			child := &vo.RoleTreeVo{
				Id:   menu.ID,
				Name: menu.RoleName,
			}
			child.Children = s.newTree(menu.ID, menus)
			tree = append(tree, child)
		}
	}
return tree
}*/

/*
has:是否存在上级
has:是否同级最后一个
num:几级循环
*/
/*func (s *roleService) findRole(has bool, num int, tree []*vo.RoleTreeVo) []*vo.RoleVo {
	list := make([]*vo.RoleVo, 0)
	i := 0
	treeLen := len(tree)
	for _, role := range tree {
		i = i + 1
		r, _ := mysql.Role.GetBeanById(role.Id)
		menuIds := mysql.Menu.FindMenuIdsByRoleId(role.Id)
		bean := &vo.RoleVo{
			Id:             r.ID,
			ParentId:       r.ParentId,
			RoleName:       r.RoleName,
			PrefixRoleName: r.RoleName,
			Status:         r.Status,
			Remark:         r.Remark,
			Menus:          menuIds,
		}
		if !r.Created.IsZero() {
			bean.Created = r.Created.Format("2006-01-02 15:04:05")
		}
		if !r.Updated.IsZero() {
			bean.Updated = r.Updated.Format("2006-01-02 15:04:05")
		}
		if has {
			prefix := ""
			for j := 0; j < num-1; j++ {
				prefix = "│ " + prefix
			}
			if i == treeLen {
				bean.PrefixRoleName = prefix + "└ " + bean.PrefixRoleName
			} else {
				bean.PrefixRoleName = prefix + "├ " + bean.PrefixRoleName
			}
		}
		list = append(list, bean)
		if 0 != len(role.Children) {
			list = append(list, s.findRole(true, num+1, role.Children)...)
		}
	}
	return list
}*/
