package services

import (
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"

	"github.com/labstack/echo"
)

type (
	AnnouncementSrv struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewAnnouncementSrv(ctx *echo.Context) *AnnouncementSrv {
	bean := &AnnouncementSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *AnnouncementSrv) Create(params vo.AnnouncementCreateParams) (err error) {
	return mysql.Announcement.Create(models.Announcement{
		Title:   params.Title,
		Content: params.Content,
		Remark:  params.Remark,
		Status:  1,
	})
}

func (srv *AnnouncementSrv) List(params vo.AnnouncementListParams) (rsp []models.Announcement, total int64, err error) {
	return mysql.Announcement.List(params)
}

func (srv *AnnouncementSrv) Delete(params vo.DeleteParams) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	_, err = daos.DelObjs(session, params.IDList, models.Announcement{})
	return
}

func (srv *AnnouncementSrv) Update(params vo.AnnouncementUpdateParams) (err error) {
	model := models.Announcement{
		Title:   params.Title,
		Content: params.Content,
		Remark:  params.Remark,
	}
	model.ID = params.ID

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.UpdateObjWithVersion(session, &model, nil)
	return
}
