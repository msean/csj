package services

import (
	"application/common/logger"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type ChannelGroupSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewChannelGroupSrv(ctx *echo.Context) *ChannelGroupSrv {
	bean := &ChannelGroupSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *ChannelGroupSrv) FromID(channelGroupID int64) (channelGroup models.ChannelGroup, has bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [FromID]", zap.Int64("channelGroupID", channelGroupID), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, channelGroupID, &channelGroup)
	return
}

func (srv *ChannelGroupSrv) Create(params vo.ChannelGroupCreateParams) (channelGroup models.ChannelGroup, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [Create]", zap.Any("params", params), zap.Error(err))
		}
	}()

	if err = copier.Copy(&channelGroup, &params); err != nil {
		return
	}
	for _, channel := range params.ChannelList {
		channelGroup.Rels = append(channelGroup.Rels, models.ChannelGroupRel{
			Percent:   1,
			ChannelID: channel,
		})
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.CreateObjs(session, &channelGroup)
	return
}

func (srv *ChannelGroupSrv) Update(params vo.ChannelGroupUpdateParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [Update]", zap.Any("params", params), zap.Error(err))
		}
	}()

	var groupRels []models.ChannelGroupRel
	for _, rel := range params.Rels {
		groupRels = append(groupRels, models.ChannelGroupRel{
			Percent:   rel.Percent,
			ChannelID: rel.ChannelID,
		})
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	return mysql.ChannelGroup.Update(session, params.ID, params.Name, groupRels)
}

func (srv *ChannelGroupSrv) Detail(id int64) (channelGroup models.ChannelGroup, has bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [Update]", zap.Int64("id", id), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &channelGroup)
	return
}

func (srv *ChannelGroupSrv) Delete(idList []int64) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [Delete]", zap.Int64s("idList", idList), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.DelObjs(session, idList, models.ChannelGroup{})
	return
}

func (srv *ChannelGroupSrv) List(params vo.ChannelGroupListParams) (channelGroups []models.ChannelGroup, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [List]", zap.Any("params", params), zap.Error(err))
		}
	}()

	channelGroups, total, err = mysql.ChannelGroup.List(params)
	return
}
