package services

import (
	"application/common/logger"
	"application/daos/mysql"
	"application/models/vo"
	"context"
	"fmt"
	"sync"
	"time"

	"go.uber.org/zap"
	"golang.org/x/time/rate"
)

// 1、下单   2、查单   3余额
type Limiter struct {
	limiter map[string]*rate.Limiter
	mu      sync.RWMutex
}

var ChannelLimiter = Limiter{
	limiter: make(map[string]*rate.Limiter),
}

func InitChannelLimiter() {
	ChannelLimiter = Limiter{
		limiter: make(map[string]*rate.Limiter),
	}
	channels, _, err := mysql.Channel.ListByParams(vo.ChannelListParams{
		StatusChoice: 2,
	})
	if err != nil {
		panic(err)
	}

	for _, channel := range channels {
		for _, thread := range channel.LimitConfig {
			key := fmt.Sprintf("%d_%d", channel.ID, thread.Type)
			requestPerSecond := 1000.0 / float64(thread.FrequencyLimit) * float64(thread.ThreadCount)
			ChannelLimiter.limiter[key] = rate.NewLimiter(rate.Limit(requestPerSecond), 10)
		}
	}
}

func (l *Limiter) Reset(channelID int64, apiType, limit int) {
	key := fmt.Sprintf("%d_%d", channelID, apiType)
	l.mu.RLock()
	_, ok := l.limiter[key]
	l.mu.Unlock()
	if !ok {
		return
	}

	limiter := rate.NewLimiter(rate.Limit(limit), 1)

	l.limiter[key] = limiter
}

func (l *Limiter) Wait(channelID int64, apiType int, timeOut time.Duration) (err error) {
	defer func() {
		if r := recover(); r != nil {
			logger.Log.Error("[Limiter] [Wait]", zap.Any("recover", r))
			err = fmt.Errorf("%v", r)
		}
	}()

	key := fmt.Sprintf("%d_%d", channelID, apiType)
	l.mu.RLock()
	limiter, ok := l.limiter[key]
	l.mu.RUnlock()
	if ok {
		ctx, cancel := context.WithTimeout(context.Background(), timeOut)
		defer cancel()
		return limiter.Wait(ctx)
	}
	return
}

func (l *Limiter) Add(channelID int64, apiType int, limit int) {
	key := fmt.Sprintf("%d_%d", channelID, apiType)
	l.mu.RLock()
	_, ok := l.limiter[key]
	l.mu.RUnlock()
	if ok {
		return
	}

	limiter := rate.NewLimiter(rate.Limit(limit), 1)

	l.limiter[key] = limiter
}

func (l *Limiter) Remove(channelID int64, apiType int) {
	key := fmt.Sprintf("%d_%d", channelID, apiType)
	l.mu.RLock()
	_, ok := l.limiter[key]
	l.mu.RUnlock()
	if !ok {
		return
	}

	delete(l.limiter, key)
}
