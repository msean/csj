package services

import (
	"application/constant"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"application/utils/jwt_auth"
	"errors"
	"fmt"

	"github.com/go-xorm/xorm"
	"github.com/labstack/echo"
)

type userService struct {
	Ctx  *echo.Context
	Uuid string
}

func (s *userService) resetGoogleCode(user *models.User) (qrCode string, qrBase64 string, err error) {
	user.GoogleCode = utils.GenerateGoogleCode()
	googleQrCode := utils.GenerateGoogleQrCode(user.Username, user.Position, user.GoogleCode)
	googleQrBase64, err := utils.GenerateGoogleQrCodeBase64(googleQrCode)
	if err != nil {
		return "", "", err
	}

	return googleQrCode, googleQrBase64, nil
}

func (s *userService) isValidOp(user *models.User, fromCustomer bool) bool {
	return (!fromCustomer && !user.IsClient) || (fromCustomer && user.IsClient)
	// return (!fromCustomer && user.CustomerID <= 0) || (fromCustomer && user.CustomerID > 0)
}

func (s *userService) makeUser(user *models.User, params vo.UserParams, role *models.Role) *models.User {
	if params.UserName != "" {
		user.Username = params.UserName
	}

	if params.PhoneNumber != "" {
		user.PhoneNumber = params.PhoneNumber
	}

	if params.Email != "" {
		user.Email = params.Email
	}

	if params.Position > 0 {
		user.Position = params.Position
	}

	if params.Sex > 0 {
		user.Sex = params.Sex
	}

	if params.Remark != "" {
		user.Remark = params.Remark
	}

	user.Available = params.Available
	user.Company = params.Company

	if role != nil {
		user.Role = role.ID
		user.IsClient = role.IsClient
	}

	return user
}

func (s *userService) makeUserRes(user *models.User, qrCode *vo.UserGoogleQRCodeVo) *vo.UserVo {
	res := &vo.UserVo{
		Id:          user.ID,
		Account:     user.Account,
		UserName:    user.Username,
		PhoneNumber: user.PhoneNumber,
		Email:       user.Email,
		Company:     user.Company,
		Position:    user.Position,
		Sex:         user.Sex,
		Available:   user.Available,
		Role:        user.Role,
		IsClient:    user.IsClient,
		Remark:      user.Remark,
		Created:     utils.FormatTime(user.Created),
		Updated:     utils.FormatTime(user.Updated),
	}

	if qrCode != nil {
		res.GoogleQRCode = qrCode
	}

	return res
}

func (s *userService) makeUserList(count int64, users []*models.User) *vo.QueryRoleUserRes {
	res := make([]*vo.UserVo, 0)
	if len(users) > 0 {
		for _, user := range users {
			res = append(res, s.makeUserRes(user, nil))
		}
	} else {
		count = 0
	}

	return &vo.QueryRoleUserRes{
		Count: count,
		Users: res,
	}
}

func NewServiceUser(ctx *echo.Context) *userService {
	bean := &userService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (s *userService) CreateUser(db *xorm.Session, params vo.UserParams, role *models.Role) (*models.User, *vo.UserVo, error) {
	user := s.makeUser(&models.User{Account: params.Account, Password: utils.MakePassword(params.Password)}, params, role)
	qrCode, qrCodeBase64, err := s.resetGoogleCode(user)
	if err != nil {
		return nil, nil, errors.New("generate qr code error, " + err.Error())
	}

	err = mysql.User.InsertBean(db, utils.UserId(*s.Ctx), user)
	if err != nil {
		return nil, nil, err
	}

	code := vo.UserGoogleQRCodeVo{
		Code:       qrCode,
		CodeBase64: qrCodeBase64,
	}
	return user, s.makeUserRes(user, &code), nil
}

func (s *userService) UpdateUser(db *xorm.Session, params vo.UserParams, role *models.Role, fromCustomer bool) (*vo.UserVo, error) {
	user, err := mysql.User.GetBeanById(params.Id)
	if err != nil {
		return nil, errors.New("find error, " + err.Error())
	}

	if !s.isValidOp(user, fromCustomer) {
		return nil, errors.New("invalid operate")
	}

	err = mysql.User.UpdateBean(db, utils.UserId(*s.Ctx), s.makeUser(user, params, role))
	if err != nil {
		return nil, errors.New("update error, " + err.Error())
	}

	return s.makeUserRes(user, nil), nil
}

func (s *userService) SetCustomer(db *xorm.Session, user *models.User, customerID int64) (*models.User, error) {
	user.CustomerID = customerID
	err := mysql.User.UpdateBean(db, utils.UserId(*s.Ctx), user)
	if err != nil {
		return nil, err
	}

	return user, nil
}

func (s *userService) ResetPassword(userId int64, password string, fromCustomer bool) error {
	user, err := mysql.User.GetBeanById(userId)
	if err != nil {
		return errors.New("query error, " + err.Error())
	}

	if !s.isValidOp(user, fromCustomer) {
		return errors.New("error operate")
	}

	user.Password = utils.MakePassword(password)
	err = mysql.User.UpdateBean(nil, utils.UserId(*s.Ctx), user)
	if err != nil {
		return errors.New("update error, " + err.Error())
	}

	return nil
}

func (s *userService) ResetGoogleCode(userId int64, fromCustomer bool) (*vo.UserGoogleQRCodeVo, error) {
	user, err := mysql.User.GetBeanById(userId)
	if err != nil {
		return nil, errors.New("query error, " + err.Error())
	}

	if !s.isValidOp(user, fromCustomer) {
		return nil, errors.New("error operate")
	}

	qrCode, qrCodeBase64, err := s.resetGoogleCode(user)
	if err != nil {
		return nil, errors.New("generate qr code error, " + err.Error())
	}

	err = mysql.User.UpdateBean(nil, utils.UserId(*s.Ctx), user)
	if err != nil {
		return nil, errors.New("update error, " + err.Error())
	}

	return &vo.UserGoogleQRCodeVo{
		Code:       qrCode,
		CodeBase64: qrCodeBase64,
	}, nil
}

func (s *userService) RemoveUser(db *xorm.Session, userIDs []int64, fromCustomer bool) (int64, error) {
	count, err := mysql.User.DeleteBeanByIds(db, userIDs, fromCustomer)
	if err != nil {
		return 0, errors.New("delete error, " + err.Error())
	}

	if count <= 0 {
		return 0, errors.New("can't find")
	}

	return count, nil
}

func (s *userService) QueryUsers(params vo.UserQueryParams) (*vo.QueryRoleUserRes, error) {
	count, users, err := mysql.User.QueryUsers(params)
	if err != nil {
		return nil, errors.New("query error, " + err.Error())
	}

	/*if count <= 0 {
		return nil, nil
	}*/

	return s.makeUserList(count, users), nil
}

func (s *userService) CheckParams(params vo.UserParams, fromCustomer bool) (bool, *models.Role, error) {
	if params.Sex < constant.USER_SEXY_MAN || params.Sex > constant.USER_SEXY_UNKNOW {
		return false, nil, errors.New("invalid sex")
	}

	/*if params.Position < constant.USER_POSITION_CHAIRMAN || params.Position > constant.USER_POSITION_FINANCE {
		return false, nil, errors.New("invalid position")
	}*/

	/*if len(params.Password) <= 0 {
		// todo: temp -----------------------
		return false, nil, errors.New("invalid password")
	}*/

	role, err := mysql.Role.GetBeanById(params.Role)
	if err != nil {
		return false, nil, errors.New("find role error, " + err.Error())
	}

	if !fromCustomer && role.IsClient {
		return false, nil, errors.New("invalid role")
	}

	return true, role, nil
}

func (s *userService) AdminLogin(account string, password string, ip string) (string, error) {
	user, err := mysql.User.GetBeanByAccount(account)
	if err != nil {
		return "", errors.New("query account error, " + err.Error())
	}

	if user == nil {
		return "", errors.New("account not found")
	}

	if !user.Available {
		return "", errors.New("account not available")
	}

	if !utils.CheckPassword(password, user.Password) {
		return "", errors.New("invalid password")
	}

	// if user.CustomerID > 0 {
	// 	var customer models.Customer
	// 	if customer, _, err = mysql.Customer.FromID(user.CustomerID); err != nil {
	// 		return "", err
	// 	}
	// 	logger.Log.Info("AdminLogin",
	// 		zap.String("ip", ip),
	// 		zap.String("customer.Ip", customer.Ip),
	// 		zap.Bool("strings.Contains(customer.Ip, ip)", strings.Contains(customer.Ip, ip)))
	// 	if !utils.IsBlankString(customer.Ip) && !strings.Contains(customer.Ip, ip) {
	// 		return "", errors.New("IP没有绑定, 无法登陆")
	// 	}
	// }

	token, err := jwt_auth.GenToken(user.ID, user.Account)
	if err != nil {
		// logger.Log.Error(fmt.Sprintf("[%s] 根据登录账号生成token 失败 [%s | %s]", s.Uuid, loginName, password), zap.Error(err))
		return "", errors.New("get token failed, " + err.Error())
	}

	return token, nil
}

func (s *userService) UpdateUserRole(userIDs []int64, roleID int64) (int64, error) {
	count, err := mysql.User.UpdateRole(userIDs, roleID)
	if err != nil {
		return 0, errors.New("update failed, " + err.Error())
	}

	return count, nil
}

func (s *userService) QueryByRole(params vo.QueryRoleUserParams) (*vo.QueryRoleUserRes, error) {
	count, users, err := mysql.User.QueryByRole(params)
	if err != nil {
		return nil, err
	}

	return s.makeUserList(count, users), nil
}

func (s *userService) MakeUserVo(obj *models.User, customer *models.Customer) *vo.UserVo {
	res := s.makeUserRes(obj, nil)
	if customer != nil {
		res.CustomerID = customer.ID
		res.Balance = customer.Balance
		res.TotalBalance = customer.TotalBalance
		res.Credit = customer.Credit
	}

	return res
}

func (s *userService) ListOnlineUser(params vo.ListOnlineUserReq) (rsp []models.OnlineUser, total int64, err error) {
	return mysql.OnlineUser.List(params)
}

func (s *userService) ForceQuit(tokens []string) (err error) {
	var _operatorToken string
	_ctx := *s.Ctx
	if _operatorToken, err = utils.ParseToken(_ctx); err != nil {
		return
	}

	for _, t := range tokens {
		if _operatorToken == t {
			err = fmt.Errorf("不能强制退出当前用户")
			return
		}
	}

	return mysql.OnlineUser.ForceQuit(tokens)
}

/*func (this *userService) GetBeanById(id int64) (*vo.UserMeVo, error) {
	user, err := mysql.User.GetBeanById(id)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 根据id获取用户信息 失败 [%d]", this.Uuid, id), zap.Error(err))
		return nil, err
	}
	var vo = &vo.UserMeVo{
		Id:          user.ID,
		ParentId:    user.ParentId,
		LoginName:   user.LoginName,
		UserName:    user.Username,
		Email:       user.Email,
		Phonenumber: user.Phonenumber,
		LoginIp:     user.LoginIp,
	}
	if !user.LoginDate.IsZero() {
		vo.LoginDate = user.LoginDate.Format("2006-01-02 15:04:05")
	}
	return vo, nil
}

func (this *userService) DeleteUserByIds(ids []int64) error {
	for _, id := range ids {
		mysql.User.DeleteBeanById(id)
		mysql.Role.DeleteUserRoleByUserId(id)
	}
	// 刷新缓存
	NewServiceCache(this.Ctx).UserMenu()
	return nil
}

func (this *userService) EditUser(uid int64, params *vo.UserParams) error {
	var (
		user *models.User
		err  error
	)
	if 0 == params.Id {
		u, err := mysql.User.GetBeanById(uid)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 根据id查询用户 失败 [%d]", this.Uuid, uid), zap.Error(err))
			return errors.New("当前用户异常")
		}
		superiorIds := u.SuperiorIds
		if "" == superiorIds {
			superiorIds, _ = utils.ToString(uid)
		} else {
			uidStr, _ := utils.ToString(uid)
			superiorIds = superiorIds + "," + uidStr
		}

		user = &models.User{
			ParentId:    uid,
			SuperiorIds: superiorIds,
			LoginName:   params.LoginName,
			Username:    params.UserName,
			UserType:    cons.USER_NOT_ADMIN,
			Email:       params.Email,
			Phonenumber: params.Phonenumber,
			Password:    utils.Md5S(params.Password),
			Status:      params.Status,
			Remark:      params.Remark,
		}
		err = mysql.User.InsertBean(uid, user)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 新增用户 失败 [%s]", this.Uuid, convertor.ToString(user)), zap.Error(err))
			return err
		}
	} else {
		user, err = mysql.User.GetBeanById(params.Id)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 根据id查询用户 失败 [%d]", this.Uuid, params.Id), zap.Error(err))
			return errors.New("查询用户异常")
		}
		user.LoginName = params.LoginName
		user.LoginName = params.LoginName
		user.Username = params.UserName
		user.Email = params.Email
		user.Phonenumber = params.Phonenumber
		user.Status = params.Status
		user.Remark = params.Remark
		if "" != params.Password {
			user.Password = utils.Md5S(params.Password)
		}
		err = mysql.User.UpdateBean(uid, user)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 修改用户 失败 [%s]", this.Uuid, convertor.ToString(user)), zap.Error(err))
			return err
		}
		// 删除权限
		mysql.Role.DeleteUserRoleByUserId(user.ID)
	}
	// 添加权限
	for _, roleId := range params.Roles {
		mysql.Role.InsertUserRole(&models.UserRole{
			UserId: user.ID,
			RoleId: roleId,
		})
	}
	// 刷新缓存
	NewServiceCache(this.Ctx).UserMenu()
	return nil
}

func (this *userService) FindUser(userId int64, params *vo.FindListParams) (int64, []*vo.UserVo, error) {
	u, err := mysql.User.GetBeanById(userId)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 获取用户 失败 [%d]", this.Uuid, userId), zap.Error(err))
		return 0, nil, err
	}
	var (
		total    int64
		userList []*models.User
	)
	if utils.IsAdmin(u) {
		total, userList, err = mysql.User.FindUserByIds(nil, params)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 获取用户列表 失败 [%d]", this.Uuid, userId), zap.Error(err))
			return 0, nil, err
		}
	} else {
		uids := mysql.User.FindUserIdsBySuperiorId(userId)
		total, userList, err = mysql.User.FindUserByIds(uids, params)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 获取用户列表 失败 [%d | %s]", this.Uuid, userId, convertor.ToString(uids)), zap.Error(err))
			return 0, nil, err
		}
	}
	voList := make([]*vo.UserVo, 0)
	for _, user := range userList {
		v := &vo.UserVo{
			Id:          user.ID,
			ParentId:    user.ParentId,
			LoginName:   user.LoginName,
			UserName:    user.Username,
			Email:       user.Email,
			Phonenumber: user.Phonenumber,
			Status:      user.Status,
			LoginIp:     user.LoginIp,
			Remark:      user.Remark,
			RolesMap:    nil,
		}
		if !user.LoginDate.IsZero() {
			v.LoginDate = user.LoginDate.Format("2006-01-02 15:04:05")
		}
		if !user.Created.IsZero() {
			v.Created = user.Created.Format("2006-01-02 15:04:05")
		}
		if !user.Updated.IsZero() {
			v.Updated = user.Updated.Format("2006-01-02 15:04:05")
		}
		rids := mysql.Role.FindRoleIdsByUserId(user.ID)
		v.Roles = rids
		rolesMap := make([]*vo.RolesVo, 0)
		roleList, err := mysql.Role.FindRoleByIds(rids, "0")
		if err == nil && 0 < len(roleList) {
			for _, role := range roleList {
				rolesMap = append(rolesMap, &vo.RolesVo{
					Id:   role.ID,
					Name: role.RoleName,
				})
			}
		}
		v.RolesMap = rolesMap
		voList = append(voList, v)
	}
	return total, voList, nil
}*/
