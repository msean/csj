package services

import (
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/services/cache"
	"application/utils"
	"fmt"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
)

type ProductSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewProductSrv(ctx *echo.Context) *ProductSrv {
	bean := &ProductSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *ProductSrv) FromCode(productCode string) (product models.Product, has bool, err error) {
	return mysql.Product.FromCode(productCode)
}

func (srv *ProductSrv) List(params vo.ProductListParams) (products []models.Product, total int64, err error) {
	return mysql.Product.List(params)
}

func (srv *ProductSrv) Create(params vo.ProductCreateParams) (prod models.Product, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	if err = copier.Copy(&prod, &params); err != nil {
		return
	}
	var exist bool
	exist, err = daos.Exist(session, &models.Product{}, 0, map[string]any{
		"code": params.Code,
	})
	if err != nil {
		return
	}
	if exist {
		err = fmt.Errorf("%s", "产品编码已经存在")
		return
	}

	_, err = daos.CreateObjs(session, &prod)
	return
}

func (srv *ProductSrv) Delete(idList []int64) (err error) {
	var products []models.Product

	if products, err = mysql.Product.FromIDlist(idList); err != nil {

		return
	}

	session := daos.Mysql.NewSession()
	if err = session.Begin(); err != nil {
		return
	}
	defer session.Close()
	if _, err = daos.DelObjs(session, idList, models.Product{}); err != nil {
		session.Rollback()
		return
	}

	for _, product := range products {
		if err = cache.DelCacheModelPk(product.TableName(), cache.ProductPk(product.Code)); err != nil {
			session.Rollback()
			return
		}
	}
	session.Commit()
	return
}

func (srv *ProductSrv) Update(params vo.ProductUpdateParams) (product models.Product, err error) {
	if err = copier.Copy(&product, &params); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()
	if err = session.Begin(); err != nil {
		return
	}

	if _, err = daos.UpdateObjWithVersion(session, product, nil); err != nil {
		return
	}

	if err = cache.UpdateCacheModelPk(product.TableName(), cache.ProductPk(product.Code), &product, false); err != nil {
		session.Rollback()
		return
	}
	session.Commit()
	return
}

func (srv *ProductSrv) FromID(id int64) (product models.Product, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	_, err = daos.ObjDetailByID(session, id, &product)
	return
}

func (srv *ProductSrv) Export(params vo.ProductListParams) (filePath string, err error) {
	filePath = fmt.Sprintf("%d基础产品.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d基础产品.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var objs []models.Product
	if objs, _, err = mysql.Product.List(params); err != nil {
		return
	}
	if len(objs) == 0 {
		objs = append(objs, models.Product{})
	}

	productExport := make([]*models.ProductExport, 0, len(objs))
	for _, obj := range objs {
		area := constant.CodeArea[obj.Area]
		productExport = append(productExport, &models.ProductExport{
			Code:      obj.Code,
			BigType:   obj.BigType,
			Name:      obj.Name,
			FaceValue: obj.FaceValue,
			Price:     obj.Price,
			Isp:       obj.Isp,
			Online:    obj.Online,
			AreaName:  area,
		})
	}

	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", productExport, mysql.SysDict.DataValueLabelMapper())
	return
}
