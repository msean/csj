package services

import (
	"application/common/logger"
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services/cache"
	"application/utils"
	"fmt"
	"strconv"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	ChannelProdSrv struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewChannelProdSrv(ctx *echo.Context) *ChannelProdSrv {
	bean := &ChannelProdSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *ChannelProdSrv) Create(params vo.ChannelProdCreateParams) (successCount int64, failCount int, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [Create]", zap.Any("params", params), zap.Error(err))
		}
	}()

	var productCodeList []string
	for _, product := range params.ProductList {
		productCodeList = append(productCodeList, product.ProductCode)
	}

	var productMap map[string]models.Product
	if productMap, err = mysql.Product.FromCodes(productCodeList); err != nil {
		return
	}

	// 不能重复创建channel_id, product_code组合的 channel product
	var existChannelProducts []models.ChannelProduct
	if existChannelProducts, err = mysql.ChannelProd.ListByChannelID(params.ChannelID); err != nil {
		return
	}
	existProducts := make(map[string]struct{})
	for _, channelProd := range existChannelProducts {
		existProducts[channelProd.ProductCode] = struct{}{}
	}

	var channelProds []models.ChannelProduct
	for _, product := range params.ProductList {
		if _, ok := existProducts[product.ProductCode]; ok {
			continue
		}
		if _, in := productMap[product.ProductCode]; !in {
			continue
		}
		var channelProd models.ChannelProduct
		if err = copier.Copy(&channelProd, &params); err != nil {
			continue
		}

		channelProd.ProductCode = product.ProductCode
		channelProd.Pcode = product.Pcode
		channelProd.Online = 2 // 默认是2
		channelProd.ActualPrice = params.Discount.Calculate(productMap[product.ProductCode].Price)
		channelProd.OrderPrice = params.Discount.Calculate(productMap[product.ProductCode].Price)
		channelProds = append(channelProds, channelProd)
	}

	if len(channelProds) > 0 {
		session := daos.Mysql.NewSession()
		defer session.Close()
		successCount, err = daos.CreateObjs(session, &channelProds)
	}
	failCount = len(params.ProductList) - int(successCount)
	if err = cache.CacheChannelProduct(params.ChannelID); err != nil {
		cache.DelCacheChannelProduct(params.ChannelID)
	}
	return
}

func (srv *ChannelProdSrv) BatchOperate(params vo.ChannelProdBatchOprParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [BatchOperate]", zap.Any("params", params), zap.Error(err))
		}
	}()

	channelMapper := make(map[int64]bool)
	var channelProducts []models.ChannelProduct
	if channelProducts, err = mysql.ChannelProd.FromIDList(params.IDList); err != nil {
		return
	}
	for _, channelProduct := range channelProducts {
		channelMapper[channelProduct.ChannelID] = true
	}

	deferDoneFunc := func() {
		for channelID, _ := range channelMapper {
			if err = cache.CacheChannelProduct(channelID); err != nil {
				cache.DelCacheChannelProduct(channelID)
			}
		}
	}

	switch params.OprType {
	case 1: // 删除
		session := daos.Mysql.NewSession()
		defer session.Close()

		if _, err = daos.DelObjs(session, params.IDList, models.ChannelProduct{}); err != nil {
			return
		}
		deferDoneFunc()

	case 2: // 开
		session := daos.Mysql.NewSession()
		defer session.Close()
		if err = mysql.ChannelProd.BatchOnlineSet(session, params.IDList, 2); err != nil {
			return
		}
		deferDoneFunc()
	case 3: // 关
		session := daos.Mysql.NewSession()
		defer session.Close()
		if err = mysql.ChannelProd.BatchOnlineSet(session, params.IDList, 1); err != nil {
			return
		}
		deferDoneFunc()
	case 4: // 批量编辑
		if err = srv.BatchUpdate(params.IDList, params.ChannelProdUpdateParams); err != nil {
			return
		}
	}

	return
}

func (srv *ChannelProdSrv) Fill(channelModel models.Channel,
	productModel models.Product,
	channelProdModel models.ChannelProduct) (channelProRsp resp.ChannelProductDetailRsp) {

	channelProRsp.ID = channelProdModel.ID
	if productModel.Price > 0 {
		channelProRsp.ActualDiscount = utils.FloatReserveString(channelProdModel.ActualPrice/productModel.Price, 2)
		channelProRsp.OrderDiscount = utils.FloatReserveString(channelProdModel.OrderPrice/productModel.Price, 2)
	}
	channelProRsp.Online = channelProdModel.Online
	channelProRsp.VoucherType = channelProdModel.VoucherType

	channelProRsp.ChannelID = channelProdModel.ChannelID
	channelProRsp.ProductCode = channelProdModel.ProductCode
	channelProRsp.ProductName = productModel.Name
	channelProRsp.ProductBigType = productModel.BigType
	channelProRsp.ProductIsp = constant.Isp(productModel.Isp).String()
	channelProRsp.ProductPrice = strconv.FormatFloat(productModel.Price, 'f', -1, 64)
	channelProRsp.ActualPrice = strconv.FormatFloat(channelProdModel.ActualPrice, 'f', -1, 64)
	channelProRsp.OrderPrice = strconv.FormatFloat(channelProdModel.OrderPrice, 'f', -1, 64)
	channelProRsp.Pcode = channelProdModel.Pcode

	channelProRsp.ChannelName = channelModel.Name
	return
}

func (srv *ChannelProdSrv) FormID(id int64) (channelProdModel models.ChannelProduct, has bool, err error) {
	db := daos.Mysql.NewSession()
	defer func() {
		db.Close()

		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [FormID]", zap.Int64("id", id), zap.Error(err))
		}
	}()

	has, err = daos.ObjDetailByID(db, id, &channelProdModel)
	return
}

func (srv *ChannelProdSrv) Detail(id int64) (channelProRsp resp.ChannelProductDetailRsp, has bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [Detail]", zap.Int64("id", id), zap.Error(err))
		}
	}()

	var channelProdModel models.ChannelProduct
	if channelProdModel, has, err = srv.FormID(id); err != nil || !has {
		return
	}

	var productModel models.Product
	productModel, _, _ = mysql.Product.FromCode(channelProdModel.ProductCode)

	var channelModel models.Channel
	channelModel, _, _ = NewChannelService(srv.Ctx).FromID(channelProdModel.ChannelID)
	channelProRsp = srv.Fill(channelModel, productModel, channelProdModel)
	return
}

func (srv *ChannelProdSrv) BatchUpdate(idList []int64, params vo.ChannelProdUpdateParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [BatchUpdate]", zap.Int64s("idList", idList), zap.Error(err))
		}
	}()

	var channelProds []models.ChannelProduct
	var channelProducts []string
	var channelIDCode = make(map[int64]string)
	var channelProdsMapper = make(map[int64]models.ChannelProduct)
	if channelProds, err = mysql.ChannelProd.FromIDList(idList); err != nil {
		return
	}
	for _, channelProd := range channelProds {
		channelProdsMapper[channelProd.ID] = channelProd
		channelProducts = append(channelProducts, channelProd.ProductCode)
		channelIDCode[channelProd.ID] = channelProd.ProductCode
	}

	productMap, _ := mysql.Product.FromCodes(channelProducts)

	// if params.EffectTime.IsZero() {

	// 	for _, id := range idList {
	// 		updateMapper := make(map[string]any)
	// 		const epsilon = 1e-9 // 设定一个极小值作为精度范围

	// 		if math.Abs(params.ActualDiscount.Value) > epsilon {
	// 			updateMapper["actual_price"] = params.ActualDiscount.Calculate(productMap[channelIDCode[id]].Price)
	// 		}
	// 		if math.Abs(params.OrderDiscount.Value) > epsilon {
	// 			updateMapper["order_price"] = params.OrderDiscount.Calculate(productMap[channelIDCode[id]].Price)
	// 		}

	// 		if params.Online != 0 && (params.Online == 1 || params.Online == 2) {
	// 			updateMapper["online"] = params.Online
	// 		}
	// 		if params.VoucherType != 0 {
	// 			updateMapper["voucher_type"] = params.VoucherType
	// 		}
	// 		if len(updateMapper) > 0 {
	// 			if _, err = utils.Update(session.Table(models.ChannelProduct{}.TableName()), updateMapper, utils.IDCond(id)); err != nil {
	// 				return
	// 			}
	// 		}
	// 	}

	// 	return
	// }

	var _effectTime time.Time
	IsZeroEffectTime := utils.IsBlankString(params.EffectTime)
	if !IsZeroEffectTime {
		_effectTime, err = time.Parse("2006-01-02 15:04:05", params.EffectTime)
		if err != nil {
			return
		}
		var loc *time.Location
		loc, err = time.LoadLocation("Asia/Shanghai")
		if err != nil {
			return
		}
		_effectTime = _effectTime.In(loc)
	}

	for _, id := range idList {
		done := func() {
			channelProd := channelProdsMapper[id]
			if err = cache.CacheChannelProduct(channelProd.ChannelID); err != nil {
				cache.DelCacheChannelProduct(channelProd.ChannelID)
			}
		}
		sql := mysql.ChannelProd.ScheduleUpdateSql(id, params, productMap, channelIDCode)

		if utils.IsBlankString(sql) {
			continue
		}
		if IsZeroEffectTime {
			if _, err = daos.Mysql.Exec(sql); err != nil {
				return
			}

			done()
		} else {
			if _effectTime.Add(1 * time.Minute).Before(time.Now()) {
				logger.Log.Error("[ChannelProdSrv] [BatchUpdate]",
					zap.Time("EffectTime", _effectTime))
				return
			}
			delayTask := models.DelayTask{
				Table:    models.ChannelProduct{}.TableName(),
				Sql:      sql,
				ExecTime: _effectTime,
				Pk:       utils.Violent2String(id),
				Remark:   params.Remark,
				Status:   3,
			}
			delayTask.CreateBy = utils.UserId(*srv.Ctx)
			Add2DelayScheduler(delayTask, true, done)
		}
	}
	return
}

func (srv *ChannelProdSrv) List(params vo.ChannelProdListParams) (channelProdRsp []resp.ChannelProductDetailRsp, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [BatchUpdate]", zap.Any("params", params), zap.Error(err))
		}
	}()

	channelProdRsp = make([]resp.ChannelProductDetailRsp, 0)

	var channelProds []models.ChannelProduct
	channelProds, total, err = mysql.ChannelProd.List(params)

	var channelIDList []int64
	var productCodes []string
	for _, channelProd := range channelProds {
		channelIDList = append(channelIDList, channelProd.ChannelID)
		productCodes = append(productCodes, channelProd.ProductCode)
	}

	productMap, _ := mysql.Product.FromCodes(productCodes)
	channelMap, _ := mysql.Channel.FromIDList(channelIDList)
	for _, channelProd := range channelProds {
		channelProdRsp = append(channelProdRsp, srv.Fill(channelMap[channelProd.ChannelID], productMap[channelProd.ProductCode], channelProd))
	}
	return
}

func (srv *ChannelProdSrv) Export(params vo.ChannelProdListParams) (filepath string, err error) {
	filepath = fmt.Sprintf("%d渠道产品.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filepath = fmt.Sprintf("%d_%d_%d渠道产品.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var channelProdModelList []resp.ChannelProductDetailRsp
	if channelProdModelList, _, err = srv.List(params); err != nil {
		return
	}
	if len(channelProdModelList) == 0 {
		channelProdModelList = append(channelProdModelList, resp.ChannelProductDetailRsp{})
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filepath), "sheet1", channelProdModelList, mysql.SysDict.DataValueLabelMapper())
	return
}

func (srv *ChannelProdSrv) UpdatePcode(params vo.ChannelProdUpdatePcodeParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelProdSrv] [UpdatePcode]", zap.Any("params", params), zap.Error(err))
		}
	}()

	channelMapper := make(map[int64]bool)
	var channelProducts []models.ChannelProduct
	if channelProducts, err = mysql.ChannelProd.FromIDList([]int64{params.ID}); err != nil {
		return
	}
	for _, channelProduct := range channelProducts {
		channelMapper[channelProduct.ChannelID] = true
	}

	if err = mysql.ChannelProd.UpdatePcode(params.ID, params.Pcode); err != nil {
		return err
	}

	for channelID, _ := range channelMapper {
		if err = cache.CacheChannelProduct(channelID); err != nil {
			cache.DelCacheChannelProduct(channelID)
		}
	}
	return
}
