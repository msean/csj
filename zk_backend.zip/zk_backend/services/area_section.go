package services

import (
	"application/conf"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"fmt"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
)

type AreaSectionSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewAreaSectionSrv(ctx *echo.Context) *AreaSectionSrv {
	bean := &AreaSectionSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *AreaSectionSrv) Create(params vo.AreaSectionCreateParam) (err error) {
	var areaSection models.AreaSection
	if err = copier.Copy(&areaSection, &params); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	var exist bool
	exist, err = daos.Exist(session, &models.AreaSection{}, 0, map[string]any{
		"section": params.Section,
	})
	if exist {
		err = fmt.Errorf("%s", "该号段已经存在")
	}
	if err != nil {
		return
	}
	_, err = daos.CreateObjs(session, &areaSection)
	return
}

func (srv *AreaSectionSrv) List(params vo.AreaSectionListParam) (objects []models.AreaSection, total int64, err error) {
	return mysql.AreaSection.List(params)
}

func (srv *AreaSectionSrv) Update(params vo.AreaSectionUpdateParam) (err error) {
	var areaSection models.AreaSection
	if err = copier.Copy(&areaSection, &params); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.UpdateObjWithVersion(session, areaSection, nil, "section")
	return
}

func (srv *AreaSectionSrv) Export(params vo.AreaSectionListParam) (filePath string, err error) {
	filePath = fmt.Sprintf("%d号段管理.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d号段管理.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var objects []models.AreaSection
	if objects, _, err = mysql.AreaSection.List(params); err != nil {
		return
	}
	if len(objects) == 0 {
		objects = append(objects, models.AreaSection{})
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objects, mysql.SysDict.DataValueLabelMapper())
	return
}

func (srv *AreaSectionSrv) Delete(params vo.DeleteParams) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	_, err = daos.DelObjs(session, params.IDList, models.AreaSection{})
	return
}

func (srv *AreaSectionSrv) Detail(id int64) (areaSection models.AreaSection, has bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &areaSection)
	return
}
