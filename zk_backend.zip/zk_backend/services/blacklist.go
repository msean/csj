package services

import (
	"application/common/logger"
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/services/cache"
	"application/utils"
	"fmt"
	"strings"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	BlacklistSvc struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewBlacklistSvc(ctx *echo.Context) *BlacklistSvc {
	return &BlacklistSvc{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
}

func (svc *BlacklistSvc) List(params vo.BlacklistParams) (blList []models.Blacklist, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[BlacklistSvc] [List]", zap.Any("params", params), zap.Error(err))
		}
	}()

	blList, total, err = mysql.Blacklist.List(params)
	return
}

func (svc *BlacklistSvc) Create(param vo.BlacklistCreateParams) (success, fail int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[BlacklistSvc] [Create]", zap.String("phones", param.Phones), zap.Error(err))
		}
	}()

	phones := strings.Split(param.Phones, ";")

	var notInPhone map[string]bool
	if notInPhone, err = mysql.Blacklist.NotInPhones(phones); err != nil {
		return
	}
	if err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	for _, phone := range phones {
		if utils.ValidPhone(phone) {
			if _, ok := notInPhone[phone]; ok {
				blacklist := models.Blacklist{
					Phone:  phone,
					Remark: param.Remark,
					Type:   uint(param.Type),
				}
				var count int64
				var crateBlackListErr error
				count, crateBlackListErr = daos.CreateObjs(session, &blacklist)
				success += count
				if crateBlackListErr == nil {
					DelayDelBlackList(blacklist)
				}
			}
		}
	}

	fail = int64(len(phones)) - success
	err = cache.RefreshBlackList()

	return
}

func (svc *BlacklistSvc) Update(param vo.BlacklistUpdateParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[BlacklistSvc] [Update]", zap.Any("param", param), zap.Error(err))
		}
	}()

	var blackList models.Blacklist
	if err = copier.Copy(&blackList, &param); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	var storage models.Blacklist
	var has bool
	if has, err = daos.GetRecordByField(session, storage.TableName(), &storage, utils.IDCond(param.ID)); err != nil {
		return
	}
	if !has {
		err = fmt.Errorf("该记录不存在")
		return
	}

	if _, err = daos.UpdateObjWithVersion(session, blackList, nil); err != nil {
		return
	}

	DelayDelBlackList(blackList)

	DelDelayTask(session, models.Blacklist{}.TableName(), storage.Phone)

	if err = cache.DeleteFromSetCache(models.Blacklist{}.TableName(), storage.Phone); err != nil {
		return
	}
	return cache.Save2SetCache(models.Blacklist{}.TableName(), blackList.Phone)
}

func (srv *BlacklistSvc) Delete(idList []int64) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[BlacklistSvc] [Delete]", zap.Int64s("idList", idList), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	var storageBlacklist []models.Blacklist
	if storageBlacklist, err = mysql.Blacklist.FromIDList(idList); err != nil {
		return
	}

	phoneMapper := make(map[string]models.Blacklist)
	for _, object := range storageBlacklist {
		phoneMapper[object.Phone] = object
	}

	if _, err = daos.DelObjs(session, idList, models.Blacklist{}); err != nil {
		return
	}

	for phone := range phoneMapper {
		setCacheKey := fmt.Sprintf("order_fail:%s", phone)
		cache.DeleteFromSetKey(setCacheKey)
	}

	err = cache.RefreshBlackList()

	return
}

func (srv *BlacklistSvc) FromID(id int64) (object models.Blacklist, has bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[BlacklistSvc] [Detail]", zap.Int64("id", id), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &object)
	return
}

func (srv *BlacklistSvc) Export(param vo.BlacklistParams) (filePath string, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[BlacklistSvc] [Export]", zap.Any("param", param), zap.Error(err))
		}
	}()

	filePath = fmt.Sprintf("%d黑名单.xlsx", time.Now().Unix())
	if len(param.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d黑名单.xlsx", time.Now().Unix(), param.IDList[0], param.IDList[len(param.IDList)-1])
	}
	var objects []models.Blacklist
	if objects, _, err = mysql.Blacklist.List(param); err != nil {
		return
	}

	if len(objects) == 0 {
		objects = append(objects, models.Blacklist{})
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objects, mysql.SysDict.DataValueLabelMapper())
	return
}

func (svc *BlacklistSvc) LimitCount() (count int, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var sysCfg models.SysArgConfig
	var has bool
	sysCfg, has, err = mysql.SysArgConfig.FromKey(session, constant.SysConfBlackListLimit)
	if err != nil {
		return
	}
	if !has {
		err = fmt.Errorf("不存在")
	}
	err = utils.ConvertIntFromString(sysCfg.Value, &count)
	return
}

func (svc *BlacklistSvc) UpdateBlacklistPhoneLimit(param vo.UpdateBlacklistPhoneLimitParams) (err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var sysCfg models.SysArgConfig
	var has bool
	sysCfg, has, err = mysql.SysArgConfig.FromKey(session, constant.SysConfBlackListLimit)
	if err != nil {
		return
	}
	if !has {
		err = fmt.Errorf("不存在")
	}

	sysCfg.Value = utils.Violent2String(param.Count)

	if _, err = daos.UpdateColsWithVersion(session, &sysCfg, "config_value"); err != nil {
		return
	}

	cache.UpdateCacheModelPk(models.SysArgConfig{}.TableName(), cache.SysConfigPk(sysCfg.Key), &models.SysArgConfig{}, true)
	return
}

// func FailOrderAddBlacklist(phone string) (err error) {
// 	var failCount int64
// 	var recordByredis bool
// 	failCount, recordByredis, err = cache.GetPhoneFailCount(phone)
// 	if err != nil || !recordByredis {
// 		// 从数据库中计算
// 		var phoneRestriction models.BlacklistRestriction
// 		session := daos.Mysql.NewSession()
// 		defer session.Close()

// 		var has bool
// 		if has, err = utils.Get(session, &phoneRestriction, utils.NewWhereCond("phone", phone)); err != nil {
// 			return
// 		}

// 		// 计算渠道订单的失败次数
// 		failOrderCondition := []utils.Cond{
// 			utils.NewWhereCond("phone", phone),
// 			utils.NewWhereCond("status", constant.OrderStatusFail),
// 		}
// 		if has {
// 			failOrderCondition = append(failOrderCondition, utils.NewWhereCond("created", phoneRestriction.LatestRestrictionTime))
// 		}
// 		if failCount, err = utils.TotalByConds(session, new(models.ChannelOrder), failOrderCondition...); err != nil {
// 			cache.SetPhoneFailCount(phone, 1)
// 		}
// 	} else {
// 		cache.SetPhoneFailCount(phone, int(failCount)+1)
// 	}

// 	var cfg models.SysArgConfig
// 	var has bool
// 	var phoneRestrictionCount int
// 	if cfg, has, err = cache.SysCfgFromKey(constant.SysConfBlackListLimit); err != nil || !has {
// 		phoneRestrictionCount = 5
// 	} else {
// 		if err = utils.ConvertIntFromString(cfg.Value, &phoneRestrictionCount); err != nil {
// 			phoneRestrictionCount = 5
// 		}
// 	}

// 	session := daos.Mysql.NewSession()
// 	defer session.Close()

// 	if int(failCount) >= phoneRestrictionCount {
// 		blacklist := models.Blacklist{
// 			Phone:  phone,
// 			Type:   2,
// 			Remark: fmt.Sprintf("失败次数超过%d, 加入临时黑名单", failCount),
// 		}
// 		if _, err = daos.CreateObjs(session, &blacklist); err != nil {
// 			DelayDelBlackList(blacklist)
// 		}
// 	}
// 	return
// }

func FailOrderAddBlacklist(phone string, orderID string) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[FailOrderAddBlacklist]", zap.String("phone", phone), zap.String("orderID", orderID), zap.Error(err))
		}
	}()

	var cfg models.SysArgConfig
	var has bool
	var phoneRestrictionCount int
	if cfg, has, err = cache.SysCfgFromKey(constant.SysConfBlackListLimit); err != nil || !has {
		phoneRestrictionCount = 5
	} else {
		if err = utils.ConvertIntFromString(cfg.Value, &phoneRestrictionCount); err != nil {
			phoneRestrictionCount = 5
		}
	}

	if phoneRestrictionCount == 0 {
		return
	}

	rdsLockKey := fmt.Sprintf("zk:fail_order_add_blacklist:%s", phone)
	lock := utils.NewLock(rdsLockKey, 5*time.Minute, daos.Rc, 20, time.Second)
	if ok := lock.Lock(); ok {
		defer lock.Unlock()
	}

	var failCount int
	now := time.Now()
	setCacheKey := fmt.Sprintf("order_fail:%s", phone)
	tomorrow := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, now.Location())
	if err = cache.Save2SetCacheWithTTL(setCacheKey, orderID, int64(tomorrow.Sub(now).Seconds())); err != nil {
		return
	}

	var phoneFailOrders []string
	if phoneFailOrders, err = cache.GetSetMembers(setCacheKey); err != nil {
		return
	}
	failCount = len(phoneFailOrders)
	// failCount, recordByredis, err = cache.InSetCache(phone)
	// if err != nil || !recordByredis {
	// 	// 从数据库中计算
	// 	var phoneRestriction models.BlacklistRestriction
	// 	session := daos.Mysql.NewSession()
	// 	defer session.Close()

	// 	var has bool
	// 	if has, err = utils.Get(session, &phoneRestriction, utils.NewWhereCond("phone", phone)); err != nil {
	// 		return
	// 	}

	// 	// 计算渠道订单的失败次数
	// 	failOrderCondition := []utils.Cond{
	// 		utils.NewWhereCond("phone", phone),
	// 		utils.NewWhereCond("status", constant.OrderStatusFail),
	// 	}
	// 	if has {
	// 		failOrderCondition = append(failOrderCondition, utils.NewWhereCond("created", phoneRestriction.LatestRestrictionTime))
	// 	}
	// 	if failCount, err = utils.TotalByConds(session, new(models.ChannelOrder), failOrderCondition...); err != nil {
	// 		cache.SetPhoneFailCount(phone, 1)
	// 	}
	// } else {
	// 	cache.SetPhoneFailCount(phone, int(failCount)+1)
	// }

	session := daos.Mysql.NewSession()
	defer session.Close()

	if int(failCount) >= phoneRestrictionCount {
		blacklist := models.Blacklist{
			Phone:  phone,
			Type:   2,
			Remark: fmt.Sprintf("失败次数超过%d, 加入临时黑名单", failCount),
		}
		yes, _ := daos.Exist(session, &models.Blacklist{}, 0, map[string]any{
			"phone": blacklist.Phone,
		})
		if !yes {
			if _, err = daos.CreateObjs(session, &blacklist); err == nil {
				if err = cache.Save2SetCache(models.Blacklist{}.TableName(), cache.BlacklistObj(blacklist)); err != nil {
					logger.Log.Error("[FailOrderAddBlacklist] [Save2SetCache]", zap.Any("blacklist", blacklist), zap.Error(err))
				}
				DelayDelBlackList(blacklist)
			}
		}
	}

	return
}
