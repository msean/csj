package services

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"fmt"
	"math"
	"sync"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type CustomerFinanceService struct {
	Ctx  *echo.Context
	Uuid string
}

type CustomerIDLock struct {
	locks sync.Map
}

func (c *CustomerIDLock) GetLock(customerID int64) *sync.Mutex {
	lock, _ := c.locks.LoadOrStore(customerID, &sync.Mutex{}) // 如果没有锁则创建
	return lock.(*sync.Mutex)
}

func (c *CustomerIDLock) RemoveLock(customerID int64) {
	c.locks.Delete(customerID)
}

var customerIDLock = &CustomerIDLock{}

func (s *CustomerFinanceService) fixAmount(businessType uint8, amount float64) float64 {
	if businessType == constant.CUSTOMER_FINANCE_TYPE_DEDUCT {
		return -math.Abs(amount)
	}

	return math.Abs(amount)
}

func (s *CustomerFinanceService) createCustomerFinance(params vo.CustomerFinanceParam) (rsp *vo.CustomerFinanceVo, err error) {

	businessType := params.Type
	amount := params.Amount
	remark := params.Remark

	customerOrder := params.CustomerOrderID
	if utils.IsBlankString(customerOrder) {
		customerOrder = utils.Username(*s.Ctx)
	}

	orderID := params.OrderID
	if utils.IsBlankString(orderID) {
		orderID = utils.MakeOrderID(fmt.Sprintf("%04d%d", params.CustomerID, businessType))
	}

	logger.Log.Info("[createCustomerFinance]",
		zap.Any("params", params))

	switch businessType {
	case constant.CUSTOMER_FINANCE_TYPE_BACK:
		var exist bool
		session := daos.Mysql.NewSession()
		exist, err = daos.Exist(session, &models.CustomerFinance{}, 0, map[string]any{
			"business_type": constant.CUSTOMER_FINANCE_TYPE_BACK,
			"customer_id":   params.CustomerID,
			"order_id":      params.OrderID,
		})
		session.Close()
		if exist || err != nil {
			logger.Log.Error("OrderBackMoney exist",
				zap.Int64("customer_id", params.CustomerID),
				zap.String("order_id", params.OrderID),
				zap.Int("business_type", constant.CUSTOMER_FINANCE_TYPE_BACK))
			return
		}
	case constant.CUSTOMER_FINANCE_TYPE_DEDUCT:
		amount = s.fixAmount(uint8(businessType), params.Amount)
		if params.IsFinish {
			var exist bool
			session := daos.Mysql.NewSession()
			exist, err = daos.Exist(session, &models.CustomerFinance{}, 0, map[string]any{
				"order_id":      params.OrderID,
				"customer_id":   params.CustomerID,
				"business_type": constant.CUSTOMER_FINANCE_TYPE_DEDUCT,
				"finish":        1,
			})
			session.Close()
			if exist || err != nil {
				return
			}
		}
	case constant.CUSTOMER_FINANCE_TYPE_SPECIAL:
		if len(params.Remark) < 5 {
			err = fmt.Errorf("%s", "备注内容不能少于5个汉字")
			return
		}
		if params.Amount == 0 {
			err = fmt.Errorf("%s", "补偿金额不能为0")
			return
		}
	case constant.CUSTOMER_FINANCE_TYPE_RE_ORDER:
		var order models.Order
		var has bool

		session := daos.Mysql.NewSession()
		if order, has, err = partition.GlobalOrderPartition.FromCustomerOrderID(session, params.CustomerOrderID, time.Now().AddDate(0, 0, -1)); err != nil {
			session.Close()
			return
		}
		session.Close()
		if !has {
			err = fmt.Errorf("%s", "补款失败，该订单号不存在")
			return
		}
		if order.CustomerID != params.CustomerID {
			err = fmt.Errorf("%s", "补款失败 该订单号不属于所选客户")
			return
		}
		var financeRecords []models.CustomerFinance
		if financeRecords, err = mysql.CustomerFinance.FromCustomerOrderIDAndType(order.CustomerOrderID, constant.CUSTOMER_FINANCE_TYPE_RE_ORDER); err != nil {
			return
		}
		if len(financeRecords) > 0 {
			err = fmt.Errorf("%s", "补款失败该订单号已有过返销补款记录")
			return
		}

		if utils.LessThanWithPrecision(order.SalePrice, params.Amount, 1e-9) {
			if utils.IsBlankString(remark) {
				remark = fmt.Sprintf("该订单实际扣款金额为：%s, 超额补款：%s", utils.FloatReserveStr(order.SalePrice, 2), utils.FloatReserveStr(params.Amount-order.SalePrice, 4))
			} else {
				remark = fmt.Sprintf("%s;该订单实际扣款金额为：%s, 超额补款：%s", remark, utils.FloatReserveStr(order.SalePrice, 2), utils.FloatReserveStr(params.Amount-order.SalePrice, 4))
			}
		}
	}

	financeUpdateFunc := func() (customerFinance *models.CustomerFinance, updateErr error) {
		lock := customerIDLock.GetLock(params.CustomerID)
		lock.Lock()
		defer lock.Unlock()

		session := daos.Mysql.NewSession()
		defer session.Close()
		session.Begin()
		var customer *models.Customer
		if customer, updateErr = NewCustomerService(s.Ctx).UpdateBalance(session, params.CustomerID, params.RechargeAmount, amount, params.IsRecharging, params.IsFinish); updateErr != nil {
			session.Rollback()
			return
		}
		// 失败扣款不需要重新插入
		if params.IsRecharging && params.IsFinish && amount < 0 {
			session.Commit()
			return
		}

		_amount := params.Amount
		if businessType != constant.CUSTOMER_FINANCE_TYPE_SPECIAL {
			_amount = math.Abs(params.Amount)
		}
		customerFinance = &models.CustomerFinance{
			CustomerID:    params.CustomerID,
			CustomerName:  customer.Name,
			OrderID:       orderID,
			CustomerOrder: customerOrder,
			BusinessType:  uint8(businessType),
			Amount:        _amount,
			Balance:       customer.Balance,
			TotalBalance:  customer.TotalBalance,
			Bank:          params.Bank,
			Remark:        remark,
		}

		if updateErr = mysql.CustomerFinance.InsertBean(session, utils.UserId(*s.Ctx), customerFinance); updateErr != nil {
			session.Rollback()
			return
		}
		session.Commit()
		return
	}

	customerFinance := new(models.CustomerFinance)
	if customerFinance, err = financeUpdateFunc(); err != nil {
		return
	}

	if businessType == constant.CUSTOMER_FINANCE_TYPE_DEDUCT && params.IsFinish {
		session := daos.Mysql.NewSession()
		defer session.Close()
		var customerFinance []models.CustomerFinance
		// 一般只有一条的
		querySQL := fmt.Sprintf(`SELECT id 
    FROM %s FORCE INDEX (IDX_xj_customer_finance_order_id)
    WHERE order_id = ? AND customer_id = ? AND business_type = ?
`, models.CustomerFinance{}.TableName())

		// 执行查询
		err = session.SQL(querySQL, params.OrderID, params.CustomerID, constant.CUSTOMER_FINANCE_TYPE_DEDUCT).Find(&customerFinance)
		if err != nil {
			return
		}
		logger.Log.Info("records", zap.Any("records", customerFinance))
		for _, obj := range customerFinance {
			if _, err = session.Exec("UPDATE "+models.CustomerFinance{}.TableName()+" SET finish=1 WHERE id = ?", obj.ID); err != nil {
				return
			}
		}
		// session.Exec(fmt.Sprintf("update %s set finish=1 where order_id=%s and customer_id=%d and business_type=2", models.CustomerFinance{}.TableName(), params.OrderID, params.CustomerID))
	}

	return s.makeCustomerFinanceVo(customerFinance), nil
}

func (s *CustomerFinanceService) makeCustomerFinanceVo(obj *models.CustomerFinance) *vo.CustomerFinanceVo {
	if obj == nil {
		obj = new(models.CustomerFinance)
	}
	return &vo.CustomerFinanceVo{
		ID:            obj.ID,
		CustomerID:    obj.CustomerID,
		CustomerName:  obj.CustomerName,
		OrderID:       obj.OrderID,
		CustomerOrder: obj.CustomerOrder,
		BusinessType:  obj.BusinessType,
		Amount:        obj.Amount,
		Balance:       utils.FormatFloat(obj.Balance),
		TotalBalance:  utils.FormatFloat(obj.TotalBalance),
		Bank:          obj.Bank,
		Remark:        obj.Remark,
		Created:       obj.Created,
		Updated:       obj.Updated,
	}
}

func NewCustomerFinanceService(ctx *echo.Context) *CustomerFinanceService {
	bean := &CustomerFinanceService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (s *CustomerFinanceService) QueryCustomerFinance(param vo.CustomerFinanceQueryParam) (*vo.CustomerFinanceQueryRes, error) {
	count, objs, err := mysql.CustomerFinance.Query(param)
	if err != nil {
		return nil, err
	}

	var customerIDList []int64
	data := make([]*vo.CustomerFinanceVo, 0)
	if count > 0 {
		for _, obj := range objs {
			customerIDList = append(customerIDList, obj.CustomerID)
		}

		customerMapper, _ := mysql.Customer.FromIDList(customerIDList)

		for _, obj := range objs {
			obj.CustomerName = customerMapper[obj.CustomerID].Name
			data = append(data, s.makeCustomerFinanceVo(obj))
		}
	}

	return &vo.CustomerFinanceQueryRes{
		Count:   count,
		Records: data,
	}, nil
}

func (s *CustomerFinanceService) AddFinance(params vo.CustomerFinanceParam) (*vo.CustomerFinanceVo, error) {
	if params.Type == 0 {

	}
	if params.Type == constant.CUSTOMER_FINANCE_TYPE_ADD {
		if params.Amount <= 0 {
			return nil, fmt.Errorf("加款金额必须是正数")
		}
	}
	return s.createCustomerFinance(params)
}

func (s *CustomerFinanceService) DeductFinance(params vo.CustomerFinanceParam) (*vo.CustomerFinanceVo, error) {
	params.Type = constant.CUSTOMER_FINANCE_TYPE_DEDUCT
	return s.createCustomerFinance(params)
}

func (s *CustomerFinanceService) BackFinance(params vo.CustomerFinanceParam) (*vo.CustomerFinanceVo, error) {
	params.Type = constant.CUSTOMER_FINANCE_TYPE_BACK
	return s.createCustomerFinance(params)
}

func (s *CustomerFinanceService) UpdateRemark(id int64, remark string) (*models.CustomerFinance, error) {
	obj, err := mysql.CustomerFinance.GetBeanById(id)
	if err != nil {
		return nil, errors.New("query failed, " + err.Error())
	}

	obj.Remark = remark
	err = mysql.CustomerFinance.UpdateBean(utils.UserId(*s.Ctx), obj)
	if err != nil {
		return nil, errors.New("update failed, " + err.Error())
	}

	return obj, nil
}

func (s *CustomerFinanceService) Statistics(params vo.FinanceMonthQueryParams) (*vo.FinanceCustomerStatistics, error) {
	balanceArr, err := mysql.CustomerFinance.QueryBalance(params)
	if err != nil {
		return nil, errors.New("query balance failed, " + err.Error())
	}

	sum, err := mysql.CustomerFinance.SumByBusinessType(params, []uint8{constant.CUSTOMER_FINANCE_TYPE_ADD, constant.CUSTOMER_FINANCE_TYPE_RE_ORDER, constant.CUSTOMER_FINANCE_TYPE_SPECIAL})
	if err != nil {
		return nil, errors.New("sum failed, " + err.Error())
	}

	return &vo.FinanceCustomerStatistics{
		FirstBalance: utils.FloatReserve(balanceArr[0], 4),
		LastBalance:  utils.FloatReserve(balanceArr[1], 4),
		AddAmount:    utils.FloatReserve(sum, 4),
	}, nil
}
