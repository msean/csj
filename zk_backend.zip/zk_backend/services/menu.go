package services

import (
	"application/constant"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"
	"fmt"
	"github.com/labstack/echo"
	"sort"
)

type menuService struct {
	Ctx  *echo.Context
	Uuid string
}

type sortTree []*vo.MenuTreeVo

func (a sortTree) Len() int           { return len(a) }
func (a sortTree) Less(i, j int) bool { return a[j].Order > a[i].Order }
func (a sortTree) Swap(i, j int)      { a[i], a[j] = a[j], a[i] }

func (s *menuService) sort(list []*vo.MenuTreeVo) {
	sort.Sort(sortTree(list))
	for _, bean := range list {
		if 0 < len(bean.Children) {
			s.sort(bean.Children)
		}
	}
}

func (s *menuService) makeMenu(menu *models.Menu, params vo.MenuParams) *models.Menu {
	menu.MenuName = params.MenuName
	menu.MenuType = params.MenuType
	menu.MenuOrder = params.MenuOrder
	menu.ParentId = params.ParentId
	menu.OpenType = params.OpenType
	menu.Url = params.Url
	menu.Method = params.Method
	menu.Visible = params.Visible
	menu.Icon = params.Icon
	menu.Remark = params.Remark
	return menu
}

func (s *menuService) makeMenuVo(menu *models.Menu) *vo.MenuVo {
	res := &vo.MenuVo{
		Id:       menu.ID,
		ParentId: menu.ParentId,
		MenuName: menu.MenuName,
		Order:    menu.MenuOrder,
		OpenType: menu.OpenType,
		Url:      menu.Url,
		Method:   menu.Method,
		MenuType: menu.MenuType,
		Visible:  menu.Visible,
		Icon:     menu.Icon,
		Remark:   menu.Remark,
		Created:  utils.FormatTime(menu.Created),
		Updated:  utils.FormatTime(menu.Updated),
	}

	return res
}

func (s *menuService) buildMenuTree(roleID int64, id int64, menus []*models.Menu, isCheck bool, level int) (parent *vo.MenuVo, tree []*vo.MenuVo) {
	cacheSrv := NewServiceCache()
	tree = make([]*vo.MenuVo, 0)
	for _, menu := range menus {
		if menu.ID == id {
			parent = s.makeMenuVo(menu)
			continue
		}

		if menu.ParentId == id {
			isCheckChild := true
			if !isCheck || roleID <= 0 || cacheSrv.CheckRoleMenu(roleID, menu.ID) {
				isCheckChild = false
			}

			if menu.MenuType != constant.MENU_TYPE_BUTTON && level < constant.MENU_TYPE_MAX {
				_, childTree := s.buildMenuTree(roleID, menu.ID, menus, isCheck, level+1)
				if !isCheckChild || len(childTree) > 0 {
					child := s.makeMenuVo(menu)
					child.Children = childTree
					tree = append(tree, child)
				}
			} else if !isCheckChild {
				child := s.makeMenuVo(menu)
				tree = append(tree, child)
			}
		}
	}

	return parent, tree
}

func (s *menuService) queryMenuByUser(userId int64, visible bool, parentId int64) ([]*models.Menu, error) {
	user, err := mysql.User.GetBeanById(userId)
	if err != nil {
		return nil, errors.New(fmt.Sprintf("query user error, %s", err.Error()))
	}

	var menus []*models.Menu
	var menuIDs []int64
	if !user.IsSuper {
		menuIDs = NewServiceCache().getRoleMenu(user.Role)
		if len(menuIDs) <= 0 {
			return menus, nil
		}
	}

	menus, err = mysql.Menu.FindMenuByIds(menuIDs, visible, parentId)
	if err != nil {
		return nil, errors.New(fmt.Sprintf("query menu[%v] error, %s", menuIDs, err.Error()))
	}

	return menus, nil
}

func (s *menuService) findParentIds(menus []*models.Menu) []int64 {
	res := make([]int64, 0)
	for _, menu := range menus {
		if menu.ParentId <= 0 {
			res = append(res, menu.ID)
		}
	}

	return res
}

func (s *menuService) findMenuTree(roleID int64) ([]*vo.MenuVo, error) {
	cacheSrv := NewServiceCache()
	res := cacheSrv.FindMenuTree(roleID)
	if res != nil {
		return res, nil
	}

	menus, err := mysql.Menu.FindMenuByIds(nil, false, 0)
	if err != nil {
		return nil, errors.New(fmt.Sprintf("findMenuTree error, %s", err.Error()))
	}

	res = make([]*vo.MenuVo, 0)
	for _, id := range s.findParentIds(menus) {
		if roleID <= 0 || cacheSrv.CheckRoleMenu(roleID, id) {
			parent, tree := s.buildMenuTree(roleID, id, menus, false, 1)
			if len(tree) > 0 {
				parent.Children = tree
			}
			res = append(res, parent)
		} else {
			parent, tree := s.buildMenuTree(roleID, id, menus, true, 1)
			if len(tree) > 0 {
				parent.Children = tree
				res = append(res, parent)
			}
		}
	}

	NewServiceCache().UpdateMenuTree(roleID, res)
	return res, nil
}

func NewServiceMenu(ctx *echo.Context) *menuService {
	bean := &menuService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (s *menuService) CheckMenu(params vo.MenuParams) error {
	if len(params.MenuName) <= 0 {
		return errors.New(fmt.Sprintf("menu name is empty"))
	}

	if params.MenuType < constant.MENU_TYPE_MIN || params.MenuType > constant.MENU_TYPE_MAX {
		return errors.New(fmt.Sprintf("menu type is invalid"))
	}

	if params.OpenType < constant.MENU_OPEN_MIN || params.OpenType > constant.MENU_OPEN_MAX {
		return errors.New(fmt.Sprintf("open type is invalid"))
	}

	if len(params.Url) <= 0 {
		return errors.New(fmt.Sprintf("url is empty"))
	}

	if !constant.CheckMethod(params.Method) {
		return errors.New(fmt.Sprintf("method is invalid"))
	}

	return nil
}

func (s *menuService) CreateMenu(params vo.MenuParams) (*vo.MenuVo, error) {
	if params.ParentId > 0 {
		_, err := mysql.Menu.GetBeanById(params.ParentId)
		if err != nil {
			return nil, errors.New("query parent error, " + err.Error())
		}
	}

	menu, err := mysql.Menu.FindByNameOrOrder(params.ParentId, params.MenuName, params.MenuOrder)
	if err != nil {
		return nil, errors.New("check error, " + err.Error())
	}

	if menu != nil {
		return nil, errors.New("menu exists")
	}

	menu = s.makeMenu(&models.Menu{}, params)
	err = mysql.Menu.InsertBean(utils.UserId(*s.Ctx), menu)
	if err != nil {
		return nil, errors.New("insert failed, " + err.Error())
	}

	NewServiceCache().UpdateMenuUrl(menu.ID, menu.ParentId, menu.Url, menu.Method, false)
	return s.makeMenuVo(menu), nil
}

func (s *menuService) UpdateMenu(params vo.MenuParams) (*vo.MenuVo, error) {
	menu, err := mysql.Menu.GetBeanById(params.Id)
	if err != nil {
		return nil, errors.New("find error, " + err.Error())
	}

	err = mysql.Menu.UpdateBean(utils.UserId(*s.Ctx), s.makeMenu(menu, params))
	if err != nil {
		return nil, errors.New("update error, " + err.Error())
	}

	NewServiceCache().UpdateMenuUrl(menu.ID, menu.ParentId, menu.Url, menu.Method, false)
	return s.makeMenuVo(menu), nil
}

func (s *menuService) RemoveMenu(menuID int64) (int64, error) {
	child, err := mysql.Menu.FindMenuByParent(menuID)
	if err != nil {
		return 0, errors.New("find child error, " + err.Error())
	}

	if child != nil && len(child) > 0 {
		_, err = mysql.Menu.DeleteByParents(child)
		if err != nil {
			return 0, errors.New("remove child error, " + err.Error())
		}
	}

	count, err := mysql.Menu.DeleteBeanById(menuID)
	if err != nil {
		return 0, errors.New("remove error, " + err.Error())
	}

	if count <= 0 {
		return 0, errors.New("not found menu")
	}

	NewServiceCache().UpdateMenuUrl(menuID, 0, "", "", true)
	return count, nil
}

func (s *menuService) FindFullMenu() ([]*vo.MenuVo, error) {
	return s.findMenuTree(0)
}

func (s *menuService) FindMenu(roleID int64) ([]*vo.MenuVo, error) {
	return s.findMenuTree(roleID)

	/*menus, err := s.queryMenuByUser(userId, false, 0)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s, %d] FindMenu failed", s.Uuid, userId), zap.Error(err))
		return nil, err
	}

	res := make([]*vo.MenuTreeVo, 0)
	for _, id := range s.findParentIds(menus) {
		tree := s.buildTree(id, menus)
		res = append(res, tree...)
	}

	s.sort(res)
	return res, nil*/
}

/*func (s *menuService) FindMenuByParentId(userId, parentId int64) ([]*vo.MenuVo, error) {
	menus, err := s.queryMenuByUser(userId, true, parentId)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s, %d, %d] FindMenuByParentId failed", s.Uuid, userId, parentId), zap.Error(err))
		return nil, err
	}

	res := make([]*vo.MenuVo, 0)
	for _, menu := range menus {
		child := s.makeMenuVo(menu)
		child.Children = make([]*vo.MenuVo, 0)
		res = append(res, child)
	}
	return res, nil
}*/

// func (s *menuService) GetRoleMenuTree(roleID int64) ([]*vo.MenuTreeVo, error) {
/*func (s *menuService) GetRoleMenuTree() ([]*vo.MenuTreeVo, error) {
	var menuIDs []int64
	visible := false
	roleID := utils.RoleID(*s.Ctx)
	if !utils.IsSuperAdmin(*s.Ctx) {
		// admin: roleID=0, full permission
		role, err := mysql.Role.GetBeanById(roleID)
		if err != nil {
			return nil, errors.New("get role error, " + err.Error())
		}

		// menuIDs = mysql.Menu.FindMenuIdsByRoleId(roleID)
		menuIDs = NewServiceCache().getRoleMenu(roleID)
		if menuIDs == nil || len(menuIDs) <= 0 {
			return nil, errors.New("none")
		}
		visible = true
	}

	menus, err := mysql.Menu.FindMenuByIds(menuIDs, visible, 0)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s, %d] GetRoleMenuTree failed, find menu error, ", s.Uuid, roleID), zap.Error(err))
		return nil, err
	}

	vos := make([]*vo.MenuTreeVo, 0)
	for _, id := range s.findParentIds(menus) {
		tree := s.buildTree(id, menus)
		vos = append(vos, tree...)
	}
	return vos, nil
}*/

/*func (s *menuService) DeleteMenuByIds(ids []int64) error {
	for _, id := range ids {
		list := mysql.Menu.FindMenuIdsByMenuId(id)
		if list != nil && len(list) > 0 {
			return errors.New(fmt.Sprintf("[%s] id为%d,的菜单正在使用中，不可删除", s.Uuid, id))
		}
		mysql.Menu.DeleteBeanById(id)
		// mysql.Menu.DeleteRoleMenuByMenuId(id)
	}
	return nil
}*/
