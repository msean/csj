package services

import (
	"application/utils"
	"fmt"
	"github.com/dop251/goja"
	"os"
)

const SCRIPT_STR = `function testFunc(x, y) {
return "" + x + " + " + y + " = " + (x + y);
}`

func TestFunc() {
	pwd, err := os.Getwd()
	if err != nil {
		fmt.Println("error: getPwd failed, " + err.Error())
		return
	}

	// scriptStr, err := utils.ReadFile("")
	scriptStr, err := utils.ReadFile(pwd + "/third_party/test.js")
	if err != nil {
		fmt.Println("error: read file failed, " + err.Error())
		return
	}

	vm := goja.New()
	_, err = vm.RunString(scriptStr)
	if err != nil {
		fmt.Println("1 err: " + err.Error())
		return
	}

	var multiFunc func(int, int) string
	err = vm.ExportTo(vm.Get("multi"), &multiFunc)
	if err != nil {
		fmt.Println("2 err: " + err.Error())
		return
	}

	fmt.Println("test multi: ", multiFunc(3, 5))

	var sumFunc func(int, int) string
	err = vm.ExportTo(vm.Get("sum"), &sumFunc)
	if err != nil {
		fmt.Println("2 err: " + err.Error())
		return
	}

	fmt.Println("test sum: ", sumFunc(3, 5))
}
