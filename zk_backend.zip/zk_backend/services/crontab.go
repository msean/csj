package services

import (
	"application/common/logger"
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services/statistic"
	"application/utils"
	"errors"
	"fmt"
	"sync"
	"time"

	"github.com/labstack/echo"
	"github.com/robfig/cron/v3"
	"go.uber.org/zap"
)

type (
	CrontabService struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewCrontabService(ctx *echo.Context) *CrontabService {
	bean := &CrontabService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

var CrontabManagerInstance *CrontabManager

const (
	cronJobCustomerDayBalance   string = "客户每日对账统计-余额"
	cronJobCustomerDayStatistic string = "客户每日对账统计-订单"
	cronJobOrderPartition       string = "订单分表生成"
)

var CronJobFuncMapper = make(map[string]CronJobExecFunc)

var SystemCronJobList = []models.Crontab{
	{
		JobName: cronJobCustomerDayStatistic,
		Spec:    "0 30 0 * * *",
		Status:  1,
		Type:    1,
	},
	{
		JobName: cronJobOrderPartition,
		Spec:    "0 0 0 * * *",
		Status:  1,
		Type:    1,
	},
	{
		JobName: cronJobCustomerDayBalance,
		Spec:    "0 0 0 * * *",
		Status:  1,
		Type:    1,
	},
}

type (
	CrontabManager struct {
		cron     *cron.Cron
		tasks    map[string]cron.EntryID
		taskLock sync.Mutex
	}
	CronJobExecFunc func()
)

func NewCrontabManager() *CrontabManager {
	return &CrontabManager{
		cron:  cron.New(cron.WithSeconds()),
		tasks: make(map[string]cron.EntryID),
	}
}

func (m *CrontabManager) InitRegisterJob() {
	CronJobFuncMapper[cronJobCustomerDayStatistic] = func() {
		yesterday := time.Now().AddDate(0, 0, -1).Format("2006-01-02")

		status := []int{constant.OrderStatusSuccess}
		err := statistic.NewCustomerDayFinanceSvc(nil).Statistic(yesterday, status)
		if err != nil {
			logger.Log.Error("Statistic", zap.String("date", yesterday), zap.Error(err))
		}
	}
	CronJobFuncMapper[cronJobOrderPartition] = func() {
		partition.Daily()
	}
	CronJobFuncMapper[cronJobCustomerDayBalance] = func() {
		yesterday := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
		err := statistic.NewCustomerDayFinanceSvc(nil).DayFinanceStatistic(yesterday)
		if err != nil {
			logger.Log.Error("DayFinanceStatistic", zap.String("date", yesterday), zap.Error(err))
		}
	}
}

func InitCrontabManager() (err error) {

	CrontabManagerInstance = NewCrontabManager()

	session := daos.Mysql.NewSession()
	defer session.Close()

	var storageCronJobList []models.Crontab
	storageCronJobMapper := make(map[string]bool)
	if err = utils.Find(session, &storageCronJobList, utils.NewWhereCond("type", 1)); err != nil {
		return
	}
	for _, crontabJob := range storageCronJobList {
		storageCronJobMapper[crontabJob.JobName] = true
	}

	for _, crontabJob := range SystemCronJobList {
		if _, ok := storageCronJobMapper[crontabJob.JobName]; !ok {
			if _, err = daos.CreateObjs(session, &crontabJob); err != nil {
				logger.Log.Error("InitCrontabManager CreateObjs", zap.String("jobName", crontabJob.JobName), zap.Error(err))
			}
			storageCronJobList = append(storageCronJobList, crontabJob)
		}
	}

	for _, storageCronJob := range storageCronJobList {
		CrontabManagerInstance.AddOrUpdateTask(storageCronJob)
	}
	CrontabManagerInstance.InitRegisterJob()
	CrontabManagerInstance.cron.Start()

	return
}

func (m *CrontabManager) AddOrUpdateTask(task models.Crontab) error {
	m.taskLock.Lock()
	defer m.taskLock.Unlock()

	if entryID, exists := m.tasks[task.JobName]; exists {
		m.cron.Remove(entryID)
	}

	if task.Status != 1 {
		delete(m.tasks, task.JobName)
		return nil
	}

	entryID, err := m.cron.AddFunc(task.Spec, func() {
		m.runTask(task)
	})

	logger.Log.Info("CrontabManager AddOrUpdateTask",
		zap.String("job", task.JobName),
		zap.String("spec", task.Spec),
		zap.Any("entryID", entryID),
		zap.Error(err),
	)

	if err != nil {
		return err
	}

	m.tasks[task.JobName] = entryID
	return nil
}

func (m *CrontabManager) RemoveTask(jobName string) {
	m.taskLock.Lock()
	defer m.taskLock.Unlock()

	if entryID, exists := m.tasks[jobName]; exists {
		m.cron.Remove(entryID)
		delete(m.tasks, jobName)
	}
}

func (m *CrontabManager) runTask(task models.Crontab) error {
	startTime := time.Now()

	taskFunc, exists := CronJobFuncMapper[task.JobName]
	if !exists {
		return fmt.Errorf("任务 [%s] 没有绑定的执行函数", task.JobName)
	}

	taskFunc()

	endTime := time.Now()
	logMsg := fmt.Sprintf("任务 [%s] 执行完成，开始时间: %s，结束时间: %s，耗时: %v",
		task.JobName,
		startTime.Format("2006-01-02 15:04:05"),
		endTime.Format("2006-01-02 15:04:05"),
		time.Since(startTime))

	session := daos.Mysql.NewSession()
	defer session.Close()
	_, err := session.Insert(&models.CrontabLog{CrontabID: task.ID, Log: logMsg})

	if err != nil {
		logger.Log.Error("runTask", zap.String("Job", task.JobName))
	}
	return nil
}

func (m *CrontabManager) UpdateTask(taskID int64, newSpec string, status int) error {
	m.taskLock.Lock()
	defer m.taskLock.Unlock()

	session := daos.Mysql.NewSession()
	defer session.Close()

	var task models.Crontab
	exist, err := session.ID(taskID).Get(&task)
	if err != nil {
		return fmt.Errorf("查询任务失败: %v", err)
	}
	if !exist {
		return fmt.Errorf("任务 ID %d 不存在", taskID)
	}

	updates := make(map[string]any)
	if !utils.IsBlankString(newSpec) {
		updates["spec"] = newSpec
	}
	if status != 0 {
		updates["status"] = status
	}
	_, err = utils.Update(session.Table(models.Crontab{}.TableName()), updates, utils.IDCond(taskID))

	if err != nil {
		return fmt.Errorf("更新数据库任务失败: %v", err)
	}

	if entryID, exists := m.tasks[task.JobName]; exists {
		m.cron.Remove(entryID)
		delete(m.tasks, task.JobName)
	}

	if status == 2 {
		return nil
	}

	entryID, err := m.cron.AddFunc(task.Spec, func() {
		m.runTask(task)
	})
	if err != nil {
		return fmt.Errorf("定时任务添加失败: %v", err)
	}

	m.tasks[task.JobName] = entryID

	return nil
}

func (srv *CrontabService) List(param vo.CrontabListParam) (rsp resp.CrontabListRsp, err error) {

	var total int64
	var crontabList []models.Crontab
	if crontabList, total, err = srv.DaoList(param); err != nil {
		return
	}
	var items []resp.CrontabListItem
	for _, _crontab := range crontabList {
		items = append(items, resp.CrontabListItem{
			JobName: _crontab.JobName,
			ID:      _crontab.ID,
			Type:    _crontab.Type,
			Status:  _crontab.Status,
			Spec:    _crontab.Spec,
			Created: _crontab.Created,
		})
	}

	rsp = resp.CrontabListRsp{
		Count:    int(total),
		Records:  items,
		Page:     param.Base.PageNum,
		PageSize: param.Base.PageSize,
	}
	return
}

func (srv *CrontabService) DaoList(param vo.CrontabListParam) (records []models.Crontab, total int64, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	conditions := []utils.Cond{}

	if param.JobNameSearch != "" {
		conditions = append(conditions, utils.NewWhereLikeCond("job_name", param.JobNameSearch, utils.LikeTypeBetween))
	}
	if param.StatusChoice != 0 {
		conditions = append(conditions, utils.NewWhereCond("status", param.StatusChoice))
	}
	if param.TypeChoice != 0 {
		conditions = append(conditions, utils.NewWhereCond("type", param.TypeChoice))
	}
	if len(param.IDList) != 0 {
		conditions = append(conditions, utils.NewInCond("id", param.IDList))
	}

	if !param.WithNoTotal {
		if total, err = utils.TotalByConds(session, new(models.Crontab), conditions...); err != nil {
			return
		}
		_, pl := utils.MutateLimitCond(param.Base)
		conditions = append(conditions, pl)
	}

	err = utils.Find(session, &records, conditions...)

	return
}

func (srv *CrontabService) Update(param vo.CrontabUpdateParam) (err error) {
	err = CrontabManagerInstance.UpdateTask(param.ID, param.Spec, param.Status)
	return
}

func (srv *CrontabService) Export(param vo.CrontabListParam) (filePath string, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[CrontabService] [Export]", zap.Any("param", param), zap.Error(err))
		}
	}()

	filePath = fmt.Sprintf("%d定时任务.xlsx", time.Now().Unix())
	if len(param.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d定时任务.xlsx", time.Now().Unix(), param.IDList[0], param.IDList[len(param.IDList)-1])
	}
	var objects []models.Crontab
	if objects, _, err = srv.DaoList(param); err != nil {
		return
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objects, mysql.SysDict.DataValueLabelMapper())
	return
}

func (srv *CrontabService) ExecOnce(param vo.CrontabExecOnceParam) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	var crontab models.Crontab
	var has bool
	if has, err = utils.Get(session, &crontab, utils.IDCond(param.ID)); err != nil {
		return
	}
	if !has {
		return errors.New("不存在改任务")
	}

	_, ok := CronJobFuncMapper[crontab.JobName]
	if !ok {
		return
	}
	go CrontabManagerInstance.runTask(crontab)
	return
}

func (srv *CrontabService) LogList(param vo.CrontabLogListParam) (rsp resp.CrontabLogListRsp, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	var conditions []utils.Cond

	var crontabIDList []int64
	if param.TypeChoice != 0 || param.JobNameSearch != "" {
		var crontabList []models.Crontab
		crontabList, _, err = srv.DaoList(vo.CrontabListParam{
			TypeChoice:    param.TypeChoice,
			JobNameSearch: param.JobNameSearch,
			WithNoTotal:   true,
		})
		for _, _crontab := range crontabList {
			crontabIDList = append(crontabIDList, _crontab.ID)
		}
		conditions = append(conditions, utils.NewInCond("crontab_id", crontabIDList))
	}

	var _limitCond utils.LimitCond
	if _limitCond, err = param.Base.ToLimitCond(); err != nil {
		return
	}

	tl, pl := utils.MutateLimitCond(_limitCond)
	conditions = append(conditions, tl)

	var total int64
	var crontabLogList []models.CrontabLog
	if total, err = utils.TotalByConds(session, new(models.CrontabLog), conditions...); err != nil {
		return
	}

	conditions = append(conditions, pl)
	if err = utils.Find(session, &crontabLogList, conditions...); err != nil {
		return
	}

	var _crontabIDList []int64
	for _, crontabLog := range crontabLogList {
		_crontabIDList = append(_crontabIDList, crontabLog.CrontabID)
	}

	var _crontabList []models.Crontab
	crontabIDMapper := make(map[int64]models.Crontab)
	if _crontabList, _, err = srv.DaoList(vo.CrontabListParam{
		IDList:      _crontabIDList,
		WithNoTotal: true,
	}); err != nil {
		return
	}

	for _, _crontab := range _crontabList {
		crontabIDMapper[_crontab.ID] = _crontab
	}

	var crontabLogItem []resp.CrontabLogItem
	for _, crontabLog := range crontabLogList {
		crontabLogItem = append(crontabLogItem, resp.CrontabLogItem{
			JobName: crontabIDMapper[crontabLog.CrontabID].JobName,
			Type:    int64(crontabIDMapper[crontabLog.CrontabID].Type),
			Created: crontabLog.Created,
			ID:      crontabLog.ID,
			Info:    crontabLog.Log,
		})
	}

	rsp = resp.CrontabLogListRsp{
		Records:  crontabLogItem,
		Count:    int(total),
		Page:     param.Base.PageNum,
		PageSize: param.Base.PageSize,
	}

	return
}

func (srv *CrontabService) Delete(param vo.DeleteParams) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	if _, err = daos.DelObjs(session, param.IDList, models.CrontabLog{}); err != nil {
		return
	}

	return
}

// func Crontab() {
// 	logger.Log.Info("Crontab Starting cron jobs...")

// 	c := cron.New(cron.WithSeconds())
// 	defer c.Stop()

// 	// template.QryChannelFinanceByChannelID(49)
// 	// 查询渠道的余额
// 	_, err := c.AddFunc("* */30 * * * *", func() {
// 		logger.Log.Info("[Crontab] ScanChannelFinance")
// 		template.ScanChannelFinance()
// 	})
// 	if err != nil {
// 		logger.Log.Error("[Crontab] Failed to add ScanChannelFinance task", zap.Error(err))
// 	}

// 	_, err = c.AddFunc("0 0 0 * * *", func() {
// 		yesterday := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
// 		logger.Log.Info("[Crontab] NewCustomerDayFinanceSvc task", zap.String("date", yesterday))

// 		status := []int{constant.OrderStatusSuccess}
// 		err := statistic.NewCustomerDayFinanceSvc(nil).Statistic(yesterday, status)
// 		if err != nil {
// 			logger.Log.Error("[Crontab] Failed NewCustomerDayFinanceSvc task", zap.String("date", yesterday), zap.Error(err))
// 		}
// 	})
// 	if err != nil {
// 		logger.Log.Error("[Crontab] Failed to add NewCustomerDayFinanceSvc task", zap.Error(err))
// 	}

// 	// 生成order_table和channel_order_table
// 	_, err = c.AddFunc("0 0 0 * * *", func() {
// 		partition.Daily()
// 	})
// 	if err != nil {
// 		logger.Log.Error("[Crontab] Failed to add NewCustomerDayFinanceSvc task", zap.Error(err))
// 	}

// 	if err != nil {
// 		logger.Log.Error("[CreateOrderTable] Failed to add NewCustomerDayFinanceSvc task", zap.Error(err))
// 	}

// 	c.Start()
// 	logger.Log.Info("[statistic] [Init] Cron jobs started")

// 	select {}
// }
