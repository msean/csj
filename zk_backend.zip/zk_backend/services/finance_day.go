package services

import (
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"errors"

	"github.com/labstack/echo"
)

type FinanceDayService struct {
	Ctx  *echo.Context
	Uuid string
}

func NewFinanceDayService(ctx *echo.Context) *FinanceDayService {
	return &FinanceDayService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
}

func (s *FinanceDayService) makeFinanceDayVo(obj *models.FinanceDay) *vo.FinanceDayVo {
	_date := obj.FinanceDate
	if len(_date) > 10 {
		_date = _date[:10]
	}
	return &vo.FinanceDayVo{
		ID:          obj.ID,
		IsCustomer:  obj.IsCustomer,
		OwnerID:     obj.OwnerID,
		Name:        obj.Name,
		Balance:     obj.Balance,
		FinanceDate: _date,
		Remark:      obj.Remark,
		Created:     obj.Created,
	}
}

func (s *FinanceDayService) CreateRecord(params *models.FinanceDay) (*vo.FinanceDayVo, error) {
	if params.IsCustomer {
		obj, err := mysql.Customer.GetBeanById(params.OwnerID)
		if err != nil {
			return nil, errors.New("invalid customer")
		}

		params.Name = obj.Name
	} else {
		obj, err := mysql.Channel.GetBeanById(params.OwnerID)
		if err != nil {
			return nil, errors.New("invalid channel")
		}

		params.Name = obj.Name
	}

	err := mysql.FinanceDay.InsertBean(utils.UserId(*s.Ctx), params)
	if err != nil {
		return nil, errors.New("insert failed, " + err.Error())
	}

	return s.makeFinanceDayVo(params), nil
}

func (s *FinanceDayService) UpdateRecord(params *models.FinanceDay) (*vo.FinanceDayVo, error) {
	obj, err := mysql.FinanceDay.GetBeanById(params.ID)
	if err != nil {
		return nil, errors.New("find failed, " + err.Error())
	}

	obj.FinanceDate = params.FinanceDate
	obj.Balance = params.Balance
	obj.Remark = params.Remark
	err = mysql.FinanceDay.UpdateBean(utils.UserId(*s.Ctx), obj)
	if err != nil {
		return nil, errors.New("update failed, " + err.Error())
	}

	return s.makeFinanceDayVo(obj), nil
}

func (s *FinanceDayService) RemoveRecord(ids []int64) (int64, error) {
	count, err := mysql.FinanceDay.DeleteBeanByIds(ids)
	if err != nil {
		return 0, errors.New("delete failed, " + err.Error())
	}

	if count <= 0 {
		return 0, errors.New("invalid ids")
	}

	return count, nil
}

func (s *FinanceDayService) QueryRecords(params vo.FinanceDayQueryParams) (*vo.FinanceDayQueryRes, error) {
	count, objs, err := mysql.FinanceDay.QueryBeans(params)
	if err != nil {
		return nil, err
	}

	data := make([]*vo.FinanceDayVo, 0)
	if count > 0 {
		for _, obj := range objs {
			data = append(data, s.makeFinanceDayVo(obj))
		}
	}

	return &vo.FinanceDayQueryRes{
		Count:   count,
		Records: data,
	}, nil
}
