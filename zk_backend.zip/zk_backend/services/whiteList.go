package services

import (
	"application/common/logger"
	"application/conf"
	"application/daos"
	"application/models"
	"application/models/vo"
	"application/utils"
	"fmt"
	"strings"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type WhiteListSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewWhiteListSrv(ctx *echo.Context) *WhiteListSrv {
	bean := &WhiteListSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *WhiteListSrv) Create(params vo.WhiteListCreateParam) (successCount int, err error) {
	var areaSection models.AreaSection
	if err = copier.Copy(&areaSection, &params); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	ipList := strings.Split(params.IpList, ",")
	for _, ip := range ipList {
		if utils.IsValidIP(ip) {
			var exist bool
			exist, err = daos.Exist(session, &models.WhiteList{}, 0, map[string]any{
				"ip": ip,
			})
			if err != nil {
				logger.Log.Error("WhiteListSrv Create", zap.String("ip", ip))
				continue
			}
			if !exist {
				var affected int64
				if affected, err = daos.CreateObjs(session, &models.WhiteList{
					IP:     ip,
					Remark: params.Remark,
				}); err != nil {
					logger.Log.Error("WhiteListSrv Create", zap.String("ip", ip), zap.String("remark", params.Remark))
				}
				successCount += int(affected)
			}
		} else {
			logger.Log.Error("WhiteListSrv Create", zap.String("ip", ip))
		}
	}
	return
}

func (srv *WhiteListSrv) List(param vo.WhiteListPageParam) (objects []models.WhiteList, total int64, err error) {
	objects = make([]models.WhiteList, 0)

	conds := []utils.Cond{}

	if len(param.IDList) != 0 {
		conds = append(conds, utils.NewInCond("id", param.IDList))
	}

	if !utils.IsBlankString(param.IpSearch) {
		conds = append(conds, utils.NewWhereLikeCond("ip", param.IpSearch, utils.LikeTypeBetween))
	}

	if !utils.IsBlankString(param.RemarkSearch) {
		conds = append(conds, utils.NewWhereLikeCond("remark", param.RemarkSearch, utils.LikeTypeBetween))
	}

	var limitCond utils.LimitCond
	if limitCond, err = param.Base.ToLimitCond(); err != nil {
		return
	}

	tl, pl := utils.MutateLimitCond(limitCond)
	conds = append(conds, tl)

	session := daos.Mysql.NewSession()
	defer session.Close()

	if total, err = utils.TotalByConds(session, new(models.WhiteList), conds...); err != nil {
		return
	}

	conds = append(conds, pl)
	err = utils.Find(session, &objects, conds...)
	return
}

func (srv *WhiteListSrv) Update(params vo.WhiteListUpdateParam) (err error) {
	whiteList := models.WhiteList{
		IP:     params.Ip,
		Remark: params.Remark,
	}
	whiteList.ID = params.ID

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.UpdateObjWithVersion(session, whiteList, nil)
	return
}

func (srv *WhiteListSrv) Export(params vo.WhiteListPageParam) (filePath string, err error) {
	filePath = fmt.Sprintf("%d白名单管理.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d白名单管理.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var objects []models.WhiteList
	if objects, _, err = srv.List(params); err != nil {
		return
	}

	exportObject := make([]*models.WhiteListExport, 0, len(objects))
	for _, obj := range objects {
		exportObject = append(exportObject, &models.WhiteListExport{
			ID:      obj.ID,
			Created: obj.Created,
			IP:      obj.IP,
			Remark:  obj.Remark,
		})
	}

	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", exportObject, nil)
	return
}

func (srv *WhiteListSrv) Delete(params vo.DeleteParams) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	_, err = daos.DelObjs(session, params.IDList, models.WhiteList{})
	return
}
