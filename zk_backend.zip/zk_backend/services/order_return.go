package services

import (
	"application/common/logger"
	"application/conf"
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/utils"
	"fmt"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	ReturnOrderSvc struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewReturnOrderSvc(ctx *echo.Context) *ReturnOrderSvc {
	bean := &ReturnOrderSvc{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (svc *ReturnOrderSvc) List(param vo.ReturnOrderListParam) (rsp []resp.ReturnOrderRsp, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ReturnOrderSvc] [List]", zap.Any("param", param), zap.Error(err))
		}
	}()

	var orderModels []models.OrderReturn
	if orderModels, total, err = mysql.ReturnOrder.List(param); err != nil {
		return
	}

	var customerIDList []int64
	var ProductCodeList []string
	var channelIDList []int64
	for _, orderModel := range orderModels {
		customerIDList = append(customerIDList, orderModel.CustomerID)
		ProductCodeList = append(ProductCodeList, orderModel.ProductCode)
		channelIDList = append(channelIDList, orderModel.ChannelID)
	}

	customerM, _ := mysql.Customer.FromIDList(utils.DedupeInt64Slice(customerIDList))
	productM, _ := mysql.Product.FromCodes(utils.DedupeStringSlice(ProductCodeList))
	channelM, _ := mysql.Channel.FromIDList(utils.DedupeInt64Slice(channelIDList))

	for _, orderModel := range orderModels {
		rsp = append(rsp, svc.Fill(orderModel, customerM[orderModel.CustomerID], productM[orderModel.ProductCode], channelM[orderModel.ChannelID]))
	}
	return
}

func (srv *ReturnOrderSvc) Fill(
	orderModel models.OrderReturn,
	customer models.Customer,
	product models.Product,
	channel models.Channel,
) (orderRsp resp.ReturnOrderRsp) {
	orderRsp = resp.ReturnOrderRsp{
		ID:              orderModel.ID,
		OrderID:         orderModel.OrderID,
		CustomerOrderID: orderModel.CustomerOrderID,
		ChannelOrderID:  orderModel.ChannelOrderID,
		ChannelName:     channel.Name,
		Area:            orderModel.Area,
		CustomerName:    customer.Name,
		Phone:           orderModel.Phone,
		Product:         product.Name,
		Isp:             int64(orderModel.Isp),
		FaceValue:       orderModel.FaceValue,
		OrderTime:       orderModel.OrderTime,
		Voucher:         orderModel.VoucherType,
		Remark:          orderModel.Remark,
		Created:         orderModel.Created,
		Type:            int(orderModel.Type),
	}
	return
}

func (srv *ReturnOrderSvc) Export(params vo.ReturnOrderListParam) (filePath string, err error) {
	filePath = fmt.Sprintf("%d渠道订单列表.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d返销订单列表.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}

	var returnOrderRsp []resp.ReturnOrderRsp
	if params.StartTime.IsZero() {
		params.StartTime = time.Now().AddDate(0, -2, 0)
	}
	params.Base.StartTime = params.StartTime
	params.Base.EndTime = params.EndTime
	if returnOrderRsp, _, err = srv.List(params); err != nil {
		return
	}
	if len(returnOrderRsp) == 0 {
		returnOrderRsp = append(returnOrderRsp, resp.ReturnOrderRsp{})
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", returnOrderRsp, mysql.SysDict.DataValueLabelMapper())
	return
}
