package services

import (
	"application/common/logger"
	"application/constant"
	_constant "application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/logic"
	"application/services/cache"
	"application/utils"
	"encoding/json"
	"fmt"
	"math/rand"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	Dispatcher struct {
		customer             models.Customer
		customerProd         models.CustomerProduct
		channelSortMatrix    []logic.ChannelSort
		orderModel           *models.Order
		allProdCode          []string // 所有的产品编码 包含请求的产品编码以及在 打开全部产品编码， 若是没有找到分省的产品则 可以查询相应的全国产品编码
		deadLine             time.Time
		channelProductMapper map[int64]map[string]models.ChannelProduct // key1 channelID key2 productCode
		currentChannel       int64
		ctx                  echo.Context
		channelChanIndex     chan int
		SchedulerTime        time.Time
	}
	ChannelFilterFunc func(*Dispatcher) (*Dispatcher, error)
)

func (dispatcher *Dispatcher) variantProductCode() (variantCode string) {
	productCode := dispatcher.orderModel.ProductCode
	if len(productCode) < 4 {
		return
	}
	// 必须要用orderModel的isp， 后台管理可以修改isp
	isp := _constant.Isp(dispatcher.orderModel.Isp)
	if dispatcher.customer.AllProductFlag {
		if isp == _constant.IspMobile || isp == _constant.IspUniCom || isp == _constant.IspTelCom {
			if !strings.HasPrefix(productCode, fmt.Sprintf("%d00", isp)) {
				variantCode = fmt.Sprintf("%d00%s", isp, productCode[3:])
			}
		}
	}
	return
}

func (dispatcher *Dispatcher) setChannelMatrix() (err error) {
	// 后台管理渠道补充可以修改
	if len(dispatcher.channelSortMatrix) == 0 {
		dispatcher.channelSortMatrix, err = new(CustomerProductService).Decompose(dispatcher.customerProd)
	}
	return
}

func NewDispatcher(customer models.Customer,
	orderModel *models.Order,
	customerProd models.CustomerProduct,
	channelSortMatrix []logic.ChannelSort,
	deadLine time.Time,
	currentChannel int64,
	ctx echo.Context,
) (dispatcher *Dispatcher, err error) {
	dispatcher = &Dispatcher{
		customerProd:      customerProd,
		customer:          customer,
		orderModel:        orderModel,
		channelSortMatrix: channelSortMatrix,
		currentChannel:    currentChannel,
		ctx:               ctx,
		channelChanIndex:  make(chan int),
	}
	if err = dispatcher.setChannelMatrix(); err != nil {
		return
	}

	if deadLine.IsZero() {
		timeOut := time.Duration(dispatcher.customer.Timeout * uint(time.Second))
		if dispatcher.customer.SlowRechargeFlag {
			timeOut = time.Duration(dispatcher.customer.SlowTimeout * uint(time.Minute))
		}
		deadLine = time.Now().Add(timeOut)
	}
	dispatcher.deadLine = deadLine
	// 给你5天够了吧
	if orderModel.Source == 1 {
		dispatcher.deadLine = time.Now().AddDate(0, 0, 5)
	}

	dispatcher.allProdCode = []string{dispatcher.orderModel.ProductCode}
	if variantCode := dispatcher.variantProductCode(); !utils.IsBlankString(variantCode) {
		dispatcher.allProdCode = append(dispatcher.allProdCode, variantCode)
	}

	if err = dispatcher.SetChannelProductMapper(); err != nil {
		return
	}

	logger.Log.Info("[NewDispatcher]",
		zap.String("customerOrderID", dispatcher.orderModel.CustomerOrderID),
		zap.Int64("orderID", dispatcher.orderModel.ID),
		zap.Strings("productCode", dispatcher.allProdCode),
		zap.Any("channels", dispatcher.channelSortMatrix),
		zap.Time("deadLine", dispatcher.deadLine),
	)
	return
}

func (dispatcher *Dispatcher) RecordChannelInfo() {
	session := daos.Mysql.NewSession()
	defer session.Close()

	mysql.Order.RecordChannelInfo(session, models.OrderChannelRecord{
		OrderID:          dispatcher.orderModel.ID,
		Type:             1,
		ChannelGroupID:   dispatcher.customerProd.ChannelGroupID,
		ChannelIds:       dispatcher.customerProd.ChannelIds,
		FirstChannelIds:  dispatcher.customerProd.FirstChannelIds,
		SecondChannelIds: dispatcher.customerProd.SecondChannelIds,
		ForbidChannelIds: dispatcher.customerProd.ForbidChannelIds,
		ValidChannel:     dispatcher.channelSortMatrix,
	})
}

func (dispatcher *Dispatcher) SendToBus(recordChannel bool) {
	if recordChannel {
		go dispatcher.RecordChannelInfo()
	}
	go GlobalDispatcherScheduler.Put(dispatcher)
}

func (dispatcher *Dispatcher) HasChannel() bool {
	for _, channelSort := range dispatcher.channelSortMatrix {
		if len(channelSort.Channels) != 0 {
			return true
		}
	}
	return false
}

func (dispatcher *Dispatcher) ChannelFilter(funcs ...ChannelFilterFunc) (err error) {
	for _, _func := range funcs {
		if dispatcher, err = _func(dispatcher); err != nil {
			return
		}
	}
	return
}

func (dispatcher *Dispatcher) SetChannelProductMapper() (err error) {
	allChannels := []int64{}
	for _, channelSort := range dispatcher.channelSortMatrix {
		allChannels = append(allChannels, channelSort.Channels...)
	}
	// dispatcher.channelProductMapper, err = mysql.ChannelProd.ListOnlineChannelProd(allChannels, dispatcher.allProdCode)
	dispatcher.channelProductMapper, err = cache.ListOnlineChannelProd(allChannels, dispatcher.allProdCode)
	return
}

// ChannelProductMatchFilter 根据所有的channel 判断是否有合适的 渠道产品
// 若是打开了查询全部产品编码，则可以查询全国产品
func ChannelProductMatchFilter(dispatcher *Dispatcher) (_dispatcher *Dispatcher, err error) {
	var channelMatrix []logic.ChannelSort
	for _, channelSort := range dispatcher.channelSortMatrix {
		var newChannelSort logic.ChannelSort
		for index, channelID := range channelSort.Channels {
			if _, ok := dispatcher.channelProductMapper[channelID]; ok {
				newChannelSort.Channels = append(newChannelSort.Channels, channelID)
				newChannelSort.SortType = channelSort.SortType
				newChannelSort.Percent = append(newChannelSort.Percent, channelSort.Percent[index])
			}
		}
		channelMatrix = append(channelMatrix, newChannelSort)
	}
	dispatcher.channelSortMatrix = channelMatrix
	return dispatcher, nil
}

func SortChannels(channelSort logic.ChannelSort) (reChannelSort logic.ChannelSort) {

	if len(channelSort.Channels) == 0 {
		return
	}

	switch channelSort.SortType {
	case 0:
		return channelSort
	default: // 目前只考虑百分比
		type Range struct {
			Start, End int
			Channel    int64
		}
		var ranges []Range
		var start, end int
		for index, channel := range channelSort.Channels {
			end = start + int(channelSort.Percent[index])
			ranges = append(ranges, Range{
				Start:   start,
				End:     end,
				Channel: channel,
			})
			if index != len(channelSort.Channels)-1 {
				start = end + 1
			}
		}
		randomValue := rand.Intn(end)
		for _, _range := range ranges {
			if _range.Start <= randomValue && randomValue <= _range.End {
				reChannelSort = logic.ChannelSort{
					Channels: []int64{_range.Channel},
					SortType: channelSort.SortType,
					Percent:  []int{100},
				}
			}
		}
	}
	return
}

// ChannelDupFilter channel 去重
func ChannelDupFilter(dispatcher *Dispatcher) (*Dispatcher, error) {
	var channelMatrix []logic.ChannelSort
	dupChannelM := make(map[int64]struct{})
	for _, channelSort := range dispatcher.channelSortMatrix {
		newChannelSort := logic.ChannelSort{
			SortType: channelSort.SortType,
		}
		for index, channelID := range channelSort.Channels {
			if _, in := dupChannelM[channelID]; !in {
				newChannelSort.Channels = append(newChannelSort.Channels, channelID)
				newChannelSort.Percent = append(newChannelSort.Percent, channelSort.Percent[index])
				dupChannelM[channelID] = struct{}{}
			}
		}
		channelMatrix = append(channelMatrix, newChannelSort)
	}
	dispatcher.channelSortMatrix = channelMatrix
	return dispatcher, nil
}

// 根据channelGroup的sortType类型进行排序
func ChannelGroupSortFilter(dispatcher *Dispatcher) (*Dispatcher, error) {
	var channelMatrix []logic.ChannelSort
	for _, channelSort := range dispatcher.channelSortMatrix {
		channelMatrix = append(channelMatrix, SortChannels(channelSort))
	}
	dispatcher.channelSortMatrix = channelMatrix
	return dispatcher, nil
}

func (dispatcher *Dispatcher) channels() (channelIDList []int64, channelIndex int, stop bool) {
	channelM := make(map[int64]bool)
	for _, channelSort := range dispatcher.channelSortMatrix {
		for _, channel := range channelSort.Channels {
			if _, ok := channelM[channel]; !ok {
				channelM[channel] = true
				channelIDList = append(channelIDList, channel)
			}
		}
	}

	if dispatcher.currentChannel != 0 {
		for i, channelID := range channelIDList {
			if channelID == dispatcher.currentChannel {
				// 最后一个渠道
				if i == len(channelIDList)-1 {
					// 慢充循环开关
					if dispatcher.customer.SlowRechargeFlag {
						// 重新开始啊 重新获取下配置吧
						var customer models.Customer
						var has bool
						var err error
						has, err = cache.FromModelPk(customer.TableName(), cache.CustomerPk(dispatcher.customer.ID), &customer, "get")
						if !has && err != nil {
							logger.Log.Error("[dispatcher] [customer] [FromID]",
								zap.Int64("customerID", dispatcher.customer.ID),
								zap.Int64("orderID", dispatcher.orderModel.ID),
								zap.Bool("has", has),
								zap.Error(err))
							return
						}
						if !customer.SlowCycleFlag {
							logger.Log.Info("[dispatcher] [re]",
								zap.Int64("customerID", dispatcher.customer.ID),
								zap.Int64("orderID", dispatcher.orderModel.ID),
								zap.Bool("customer.SlowCycleFlag", customer.SlowCycleFlag))
							return
						}

						// 重新去拉产品参数
						if err = dispatcher.SetChannelProductMapper(); err != nil {
							return
						}

						// 慢充循环一直是最后一个
						if dispatcher.customer.SlowCycleFlag {
							channelIndex = len(channelIDList) - 1
						} else {
							channelIndex = 0
						}

					} else {
						stop = true
						dispatcher.Fail(map[string]any{"finish_time": time.Now()})
						return
					}
				} else {
					channelIndex = i + 1
				}
			}
		}
	}
	return
}

func (dispatcher *Dispatcher) sendChannelIndex(index int) {
	defer func() {
		if r := recover(); r != nil {
			logger.Log.Info("[Dispatcher] [sendChannelIndex]", zap.Any("recover", r))
		}
	}()
	dispatcher.channelChanIndex <- index
}

func (dispatcher *Dispatcher) receiveChannelIndex(channelIDList []int64, channelIndex int) (submitResult bool, nextChannelIndex int, stop bool) {
	canSubmit, channelProduct, err := dispatcher.ChannelCheck(channelIDList[channelIndex])
	logger.Log.Info("ChannelCheck",
		zap.Int64("orderID", dispatcher.orderModel.ID),
		zap.Bool("canSubmit", canSubmit),
		zap.Error(err),
		zap.Int64("product", channelProduct.ID),
		zap.Int64("channel", channelProduct.ChannelID))

	if err == nil && canSubmit {
		var submitSuccess bool
		submitSuccess, err = dispatcher.SubmitToChannel(channelProduct)
		logger.Log.Info("SubmitToChannel",
			zap.Int64("orderID", dispatcher.orderModel.ID),
			zap.Bool("submit", submitSuccess),
			zap.Error(err))
		if submitSuccess && err == nil {
			// 假如是由地区产品->全国产品
			if channelProduct.ProductCode != dispatcher.orderModel.ProductCode {
				dispatcher.orderModel.Area = "全国"
				dispatcher.orderModel.Province = "全国"
				dispatcher.orderModel.ProductCode = channelProduct.ProductCode
				partition.GlobalOrderPartition.ReplaceProductCode(channelProduct.ProductCode, dispatcher.orderModel.ID, "全国", "全国")
			}
			submitResult = true
			stop = true
			return
		}
	}

	// 最后一个啊
	if channelIndex == len(channelIDList)-1 {
		if dispatcher.customer.SlowRechargeFlag {
			// 重新开始啊 重新获取下配置吧
			var customer models.Customer
			var has bool
			var err error
			// 中途后台修改了慢充配置
			has, err = cache.FromModelPk(customer.TableName(), cache.CustomerPk(dispatcher.customer.ID), &customer, cache.FromDatabaseGet)
			if !has && err != nil {
				logger.Log.Error("[dispatcher] [customer] [FromID]", zap.Bool("has", has), zap.Error(err))
				return
			}
			// 重新去拉产品参数
			if err = dispatcher.SetChannelProductMapper(); err != nil {
				return
			}
			if dispatcher.customer.SlowCycleFlag {
				nextChannelIndex = len(channelIDList) - 1
			} else {
				nextChannelIndex = 0
			}
			// go dispatcher.sendChannelIndex(0)
		} else {
			dispatcher.Fail(map[string]any{
				"remark":      "无渠道成功",
				"finish_time": time.Now(),
			})
			stop = true
			return
		}
	} else {
		nextChannelIndex = channelIndex + 1
		// go dispatcher.sendChannelIndex(channelIndex + 1)
	}
	return
}

func (dispatcher *Dispatcher) Exit() {
	close(dispatcher.channelChanIndex)
	GlobalDispatcherScheduler.Remove(dispatcher)
	logger.Log.Info("[dispatcher exit]",
		zap.Int64("orderID", dispatcher.orderModel.ID),
		zap.Duration("take", time.Since(dispatcher.SchedulerTime)),
	)
}

func (dispatcher *Dispatcher) Do() {

	defer func() {
		dispatcher.Exit()
	}()

	var stop bool
	channelIDList, currentIndex, stop := dispatcher.channels()

	if stop {
		return
	}

	if len(channelIDList) == 0 {
		return
	}

	if time.Now().After(dispatcher.deadLine) {
		dispatcher.Fail(map[string]any{
			"remark":      "超时 无渠道成功",
			"finish_time": time.Now(),
		})
		return
	}

	go dispatcher.sendChannelIndex(currentIndex)

	var submitSuccess bool
	for {
		select {
		case channelIndex := <-dispatcher.channelChanIndex:
			var nextChannelIndex int
			submitSuccess, nextChannelIndex, stop = dispatcher.receiveChannelIndex(channelIDList, channelIndex)

			if stop {
				return
			}

			// 慢充第一轮遍历后退出，防止占坑很久
			if dispatcher.customer.SlowRechargeFlag {
				if dispatcher.customer.SlowCycleFlag {
					if channelIndex == len(channelIDList)-1 && nextChannelIndex == len(channelIDList)-1 {
						dispatcher.slowDelay(
							func() {
								ReDispatcher(dispatcher.ctx, dispatcher.orderModel.ID, 0, nil, 0, channelIDList[len(channelIDList)-1])
							},
						)
						return
					}
				}
				if nextChannelIndex == 0 {
					dispatcher.slowDelay(
						func() {
							ReDispatcher(dispatcher.ctx, dispatcher.orderModel.ID, 0, nil, 0, 0)
						},
					)
					return
				}
			} else {
				go dispatcher.sendChannelIndex(nextChannelIndex)
			}
		case <-time.After(time.Until(dispatcher.deadLine)):
			if !submitSuccess {
				dispatcher.Fail(map[string]any{
					"remark":      "超时 无渠道成功",
					"finish_time": time.Now(),
				})
			}
			return
		}
	}
}

// 防止无休止刷单
func (dispatcher *Dispatcher) slowDelay(delay func()) {
	if GlobalDispatcherScheduler.Len() >= GlobalDispatcherScheduler.Cap() {
		delay()
		return
	}
	if GlobalDispatcherScheduler.Len() >= GlobalDispatcherScheduler.Cap()/4*3 {
		time.AfterFunc(5*time.Second, delay)
		return
	}
	if GlobalDispatcherScheduler.Len() >= GlobalDispatcherScheduler.Cap()/2 {
		time.AfterFunc(10*time.Second, delay)
		return
	}
	if GlobalDispatcherScheduler.Len() >= GlobalDispatcherScheduler.Cap()/4 {
		time.AfterFunc(15*time.Second, delay)
		return
	}
	time.AfterFunc(30*time.Second, delay)
}

func (dispatcher *Dispatcher) Fail(updates map[string]any) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	if err := partition.GlobalOrderPartition.ModifyStatus(session, *dispatcher.orderModel, constant.OrderStatusFail, updates); err != nil {
		logger.Log.Error("[Dispatcher] [ModifyStatus]", zap.Error(err), zap.Int64("order id", dispatcher.orderModel.ID))
	}
	go func() {
		defer func() {
			if r := recover(); r != nil {
				logger.Log.Error("[dispatcher] [FinalDefer] [OrderBackMoney]", zap.Any("error", r))
			}
		}()
		NewOrderService(&dispatcher.ctx).OrderBackMoney(*dispatcher.orderModel)
	}()

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[dispatcher] [FinalDefer] [Notify]", zap.Any("error", r))
		}
		NewCallbackSvc(&dispatcher.ctx).Notify(dispatcher.orderModel.ID, models.ChannelOrder{})
	}()

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[dispatcher] [FinalDefer] [PublishOrderStuck]", zap.Any("error", r))
		}
		PublishOrderStuck(*dispatcher.orderModel, constant.OrderStatusFail)
	}()
}

func (dispatcher *Dispatcher) ChannelCheck(channelID int64) (canSubmit bool, channelProduct models.ChannelProduct, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[Dispatcher] [ChannelCheck]",
				zap.Any("channelID", channelID),
				zap.Error(err),
			)
		}
	}()
	var channel models.Channel
	var has bool
	if has, err = cache.FromModelPk(channel.TableName(), cache.ChannelPk(channelID), &channel, cache.FromDatabaseGet); err != nil {
		return
	}

	if !has || channel.Online == 1 {
		return
	}
	// 判断渠道是否在区域维护中
	areaCode := constant.AreaCodeM[dispatcher.orderModel.Province]
	areaSuspend := models.AreaSuspend{
		ApplyID: channel.ID,
		Type:    _constant.SuspendTypeChannel,
		Isp:     int64(dispatcher.orderModel.Isp),
		Area:    int64(areaCode),
	}
	yes, _ := cache.InSetCache(models.AreaSuspend{}.TableName(), cache.AreaSuspendObj(areaSuspend))
	// yes, _ := mysql.AreaSuspend.InSuspend(channel.ID, int64(dispatcher.orderModel.Isp), _constant.SuspendTypeChannel, int64(areaCode))
	if yes {
		logger.Log.Info("ChannelCheck",
			zap.Int64("orderID", dispatcher.orderModel.ID),
			zap.Int64("channel", channel.ID),
			zap.Int("areaCode", areaCode),
			zap.Int("isp", dispatcher.orderModel.Isp),
		)
		return
	}

	if channel.StuckLimit > 0 {
		channelStuckCount := OrderStuckChecker.ChannelStuckCount(channelID)
		if channelStuckCount >= int(channel.StuckLimit) {
			logger.Log.Info("ChannelCheck",
				zap.Int64("orderID", dispatcher.orderModel.ID),
				zap.Int64("channelID", channelID),
				zap.Int("count", channelStuckCount),
				zap.Uint("limit", channel.StuckLimit),
			)
			return
		}
	}

	for _, productCode := range dispatcher.allProdCode {
		_channelProduct := dispatcher.channelProductMapper[channelID][productCode]
		if _channelProduct.ID != 0 {
			p := func(channelProduct models.ChannelProduct) (valid bool) {
				valid = true
				customerProdPrice := dispatcher.customerProd.SalePrice + dispatcher.customerProd.BackMoney
				channelProductPrice := channelProduct.OrderPrice
				epsilon := 1e-9
				if dispatcher.orderModel.TaxType <= 1 && utils.LessThanWithPrecision(customerProdPrice, channelProductPrice, epsilon) {

					logger.Log.Info("ChannelCheck",
						zap.Int64("orderID", dispatcher.orderModel.ID),
						zap.String("productCode", productCode),
						zap.Int64("channelID", channelID),
						zap.Float64("customer price", dispatcher.customerProd.SalePrice+dispatcher.customerProd.BackMoney),
						zap.Float64("channel price", channelProduct.OrderPrice),
					)
					return false
				}
				return true
			}

			if p(_channelProduct) {
				channelProduct = _channelProduct
				canSubmit = true
				return
			}
		}
	}
	return
}

// 后台管理修改Isp 渠道补充的时候都需要重置dispatcher
// reDispatchType 0 正常重新分发 1 修改isp 2 修改渠道
// channelIDList channelGroupID reDispatchType 为2的时候需要传递重新补充的渠道
// timeout 不设置根据customer的超时时间来确定
// currentChannel 当前处理的
func ReDispatcher(ctx echo.Context,
	orderID int64,
	reDispatchType int,
	channelIDList []int64,
	channelGroupID int64,
	currentChannel int64,
) (err error) {
	logger.Log.Info("ReDispatcher",
		zap.Int64("orderID", orderID),
		zap.Int("reDispatchType", reDispatchType),
		zap.Int64s("channelIDList", channelIDList),
		zap.Int64("channelGroup", channelGroupID),
		zap.Int64("currentChannel", currentChannel),
	)
	if reDispatchType == 2 && len(channelIDList) == 0 && channelGroupID == 0 {
		return
	}

	GlobalDispatcherScheduler.RemoveByOrderID(orderID)

	session := daos.Mysql.NewSession()
	defer session.Close()

	var has bool
	var order models.Order
	if order, has, err = partition.GlobalOrderPartition.FromID(session, orderID); !has || err != nil {
		logger.Log.Error("[ReDispatcher]",
			zap.Int64("order", order.ID),
			zap.Bool("has", has),
			zap.Error(err),
		)
		return
	}

	// 退单了 不进行下发了
	if order.HasReturned == 2 {
		return
	}

	if reDispatchType == 1 && (order.Status == _constant.OrderStatusFail || order.Status == _constant.OrderStatusSuccess) {
		return
	}

	var customer models.Customer
	if has, err = cache.FromModelPk(customer.TableName(), cache.CustomerPk(order.CustomerID), &customer, cache.FromDatabaseGet); !has || err != nil {
		logger.Log.Error("[ReDispatcher]",
			zap.Int64("customer", order.CustomerID),
			zap.Bool("has", has),
			zap.Error(err),
		)
	}

	var customerProd models.CustomerProduct
	if has, err = cache.FromModelPk(customerProd.TableName(), cache.CustomerProductPk(order.CustomerID, order.ProductCode), &customerProd, cache.FromDatabaseGet); !has || err != nil {
		logger.Log.Error("[ReDispatcher] [customerProd]",
			zap.Int64("customerProd", order.CustomerID),
			zap.String("customerProd", order.ProductCode),
			zap.Bool("has", has),
			zap.Error(err),
		)
		return
	}

	var channelSortMatrix []logic.ChannelSort
	var recordChannelFlow bool
	// 重新分发的用老的渠道策略
	if reDispatchType == 0 {
		var channelRecord models.OrderChannelRecord
		has, err = session.Table(channelRecord.TableName()).Where("order_id = ? AND type = ?", orderID, 1).
			OrderBy("created DESC").Limit(1).Get(&channelRecord)

		if has && err == nil {
			channelSortMatrix = channelRecord.ValidChannel
		} else {
			recordChannelFlow = true
		}
	}
	if len(channelIDList) != 0 {
		channelSortMatrix = append(channelSortMatrix, logic.ChannelSort{
			Channels: channelIDList,
			SortType: 0,
			Percent: func(n int) []int {
				p := make([]int, n)
				for i := range p {
					p[i] = 100
				}
				return p
			}(len(channelIDList)),
		})
		recordChannelFlow = true
	}

	if len(channelIDList) == 0 && channelGroupID != 0 {
		var channelGroup models.ChannelGroup
		if channelGroup, has, err = mysql.ChannelGroup.FromID(channelGroupID); !has || err != nil {
			logger.Log.Error("[ReDispatcher] [customerProd]",
				zap.Int64("channelGroupID", channelGroupID),
				zap.Bool("has", has),
				zap.Error(err),
			)
			return
		}
		var channelSort logic.ChannelSort
		channelSort.SortType = channelGroup.SortType
		for _, rel := range channelGroup.Rels {
			channelSort.Channels = append(channelSort.Channels, rel.ChannelID)
			channelSort.Percent = append(channelSort.Percent, int(rel.Percent))
		}

		channelSortMatrix = append(channelSortMatrix, channelSort)
		recordChannelFlow = true
	}

	var deadLine time.Time
	_timeOut := time.Duration(customer.Timeout * uint(time.Second))
	if customer.SlowRechargeFlag {
		_timeOut = time.Duration(customer.SlowTimeout * uint(time.Minute))
	}

	// 是回调的时候重新分发的
	if currentChannel != 0 {
		deadLine = order.Created.Add(_timeOut)
	} else {
		deadLine = time.Now().Add(_timeOut)
	}

	logger.Log.Info("[ReDispatcher]",
		zap.Int64("orderID", orderID),
		zap.Time("deadLine", deadLine),
	)

	// 属于回调超时
	if time.Since(deadLine) > 0 && currentChannel != 0 {
		if err := partition.GlobalOrderPartition.ModifyStatus(session, order, constant.OrderStatusFail, map[string]any{
			"remark":      "超时 无渠道成功",
			"finish_time": time.Now().Local(),
		}); err != nil {
			logger.Log.Error("[Dispatcher] [ModifyStatus]", zap.Error(err), zap.Int64("order id", order.ID))
		}
		go NewOrderService(&ctx).OrderBackMoney(order)
		go PublishOrderStuck(order, constant.OrderStatusFail)
		if reDispatchType == 0 {
			go NewCallbackSvc(&ctx).Notify(order.ID, models.ChannelOrder{})
		}
		logger.Log.Info("[ReDispatcher] ", zap.Time("deadline", deadLine), zap.Time("now", time.Now()))
		return
	}

	var dispatcher *Dispatcher
	if dispatcher, err = NewDispatcher(customer, &order, customerProd, channelSortMatrix, deadLine, currentChannel, ctx); err != nil {
		logger.Log.Error("[ReDispatcher]",
			zap.Int64("orderID", orderID),
			zap.Error(err),
		)
		return
	}

	dispatcher.SendToBus(recordChannelFlow)
	return
}

func (dispatcher *Dispatcher) SubmitToChannel(channelProd models.ChannelProduct) (success bool, err error) {
	var channel models.Channel
	var has bool
	has, err = cache.FromModelPk(channel.TableName(), cache.ChannelPk(channelProd.ChannelID), &channel, cache.FromDatabaseGet)
	if err != nil {
		return
	}
	if !has {
		err = fmt.Errorf("%s", "channel not exist")
		return
	}
	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = session.Begin(); err != nil {
		return
	}
	channelOrder := models.NewChannelOrder(*dispatcher.orderModel, channel.ID, channelProd.ActualPrice, channelProd.Pcode)
	if channelOrder.ID, err = partition.GlobalChannelOrderPartition.NewID(session); err != nil {
		logger.Log.Error("[SubmitToChannel] [NewID]",
			zap.Int64("orderID", channelOrder.OrderID),
			zap.Error(err))
	}
	if err = partition.GlobalChannelOrderPartition.Create(session, &channelOrder); err != nil {
		logger.Log.Error("[Dispatcher] [SubmitToChannel] [Create]",
			zap.Int64("orderID", channelOrder.OrderID),
			zap.Error(err))
		session.Rollback()
		return
	}

	if err = partition.GlobalOrderPartition.UpdateCurrentChannel(session, dispatcher.orderModel.ID, channelProd.ChannelID, channelProd.ActualPrice); err != nil {
		logger.Log.Error("[Dispatcher] [SubmitToChannel] [UpdateCurrentChannel]",
			zap.Int64("orderID", channelOrder.OrderID),
			zap.Error(err))
		session.Rollback()
		return
	}
	session.Commit()
	go PublishChannelOrderStuck(channelOrder, int(channelOrder.Status))

	var submitter *Submitter
	if submitter, err = NewSubmitter(channel, channelOrder, dispatcher.ctx); err != nil {
		remark := append(channelOrder.Remark, models.RemarkRecord{
			RemarkTime: time.Now(),
			Remark:     "该渠道没有对应的渠道模版",
		})

		var remarkJSON []byte
		remarkJSON, err = json.Marshal(remark)
		if err != nil {
			return
		}

		session := daos.Mysql.NewSession()
		defer session.Close()

		partition.GlobalChannelOrderPartition.UpdateFields(session, channelOrder.ID, map[string]any{
			"remark": string(remarkJSON),
			"status": constant.OrderStatusFail,
		})
		return
	}
	success, err = submitter.Do()
	if err != nil {
		session := daos.Mysql.NewSession()
		defer session.Close()
		partition.GlobalChannelOrderPartition.UpdateFields(session, channelOrder.ID, map[string]any{
			"remark": string(err.Error()),
			"status": constant.OrderStatusFail,
		})
	}
	return
}
