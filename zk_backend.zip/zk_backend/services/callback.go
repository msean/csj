package services

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/services/cache"
	"application/template"
	"application/utils"
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type CallBackSvc struct {
	Ctx *echo.Context
}

func NewCallbackSvc(ctx *echo.Context) *CallBackSvc {
	return &CallBackSvc{
		Ctx: ctx,
	}
}

func (svc CallBackSvc) Receive(channelID int64) (err error) {
	var channel models.Channel
	var has bool
	// if channel, has, err = mysql.Channel.FromID(channelID); !has {
	// 	err = fmt.Errorf("channel not exist")
	// }

	has, err = cache.FromModelPk(models.Channel{}.TableName(), cache.ChannelPk(channelID), &channel, cache.FromDatabaseGet)
	if !has {
		err = fmt.Errorf("record not found")
	}
	if err != nil {
		return resp.Resp(*svc.Ctx, false, 500, "fail", nil)
	}

	tml, err := template.NewTemplate(&channel, template.Option{})
	if err != nil {
		logger.Log.Error("CallBackSvc Receive", zap.Int64("channel ID", channel.ID), zap.String("channel", channel.TemplateName), zap.Error(err))
		return
	}

	var receiveRsp resp.ClientOrderCallbackResult
	if receiveRsp, err = tml.ReceiveCallback(*svc.Ctx); err != nil {
		return
	}

	// 取消等待回调
	cancelWaitCallback := func() {
		var submitter *Submitter
		var in bool
		if in, submitter = GlobalCallbackBus.Get(receiveRsp.ChannelOrder.ID); in {
			go submitter.SendCallback()
		}
	}

	switch receiveRsp.Status {
	case constant.OrderReceiveCallbackSuccess:
		orderUpdate := make(map[string]any)
		if receiveRsp.Cert != "" {
			orderUpdate["voucher"] = receiveRsp.Cert
		}
		FeedBackChannelOrder(constant.OrderStatusSuccess, receiveRsp.ChannelOrder, *svc.Ctx, orderUpdate, orderUpdate)
		cancelWaitCallback()
		// svc.Notify(receiveRsp.ChannelOrder.OrderID, receiveRsp.ChannelOrder)

	case constant.OrderReceiveCallbackFail,
		constant.OrderReceiveCallbackNoCharge,
		constant.OrderReceiveCallbackTimeout,
		constant.OrderReceiveCallbackCancel:
		if channel.ManualProcess == 2 {
			FeedBackChannelOrder(constant.OrderStatusManual, receiveRsp.ChannelOrder, *svc.Ctx, nil, nil)
		} else {
			FeedBackChannelOrder(constant.OrderStatusFail, receiveRsp.ChannelOrder, *svc.Ctx, nil, nil)
		}
		cancelWaitCallback()
		// svc.Notify(receiveRsp.ChannelOrder.OrderID, receiveRsp.ChannelOrder)
	default:
	}
	return
}

func (svc CallBackSvc) Notify(orderID int64, channelOrder models.ChannelOrder) (err error) {
	var order models.Order
	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()

	order, has, err = partition.GlobalOrderPartition.FromID(session, orderID)
	if !has {
		err = fmt.Errorf("object not found")
	}
	if err != nil {
		logger.Log.Error("[Notify] [Notify]", zap.Error(err))
		return
	}

	if order.Status == constant.OrderStatusFail {
		FailOrderAddBlacklist(order.Phone, utils.Violent2String(order.ID))
	}

	// 手动提的单 回调个毛线哦
	if order.BackUrl == "" {
		if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifySuccess, "手动提单 回调成功"); updateSqlErr != nil {
			logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
		}
		return
	}

	// 当天
	// if len(order.BackTime) == 0 && order.Status == constant.OrderStatusFail {
	// 	var sysArg models.SysArgConfig
	// 	sysArg, _, _ = mysql.SysArgConfig.FromKey("blackphone.number")
	// 	if sysArg.ID != 0 {
	// 		maxDayFailCount, _ := strconv.Atoi(sysArg.Value)
	// 		now := time.Now()
	// 		dayFailOrders, _, _ := mysql.Order.List(vo.OrderListParam{
	// 			PhoneSearch: order.Phone,
	// 			Base: utils.LimitCond{
	// 				StartTime: time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location()),
	// 			},
	// 			StatusChoice: constant.OrderStatusFail,
	// 		})
	// 		if maxDayFailCount > len(dayFailOrders) {
	// 			daos.CreateObjs(daos.Mysql.NewSession(), models.Blacklist{
	// 				Phone:  order.Phone,
	// 				Remark: fmt.Sprintf("失败次数超限:%d", maxDayFailCount),
	// 			})
	// 		}
	// 	}
	// }

	var customer models.Customer
	if has, err = cache.FromModelPk(models.Customer{}.TableName(), cache.CustomerPk(order.CustomerID), &customer, cache.FromDatabaseGet); !has || err != nil {
		logger.Log.Error("[Notify]", zap.Error(err), zap.Bool("customer has", has))
		return
	}

	params := map[string]string{
		"szAgentId":  utils.Violent2String(customer.ID),
		"szOrderId":  utils.Violent2String(order.CustomerOrderID),
		"szPhoneNum": order.Phone,
		"nDemo":      utils.Violent2String(order.FaceValue),
		"fSalePrice": utils.Violent2String(order.SalePrice),
		"szRtnMsg":   order.Voucher,
	}
	switch order.Status {
	case constant.OrderStatusSuccess:
		params["nFlag"] = utils.Violent2String(2)
	case constant.OrderStatusFail:
		params["nFlag"] = utils.Violent2String(3)

	default:
		logger.Log.Error("[CallBackSvc]", zap.Uint("order.Status", order.Status))
		return
	}

	sign := utils.Md5KvArray([][2]any{
		{"szAgentId", params["szAgentId"]},
		{"szOrderId", params["szOrderId"]},
		{"szPhoneNum", params["szPhoneNum"]},
		{"nDemo", params["nDemo"]},
		{"fSalePrice", params["fSalePrice"]},
		{"nFlag", params["nFlag"]},
		{"szKey", customer.ApiKey},
	}, "&")

	if customer.CallbackType != constant.CUSTOMER_CALLBACK_TYPE_NO_KEY {
		params["szRtnMsg"] = order.Voucher
	}
	params["szVerifyString"] = sign

	switch int(customer.CallbackType) {
	case constant.CUSTOMER_CALLBACK_TYPE_DEFAULT, 0: // 默认
		var body []byte
		var httpCode int
		httpCode, body, err = utils.NewRequest().Params(params).PostForm().Url(order.BackUrl).Do()

		if err != nil {
			logger.Log.Error("[CallBackSvc] [Receive] PostForm", zap.Int64("orderID", order.ID), zap.Error(err))
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifyFail, fmt.Sprintf("回调通知异常: %s", err.Error())); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
			return
		}

		if httpCode == http.StatusOK {
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifySuccess, string(body)); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
		}
	case constant.CUSTOMER_CALLBACK_TYPE_JSON: // "json"
		var payload []byte

		if payload, err = json.Marshal(params); err != nil {
			logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(err))
			return
		}

		var body []byte
		var httpCode int
		if httpCode, body, err = utils.NewRequest().Payload(payload).Post().Url(order.BackUrl).Do(); err != nil {
			logger.Log.Error("[CallBackSvc] [Receive] Post", zap.Int64("orderID", order.ID), zap.Error(err))
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifyFail, fmt.Sprintf("回调通知异常: %s", err.Error())); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
			return
		}
		if httpCode == http.StatusOK {
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifySuccess, string(body)); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
		}
	case constant.CUSTOMER_CALLBACK_TYPE_GET: //  get方式
		var httpCode int
		var body []byte
		if httpCode, body, err = utils.NewRequest().Get().Params(params).Url(order.BackUrl).Do(); err != nil {
			logger.Log.Error("[CallBackSvc] [Receive] Get", zap.Int64("orderID", order.ID), zap.Error(err))
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifyFail, fmt.Sprintf("回调通知异常: %s", err.Error())); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
			return
		}
		if httpCode == http.StatusOK {
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifySuccess, string(body)); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
		}
	case constant.CUSTOMER_CALLBACK_TYPE_NO: // // 不回调
		if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifySuccess, "不回调"); updateSqlErr != nil {
			logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
		}
	case constant.CUSTOMER_CALLBACK_TYPE_NO_KEY: // 无凭证
		var body []byte
		var httpCode int
		if httpCode, body, err = utils.NewRequest().Params(params).PostForm().Url(order.BackUrl).Do(); err != nil {
			logger.Log.Error("[CallBackSvc] [Receive] PostForm", zap.Int64("orderID", order.ID), zap.Error(err))
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifyFail, fmt.Sprintf("回调通知异常: %s", err.Error())); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
			return
		}
		if httpCode == http.StatusOK {
			if updateSqlErr := partition.GlobalOrderPartition.UpdateCallback(session, order, channelOrder, constant.OrderNotifySuccess, string(body)); updateSqlErr != nil {
				logger.Log.Error("[CallBackSvc] [Receive] updateCallback", zap.Int64("orderID", order.ID), zap.Error(updateSqlErr))
			}
		}
	}
	return
}

func (svc CallBackSvc) NotifyOrderList(orderIDList []int64) (err error) {
	for _, orderID := range orderIDList {
		go func() { svc.Notify(orderID, models.ChannelOrder{}) }()
	}
	return
}

func ComposeCallback(order models.Order, customer models.Customer) map[string]string {
	params := map[string]string{
		"szAgentId":  utils.Violent2String(customer.ID),
		"szOrderId":  utils.Violent2String(order.CustomerOrderID),
		"szPhoneNum": order.Phone,
		"nDemo":      utils.Violent2String(order.FaceValue),
		"fSalePrice": utils.Violent2String(order.SalePrice),
		"szRtnMsg":   order.Voucher,
	}
	switch order.Status {
	case constant.OrderStatusSuccess:
		params["nFlag"] = utils.Violent2String(2)
	case constant.OrderStatusFail:
		params["nFlag"] = utils.Violent2String(3)
	}

	sign := utils.Md5KvArray([][2]any{
		{"szAgentId", params["szAgentId"]},
		{"szOrderId", params["szOrderId"]},
		{"szPhoneNum", params["szPhoneNum"]},
		{"nDemo", params["nDemo"]},
		{"fSalePrice", params["fSalePrice"]},
		{"nFlag", params["nFlag"]},
		{"szKey", customer.ApiKey},
	}, "&")

	if customer.CallbackType != constant.CUSTOMER_CALLBACK_TYPE_NO_KEY {
		params["szRtnMsg"] = order.Voucher
	}
	params["szVerifyString"] = sign
	return params
}
