package services

import (
	"application/common/logger"
	"application/conf"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services/cache"
	"application/utils"
	"fmt"
	"strconv"
	"time"

	"github.com/go-xorm/xorm"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type DelayTaskSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewDelayTaskSrv(ctx *echo.Context) *DelayTaskSrv {
	bean := &DelayTaskSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func Add2DelayScheduler(
	delayTask models.DelayTask,
	toStorage bool,
	extraDoneFuncList ...func()) (err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	if toStorage {
		if _, err = daos.CreateObjs(session, &delayTask); err != nil {
			logger.Log.Error("[DelayTask] add", zap.Error(err))
		}
	}

	delayFunc := func() (err error) {
		_, err = daos.Mysql.Exec(delayTask.Sql)
		return
	}

	doneFunc := func() {
		session := daos.Mysql.NewSession()
		defer session.Close()
		if _, err = utils.Update(session.Table(models.DelayTask{}.TableName()), map[string]any{
			"status": 2,
		}, utils.NewWhereCond("id", delayTask.ID)); err != nil {
			logger.Log.Info("[Add2DelayScheduler] [doneFunc]", zap.Int64("id", delayTask.ID))
		}
		// if _, delObjErr := daos.DelObjs(session, []int64{delayTask.ID}, &models.DelayTask{}); delObjErr != nil {
		// }
		for _, extraFunc := range extraDoneFuncList {
			extraFunc()
		}
	}

	DelayTaskScheduler.Add(utils.NewDelayTask(delayTask.ExecTime, delayFunc, doneFunc), delayTask.ID)
	return
}

func DelayDelBlackList(blackList models.Blacklist) {

	if blackList.Type == 1 {
		return
	}

	var cfg models.SysArgConfig
	var has bool
	restriction := 24 * 60
	var err error

	if cfg, has, err = cache.SysCfgFromKey("xj_blacklist_restrictions"); err == nil && has {
		if i, err := strconv.ParseInt(cfg.Value, 10, 64); err == nil {
			restriction = int(i)
		}
	}
	if !has {
		session := daos.Mysql.NewSession()
		defer session.Close()
		daos.CreateObjs(session, models.SysArgConfig{
			Name:   "解除临时黑名单限制时间",
			Key:    "xj_blacklist_restrictions",
			Value:  utils.Violent2String(24 * 60),
			Typ:    1,
			Remark: "单位：分钟",
		})
	}
	sql := fmt.Sprintf(`UPDATE xj_blacklist SET deleted = NOW() WHERE id = %d and type=2;`, blackList.ID)

	var execTime time.Time
	if !blackList.Created.IsZero() {
		elapsedMinutes := time.Since(blackList.Created).Minutes()

		remainingDuration := time.Duration(restriction)*time.Minute - time.Duration(elapsedMinutes)*time.Minute
		execTime = time.Now().Add(remainingDuration)
	} else {
		execTime = time.Now().Add(time.Duration(restriction) * time.Minute)
	}

	delayTask := models.DelayTask{
		Table:    blackList.TableName(),
		Pk:       blackList.Phone,
		Sql:      sql,
		ExecTime: execTime,
	}
	delayTask.Mutate()

	session := daos.Mysql.NewSession()
	defer session.Close()
	Add2DelayScheduler(delayTask, true, BlacklistDelDone(session, blackList)...)
}

func DelayTaskExec() {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var tasks []models.DelayTask
	// 查找所有的未执行的延时函数
	if err := utils.Find(session, &tasks, utils.NewWhereCond("status", 3)); err != nil {
		panic(err)
	}

	var err error
	var has bool

	for _, task := range tasks {
		switch task.Table {
		case models.Blacklist{}.TableName():
			var blackList models.Blacklist
			has, err = daos.GetRecordByField(session, task.Table, &blackList, utils.NewWhereCond("phone", task.Pk))
			if err != nil {
				logger.Log.Error("DelayTaskExec GetRecordByField", zap.Error(err))
			}
			if !has {
				daos.DelObjs(session, []int64{task.ID}, &models.DelayTask{})
			} else {
				Add2DelayScheduler(task, false, BlacklistDelDone(session, blackList)...)
			}
		case models.ChannelProduct{}.TableName():
			Add2DelayScheduler(task, false,
				func() {
					var err error
					var id int64
					if id, err = strconv.ParseInt(task.Pk, 10, 64); err != nil {
						return
					}
					if err = cache.CacheChannelProduct(id); err != nil {
						cache.DelCacheChannelProduct(id)
					}
				})
		case models.CustomerProduct{}.TableName():
			Add2DelayScheduler(task, false,
				func() {
					var err error
					var id int64
					if id, err = strconv.ParseInt(task.Pk, 10, 64); err != nil {
						return
					}
					cache.OprCustomerProductCache([]int64{id}, 1)
				})
		default:
			Add2DelayScheduler(task, false)
		}
	}
}

func BlacklistDelDone(session *xorm.Session, blacklist models.Blacklist) []func() {
	doneFunc1 := func() {
		cache.DeleteFromSetCache(blacklist.TableName(), cache.BlacklistObj(blacklist))
	}
	doneFunc2 := func() {

		setCacheKey := fmt.Sprintf("order_fail:%s", blacklist.Phone)
		cache.DeleteFromSetKey(setCacheKey)
		// var has bool
		// var err error
		// has, err = daos.Exist(session, &models.BlacklistRestriction{}, 0, map[string]any{
		// 	"phone": blacklist.Phone,
		// })
		// if err != nil {
		// 	return
		// }
		// if !has {
		// 	daos.CreateObjs(session, &models.BlacklistRestriction{
		// 		Phone:                 blacklist.Phone,
		// 		LatestRestrictionTime: time.Now(),
		// 	})
		// } else {
		// 	utils.Update(session.Table(models.BlacklistRestriction{}.TableName()), map[string]any{
		// 		"r_time": time.Now(),
		// 	}, utils.NewWhereCond("phone", blacklist.Phone))
		// }
	}
	return []func(){doneFunc1, doneFunc2}
}

func DelDelayTask(session *xorm.Session, table, pk string) (err error) {
	query := "UPDATE xj_delay_task SET deleted = ? WHERE pk = ? AND `table` = ? AND (deleted IS NULL OR deleted = ?)"
	_, err = session.Exec(query, time.Now(), pk, table, "0001-01-01 00:00:00")
	return
}

func (srv *DelayTaskSrv) List(params vo.DelayTaskListParams) (delayTasks []resp.DelayListRsp, total int64, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("DelayTaskSrv List", zap.Any("params", params), zap.Error(err))
		}
	}()

	var delayModels []models.DelayTask
	conditions := []utils.Cond{}

	if params.TypeSearch != 0 {
		switch params.TypeSearch {
		case 1:
			conditions = append(conditions, utils.NewBaseCond(fmt.Sprintf("`table`='%s'", models.CustomerProduct{}.TableName())))
		case 2:
			conditions = append(conditions, utils.NewBaseCond(fmt.Sprintf("`table`='%s'", models.ChannelProduct{}.TableName())))
		}
	} else {
		conditions = append(conditions, utils.NewBaseCond(fmt.Sprintf("`table`='%s' or `table`='%s'", models.CustomerProduct{}.TableName(), models.ChannelProduct{}.TableName())))
	}

	if params.StatusSearch != 0 {
		conditions = append(conditions, utils.NewWhereCond("status", params.StatusSearch))
	}

	if !params.ExecTimePicker.StartTime.IsZero() {
		conditions = append(conditions, utils.NewCmpCond("exec_time", ">=", params.ExecTimePicker.StartTime))
	}

	if !params.ExecTimePicker.EndTime.IsZero() {
		conditions = append(conditions, utils.NewCmpCond("exec_time", "<=", params.ExecTimePicker.EndTime))
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, pl := utils.MutateLimitCond(params.Base)

	if total, err = utils.TotalByConds(session, new(models.DelayTask), conditions...); err != nil {
		return
	}

	conditions = append(conditions, pl)

	if err = utils.Find(session, &delayModels, conditions...); err != nil {
		return
	}

	_typeMapper := map[string]int{
		models.CustomerProduct{}.TableName(): 1,
		models.ChannelProduct{}.TableName():  2,
	}

	var createdByList []int64
	for _, model := range delayModels {
		createdByList = append(createdByList, model.CreateBy)
	}

	userMapper, _ := mysql.User.UserMapper(createdByList)

	for _, model := range delayModels {
		delayTasks = append(delayTasks, resp.DelayListRsp{
			ID:        model.ID,
			Type:      _typeMapper[model.Table],
			Remark:    model.Remark,
			ExecTime:  model.ExecTime,
			CreatedBy: userMapper[model.CreateBy].Username,
			Status:    model.Status,
		})
	}
	return
}

func (srv *DelayTaskSrv) Delete(params vo.DeleteParams) (err error) {
	var delayTasks []models.DelayTask

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = utils.Find(session, &delayTasks, utils.NewInCond("id", params.IDList)); err != nil {
		return
	}

	for _, task := range delayTasks {
		if task.Status != 2 {
			DelayTaskScheduler.Delete(task.ID)
		}
	}

	daos.DelObjs(session, params.IDList, &models.DelayTask{})
	return
}

func (srv *DelayTaskSrv) Update(params vo.DelayTaskUpdateParams) (err error) {
	var _storage models.DelayTask
	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()

	if has, err = utils.Get(session, &_storage, utils.NewWhereCond("id", params.ID)); err != nil {
		return
	}

	if !has {
		return fmt.Errorf("Record not found")
	}

	if _storage.Status == 1 && params.ExecTime.Before(time.Now()) && params.Status != 1 {
		params.Status = 2
	}

	// newTask := models.DelayTask{
	// 	Table:    _storage.Table,
	// 	Pk:       _storage.Pk,
	// 	Sql:      _storage.Sql,
	// 	ExecTime: params.ExecTime,
	// 	Remark:   params.Remark,
	// 	Annul:    params.Status,
	// }

	// 作废 -> 再度执行
	if _storage.Status == 1 && params.Status == 3 && params.ExecTime.After(time.Now()) {
		var schedulerTask *utils.DelayTask
		var exist bool
		if exist, schedulerTask = DelayTaskScheduler.Get(_storage.ID); !exist {
			return
		}
		DelayTaskScheduler.Add(utils.NewDelayTask(params.ExecTime, schedulerTask.Exec, schedulerTask.Done), _storage.ID)
	}

	if _storage.Status == 2 && params.Status != 1 {
		return fmt.Errorf("已执行的不能再修改状态")
	}

	if _storage.Status == 3 && params.Status == 2 {
		return fmt.Errorf("不能将未执行状态直接修改成已执行")
	}

	// 未执行 -> 作废
	if _storage.Status == 3 && params.Status == 1 {
		DelayTaskScheduler.Discard(_storage.ID)
	}

	_, err = utils.Update(session, map[string]any{
		"exec_time": params.ExecTime,
		"remark":    params.Remark,
		"status":    params.Status,
	}, utils.IDCond(_storage.ID))

	return
}

func (srv *DelayTaskSrv) Export(params vo.DelayTaskListParams) (filePath string, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[DelayTaskSrv] [Export]", zap.Any("params", params), zap.Error(err))
		}
	}()

	filePath = fmt.Sprintf("%d_定时任务.xlsx", time.Now().Unix())

	var objs []resp.DelayListRsp
	if objs, _, err = srv.List(params); err != nil {
		return
	}

	statusMapper := map[int]string{
		1: "作废", 2: "已经执行", 3: "未执行",
	}

	typeMapper := map[int]string{
		1: "客户", 2: "渠道",
	}

	exportObjs := make([]models.ExportDelayTask, 0, len(objs))

	for _, obj := range objs {
		exportObjs = append(exportObjs, models.ExportDelayTask{
			ID:        obj.ID,
			Type:      typeMapper[obj.Type],
			Remark:    obj.Remark,
			ExecTime:  obj.ExecTime,
			CreatedBy: obj.CreatedBy,
			Status:    statusMapper[obj.Status],
		})
	}

	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", exportObjs, mysql.SysDict.DataValueLabelMapper())
	return
}
