package services

import (
	"application/conf"
	"application/constant"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/services/ws"
	"application/utils"
	"errors"
	"fmt"
	"math"

	"github.com/go-xorm/xorm"
	"github.com/labstack/echo"
)

type CustomerService struct {
	Ctx  *echo.Context
	Uuid string
}

func (s *CustomerService) makeCustomerVo(obj *models.Customer) *vo.CustomerVo {
	return &vo.CustomerVo{
		ID:                obj.ID,
		UserID:            obj.UserID,
		Account:           obj.Account,
		ApiKey:            obj.ApiKey,
		Name:              obj.Name,
		ShortName:         obj.ShortName,
		Balance:           obj.Balance,
		TotalBalance:      obj.TotalBalance,
		RechargeAmount:    obj.RechargeAmount,
		PayAmount:         obj.PayAmount,
		Credit:            obj.Credit,
		WarnBalance:       obj.WarnBalance,
		Timeout:           obj.Timeout,
		SlowTimeout:       obj.SlowTimeout,
		SlowRechargeFlag:  obj.SlowRechargeFlag,
		SlowCycleFlag:     obj.SlowCycleFlag,
		AllProductFlag:    obj.AllProductFlag,
		OperatorQueryFlag: obj.OperatorQueryFlag,
		SwitchCheckFlag:   obj.SwitchCheckFlag,
		AreaFlag:          obj.AreaFlag,
		ApiFlag:           obj.ApiFlag,
		RechargeFlag:      obj.RechargeFlag,
		Detail:            obj.Detail,
		Extra:             obj.Extra,
		MaxOrder:          obj.MaxOrder,
		MaxPendingOrder:   obj.MaxPendingOrder,
		RepeatTimeout:     obj.RepeatTimeout,
		CallbackType:      obj.CallbackType,
		Ip:                obj.Ip,
		Available:         obj.Available,
		Created:           obj.Created,
	}
}

func (s *CustomerService) makeCustomerOtherVo(obj *models.Customer, isCheck bool) *vo.CustomerOtherVo {
	data := &vo.CustomerOtherVo{
		OrderURL:   conf.Config().Url.Order,
		CheckURL:   conf.Config().Url.Check,
		BalanceURL: conf.Config().Url.Balance,
	}

	if isCheck {
		data.CustomerID = obj.ID
		data.CustomerKey = obj.ApiKey
		data.IPWhitelist = obj.Ip
	}
	return data
}

func (s *CustomerService) checkPassword(id int64, password string) (*models.Customer, bool, error) {
	customer, err := mysql.Customer.GetBeanById(id)
	if err != nil {
		return nil, false, errors.New("find customer failed, " + err.Error())
	}

	user, err := mysql.User.GetBeanById(customer.UserID)
	if err != nil {
		return nil, false, errors.New("find user failed, " + err.Error())
	}

	isCheck := false
	if password != "" {
		isCheck = utils.CheckPassword(password, user.Password)
	}

	return customer, isCheck, nil
}

/*func (s *CustomerService) updateCustomerTimeout(customer *models.Customer, params vo.CustomerTimeoutParam) *models.Customer {
    customer.Timeout = params.Timeout
    customer.SlowTimeout = params.SlowTimeout
    return customer
}

func (s *CustomerService) updateCustomerFlag(customer *models.Customer, params vo.CustomerFlagParam) *models.Customer {
    customer.SlowRechargeFlag = params.SlowRechargeFlag
    customer.SlowCycleFlag = params.SlowCycleFlag
    customer.AllProductFlag = params.AllProductFlag
    customer.OperatorQueryFlag = params.OperatorQueryFlag
    customer.SwitchCheckFlag = params.SwitchCheckFlag
    customer.AreaFlag = params.AreaFlag
    customer.ApiFlag = params.ApiFlag
    customer.RechargeFlag = params.RechargeFlag
    return customer
}*/

func (s *CustomerService) updateCustomer(customer *models.Customer, params vo.CustomerUpdateParam) *models.Customer {
	// customer.Key = utils.Md5S(fmt.Sprintf("%s_%d_%d", customer.Name, time.Now().UnixNano(), utils.RandomByNow()))
	p0 := params.Base
	if p0 != nil {
		customer.Name = p0.Name
		customer.ShortName = p0.ShortName
		customer.Credit = p0.Credit
		// customer.ApiKey = p0.ApiKey
		customer.Ip = p0.Ip
		customer.CallbackType = p0.CallbackType
		customer.MaxOrder = p0.MaxOrder
		customer.MaxPendingOrder = p0.MaxPendingOrder
		customer.WarnBalance = p0.WarnBalance
		customer.RepeatTimeout = p0.RepeatTimeout
		customer.Extra = p0.Extra
		customer.Detail = p0.Detail
		customer.Available = p0.Available
	}

	p1 := params.Timeout
	if p1 != nil {
		customer.Timeout = p1.Timeout
		customer.SlowTimeout = p1.SlowTimeout
	}

	p2 := params.Flag
	if p2 != nil {
		customer.SlowRechargeFlag = p2.SlowRechargeFlag
		customer.SlowCycleFlag = p2.SlowCycleFlag
		customer.AllProductFlag = p2.AllProductFlag
		customer.OperatorQueryFlag = p2.OperatorQueryFlag
		customer.SwitchCheckFlag = p2.SwitchCheckFlag
		customer.AreaFlag = p2.AreaFlag
		customer.ApiFlag = p2.ApiFlag
		customer.RechargeFlag = p2.RechargeFlag
	}

	if params.ApiKey != "" {
		customer.ApiKey = params.ApiKey
	}

	return customer
}

func NewCustomerService(ctx *echo.Context) *CustomerService {
	bean := &CustomerService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (s *CustomerService) FromID(customerID int64) (customer models.Customer, has bool, err error) {
	return mysql.Customer.FromID(customerID)
}

func (s *CustomerService) CheckParams(params vo.CustomerParam) error {
	// todo: check params ----------------------------
	return nil
}

func (s *CustomerService) FindCustomer(id int64) (*models.Customer, error) {
	obj, err := mysql.Customer.GetBeanById(id)
	if err != nil || obj == nil {
		return nil, err
	}

	return obj, nil
}

func (s *CustomerService) QueryCustomer(params vo.CustomerQueryParam) (*vo.CustomerQueryRes, error) {
	count, customers, err := mysql.Customer.QueryCustomer(params)
	if err != nil {
		return nil, err
	}

	sums, err := mysql.Customer.Sum()
	if err != nil {
		return nil, errors.New("sum customer failed, " + err.Error())
	}

	data := make([]*vo.CustomerVo, 0)
	if count > 0 {
		for _, obj := range customers {
			data = append(data, s.makeCustomerVo(obj))
		}
	}

	return &vo.CustomerQueryRes{
		TotalBalance:         sums[0],
		TotalRechargeBalance: sums[1],
		Warning:              NewServiceCache().CustomerWarning(),
		Count:                count,
		Customers:            data,
	}, nil
}

func (s *CustomerService) CreateCustomer(db *xorm.Session, params vo.CustomerParam, userID int64) (*models.Customer, error) {
	customer := &models.Customer{UserID: userID, Account: params.Account, Name: params.Name, ApiKey: params.ApiKey}
	err := mysql.Customer.InsertBean(db, utils.UserId(*s.Ctx), s.updateCustomer(customer, vo.CustomerUpdateParam{Base: &params,
		Timeout: &vo.CustomerTimeoutParam{Timeout: constant.CUSTOMER_DEFAULT_TIMEOUT, SlowTimeout: constant.CUSTOMER_DEFAULT_SLOW_TIMEOUT},
		Flag:    &vo.CustomerFlagParam{ApiFlag: true}}))
	if err != nil {
		return nil, err
	}

	return customer, nil
}

func (s *CustomerService) UpdateCustomer(db *xorm.Session, id int64, params vo.CustomerUpdateParam) (*models.Customer, error) {
	customer, err := mysql.Customer.GetBeanById(id)
	if err != nil {
		return nil, errors.New("find error, " + err.Error())
	}

	if params.Base != nil && params.Base.Name != "" && customer.Name != params.Base.Name {
		_, err = mysql.CustomerProduct.UpdateCustomerNameByID(db, customer.ID, params.Base.Name)
		if err != nil {
			return nil, errors.New(fmt.Sprintf("update product customer name error, " + err.Error()))
		}
	}

	err = mysql.Customer.UpdateBean(db, utils.UserId(*s.Ctx), s.updateCustomer(customer, params))
	if err != nil {
		return nil, errors.New(fmt.Sprintf("update error, " + err.Error()))
	}

	return customer, nil
}

func (s *CustomerService) RemoveCustomer(db *xorm.Session, customerIDs []int64) (int64, error) {
	count, err := mysql.Customer.DeleteBeanByIds(db, customerIDs)
	if err != nil {
		return 0, errors.New("delete error, " + err.Error())
	}

	if count <= 0 {
		return 0, errors.New("can't find")
	}

	return count, nil
}

func (s *CustomerService) UpdateBalance(session *xorm.Session, customerID int64, rechargeAmount float64, amount float64, isRecharging bool, isFinish bool) (*models.Customer, error) {
	customer, err := mysql.Customer.GetBeanById(customerID)
	if err != nil {
		return nil, errors.New("can't find customer")
	}

	// amount < 0: reduce balance; amount > 0: increase balance
	balance := customer.TotalBalance + amount
	if (balance + customer.Credit) < 0 {
		return nil, errors.New("insufficient balance")
	}

	if isRecharging {
		if isFinish {
			customer.RechargeAmount -= math.Abs(rechargeAmount)
			customer.PayAmount -= math.Abs(amount)
		} else {
			customer.RechargeAmount += math.Abs(rechargeAmount)
			customer.PayAmount += math.Abs(amount)
		}
	}

	// recharge success, keep balance
	if !(isRecharging && isFinish && amount < 0) {
		customer.TotalBalance = balance
	}

	customer.Balance = customer.TotalBalance + customer.PayAmount
	// daos.UpdateColsWithVersion()
	if _, err = session.Table(models.Customer{}.TableName()).Where("id=?", customer.ID).Cols("total_balance", "recharge_amount", "pay_amount", "balance").Update(map[string]any{
		"total_balance":   customer.TotalBalance,
		"recharge_amount": customer.RechargeAmount,
		"pay_amount":      customer.PayAmount,
		"balance":         customer.Balance,
	}); err != nil {
		return nil, errors.New("update balance failed, " + err.Error())
	}
	// err = mysql.Customer.UpdateBean(session, utils.UserId(*s.Ctx), customer)
	// if err != nil {
	// 	return nil, errors.New("update balance failed, " + err.Error())
	// }
	ws.FinanceWsManager.SendFinanceInfo(customerID, customer.Balance, customer.Credit)
	return customer, nil
}

func (s *CustomerService) UpdateWhitelist(id int64, password string, whitelist string) (*vo.CustomerOtherVo, error) {
	customer, isCheck, err := s.checkPassword(id, password)
	if err != nil {
		return nil, err
	}

	if !isCheck {
		return nil, errors.New("invalid operate")
	}

	customer.Ip = whitelist
	if err = mysql.Customer.UpdateBean(nil, utils.UserId(*s.Ctx), customer); err != nil {
		return nil, errors.New("update error, " + err.Error())
	}

	return s.makeCustomerOtherVo(customer, true), nil
}

func (s *CustomerService) QueryOther(customerID int64, password string) (*vo.CustomerOtherVo, error) {
	customer, isCheck, err := s.checkPassword(customerID, password)
	if err != nil {
		return nil, err
	}

	return s.makeCustomerOtherVo(customer, isCheck), nil
}
