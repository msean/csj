package services

import (
	"application/common/logger"
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services/cache"
	"application/template"
	"application/utils"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	ChannelOrderSvc struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewChannelOrderService(ctx *echo.Context) *ChannelOrderSvc {
	bean := &ChannelOrderSvc{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (svc *ChannelOrderSvc) List(param vo.ChannelOrderListParam) (rsp []resp.ChannelOrderRsp, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelOrderSvc] [List]", zap.Any("param", param), zap.Error(err))
		}
	}()

	customerID := utils.CustomerID(*svc.Ctx)
	isSuper := utils.IsSuperAdmin(*svc.Ctx)
	if !isSuper {
		if customerID != 0 {
			param.CustomerChoice = customerID
		}
	}

	var orderModels []models.ChannelOrder
	if orderModels, total, err = partition.GlobalChannelOrderPartition.List(param); err != nil {
		return
	}

	var customerIDList []int64
	var ProductCodeList []string
	var channelIDList []int64
	for _, orderModel := range orderModels {
		customerIDList = append(customerIDList, orderModel.CustomerID)
		ProductCodeList = append(ProductCodeList, orderModel.ProductCode)
		channelIDList = append(channelIDList, orderModel.ChannelID)
	}

	customerM, _ := mysql.Customer.FromIDList(utils.DedupeInt64Slice(customerIDList))
	productM, _ := mysql.Product.FromCodes(utils.DedupeStringSlice(ProductCodeList))
	channelM, _ := mysql.Channel.FromIDList(utils.DedupeInt64Slice(channelIDList))

	for _, orderModel := range orderModels {
		rsp = append(rsp, svc.Fill(orderModel, customerM[orderModel.CustomerID], productM[orderModel.ProductCode], channelM[orderModel.ChannelID]))
	}
	return
}

func (svc *ChannelOrderSvc) Fill(
	orderModel models.ChannelOrder,
	customer models.Customer,
	product models.Product,
	channel models.Channel,
) (orderRsp resp.ChannelOrderRsp) {
	var take string
	if orderModel.Status == constant.OrderStatusFail || orderModel.Status == constant.OrderStatusManual || orderModel.Status == constant.OrderStatusNoResult || orderModel.Status == constant.OrderStatusSuccess {
		take = utils.TimeSubString(orderModel.FinishTime, orderModel.Created)
	} else {
		take = utils.TimeSubString(time.Now(), orderModel.Created)
	}

	// remark := orderModel.Remark
	// remark = append(remark, models.RemarkRecord{
	// 	Remark: orderModel.ChannelMsg,
	// })
	orderRsp = resp.ChannelOrderRsp{
		ID:           orderModel.ID,
		OrderID:      orderModel.OrderID,
		Customer:     customer.Name,
		Phone:        orderModel.Phone,
		Area:         orderModel.Area,
		Product:      product.Name,
		ChannelName:  channel.Name,
		Isp:          int64(orderModel.Isp),
		OrderStatus:  orderModel.Status,
		Created:      orderModel.Created,
		Voucher:      orderModel.Voucher,
		Remark:       orderModel.Remark,
		FaceValue:    orderModel.FaceValue,
		Province:     orderModel.Province,
		CustomerTime: orderModel.OrderTime,
		VoucherType:  orderModel.VoucherType,
		Take:         take,
	}
	return
}

func (svc *ChannelOrderSvc) UpdateIsp(param vo.ChannelOrderUpdateIspParam) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[OrderService] [UpdateIsp]", zap.Any("param", param), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = session.Begin(); err != nil {
		return
	}

	if err = partition.GlobalOrderPartition.UpdateIsp(session, param.OrderID, param.Isp); err != nil {
		session.Rollback()
		return
	}

	if err = partition.GlobalOrderPartition.UpdateIsp(session, param.ChannelOrderID, param.Isp); err != nil {
		session.Rollback()
		return
	}

	session.Commit()

	return
}

func (svc *ChannelOrderSvc) ManualSuccess(param vo.ChannelOrderManualSuccessParam) (err error) {

	logger.Log.Info("[ChannelOrderSvc] [ManualSuccess]", zap.Any("param", param), zap.String("operator", svc.Uuid))

	for _, item := range param.Items {
		func() (funcErr error) {
			defer func() {
				if funcErr != nil {
					logger.Log.Error("[ChannelOrderSvc] [ManualSuccess] [in function]", zap.Int64("channelOrderID", item.ChannelOrderID), zap.Error(err))
				}
			}()

			svc.ManualSuccessByChannelOrderID(item.ChannelOrderID, map[string]any{
				"voucher": item.Remark,
				"remark":  "人工手动处理成功",
			}, map[string]any{
				"voucher": item.Remark,
				"remark":  "人工手动处理成功",
			})
			return
		}()

	}
	return
}

func (svc *ChannelOrderSvc) UpdateRemark(param vo.ChannelOrderUpdateRemarkParam) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelOrderSvc] [UpdateManualRemark]", zap.Any("param", param), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	return partition.GlobalChannelOrderPartition.UpdateRemark(session, param.ID, param.Remark)
}

func (svc *ChannelOrderSvc) ManualFail(param vo.ChannelOrderModifyFailParam) (err error) {

	logger.Log.Info("[ChannelOrderSvc] [ManualFail]", zap.Any("param", param))

	for _, item := range param.Items {
		func() (funcErr error) {
			defer func() {
				if funcErr != nil {
					logger.Log.Error("[ChannelOrderSvc] [ManualFail] [in function]", zap.Int64("channelOrderID", item.ChannelOrderID), zap.Error(err))
				}
			}()

			updates := make(map[string]any)
			if !utils.IsBlankString(item.Remark) {
				updates = map[string]any{
					"remark": item.Remark,
				}
			}
			svc.ManualFailByChannelID(item.ChannelOrderID, updates, updates, true)
			return
		}()
	}
	return
}

func (svc *ChannelOrderSvc) ManualFailByChannelID(channelOrderID int64, extraChannelOrderUpdate, extraOrderUpdate map[string]any, reDispatch bool) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelOrderSvc] [ManualFailByChannelID]", zap.Int64("channelOrderID", channelOrderID), zap.Error(err))
		}
	}()
	var channelOrder models.ChannelOrder
	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()

	channelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has {
		err = errors.New("record not found")
	}
	return NewChannelOrderService(svc.Ctx).Fail(channelOrder, extraChannelOrderUpdate, extraOrderUpdate, 1, reDispatch)
}

func (svc *ChannelOrderSvc) ManualSuccessByChannelOrderID(channelOrderID int64, extraChannelOrderUpdate, extraOrderUpdate map[string]any) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelOrderSvc] [ManualSuccessByChannelOrderID]", zap.Int64("channelOrderID", channelOrderID), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	var has bool
	var channelOrder models.ChannelOrder
	channelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has {
		err = errors.New("record not found")
	}

	if channelOrder.Status == constant.OrderStatusFail {
		err = fmt.Errorf("失败订单不能手动成功")
	}
	if err != nil {
		return
	}

	_, err = NewChannelOrderService(svc.Ctx).Success(channelOrder, extraChannelOrderUpdate, extraOrderUpdate, 1)

	return
}

// 调整渠道
func (svc *ChannelOrderSvc) AdjustChannel(param vo.ChannelOrderAdjustParam) (err error) {

	logger.Log.Info("[ChannelOrderSvc] [AdjustChannel]", zap.Any("param", param))

	for _, orderAdjust := range param.ChannelOrders {
		func() (funcErr error) {
			defer func() {
				if funcErr != nil {
					logger.Log.Error("[ChannelOrderSvc] [AdjustChannel] [in function]", zap.Int64("channelOrderID", orderAdjust.ChannelOrderID), zap.Error(err))
				}
			}()

			if funcErr = svc.ManualFailByChannelID(orderAdjust.ChannelOrderID, nil, map[string]any{
				"remark": "重新调整渠道",
			}, false); funcErr != nil {
				return
			}

			go ReDispatcher(*svc.Ctx, orderAdjust.OrderID, 2, param.AdjustChannels, 0, 0)

			return
		}()
	}
	return
}

func FeedBackChannelOrder(status int, channelOrder models.ChannelOrder, ctx echo.Context, channelOrderExtra map[string]any, orderExtra map[string]any) (err error) {

	logger.Log.Info("[FeedBackChannelOrder]",
		zap.Int("status", status),
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.Int64("orderID", channelOrder.OrderID),
	)
	switch status {
	case constant.OrderStatusFail:
		NewChannelOrderService(&ctx).Fail(channelOrder, channelOrderExtra, orderExtra, 2, true)
	case constant.OrderStatusSuccess:
		NewChannelOrderService(&ctx).Success(channelOrder, channelOrderExtra, orderExtra, 2)
	case constant.OrderStatusManual:
		if channelOrder.Status != constant.OrderStatusManual {
			session := daos.Mysql.NewSession()
			defer session.Close()
			if len(channelOrderExtra) == 0 {
				remark := append(channelOrder.Remark, models.RemarkRecord{
					RemarkTime: time.Now(),
					Remark:     "需要手工处理",
				})

				var remarkJSON []byte
				remarkJSON, err = json.Marshal(remark)
				if err != nil {
					return
				}
				channelOrderExtra = map[string]any{
					"remark": string(remarkJSON),
				}
			} else {
				remark := append(channelOrder.Remark, models.RemarkRecord{
					RemarkTime: time.Now(),
					Remark:     "该渠道没有对应的渠道模版",
				})
				var remarkJSON []byte
				remarkJSON, err = json.Marshal(remark)
				if err != nil {
					return
				}
				for k, v := range map[string]any{
					"remark": string(remarkJSON),
				} {
					channelOrderExtra[k] = v
				}
			}
			if err = partition.GlobalChannelOrderPartition.UpdateFields(session, channelOrder.ID, channelOrderExtra); err != nil {
				logger.Log.Error("[CallBackSvc] [Receive]", zap.Error(err))
				return
			}
		}
		go PublishChannelOrderStuck(channelOrder, constant.OrderStatusManual)
		go PublishOrderStuck(models.Order{
			BeanShard:              models.BeanShard{ID: channelOrder.OrderID, Created: channelOrder.OrderTime},
			OrderCustomerProdField: models.OrderCustomerProdField{CustomerID: channelOrder.CustomerID},
		}, constant.OrderStatusManual)
	case constant.OrderStatusNoResult:
		if channelOrder.Status != constant.OrderStatusNoResult {

			session := daos.Mysql.NewSession()
			defer session.Close()

			if err = session.Begin(); err != nil {
				return
			}
			if err = partition.GlobalChannelOrderPartition.ModifyStatus(session, channelOrder, constant.OrderStatusNoResult, map[string]any{
				"remark":      "无结果",
				"finish_time": time.Now().Local(),
			}); err != nil {
				session.Rollback()
				logger.Log.Error("[CallBackSvc] [Receive]", zap.Error(err))
				return
			}
			if err = partition.GlobalOrderPartition.ModifyStatus(session, models.Order{BeanShard: models.BeanShard{ID: channelOrder.OrderID, Created: channelOrder.OrderTime}}, constant.OrderStatusNoResult, map[string]any{
				"remark":      "无结果",
				"finish_time": time.Now().Local(),
			}); err != nil {
				session.Rollback()
				logger.Log.Error("[CallBackSvc] [Receive]", zap.Error(err))
				return
			}
			session.Commit()
		}
		go PublishChannelOrderStuck(channelOrder, constant.OrderStatusNoResult)
		go PublishOrderStuck(models.Order{
			BeanShard:              models.BeanShard{ID: channelOrder.OrderID, Created: channelOrder.OrderTime},
			OrderCustomerProdField: models.OrderCustomerProdField{CustomerID: channelOrder.CustomerID},
		}, constant.OrderStatusNoResult)
	}
	return
}

func (srv *ChannelOrderSvc) Export(params vo.ChannelOrderListParam) (filePath string, err error) {
	filePath = fmt.Sprintf("%d渠道订单列表.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d渠道订单列表.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var channelOrderRsp []resp.ChannelOrderRsp
	if params.Base.StartTime.IsZero() {
		params.Base.StartTime = time.Now().AddDate(0, -2, 0)
	}
	params.NoWithCount = true
	if channelOrderRsp, _, err = srv.List(params); err != nil {
		return
	}
	if len(channelOrderRsp) == 0 {
		channelOrderRsp = append(channelOrderRsp, resp.ChannelOrderRsp{})
	}
	_m := mysql.SysDict.DataValueLabelMapper()
	_m["xj_order"] = map[string]string{
		"1":   "初始化",
		"2":   "处理中",
		"102": "成功",
		"103": "失败",
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", channelOrderRsp, _m)
	return
}

func (svc *ChannelOrderSvc) DispatcherNext(param vo.ChannelOrderNextParam) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelOrderSvc] [DispatcherNext]", zap.Any("param", param), zap.Error(err))
		}
	}()

	var has bool
	var channelOrder models.ChannelOrder

	session := daos.Mysql.NewSession()
	defer session.Close()

	channelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, param.ChannelOrderID)
	if !has {
		err = fmt.Errorf("渠道订单不存在")
	}
	if err != nil {
		return
	}

	if err = partition.GlobalChannelOrderPartition.ModifyStatus(session, channelOrder, constant.OrderStatusFail, map[string]any{
		"remark":      "手工跳转下个渠道",
		"finish_time": time.Now().Local(),
	}); err != nil {
		logger.Log.Error("[CallBackSvc] [Receive]", zap.Error(err))
		return
	}

	ReDispatcher(*svc.Ctx, channelOrder.OrderID, 0, nil, 0, channelOrder.ChannelID)
	return
}

func (svc *ChannelOrderSvc) Query(param vo.ChannelOrderQueryParam) (rsp vo.ChannelOrderQueryRsp, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelOrderSvc] [Query]", zap.Any("param", param), zap.Error(err))
		}
	}()

	var has bool
	var channelOrder models.ChannelOrder

	session := daos.Mysql.NewSession()
	defer session.Close()

	channelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, param.ChannelOrderID)
	if !has {
		err = fmt.Errorf("渠道订单不存在")
	}
	if err != nil {
		return
	}

	var channel models.Channel
	channel, has, err = mysql.Channel.FromID(channelOrder.ChannelID)
	if !has {
		err = fmt.Errorf("渠道不存在")
	}
	if err != nil {
		return
	}
	// 选择模版发送
	var tml template.TemplateInterface
	if tml, err = template.NewTemplate(&channel, template.Option{}); err != nil {
		return
	}

	var queryRsp resp.ClientOrderQryResult
	queryRsp, err = tml.QryOrder(channelOrder)

	if err != nil {
		rsp.Result = fmt.Sprintf("订单查询异常，异常原因:%s", err.Error())
		return
	}

	rsp.Result = fmt.Sprintf("订单查询成功，订单查询结果:%s", constant.OrderQryStatusString(queryRsp.Status))
	return
}

// Success
// from 1 手动 2 回调
// 手动成功 需要生成返销记录，并且变更订单状态 同步财务记录
// 回调成功 只需要记录财务记录，不需要做订单状态处理
func (svc *ChannelOrderSvc) Success(channelOrder models.ChannelOrder,
	channelOrderExtra map[string]any,
	orderExtra map[string]any,
	from int) (
	order models.Order, err error) {

	// 防止渠道订单在查单以及回调同时调用带来问题
	rdsLockKey := fmt.Sprintf("zk:channel_order_success:%d", channelOrder.ID)
	lock := utils.NewLock(rdsLockKey, 5*time.Minute, daos.Rc, 10, 10*time.Second)
	if ok := lock.Lock(); ok {
		defer lock.Unlock()
	}

	if channelOrder.Status == constant.OrderStatusSuccess {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()
	if err = session.Begin(); err != nil {
		return
	}

	// 生成返销记录
	if channelOrder.Status == constant.OrderStatusFail {
		// isReturnOrder = true
		var channel models.Channel
		var has bool
		// channel, _, _ := mysql.Channel.FromID(channelOrder.ChannelID)
		has, err = cache.FromModelPk(models.Channel{}.TableName(), cache.CustomerPk(channelOrder.ChannelID), &channel, cache.FromDatabaseGet)
		if has && err == nil {
			has, err = daos.Exist(session, &models.OrderReturn{}, 0, map[string]any{
				"order_id": channelOrder.OrderID,
			})
			if err != nil {
				session.Rollback()
				return
			}
			if !has {
				returnOrder := models.NewReturnOrderByChannel(channelOrder, constant.ROrderTypeSuccess, channel)
				if _, err = daos.CreateObjs(session, returnOrder); err != nil {
					logger.Log.Error("[ChannelOrderSvc] [Fail] [NewReturnOrderByChannel]",
						zap.String("customerOrderID", channelOrder.CustomerOrderID),
						zap.Int64("channelID", channelOrder.ChannelID),
						zap.Int64("channelOrderID", channelOrder.ID),
					)
					session.Rollback()
					return
				}
			}
		}

	}

	// 回调的返销订单不需要做状态更改
	if from == 1 || from == 2 && channelOrder.Status != constant.OrderStatusFail {
		if len(channelOrderExtra) == 0 {
			channelOrderExtra = map[string]any{
				"finish_time": time.Now().Local(),
			}
			orderExtra = map[string]any{
				"finish_time": time.Now().Local(),
			}
		} else {
			for k, v := range map[string]any{
				"finish_time": time.Now().Local(),
			} {
				channelOrderExtra[k] = v
				orderExtra[k] = v
			}
		}

		if err = partition.GlobalChannelOrderPartition.Success(session, channelOrder, channelOrderExtra, orderExtra); err != nil {
			session.Rollback()
			logger.Log.Error("[Dispatcher] [Success]", zap.Error(err))
			return
		}
		session.Commit()
		financeParam := vo.CustomerFinanceParam{
			CustomerID:      channelOrder.CustomerID,
			Amount:          channelOrder.SalePrice,
			RechargeAmount:  float64(channelOrder.FaceValue),
			IsRecharging:    true,
			IsFinish:        true,
			Remark:          fmt.Sprintf("订单充值扣款,订单ID: %d", channelOrder.OrderID),
			OrderID:         utils.Violent2String(channelOrder.OrderID),
			CustomerOrderID: channelOrder.CustomerOrderID,
		}

		_, err = NewCustomerFinanceService(svc.Ctx).DeductFinance(financeParam)
		if err != nil {
			logger.Log.Error("Success DeductFinance",
				zap.Any("financeParam", financeParam),
				zap.Error(err))
		}
	}

	go PublishChannelOrderStuck(channelOrder, constant.OrderStatusSuccess)
	go PublishOrderStuck(models.Order{
		BeanShard:              models.BeanShard{ID: channelOrder.OrderID, Created: channelOrder.OrderTime},
		OrderCustomerProdField: models.OrderCustomerProdField{CustomerID: channelOrder.CustomerID},
	}, constant.OrderStatusSuccess)

	// 通知回调处理
	go NewCallbackSvc(svc.Ctx).Notify(channelOrder.OrderID, channelOrder)

	return
}

// from 1 手动 2 回调
func (svc *ChannelOrderSvc) Fail(channelOrder models.ChannelOrder,
	channelOrderExtra map[string]any,
	orderExtra map[string]any,
	from int,
	reDispatch bool,
) (err error) {

	// 防止渠道订单在还没有更改失败情况下多次调用 导致重新分发多个渠道订单
	rdsLockKey := fmt.Sprintf("zk:channel_order_fail:%d", channelOrder.ID)
	lock := utils.NewLock(rdsLockKey, 5*time.Minute, daos.Rc, 10, 10*time.Second)
	if ok := lock.Lock(); ok {
		defer lock.Unlock()
	}

	if channelOrder.Status == constant.OrderStatusFail {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = session.Begin(); err != nil {
		return
	}

	// 是否是返销单
	var isReOrder bool
	if channelOrder.Status == constant.OrderStatusSuccess {
		isReOrder = true
		var channel models.Channel
		var has bool
		has, err = cache.FromModelPk(models.Channel{}.TableName(), cache.ChannelPk(channelOrder.ChannelID), &channel, cache.FromDatabaseGet)
		if has && err == nil {
			has, err = daos.Exist(session, &models.OrderReturn{}, 0, map[string]any{
				"order_id": channelOrder.OrderID,
			})
			if err != nil {
				session.Rollback()
				return
			}
			if !has {
				returnOrder := models.NewReturnOrderByChannel(channelOrder, constant.ROrderTypeFail, channel)
				if _, err = daos.CreateObjs(session, returnOrder); err != nil {
					logger.Log.Error("[ChannelOrderSvc] [Fail] [NewReturnOrderByChannel]",
						zap.String("customerOrderID", channelOrder.CustomerOrderID),
						zap.Int64("channelID", channelOrder.ChannelID),
						zap.Int64("channelOrderID", channelOrder.ID),
					)
					session.Rollback()
					return
				}
			}

		}
	}

	var customer models.Customer
	var has bool

	has, err = cache.FromModelPk(models.Customer{}.TableName(), cache.CustomerPk(channelOrder.CustomerID), &customer, cache.FromDatabaseGet)
	if !has || err != nil {
		logger.Log.Error("[ChannelOrderSvc] [Customer FromID]",
			zap.Error(err),
			zap.Bool("has", has),
			zap.Int64("customerID", channelOrder.CustomerID),
			zap.Int64("channelID", channelOrder.ID),
		)
		session.Rollback()
		return
	}

	var toUpdateOrder bool
	// 手动失败或者正常回调失败并且是返销订单则直接更新订单状态，不再分发新渠道
	if from == 1 || (from == 2 && isReOrder) {
		if len(channelOrderExtra) == 0 {
			channelOrderExtra = map[string]any{
				"finish_time": time.Now().Local(),
			}
		} else {
			for k, v := range map[string]any{
				"finish_time": time.Now().Local(),
			} {
				channelOrderExtra[k] = v
			}
		}
		toUpdateOrder = true

	}

	// 假如是慢充订单并且退单了也就直接更新订单状态，不再分发新渠道
	if customer.SlowRechargeFlag {
		in, _ := cache.InSetCache(cache.SetReturnOrderTable(), cache.ReturnOrderObj(channelOrder.OrderID))
		if in {
			toUpdateOrder = true
		} else {
			toUpdateOrder = false
		}
	}

	if err = partition.GlobalChannelOrderPartition.Fail(session, channelOrder, channelOrderExtra, orderExtra, toUpdateOrder); err != nil {
		session.Rollback()
		return
	}

	logger.Log.Info("[ChannelOrderSvc] [Fail]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.Bool("toUpdateOrder", toUpdateOrder),
		zap.Bool("isReturnOrder", isReOrder),
		zap.Bool("reDispatch", reDispatch),
	)
	// 退款
	if toUpdateOrder && !isReOrder {
		var order models.Order
		order, has, err = partition.GlobalOrderPartition.FromID(session, channelOrder.OrderID)
		if !has {
			err = errors.New("record not found")
		}
		if err != nil {
			session.Rollback()
			return
		}
		go NewOrderService(svc.Ctx).OrderBackMoney(order)
	}

	session.Commit()
	go PublishChannelOrderStuck(channelOrder, constant.OrderStatusFail)
	go PublishOrderStuck(models.Order{
		BeanShard:              models.BeanShard{ID: channelOrder.OrderID, Created: channelOrder.OrderTime},
		OrderCustomerProdField: models.OrderCustomerProdField{CustomerID: channelOrder.CustomerID},
		Status:                 constant.OrderStatusFail,
	}, constant.OrderStatusFail)

	if !toUpdateOrder && !isReOrder && reDispatch {
		err = ReDispatcher(*svc.Ctx, channelOrder.OrderID, 0, nil, 0, channelOrder.ChannelID)
	}

	if toUpdateOrder && reDispatch {
		go NewCallbackSvc(svc.Ctx).Notify(channelOrder.OrderID, channelOrder)
	}

	return
}
