package cache

import (
	"application/models"
)

func GetOnlineChannelM(contain []int64, except []int64) (channelM map[int64]models.Channel, err error) {
	exceptMapper := make(map[int64]bool)
	channelM = make(map[int64]models.Channel)
	var validChannel []int64
	for _, channelID := range contain {
		if _, ok := exceptMapper[channelID]; !ok {
			validChannel = append(validChannel, channelID)
		}
	}

	for _, channelID := range validChannel {
		var channel models.Channel
		var has bool
		has, err = FromModelPk(models.Channel{}.TableName(), ChannelPk(channelID), &channel, FromDatabaseGet)
		if err != nil {
			return
		}
		if has && channel.Online == 2 {
			channelM[channelID] = channel
		}
	}
	return
}
