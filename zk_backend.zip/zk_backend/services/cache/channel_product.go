package cache

import (
	"application/common/logger"
	"application/daos/mysql"
	"application/models"

	"go.uber.org/zap"
)

func CacheChannelProduct(channelID int64) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[CacheChannelProduct]", zap.Int64("channelID", channelID), zap.Error(err))
		}
	}()
	var channelProduct []models.ChannelProduct
	if channelProduct, err = mysql.ChannelProd.ListByChannelID(channelID); err != nil {
		return
	}

	cache := NewKvCacheObject(models.ChannelProduct{}.TableName(), ChannelProductPk(channelID))

	return cache.Set(&channelProduct)
}

func DelCacheChannelProduct(channelID int64) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[DelCacheChannelProduct]", zap.Int64("channelID", channelID), zap.Error(err))
		}
	}()

	cache := NewKvCacheObject(models.ChannelProduct{}.TableName(), ChannelProductPk(channelID))

	return cache.Release()
}

func ListOnlineByChannel(channelID int64) (channelProducts []models.ChannelProduct, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[ListOnlineChannelProd]", zap.Int64("channelID", channelID), zap.Error(err))
		}
	}()

	if _, err = FromModelPk(models.ChannelProduct{}.TableName(), ChannelProductPk(channelID), &channelProducts, FromDatabaseList); err != nil {
		return
	}
	return
}

func FromChannelProduct(channelID int64, productCode string) (channelProduct models.ChannelProduct, has bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Info("[GetChannelProduct]",
				zap.Int64("channelID", channelID),
				zap.String("productCode", productCode),
				zap.Error(err))
		}
	}()

	var _channelProducts []models.ChannelProduct

	if _, err = FromModelPk(models.ChannelProduct{}.TableName(), ChannelProductPk(channelID), &_channelProducts, FromDatabaseList); err != nil {
		return
	}

	for _, _channelProduct := range _channelProducts {
		if _channelProduct.ProductCode == productCode {
			channelProduct = _channelProduct
			has = true
			return
		}
	}
	return
}

func ListOnlineChannelProd(channelIDlist []int64, productCodes []string) (channelProductM map[int64]map[string]models.ChannelProduct, err error) {
	productCodeMapper := make(map[string]bool)
	for _, product := range productCodes {
		productCodeMapper[product] = true
	}

	channelProductM = make(map[int64]map[string]models.ChannelProduct)
	for _, channelID := range channelIDlist {
		var channelProds []models.ChannelProduct
		channelProds, err = ListOnlineByChannel(channelID)
		for _, channelProd := range channelProds {
			if _, ok := productCodeMapper[channelProd.ProductCode]; ok && channelProd.Online == 2 {
				if _channelProdMap, ok := channelProductM[channelProd.ChannelID]; ok {
					_channelProdMap[channelProd.ProductCode] = channelProd
				} else {
					channelProductM[channelProd.ChannelID] = map[string]models.ChannelProduct{
						channelProd.ProductCode: channelProd,
					}
				}
			}
		}
	}
	return
}
