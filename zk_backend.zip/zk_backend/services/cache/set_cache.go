package cache

import (
	"application/common/logger"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/vo"
	"fmt"
	"time"

	"go.uber.org/zap"
)

type (
	SetCacheObject struct {
		tableName string
	}
	SetCacheFunc func() ([]any, error)
)

func NewSetCacheObject(tableName string) *SetCacheObject {
	return &SetCacheObject{tableName: tableName}
}

func (cache *SetCacheObject) Key() string {
	return fmt.Sprintf("zk:%s", cache.tableName)
}

func (cache *SetCacheObject) Save(obj any) error {
	return daos.Rc.SAdd(cache.Key(), obj).Err()
}

func (cache *SetCacheObject) Delete(obj any) error {
	return daos.Rc.SRem(cache.Key(), obj).Err()
}

func (cache *SetCacheObject) Del() error {
	return daos.Rc.Del(cache.Key()).Err()
}

func (cache *SetCacheObject) Contain(obj any) (bool, error) {
	return daos.Rc.SIsMember(cache.Key(), obj).Result()
}

func Save2SetCache(tableName string, obj any) (err error) {
	return NewSetCacheObject(tableName).Save(obj)
}

func Save2SetCacheWithTTL(tableName string, obj any, ttlSeconds int64) (err error) {
	o := NewSetCacheObject(tableName)
	if err = NewSetCacheObject(tableName).Save(obj); err != nil {
		return
	}
	daos.Rc.Expire(o.Key(), time.Duration(ttlSeconds)*time.Second).Err()
	return
}

func DeleteFromSetCache(tableName string, obj any) (err error) {
	return NewSetCacheObject(tableName).Delete(obj)
}

func DeleteFromSetKey(tableName string) (err error) {
	return NewSetCacheObject(tableName).Del()
}

func InSetCache(tableName string, obj any) (bool, error) {
	return NewSetCacheObject(tableName).Contain(obj)
}

func GetSetMembers(tableName string) ([]string, error) {
	return daos.Rc.SMembers(NewSetCacheObject(tableName).Key()).Result()
}

func RefreshSetCache(tableName string, loadFunc SetCacheFunc) (err error) {
	if err = daos.Rc.Del(NewSetCacheObject(tableName).Key()).Err(); err != nil {
		return
	}
	var objects []any
	if objects, err = loadFunc(); err != nil {
		return
	}

	for _, obj := range objects {
		Save2SetCache(tableName, obj)
	}
	return
}

func RefreshBlackList() (err error) {
	return RefreshSetCache(models.Blacklist{}.TableName(), func() (items []any, err error) {
		var objects []models.Blacklist
		if objects, err = mysql.Blacklist.LoadAll(); err != nil {
			return
		}

		logger.Log.Info("RefreshBlackList", zap.Any("objects", objects))

		for _, obj := range objects {
			items = append(items, BlacklistObj(obj))
		}
		return
	})
}

func RefreshSuspendArea() (err error) {
	return RefreshSetCache(models.AreaSuspend{}.TableName(), func() (items []any, err error) {
		var objects []models.AreaSuspend
		if objects, err = mysql.AreaSuspend.All(); err != nil {
			return
		}

		for _, obj := range objects {
			items = append(items, AreaSuspendObj(obj))
		}
		return
	})
}

func SetReturnOrderTable() string {
	return fmt.Sprintf("%s_return", models.Order{}.TableName())
}

func RefreshReturnOrder() (err error) {
	return RefreshSetCache(SetReturnOrderTable(), func() (items []any, err error) {
		var objects []models.Order
		session := daos.Mysql.NewSession()
		defer session.Close()
		params := vo.OrderListParam{
			IsSlowChoice:   2,
			IsReturnChoice: 2,
			NoWithCount:    true,
			AreaChoice:     -1,
		}
		// 传单用来判断是否是退单，2天足矣啊
		params.Base.StartTime = time.Now().AddDate(0, 0, -2)
		params.Base.EndTime = time.Now()
		if objects, _, err = partition.GlobalOrderPartition.List(params); err != nil {
			return
		}

		for _, obj := range objects {
			logger.Log.Info("RefreshReturnOrder", zap.Any("orderID", obj.ID))
			items = append(items, ReturnOrderObj(obj.ID))
		}
		return
	})
}

func BlacklistObj(obj models.Blacklist) any {
	return obj.Phone
}

func AreaSuspendObj(obj models.AreaSuspend) any {
	return fmt.Sprintf("%d:%d:%d:%d", obj.ApplyID, obj.Type, obj.Isp, obj.Area)
}

func ReturnOrderObj(orderID int64) any {
	return fmt.Sprintf("%d", orderID)
}
