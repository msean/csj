package cache

import (
	"application/common/logger"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"encoding/json"

	"go.uber.org/zap"
)

func OprCustomerProductCache(idList []int64, opr int) (err error) {
	var customerProdList []models.CustomerProduct

	switch opr {
	case 1:
		if customerProdList, err = mysql.CustomerProduct.FromIDList(idList); err != nil {
			return
		}
		for _, customerProd := range customerProdList {
			if err = UpdateCacheModelPk(models.CustomerProduct{}.TableName(), CustomerProductPk(customerProd.CustomerID, customerProd.ProductCode), &models.CustomerProduct{}, true); err != nil {
				logger.Log.Error("[OprCustomerProductCache] [UpdateCacheModelPk]",
					zap.Int64("customerProduct", customerProd.ID),
					zap.Error(err),
				)
				DelCacheModelPk(customerProd.TableName(), CustomerProductPk(customerProd.CustomerID, customerProd.ProductCode))
			}
		}
	case 2:
		var ret map[string]string
		if ret, err = ScanCategory(models.CustomerProduct{}.TableName(), false); err != nil {
			return
		}

		idKeyMapper := make(map[int64]string)
		for key, val := range ret {

			var object models.CustomerProduct
			if err = json.Unmarshal([]byte(val), &object); err != nil {
				logger.Log.Error("[OprCustomerProductCache] [Unmarshal]",
					zap.String("key", key),
					zap.String("value", val),
					zap.Error(err))
				continue
			}
			idKeyMapper[object.ID] = key
		}

		for _, id := range idList {
			if _key, ok := idKeyMapper[id]; ok {
				daos.Rc.Del(_key)
			}
		}
	}

	return
}
