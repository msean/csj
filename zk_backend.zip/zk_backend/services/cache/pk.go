package cache

import (
	"application/utils"
)

// 涉及余额和授信额度的不做缓存，需要查询的时候请查询数据库
func CustomerPk(customerID int64) []KvPkPair {
	return []KvPkPair{
		{
			pkColName: "id",
			pkVal:     utils.Violent2String(customerID),
		},
	}
}

func ProductPk(productCode string) []KvPkPair {
	return []KvPkPair{
		{
			pkColName: "code",
			pkVal:     productCode,
		},
	}
}

func CustomerProductPk(customerID int64, productCode string) []KvPkPair {
	return []KvPkPair{
		{
			pkColName: "customer_id",
			pkVal:     utils.Violent2String(customerID),
		},
		{
			pkColName: "product_code",
			pkVal:     productCode,
		},
	}
}

func ChannelPk(channelID int64) []KvPkPair {
	return []KvPkPair{
		{
			pkColName: "id",
			pkVal:     utils.Violent2String(channelID),
		},
	}
}

func ChannelProductPk(channelID int64) []KvPkPair {
	return []KvPkPair{
		{
			pkColName: "channel_id",
			pkVal:     utils.Violent2String(channelID),
		},
	}
}

func SysConfigPk(key string) []KvPkPair {
	return []KvPkPair{
		{
			pkColName: "config_key",
			pkVal:     key,
		},
	}
}
