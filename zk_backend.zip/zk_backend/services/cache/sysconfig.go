package cache

import "application/models"

func SysCfgFromKey(key string) (cfg models.SysArgConfig, has bool, err error) {
	has, err = FromModelPk(models.SysArgConfig{}.TableName(), SysConfigPk(key), &cfg, FromDatabaseGet)
	return
}
