package cache

import (
	"application/common/logger"
	"application/daos"
	"application/utils"
	"encoding/json"
	"fmt"
	"reflect"
	"time"

	"go.uber.org/zap"
	"gopkg.in/redis.v5"
)

var DefaultTimeOut = 24 * time.Hour

var (
	FromDatabaseGet  = "get"
	FromDatabaseList = "list"
)

type (
	KvCacheObject struct {
		tableName string
		pkPairs   []KvPkPair
		val       []byte
	}
	KvPkPair struct {
		pkColName string
		pkVal     string
	}
)

func NewKvCacheObject(tableName string, pairs []KvPkPair) *KvCacheObject {
	return &KvCacheObject{
		tableName: tableName,
		pkPairs:   pairs,
	}
}

func (cache *KvCacheObject) categoryKey() string {
	return fmt.Sprintf("zk:%s", cache.tableName)
}

func (cache *KvCacheObject) individualKey() string {
	var pkKey string
	for i, pair := range cache.pkPairs {
		if i == 0 {
			pkKey = pair.pkVal
		} else {
			pkKey = fmt.Sprintf("%s_%s", pkKey, pair.pkVal)
		}
	}
	return pkKey
}

func ScanCategory(tableName string, onlyKeys bool) (result map[string]string, err error) {
	categoryKey := fmt.Sprintf("zk:%s*", tableName)
	var cursor uint64
	var allKeys []string
	result = make(map[string]string)
	for {
		keys, nextCursor, err := daos.Rc.Scan(cursor, categoryKey, 100).Result()
		if err != nil {
			return nil, fmt.Errorf("error scanning keys with prefix '%s': %w", categoryKey, err)
		}

		allKeys = append(allKeys, keys...)

		if nextCursor == 0 {
			break
		}
		cursor = nextCursor
	}

	if len(allKeys) == 0 {
		return
	}

	if onlyKeys {
		for _, key := range allKeys {
			result[key] = ""
		}
		return
	}

	values, err := daos.Rc.MGet(allKeys...).Result()
	if err != nil {
		return nil, fmt.Errorf("error fetching values for keys: %w", err)
	}

	result = make(map[string]string, len(allKeys))
	for i, key := range allKeys {
		if values[i] != nil {
			result[key] = values[i].(string)
		}
	}

	return result, nil
}

func (cache *KvCacheObject) Key() string {
	return fmt.Sprintf("%s:%s", cache.categoryKey(), cache.individualKey())
}

func (cache *KvCacheObject) Set(obj any) (err error) {
	if cache.val, err = json.Marshal(obj); err != nil {
		return
	}
	return daos.Rc.Set(cache.Key(), cache.val, DefaultTimeOut).Err()
}

func (cache *KvCacheObject) Release() (err error) {
	return daos.Rc.Del(cache.Key()).Err()
}

func (cache *KvCacheObject) Get(obj any) (has bool, err error) {
	has = true
	cache.val, err = daos.Rc.Get(cache.Key()).Bytes()
	if err != nil {
		if err == redis.Nil {
			has = false
			err = nil
		}
	}
	if !has || err != nil {
		return
	}
	err = json.Unmarshal(cache.val, obj)
	return
}

func (cache *KvCacheObject) FromDatabase(obj any) (has bool, err error) {
	whereConditions := []utils.Cond{}
	for _, pair := range cache.pkPairs {
		whereConditions = append(whereConditions, utils.NewWhereCond(pair.pkColName, pair.pkVal))
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.GetRecordByField(session, cache.tableName, obj, whereConditions...)
	return
}

func (cache *KvCacheObject) ListFromDatabase(obj any) (err error) {
	whereConditions := []utils.Cond{}
	for _, pair := range cache.pkPairs {
		whereConditions = append(whereConditions, utils.NewWhereCond(pair.pkColName, pair.pkVal))
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	return daos.ListByCondition(session, cache.tableName, obj, whereConditions...)
}

func FromModelPk(tableName string, pkPairs []KvPkPair, obj any, _type string) (has bool, err error) {
	cache := NewKvCacheObject(tableName, pkPairs)

	defer func() {
		if err != nil {
			logger.Log.Error("[FromModelPk]",
				zap.Any("cache", cache),
				zap.Bool("has", has),
				zap.Error(err))
			return
		}
	}()

	// 缓存获取的时候有错误不影响从数据库中获取
	var cacheGetErr error
	has, cacheGetErr = cache.Get(obj)

	if has {
		return
	}

	if cacheGetErr != nil {
		logger.Log.Error("[FromModelPk] cacheGetErr",
			zap.String("tableName", tableName),
			zap.String("key", cache.Key()),
			zap.Bool("has", has),
			zap.Error(err),
			zap.String("_type", _type))
	}

	switch _type {
	case FromDatabaseGet:
		if has, err = cache.FromDatabase(obj); err != nil || !has {
			return
		}
	case FromDatabaseList:
		if err = cache.ListFromDatabase(obj); err != nil {
			return
		}
	}

	err = cache.Set(obj)
	return
}

func ListModelPk(tableName string, pkPairs []KvPkPair, obj any) (has bool, err error) {
	cache := NewKvCacheObject(tableName, pkPairs)

	defer func() {
		if err != nil {
			logger.Log.Error("[FromModelPk]",
				zap.Any("cache", cache),
				zap.Bool("has", has),
				zap.Error(err))
			return
		}
	}()

	// 缓存获取的时候有错误不影响从数据库中获取
	var GetErr error
	if has, GetErr = cache.Get(obj); GetErr != nil {
		logger.Log.Info("[FromModelPk]",
			zap.String("tableName", tableName),
			zap.String("key", cache.Key()),
			zap.Bool("has", has),
			zap.Error(err))
	}

	if has {
		return
	}

	if has, err = cache.FromDatabase(obj); err != nil || !has {
		return
	}

	err = cache.Set(obj)

	return
}

func DelCacheModelPk(tableName string, pkPairs []KvPkPair) (err error) {
	cache := NewKvCacheObject(tableName, pkPairs)
	err = cache.Release()

	logger.Log.Error("[DelCacheModelPk]",
		zap.Any("key", cache.Key()),
		zap.Error(err))

	return
}

// loadFromDB false 直接将obj 设置到缓存中 true 则从数据库中去拿了后赋值给obj，然后放到缓存中去
func UpdateCacheModelPk(tableName string, pkPairs []KvPkPair, obj any, loadFromDB bool) (err error) {

	if reflect.TypeOf(obj).Kind() != reflect.Ptr {
		return fmt.Errorf("expected obj to be a pointer, got %v", reflect.TypeOf(obj).Kind())
	}

	cache := NewKvCacheObject(tableName, pkPairs)

	defer func() {
		if err != nil {
			logger.Log.Error("[UpdateCacheModelPk]", zap.Any("cache", cache), zap.Error(err))
			return
		}
	}()

	if err = cache.Release(); err != nil {
		return
	}

	if !loadFromDB {
		return cache.Set(obj)
	}

	var has bool
	if has, err = cache.FromDatabase(obj); err != nil || !has {
		return
	}

	return cache.Set(obj)
}
