package services

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/services/cache"
	"application/template"
	"encoding/json"
	"fmt"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	Submitter struct {
		channel      models.Channel
		ChannelOrder models.ChannelOrder
		callbackCh   chan struct{}
		ctx          echo.Context
		template     template.TemplateInterface
		submitTime   time.Time
	}
)

func NewSubmitter(channel models.Channel, channelOrder models.ChannelOrder, ctx echo.Context) (submitter *Submitter, err error) {
	var tml template.TemplateInterface
	tml, err = template.NewTemplate(&channel, template.Option{Pcode: channelOrder.Pcode})
	if err != nil {
		return
	}
	submitter = &Submitter{
		channel:      channel,
		ChannelOrder: channelOrder,
		callbackCh:   make(chan struct{}),
		ctx:          ctx,
		template:     tml,
	}
	return
}

func (s *Submitter) Do() (success bool, err error) {
	// 请求频率限制
	if err = ChannelLimiter.Wait(s.channel.ID, 1, 120*time.Second); err != nil {
		logger.Log.Error("[Dispatcher] [SubmitToChannel] wait", zap.Error(err))
		return
	}

	result := resp.ClientOrderSubmitResult{Code: constant.ChannelSubmitException}
	start := time.Now()
	s.template.Submit(s.ChannelOrder, &result)
	logger.Log.Info("[SubmitToChannel Result]",
		zap.Int64("channelOrderID", s.ChannelOrder.ID),
		zap.Int64("orderID", s.ChannelOrder.OrderID),
		zap.Any("result", result),
		zap.Duration("duration", time.Since(start)),
	)

	session := daos.Mysql.NewSession()
	defer session.Close()

	switch result.Code {
	case constant.ChannelSubmitSuccess:
		remark := append(s.ChannelOrder.Remark, models.RemarkRecord{
			RemarkTime: time.Now(),
			Remark:     "提交成功",
		})
		var remarkJSON []byte
		remarkJSON, err = json.Marshal(remark)
		if err != nil {
			return
		}
		err = partition.GlobalChannelOrderPartition.UpdateFields(session, s.ChannelOrder.ID, map[string]any{
			"remark":      string(remarkJSON),
			"status":      constant.OrderStatusHandle,
			"finish_time": time.Now().Local(),
		})
		go PublishChannelOrderStuck(s.ChannelOrder, constant.OrderStatusHandle)
		success = true
		s.submitTime = time.Now()
		GlobalCallbackBus.Put(s)

	default:
		remark := append(s.ChannelOrder.Remark, models.RemarkRecord{
			RemarkTime: time.Now(),
			Remark:     fmt.Sprintf("状态码:%d, 异常原因: %s", result.Code, result.Err),
		})
		var remarkJSON []byte
		remarkJSON, err = json.Marshal(remark)
		if err != nil {
			return
		}
		err = partition.GlobalChannelOrderPartition.UpdateFields(session, s.ChannelOrder.ID, map[string]any{
			"remark":      string(remarkJSON),
			"status":      constant.OrderStatusFail,
			"finish_time": time.Now().Local(),
		})
		go PublishChannelOrderStuck(s.ChannelOrder, constant.OrderStatusFail)
	}
	return
}

func (s *Submitter) WaitCallback() {
	if time.Now().After(s.submitTime.Add(4 * time.Minute)) {
		go func() {
			if r := recover(); r != nil {
				logger.Log.Error("[Submitter] [QryOrder]",
					zap.Int64("channelOrderID", s.ChannelOrder.ID),
					zap.Int64("orderID", s.ChannelOrder.OrderID),
					zap.Any("error", r))
			}
			s.QryOrder()
		}()
		return
	}

	for {
		select {
		case <-s.callbackCh:
			logger.Log.Info("Submitter WaitCallback",
				zap.Int64("channelOrderID", s.ChannelOrder.ID),
				zap.Int64("orderID", s.ChannelOrder.OrderID),
				zap.Duration("duration", time.Since(s.submitTime)),
			)
			GlobalCallbackBus.Delete(s.ChannelOrder.ID)
			return
		case <-time.After(time.Until(s.submitTime.Add(4 * time.Minute))):
			logger.Log.Info("[Submitter] [WaitCallbackTimeout]",
				zap.Int64("channelOrderID", s.ChannelOrder.ID),
				zap.Int64("orderID", s.ChannelOrder.OrderID),
			)
			go s.CallbackWaitTimeOut()
			return
		}
	}
}

func (s *Submitter) CallbackWaitTimeOut() {
	defer func() {
		if r := recover(); r != nil {
			logger.Log.Error("[Submitter] [CallbackWaitTimeOut]",
				zap.Int64("channelOrderID", s.ChannelOrder.ID),
				zap.Int64("orderID", s.ChannelOrder.OrderID),
				zap.Any("error", r))
		}
	}()
	GlobalCallbackBus.Delete(s.ChannelOrder.ID)
	close(s.callbackCh)
	s.QryOrder()
}

func (s *Submitter) SendCallback() {
	defer func() {
		if r := recover(); r != nil {
			logger.Log.Error("SendCallback3",
				zap.Int64("channelOrderID", s.ChannelOrder.ID),
				zap.Int64("orderID", s.ChannelOrder.OrderID),
				zap.Any("error", r))
		}
	}()
	select {
	case s.callbackCh <- struct{}{}:
		logger.Log.Info("SendCallback0",
			zap.Int64("channelOrderID", s.ChannelOrder.ID),
			zap.Int64("orderID", s.ChannelOrder.OrderID))
	// 避免无消费导致内存泄漏
	case <-time.After(time.Until(s.submitTime.Add(4 * time.Minute))):
		logger.Log.Warn("SendCallback1",
			zap.Int64("channelOrderID", s.ChannelOrder.ID),
			zap.Int64("orderID", s.ChannelOrder.OrderID))
		return
	}
}

func (s *Submitter) QryOrder() {
	var success bool
	if success, _ = _qryOrderWithFeedBack(s.ChannelOrder); success {
		return
	}

	ticker := time.NewTicker(35 * time.Second)
	defer ticker.Stop()

	timeout := time.NewTimer((35*4 + 5) * time.Second)
	defer timeout.Stop()

	for {
		select {
		case <-ticker.C:
			if success, _ = _qryOrderWithFeedBack(s.ChannelOrder); success {
				return
			}
		case <-timeout.C:
			logger.Log.Info("Submitter QryOrder timeout",
				zap.String("orderID", s.ChannelOrder.CustomerOrderID),
				zap.Int64("channelOrderID", s.channel.ID),
			)
			return
		}
	}
}

func _qryOrderWithFeedBack(channelOrder models.ChannelOrder) (success bool, err error) {
	var tml template.TemplateInterface
	var channel models.Channel
	var has bool
	has, err = cache.FromModelPk(models.Channel{}.TableName(), cache.ChannelPk(channelOrder.ChannelID), &channel, cache.FromDatabaseGet)
	if !has || err != nil {
		logger.Log.Info("QryOrderWithFeedBack",
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.Int64("orderID", channelOrder.OrderID),
			zap.Bool("has", has),
			zap.Error(err),
		)
	}
	if tml, err = template.NewTemplate(&channel, template.Option{}); err != nil {
		return
	}
	var queryRsp resp.ClientOrderQryResult
	queryRsp, err = tml.QryOrder(channelOrder)
	if err != nil {
		logger.Log.Info("[Submitter] [QryOrder]",
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.Int64("orderID", channelOrder.OrderID),
			zap.Error(err),
		)
		return
	}

	switch queryRsp.Status {
	case constant.OrderQryNoExist,
		constant.OrderQryCustomerNotExist,
		constant.OrderQryCancel,
		constant.OrderQryFail,
		constant.OrderQryFailNotified,
		constant.OrderQryTimeout:
		extraChannelOrderMsg := map[string]any{
			"remark": constant.OrderQryStatusString(queryRsp.Status),
		}
		var _channelOrder models.ChannelOrder
		var has bool
		session := daos.Mysql.NewSession()
		defer session.Close()
		if _channelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrder.ID); err != nil || !has {
			return
		}
		// 返回订单失败 并且是手工处理
		if queryRsp.Status == constant.OrderQryFail && channel.ManualProcess == 2 {
			e := echo.New()
			ctx := e.AcquireContext()
			defer e.ReleaseContext(ctx)
			FeedBackChannelOrder(constant.OrderStatusManual, channelOrder, ctx, nil, nil)
			success = true
			return
		}
		e := echo.New()
		ctx := e.AcquireContext()
		defer e.ReleaseContext(ctx)
		FeedBackChannelOrder(constant.OrderStatusFail, _channelOrder, ctx, extraChannelOrderMsg, nil)
		success = true
		return
	case constant.OrderQryParamsErr, constant.OrderQrySignErr:
		logger.Log.Info("Submitter QryOrder",
			zap.Int64("orderID", channelOrder.OrderID),
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("channelMsg", queryRsp.ChannelMsg),
			zap.Int("status", queryRsp.Status),
		)
	case constant.OrderQryApiClose, constant.OrderQryCustomerClose:
		logger.Log.Info("Submitter QryOrder",
			zap.Int64("orderID", channelOrder.OrderID),
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("channelMsg", queryRsp.ChannelMsg),
			zap.Int("status", queryRsp.Status),
		)
		success = true
		return
	case constant.OrderQryCreated, constant.OrderQryWaiting, constant.OrderQryHandle, constant.OrderQryWaitCheck:
	case constant.OrderQryApiFrequency:
	case constant.OrderQryApiException:
	case constant.OrderQrySuccess:
		// 重新查channelOrder
		var _channelOrder models.ChannelOrder
		var has bool
		session := daos.Mysql.NewSession()
		defer session.Close()
		if _channelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrder.ID); err != nil || !has {
			return
		}
		orderUpdate := make(map[string]any)
		if queryRsp.Cert != "" {
			orderUpdate = map[string]any{
				"voucher": queryRsp.Cert,
			}
		}
		e := echo.New()
		ctx := e.AcquireContext()
		defer e.ReleaseContext(ctx)
		FeedBackChannelOrder(constant.OrderStatusSuccess, _channelOrder, ctx, orderUpdate, orderUpdate)
		success = true
		return
	}

	return
}

func QryOrderWithFeedBack(channelOrder models.ChannelOrder) (success bool, err error) {
	if success, _ = _qryOrderWithFeedBack(channelOrder); success {
		return
	}
	ticker := time.NewTicker(35 * time.Second)
	defer ticker.Stop()
	timeout := time.NewTimer(time.Until(channelOrder.Created.Add(15 * time.Minute)))
	defer timeout.Stop()

	for {
		select {
		case <-ticker.C:
			logger.Log.Info("QryOrderWithFeedBack",
				zap.String("orderID", channelOrder.CustomerOrderID),
				zap.Int64("channelOrderID", channelOrder.ID),
				zap.Int64("orderID", channelOrder.OrderID),
			)
			if success, _ = _qryOrderWithFeedBack(channelOrder); success {
				return
			}
		case <-timeout.C:
			logger.Log.Info("QryOrderWithFeedBack timeout",
				zap.String("orderID", channelOrder.CustomerOrderID),
				zap.Int64("channelOrderID", channelOrder.ID),
				zap.Int64("orderID", channelOrder.OrderID),
			)
			return
		}
	}
}
