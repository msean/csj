package services

import (
	"application/common/logger"
	"application/conf"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"fmt"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type SysDictSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewSysDictSrv(ctx *echo.Context) *SysDictSrv {
	bean := &SysDictSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *SysDictSrv) CreateType(param vo.SysDictTypeCreateParams) (sysDict models.SysDictType, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [CreateType]", zap.Any("param", param), zap.Error(err))
		}
	}()

	if err = copier.Copy(&sysDict, &param); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.CreateObjs(session, &sysDict)
	return
}

func (srv *SysDictSrv) ListType(param vo.SysDictTypeListParams) (objects []*models.SysDictType, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [ListType]", zap.Any("param", param), zap.Error(err))
		}
	}()

	if objects, total, err = mysql.SysDict.ListType(param); err != nil {
		return
	}

	if param.LoadData {
		var dictTypeIDList []int64
		for _, obj := range objects {
			dictTypeIDList = append(dictTypeIDList, obj.ID)
		}

		dictDataM, _ := mysql.SysDict.TypeDataMap(dictTypeIDList)

		for _, obj := range objects {
			obj.Data = dictDataM[obj.ID]
		}
	}
	return
}

func (srv *SysDictSrv) UpdateType(param vo.SysDictTypeUpdateParams) (sysDict models.SysDictType, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [UpdateType]", zap.Any("param", param), zap.Error(err))
		}
	}()

	if err = copier.Copy(&sysDict, &param); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.UpdateObjWithVersion(session, &sysDict, nil)
	return
}

func (srv *SysDictSrv) UpdateEffectType(param vo.SysDictUpdateEffectTypeParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [UpdateEffectType]", zap.Any("param", param), zap.Error(err))
		}
	}()

	var sysDictType models.SysDictType
	if err = copier.Copy(&sysDictType, &param); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.UpdateColsWithVersion(session, &sysDictType, "effect_type")
	return
}

func (srv *SysDictSrv) DelType(param vo.DeleteParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [DelType]", zap.Any("param", param), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.DelObjs(session, param.IDList, &models.SysDictType{})
	return
}

func (srv *SysDictSrv) CreateTypeData(param vo.SysDictDataCreateParams) (sysDictData models.SysDictData, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [CreateTypeData]", zap.Any("param", param), zap.Error(err))
		}
	}()

	if err = copier.Copy(&sysDictData, &param); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.CreateObjs(session, &sysDictData)
	return
}

func (srv *SysDictSrv) TypeFromID(id int64) (sysDictType models.SysDictType, has bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [TypeFromID]", zap.Int64("id", id), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &sysDictType)
	return
}

func (srv *SysDictSrv) TypeExport(params vo.SysDictTypeListParams) (filePath string, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [TypeExport]", zap.Any("params", params), zap.Error(err))
		}
	}()

	filePath = fmt.Sprintf("%d字典类型.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d字典类型.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var objs []*models.SysDictType
	if objs, _, err = mysql.SysDict.ListType(params); err != nil {
		return
	}
	if len(objs) == 0 {
		objs = append(objs, &models.SysDictType{})
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objs, mysql.SysDict.DataValueLabelMapper())
	return
}

func (srv *SysDictSrv) TypeDataFromID(id int64) (sysDictData models.SysDictData, has bool, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [TypeDataFromID]", zap.Int64("id", id), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &sysDictData)
	return
}

func (srv *SysDictSrv) UpdateTypeData(param vo.SysDictDataUpdateParams) (sysDictData models.SysDictData, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [UpdateTypeData]", zap.Any("param", param), zap.Error(err))
		}
	}()

	if err = copier.Copy(&sysDictData, &param); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.UpdateObjWithVersion(session, &sysDictData, nil)
	return
}

func (srv *SysDictSrv) ListTypeData(params vo.SysDictDataListParams) (objs []models.SysDictData, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [ListTypeData]", zap.Any("params", params), zap.Error(err))
		}
	}()

	return mysql.SysDict.ListTypeData(params)

}

func (srv *SysDictSrv) DelTypeData(params vo.DeleteParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [DelTypeData]", zap.Any("params", params), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.DelObjs(session, params.IDList, &models.SysDictData{})
	return
}

func (srv *SysDictSrv) DataByType(dictType string) (objects []models.SysDictData, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [DataByType]", zap.String("dictType", dictType), zap.Error(err))
		}
	}()

	return mysql.SysDict.DataByType(dictType)
}

func (srv *SysDictSrv) DataByTypeLabel(dictType, label string) (object models.SysDictData, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [DataByType]", zap.String("dictType", dictType), zap.Error(err))
		}
	}()
	var objects []models.SysDictData
	if objects, err = srv.DataByType(dictType); err != nil {
		return
	}

	for _, _object := range objects {
		if _object.Label == label {
			object = _object
			return
		}
	}

	return
}

func (srv *SysDictSrv) DataExport(params vo.SysDictDataListParams) (filePath string, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[SysDictSrv] [DataExport]", zap.Any("params", params), zap.Error(err))
		}
	}()

	filePath = fmt.Sprintf("%d字典数据.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d字典数据.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var objs []models.SysDictData
	if objs, _, err = mysql.SysDict.ListTypeData(params); err != nil {
		return
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objs, mysql.SysDict.DataValueLabelMapper())
	return
}
