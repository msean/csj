package services

import (
	"application/utils"
	"github.com/labstack/echo"
)

type beanService struct {
	Ctx  *echo.Context
	Uuid string
}

func NewServiceBean(ctx *echo.Context) *beanService {
	bean := &beanService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}
