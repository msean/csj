package services

import (
	"application/common/logger"
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models/vo"
	"application/services/cache"
	"application/services/ws"
	"application/utils"
	"fmt"

	"application/models"
	"sync"
	"time"

	"github.com/labstack/echo"
	"github.com/spf13/viper"
	"go.uber.org/zap"
)

var AdminLogChan chan *models.Adminlog
var DelayTaskScheduler *utils.DelayTaskScheduler

type (
	DispatcherScheduler struct {
		workChan    chan *Dispatcher
		mapper      map[int64]*Dispatcher
		mu          sync.Mutex
		concurrency chan int64
	}
	CallbackWorker struct {
		mapper      map[int64]*Submitter
		mu          sync.Mutex
		workChan    chan *Submitter
		concurrency chan int64
	}
)

var RechargeConcurrency chan struct{}
var GlobalDispatcherScheduler *DispatcherScheduler
var GlobalCallbackBus CallbackWorker
var ChannelFinanceScheduler ScheduleChannelFinance

func (bus *DispatcherScheduler) Listen() {
	for {
		select {
		case item := <-bus.workChan:
			logger.Log.Info("scheduler Listen",
				zap.Int64("orderID", item.orderModel.ID),
				zap.String("customerID", item.orderModel.CustomerOrderID),
				zap.Duration("take", time.Since(item.SchedulerTime)))
			bus.concurrency <- item.orderModel.ID
			bus.mu.Lock()
			bus.mapper[item.orderModel.ID] = item
			bus.mu.Unlock()
			go func() {
				defer func() {
					if r := recover(); r != nil {
						logger.Log.Error("[DispatcherWorker]",
							zap.Int64("orderModelID", item.orderModel.ID),
							zap.Any("error", r))
					}
				}()
				item.Do()
			}()
		}
	}
}

func (bus *DispatcherScheduler) Put(worker *Dispatcher) {
	worker.SchedulerTime = time.Now()
	bus.workChan <- worker
}

func (bus *DispatcherScheduler) Remove(worker *Dispatcher) {
	defer func() {
		if r := recover(); r != nil {
			logger.Log.Error("DispatcherWorker Remove",
				zap.Int64("orderID", worker.orderModel.ID),
				zap.String("customerOrderID", worker.orderModel.CustomerOrderID),
				zap.Any("error", r))
		}
	}()
	bus.mu.Lock()
	if len(bus.concurrency) > 0 {
		<-bus.concurrency
	}
	bus.mu.Unlock()
	if worker != nil {
		bus.mu.Lock()
		defer bus.mu.Unlock()
		delete(bus.mapper, worker.orderModel.ID)
	}
}

func RunTimePrint() {
	t := time.NewTicker(1 * time.Minute)
	defer t.Stop()
	for {
		select {
		case <-t.C:
			logger.Log.Info("RunTimePrint",
				zap.Int("Dispatcher", len(GlobalDispatcherScheduler.concurrency)),
				zap.Int("Recharge", len(RechargeConcurrency)),
				zap.Int("WaitCallback", len(GlobalCallbackBus.concurrency)))
		}
	}
}

func (bus *DispatcherScheduler) RemoveByOrderID(orderID int64) {
	in, worker := bus.Get(orderID)
	logger.Log.Info("[RemoveByOrderID",
		zap.Int64("orderID", orderID),
		zap.Bool("in", in))
	if !in {
		return
	}
	bus.Remove(worker)
}

func (bus *DispatcherScheduler) Get(orderID int64) (in bool, worker *Dispatcher) {
	bus.mu.Lock()
	defer bus.mu.Unlock()
	worker, in = bus.mapper[orderID]
	return
}

func (bus *DispatcherScheduler) Len() int {
	return len(bus.concurrency)
}

func (bus *DispatcherScheduler) Cap() int {
	return cap(bus.concurrency)
}

func (callbackWork *CallbackWorker) Listen() {
	for {
		select {
		case item := <-callbackWork.workChan:
			callbackWork.concurrency <- item.ChannelOrder.ID
			callbackWork.mu.Lock()
			callbackWork.mapper[item.ChannelOrder.ID] = item
			callbackWork.mu.Unlock()
			go func() {
				defer func() {
					if r := recover(); r != nil {
						logger.Log.Error("[CallbackWorker]",
							zap.Int64("orderModelID", item.ChannelOrder.ID),
							zap.Any("error", r))
					}
				}()
				logger.Log.Info("[callbackWork]",
					zap.Int64("orderID", item.ChannelOrder.OrderID),
					zap.Int64("channelOrderID", item.ChannelOrder.ID),
					zap.Time("submitTime", item.submitTime),
				)
				item.WaitCallback()
			}()
		}
	}
}

func (callbackWork *CallbackWorker) Put(s *Submitter) {
	defer func() {
		if r := recover(); r != nil {
			logger.Log.Error("[CallbackWorker]",
				zap.Int64("orderID", s.ChannelOrder.OrderID),
				zap.Any("error", r))
			return
		}
	}()
	go func() {
		callbackWork.workChan <- s
	}()
}

func (callbackWork *CallbackWorker) Delete(channelOrderID int64) {
	<-callbackWork.concurrency
	callbackWork.mu.Lock()
	defer callbackWork.mu.Unlock()
	delete(callbackWork.mapper, channelOrderID)
}

func (callbackWork *CallbackWorker) Get(channelOrderID int64) (bool, *Submitter) {
	callbackWork.mu.Lock()
	defer callbackWork.mu.Unlock()

	if s, ok := callbackWork.mapper[channelOrderID]; ok {
		return true, s
	}
	return false, nil
}

func Init() {
	partition.StartUp()

	ws.Init()

	RechargeConcurrency = make(chan struct{}, conf.Config().Echo.RechargeConcurrency)

	GlobalDispatcherScheduler = &DispatcherScheduler{
		workChan:    make(chan *Dispatcher, conf.Config().Echo.DispatcherWorkers),
		mapper:      make(map[int64]*Dispatcher),
		concurrency: make(chan int64, conf.Config().Echo.DispatcherWorkers),
	}
	GlobalCallbackBus = CallbackWorker{
		mapper:      make(map[int64]*Submitter),
		workChan:    make(chan *Submitter, conf.Config().Echo.WaitCallBackConcurrency),
		concurrency: make(chan int64, conf.Config().Echo.WaitCallBackConcurrency),
	}
	ChannelFinanceScheduler = NewScheduleChannelFinance()

	logger.Log.Info("[InitRechargeConcurrency]",
		zap.Int("RechargeConcurrency cap", cap(RechargeConcurrency)),
		zap.Int("WaitCallbackConcurrency", cap(GlobalCallbackBus.concurrency)),
		zap.Int("GlobalDispatcherBus concurrency", cap(GlobalDispatcherScheduler.concurrency)))

	InitChannelLimiter()
	InitOrderStuckChecker()

	cache.RefreshBlackList()
	cache.RefreshSuspendArea()
	cache.RefreshReturnOrder()
	DelayTaskScheduler = utils.NewDelayTaskScheduler()
	go DelayTaskScheduler.Run()
	DelayTaskExec()
	if viper.GetString("echo.env") != "debug" {
		ChannelFinanceScheduler.Init()
	}

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[Crontab Init]",
				zap.Any("error", r))
		}
		InitCrontabManager()
	}()

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[OrderStuckChecker.Check]",
				zap.Any("error", r))
		}
		OrderStuckChecker.Check(daos.Rc)
	}()

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[OrderStuckChecker.Subscribe]",
				zap.Any("error", r))
		}
		OrderStuckChecker.Subscribe(daos.Rc)
	}()

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[GlobalDispatcherBus.Listen]",
				zap.Any("error", r))
		}
		GlobalDispatcherScheduler.Listen()
	}()

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[GlobalCallbackBus.Listen]",
				zap.Any("error", r))
		}
		GlobalCallbackBus.Listen()
	}()

	go func() {
		if r := recover(); r != nil {
			logger.Log.Error("[RunTimePrint]",
				zap.Any("error", r))
		}
		RunTimePrint()
	}()

	inHandleOrders := make(map[int64]struct{})
	tStart := time.Now().Add(-15 * time.Hour)
	// 查找15分钟内处于处理中的渠道订单
	params := vo.ChannelOrderListParam{
		Base: utils.LimitCond{
			StartTime: tStart,
			EndTime:   time.Now().Add(20 * time.Hour),
		},
		InStatusChoice: []int{int(constant.OrderStatusHandle)},
		NoWithCount:    true,
		AreaChoice:     -1,
	}
	channelOrders, _, _ := partition.GlobalChannelOrderPartition.List(params)
	for _, channelOrder := range channelOrders {
		inHandleOrders[channelOrder.OrderID] = struct{}{}
		logger.Log.Info("Init QryOrderWithFeedBack",
			zap.Int64("orderID", channelOrder.OrderID))
		go QryOrderWithFeedBack(channelOrder)
	}

	go func() {

		// 查找15分钟内处于初始化的订单
		params := vo.OrderListParam{
			Base: utils.LimitCond{
				StartTime: tStart,
				EndTime:   time.Now(),
			},
			InStatusChoice: []int{constant.OrderStatusInit, constant.OrderStatusHandle},
			NoWithCount:    true,
			AreaChoice:     -1,
		}

		orders, _, _ := partition.GlobalOrderPartition.List(params)
		logger.Log.Info("Init OrderReDispatcher",
			zap.Int("count", len(orders)))
		for _, order := range orders {
			logger.Log.Info("Init OrderReDispatcher",
				zap.Int64("orderID", order.ID))

			if _, ok := inHandleOrders[order.ID]; ok {
				continue
			}

			go func() (err error) {
				// 删除没有下发到渠道的初始化订单
				params := vo.ChannelOrderListParam{
					Base: utils.LimitCond{
						StartTime: tStart,
						EndTime:   time.Now(),
					},
					InStatusChoice: []int{int(constant.OrderNotifyInit)},
					OrderIDSearch:  utils.Violent2String(order.ID),
					NoWithCount:    true,
					AreaChoice:     -1,
				}
				channelOrders, _, _ := partition.GlobalChannelOrderPartition.List(params)
				for _, channelOrder := range channelOrders {
					partition.GlobalChannelOrderPartition.UnscopeDelete(channelOrder.ID)
				}

				var has bool
				var customer models.Customer
				if has, err = cache.FromModelPk(models.Customer{}.TableName(), cache.CustomerPk(order.CustomerID), &customer, cache.FromDatabaseGet); !has || err != nil {
					logger.Log.Info("orderModel",
						zap.Int64("channelOrderId", order.ID),
						zap.Int64("CustomerID", order.CustomerID),
						zap.Bool("has", has),
						zap.Error(err),
					)
					return
				}
				var customerPro models.CustomerProduct
				has, err = cache.FromModelPk(customerPro.TableName(), cache.CustomerProductPk(order.CustomerID, order.ProductCode), &customerPro, cache.FromDatabaseGet)
				if !has || err != nil {
					logger.Log.Info("orderModel",
						zap.Int64("channelOrderId", order.ID),
						zap.Int64("CustomerID", order.CustomerID),
						zap.String("product code", order.ProductCode),
						zap.Bool("has", has),
						zap.Error(err),
					)
					return
				}

				session := daos.Mysql.NewSession()
				session.Close()
				var deductFinanced bool
				if deductFinanced, err = daos.Exist(session, &models.CustomerFinance{}, 0, map[string]any{
					"order_id":      order.ID,
					"customer_id":   order.CustomerID,
					"business_type": constant.CUSTOMER_FINANCE_TYPE_DEDUCT,
					"finish":        0,
				}); err != nil {
					logger.Log.Info("orderModel",
						zap.Int64("orderID", order.ID),
						zap.Bool("deductFinanced", deductFinanced),
						zap.Error(err),
					)
					return
				}

				e := echo.New()
				ctx := e.AcquireContext()
				defer e.ReleaseContext(ctx)
				var dispatcher *Dispatcher
				if dispatcher, err = NewDispatcher(customer, &order, customerPro, nil, time.Time{}, 0, ctx); err != nil {
					logger.Log.Info("orderModel",
						zap.Int64("channelOrderId", order.ID),
						zap.Error(err),
					)
					return
				}
				if err = dispatcher.ChannelFilter(ChannelProductMatchFilter, ChannelGroupSortFilter, ChannelDupFilter); err != nil {
					logger.Log.Info("orderModel",
						zap.Int64("channelOrderId", order.ID),
						zap.Error(err))
					return
				}

				if !dispatcher.HasChannel() {
					logger.Log.Error("InitOrder DeductFinance HasChannel")
					dispatcher.Fail(map[string]any{
						"remark":      "没有匹配渠道",
						"finish_time": time.Now(),
					})
					return
				}

				// 没有进行扣款
				if !deductFinanced {
					logger.Log.Info("orderModel",
						zap.Int64("orderID", order.ID),
						zap.Bool("deductFinanced", deductFinanced),
						zap.Error(err),
					)

					financeParam := vo.CustomerFinanceParam{
						CustomerID:      order.CustomerID,
						Amount:          order.SalePrice,
						RechargeAmount:  order.Price,
						IsRecharging:    true,
						IsFinish:        false,
						Remark:          fmt.Sprintf("订单充值扣款,订单ID: %d", order.ID),
						OrderID:         utils.Violent2String(order.ID),
						CustomerOrderID: order.CustomerOrderID,
					}
					if _, err = NewCustomerFinanceService(&ctx).DeductFinance(financeParam); err != nil {
						logger.Log.Error("InitOrder DeductFinance", zap.Any("financeParam", financeParam), zap.Error(err))
						dispatcher.Fail(map[string]any{
							"remark":      fmt.Sprintf("扣款失败：%s", err.Error()),
							"finish_time": time.Now(),
						})
						return
					}
				}

				dispatcher.SendToBus(true)
				return
			}()
		}
	}()
}

/*func init() {
	AdminLogChan = make(chan *models.Adminlog, 1000)
	go func() {
		for {
			select {
			case bean := <-AdminLogChan:
				// 查询菜单标题
				menu := mysql.Menu.GetBeanByMethodUrl(bean.Method, bean.Url)
				if nil != menu {
					if "S" == menu.Classification {
						continue
					}
					name := findParentMenuName(menu.ID)
					bean.Name = name
				}
				// 添加操作日志
				mysql.Adminlog.InsertBean(bean)
			}
		}
	}()
}

func findParentMenuName(mid int64) string {
	name := ""
	m, _ := mysql.Menu.GetBeanById(mid)
	if m != nil {
		name = m.MenuName
		if 0 != m.ParentId {
			name = findParentMenuName(m.ParentId) + " / " + name
		}
	}
	return name
}*/
