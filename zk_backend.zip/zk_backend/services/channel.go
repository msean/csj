package services

import (
	"application/common/logger"
	"application/conf"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services/cache"
	"application/template"
	"application/utils"
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/jinzhu/copier"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	ChannelService struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewChannelService(ctx *echo.Context) *ChannelService {
	bean := &ChannelService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

// func (srv *ChannelService) GetChannelM(contain []int64, except []int64) (channelM map[int64]models.Channel, err error) {
// 	channelM = make(map[int64]models.Channel)
// 	var channels []models.Channel
// 	if channels, err = mysql.Channel.ListOnlineChannel(contain, except); err != nil {
// 		return
// 	}
// 	for _, _chan := range channels {
// 		channelM[_chan.ID] = _chan
// 	}
// 	return
// }

func (srv *ChannelService) FromID(id int64) (channel models.Channel, has bool, err error) {
	return mysql.Channel.FromID(id)
}

func (srv *ChannelService) Create(params vo.ChannelCreateParams) (channel models.Channel, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelService] [Create]", zap.Any("params", params), zap.Error(err))
		}
	}()

	if err = copier.Copy(&channel, &params); err != nil {
		return
	}

	channel.LimitConfig = channel.LimitDefault()
	if err = mysql.Channel.Create(&channel); err != nil {
		return
	}

	ChannelFinanceScheduler.AddChannel(channel)
	// ChannelLimiter Set
	for _, channelLimit := range channel.LimitConfig {
		ChannelLimiter.Add(channel.ID, int(channelLimit.Type), int(channelLimit.FrequencyLimit))
	}
	return
}

func (srv *ChannelService) Delete(idList []int64) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelService] [Delete]", zap.Int64s("idList", idList), zap.Error(err))
		}
	}()

	var channels []models.Channel
	if channels, _, err = srv.List(vo.ChannelListParams{IDList: idList}); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()
	if err = session.Begin(); err != nil {
		return
	}

	if _, err = daos.DelObjs(session, idList, models.Channel{}); err != nil {
		session.Rollback()
		return
	}

	// ChannelLimiter Set
	for _, channel := range channels {
		if err = cache.DelCacheModelPk(channel.TableName(), cache.ChannelPk(channel.ID)); err != nil {
			session.Rollback()
			return
		}
		ChannelFinanceScheduler.DeleteChannel(channel)
		for _, channelLimit := range channel.LimitConfig {
			ChannelLimiter.Remove(channel.ID, int(channelLimit.Type))
		}
	}

	return session.Commit()
}

func (srv *ChannelService) Update(params vo.ChannelUpdateParams) (channel models.Channel, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelService] [Update]", zap.Any("params", params), zap.Error(err))
		}
	}()

	if err = copier.Copy(&channel, &params); err != nil {
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if _, err = daos.UpdateObjWithVersion(session, channel, nil, "limit_config"); err != nil {
		return
	}

	ChannelFinanceScheduler.DeleteChannel(channel)
	ChannelFinanceScheduler.AddChannel(channel)
	if err = cache.UpdateCacheModelPk(channel.TableName(), cache.ChannelPk(channel.ID), &models.Channel{}, true); err != nil {
		cache.DelCacheModelPk(channel.TableName(), cache.ChannelPk(channel.ID))
		return
	}
	return
}

func (srv *ChannelService) List(params vo.ChannelListParams) (channels []models.Channel, total int64, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelService] [List]", zap.Any("params", params), zap.Error(err))
		}
	}()

	channels, total, err = mysql.Channel.ListByParams(params)
	return
}

func (srv *ChannelService) Export(params vo.ChannelListParams) (filePath string, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelService] [Export]", zap.Any("params", params), zap.Error(err))
		}
	}()

	filePath = fmt.Sprintf("%d渠道.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d渠道.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var objs []models.Channel
	if objs, _, err = mysql.Channel.ListByParams(params); err != nil {
		return
	}
	if len(objs) == 0 {
		objs = append(objs, models.Channel{})
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", objs, mysql.SysDict.DataValueLabelMapper())
	return
}

func (srv *ChannelService) UpdateThreadConfig(param vo.ChannelThreadUpdateParams) (err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[ChannelService] [UpdateThreadConfig]", zap.Any("param", param), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = mysql.Channel.UpdateLimitConfig(session, param.ID, param.ThreadConfig); err != nil {
		return
	}

	var channel models.Channel
	var has bool
	if channel, has, err = mysql.Channel.FromID(channel.ID); !has || err != nil {
		logger.Log.Error("UpdateThreadConfig", zap.Bool("has", has), zap.Error(err))
		return
	}
	ChannelFinanceScheduler.DeleteChannel(channel)
	ChannelFinanceScheduler.AddChannel(channel)
	// ChannelLimiter Set
	for _, channelLimiterConf := range param.ThreadConfig {
		ChannelLimiter.Reset(param.ID, int(channelLimiterConf.Type), int(channelLimiterConf.FrequencyLimit))
	}

	return
}

func (srv *ChannelService) TemplateDescriptions() (rsp []resp.TemplateDescribeRsp, err error) {
	rsp, err = template.ConfigDescribe()
	return
}

// func (srv *ChannelService) UpdateTemplateDescription(param vo.TemplateUpdateParams) (err error) {
// 	err = template.UpdateTemplateDescription(param)
// 	return
// }

// func (srv *ChannelService) DeleteTemplateDescription(param vo.DeleteParams) (err error) {
// 	session := daos.Mysql.NewSession()
// 	defer session.Close()

//		_, err = daos.DelObjs(session, param.IDList, &models.TemplateDescription{})
//		return
//	}
type ScheduleChannelFinance struct {
	mu           sync.Mutex
	channelTasks map[int64]*time.Ticker
	cancelFuncs  map[int64]context.CancelFunc
}

func NewScheduleChannelFinance() ScheduleChannelFinance {
	return ScheduleChannelFinance{
		channelTasks: make(map[int64]*time.Ticker),
		cancelFuncs:  make(map[int64]context.CancelFunc),
	}
}

func GetFrequencyLimit(channel models.Channel) (d time.Duration, err error) {
	var limitConfig models.ChannelLimit
	if limitConfig, err = channel.GetByType(3); err != nil {
		return
	}
	d = time.Duration(int64(limitConfig.FrequencyLimit)) * time.Second
	return
}

func (scheduler *ScheduleChannelFinance) Init() {

	var channels []models.Channel
	session := daos.Mysql.NewSession()
	defer session.Close()

	err := utils.Find(session, &channels, utils.NewWhereCond("online", 2))
	if err != nil {
		logger.Log.Error("ScheduleQryFinance Init", zap.Error(err))
		return
	}

	for _, channel := range channels {
		ctx, cancel := context.WithCancel(context.Background())
		scheduler.cancelFuncs[channel.ID] = cancel
		go scheduler.ScheduleQryFinance(ctx, channel)
	}
}

func (scheduler *ScheduleChannelFinance) Stop(channelID int64) {
	scheduler.mu.Lock()
	defer scheduler.mu.Unlock()

	if cancel, exists := scheduler.cancelFuncs[channelID]; exists {
		cancel() // 终止 Goroutine
		delete(scheduler.cancelFuncs, channelID)
	}
}

func (scheduler *ScheduleChannelFinance) ScheduleQryFinance(ctx context.Context, channel models.Channel) error {
	scheduler.mu.Lock()
	freq, err := GetFrequencyLimit(channel)
	if err != nil {
		scheduler.mu.Unlock()
		return err
	}

	ticker := time.NewTicker(freq)
	scheduler.channelTasks[channel.ID] = ticker
	scheduler.mu.Unlock()

	logger.Log.Info("ScheduleQryFinance", zap.Int64("channelID", channel.ID), zap.Duration("freq", freq))

	for {
		select {
		case <-ctx.Done():
			logger.Log.Info("Stopping ScheduleQryFinance", zap.Int64("channelID", channel.ID))
			return nil

		case <-ticker.C:
			if err = template.QryChannelFinance(&channel); err != nil {
				logger.Log.Error("ScheduleQryFinance", zap.Int64("channelID", channel.ID), zap.Error(err))
			}

		}
	}
}

func (scheduler *ScheduleChannelFinance) AddChannel(channel models.Channel) {
	if channel.Online != 2 {
		return
	}
	scheduler.mu.Lock()
	defer scheduler.mu.Unlock()

	if _, exists := scheduler.cancelFuncs[channel.ID]; exists {
		return
	}

	freq, err := GetFrequencyLimit(channel)
	if err != nil {
		logger.Log.Error("AddChannel: failed to get frequency limit", zap.Int64("channelID", channel.ID), zap.Error(err))
		return
	}

	ctx, cancel := context.WithCancel(context.Background())
	scheduler.cancelFuncs[channel.ID] = cancel

	go scheduler.ScheduleQryFinance(ctx, channel)

	logger.Log.Info("ScheduleChannelFinance AddChannel", zap.Int64("channelID", channel.ID), zap.Duration("freq", freq))
}

func (scheduler *ScheduleChannelFinance) DeleteChannel(channel models.Channel) {
	scheduler.mu.Lock()
	defer scheduler.mu.Unlock()

	if cancel, exists := scheduler.cancelFuncs[channel.ID]; exists {
		cancel()

		delete(scheduler.cancelFuncs, channel.ID)

		if ticker, exists := scheduler.channelTasks[channel.ID]; exists {
			ticker.Stop()
			delete(scheduler.channelTasks, channel.ID)
		}

		logger.Log.Info("ScheduleChannelFinance Delete", zap.Int64("channelID", channel.ID))
	}
}
