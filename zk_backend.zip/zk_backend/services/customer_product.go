package services

import (
	"application/daos/mysql"
	"application/models"
	"application/models/logic"
	"application/models/vo"
	"application/services/cache"
	"application/utils"
	"errors"
	"fmt"
	"math"
	"strings"
	"time"

	"github.com/labstack/echo"
)

type (
	CustomerProductService struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func (s *CustomerProductService) isUpdateIds(ids []int64) bool {
	return ids == nil || len(ids) <= 0 || ids[0] > 0
}

func (s *CustomerProductService) makeProduct(customerID int64, customerName string, product *models.Product) *models.CustomerProduct {
	obj := &models.CustomerProduct{CustomerID: customerID, CustomerName: customerName}
	obj.Code = product.ID
	obj.Name = product.Name
	obj.ProductCode = product.Code
	obj.ProductPrice = product.Price
	obj.ProductValue = product.FaceValue
	obj.ProductArea = product.Area
	obj.ProductType = product.BigType
	obj.ProductSubType = product.SmallType
	obj.ProductIsp = product.Isp
	return obj
}

func (s *CustomerProductService) makeProductVo(obj *models.CustomerProduct) *vo.CustomerProductVo {
	return &vo.CustomerProductVo{
		ID:               obj.ID,
		CustomerID:       obj.CustomerID,
		CustomerName:     obj.CustomerName,
		Name:             obj.Name,
		Cert:             obj.Cert,
		CalType:          obj.CalType,
		CalValue:         obj.CalValue,
		SalePrice:        obj.SalePrice,
		BackMoney:        obj.BackMoney,
		Discount:         utils.FloatReserve(obj.Discount, 2),
		TaxType:          obj.TaxType,
		Available:        obj.Available,
		AvailableTick:    obj.AvailableTick,
		ProductCode:      obj.ProductCode,
		ProductValue:     obj.ProductValue,
		ProductPrice:     obj.ProductPrice,
		ProductType:      obj.ProductType,
		ProductSubType:   obj.ProductSubType,
		ProductIsp:       obj.ProductIsp,
		ProductArea:      obj.ProductArea,
		ChannelGroupID:   obj.ChannelGroupID,
		ChannelIds:       obj.ChannelIds,
		FirstChannelIds:  obj.FirstChannelIds,
		SecondChannelIds: obj.SecondChannelIds,
		ForbidChannelIds: obj.ForbidChannelIds,
	}
}

// Convert int64 slice to string representation for SQL
func int64ArrayToString(arr []int64) string {
	if len(arr) == 0 {
		return `[]`
	}
	var strArr []string
	for _, v := range arr {
		strArr = append(strArr, fmt.Sprintf("%d", v))
	}
	return fmt.Sprintf("[%s]", strings.Join(strArr, ","))
}

func (s *CustomerProductService) updateProduct(product *models.CustomerProduct, params vo.CustomerProductParam) (*models.CustomerProduct, string) {

	var updates []string

	if params.ChannelGroupID >= 0 {
		product.ChannelGroupID = params.ChannelGroupID
		updates = append(updates, fmt.Sprintf("channel_group_id = %d", params.ChannelGroupID))
	}

	if s.isUpdateIds(params.ChannelIDs) {
		product.ChannelIds = params.ChannelIDs
		updates = append(updates, fmt.Sprintf("channel_ids = '%s'", int64ArrayToString(params.ChannelIDs)))
	}

	if s.isUpdateIds(params.FirstChannelIds) {
		product.FirstChannelIds = params.FirstChannelIds
		updates = append(updates, fmt.Sprintf("first_channel_ids = '%s'", int64ArrayToString(params.FirstChannelIds)))
	}

	if s.isUpdateIds(params.SecondChannelIds) {
		product.SecondChannelIds = params.SecondChannelIds
		updates = append(updates, fmt.Sprintf("second_channel_ids = '%s'", int64ArrayToString(params.SecondChannelIds)))
	}

	if s.isUpdateIds(params.ForbidChannelIds) {
		product.ForbidChannelIds = params.ForbidChannelIds
		updates = append(updates, fmt.Sprintf("forbid_channel_ids = '%s'", int64ArrayToString(params.ForbidChannelIds)))
	}

	if params.Available >= 0 {
		if params.Available >= 1 {
			product.Available = true
		} else {
			product.Available = false
		}
		updates = append(updates, fmt.Sprintf("available = %t", product.Available))
	}

	if params.Cert > 0 {
		product.Cert = params.Cert
		updates = append(updates, fmt.Sprintf("cert = %d", params.Cert))
	}

	if params.TaxType > 0 {
		product.TaxType = params.TaxType
		updates = append(updates, fmt.Sprintf("tax_type = %d", params.TaxType))
	}

	if params.BackMoney >= 0 {
		product.BackMoney = params.BackMoney
		updates = append(updates, fmt.Sprintf("back_money = %.2f", params.BackMoney))
	}

	if params.CalType > 0 {
		product.CalType = params.CalType
		product.CalValue = params.CalValue
		product.SalePrice = math.Max(utils.CalByType(product.ProductPrice, params.CalValue, params.CalType), 0)
		product.Discount = utils.FloatReserve(product.SalePrice/product.CalValue, 2)
		updates = append(updates, fmt.Sprintf("cal_type = %d, cal_value = %.2f, sale_price = %.2f, discount = %.2f",
			params.CalType, params.CalValue, product.SalePrice, product.Discount))
	}

	if params.AvailableTick >= 0 {
		product.AvailableTick = params.AvailableTick
	}

	sql := fmt.Sprintf("UPDATE xj_customer_product SET %s WHERE id = %d", strings.Join(updates, ", "), product.ID)
	return product, sql
}

func NewCustomerProdSrv(ctx *echo.Context) *CustomerProductService {
	bean := &CustomerProductService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (s *CustomerProductService) CheckProductParams(params vo.CustomerProductParam) error {
	// todo: check params ----------------------------
	return nil
}

func (s *CustomerProductService) QueryCustomerProduct(params vo.CustomerProductQueryParam) (*vo.CustomerProductQueryRes, error) {
	count, res, err := mysql.CustomerProduct.QueryCustomerProduct(params)
	if err != nil {
		return nil, errors.New("query customer product error, " + err.Error())
	}

	data := make([]*vo.CustomerProductVo, 0)
	if count > 0 {
		for _, obj := range res {
			data = append(data, s.makeProductVo(obj))
		}
	}

	channels := make([]*vo.CustomerProductChannelVo, 0)
	groups := make([]*vo.CustomerProductChannelVo, 0)
	if params.NeedChannelData {
		channelObjs, count, _ := NewChannelService(s.Ctx).List(vo.ChannelListParams{})
		if count > 0 {
			for _, channel := range channelObjs {
				channels = append(channels, &vo.CustomerProductChannelVo{ID: channel.ID, Name: channel.Name})
			}
		}

		groupObjs, count, _ := NewChannelGroupSrv(s.Ctx).List(vo.ChannelGroupListParams{})
		if count > 0 {
			for _, group := range groupObjs {
				groups = append(groups, &vo.CustomerProductChannelVo{ID: group.ID, Name: group.Name})
			}
		}
	}

	return &vo.CustomerProductQueryRes{Count: count, Products: data, Channels: channels, ChannelGroups: groups}, nil
}

func (s *CustomerProductService) CreateCustomerProduct(customer *models.Customer, params vo.CustomerProductCreateParam) ([]*models.CustomerProduct, []string) {
	var errs []string
	var objs []*models.CustomerProduct
	for _, code := range params.Codes {
		codeObj, err := mysql.Product.GetBeanById(code)
		if err == nil {
			obj := s.makeProduct(params.CustomerID, customer.Name, codeObj)
			bean, _ := s.updateProduct(obj, params.CustomerProductParam)
			err = mysql.CustomerProduct.InsertBean(utils.UserId(*s.Ctx), bean)
			if err == nil {
				objs = append(objs, obj)
			}
		}

		if err != nil {
			errs = append(errs, err.Error())
		}
	}

	return objs, errs
}

func (s *CustomerProductService) UpdateCustomerProduct(id int64, params vo.CustomerProductParam) (*models.CustomerProduct, error) {

	doneFunc := func() {
		cache.OprCustomerProductCache([]int64{id}, 1)
	}

	obj, err := mysql.CustomerProduct.GetBeanById(id)
	if err != nil {
		return nil, errors.New("query error, " + err.Error())
	}

	bean, sql := s.updateProduct(obj, params)
	if params.AvailableTick == 0 {
		err = mysql.CustomerProduct.UpdateBean(utils.UserId(*s.Ctx), bean)
		if err != nil {
			return nil, errors.New("update error, " + err.Error())
		}
		doneFunc()
	} else {
		t := time.Unix(params.AvailableTick/1000, 0)
		if t.After(time.Now().Add(-1 * time.Minute)) {
			delayTask := models.DelayTask{
				Table:    models.CustomerProduct{}.TableName(),
				Pk:       utils.Violent2String(obj.ID),
				Sql:      sql,
				ExecTime: t,
				Remark:   params.Remark,
			}
			delayTask.Mutate()
			delayTask.CreateBy = utils.UserId(*s.Ctx)
			Add2DelayScheduler(delayTask, true, doneFunc)
		}
	}

	return obj, nil
}

func (s *CustomerProductService) RemoveCustomerProduct(productIDs []int64) (int64, error) {
	count, err := mysql.CustomerProduct.DeleteBeanByIds(productIDs)
	if err != nil {
		return 0, errors.New("delete error, " + err.Error())
	}

	if count <= 0 {
		return 0, errors.New("can't find")
	}

	return count, nil
}

// todo: check api ----------------------
func (s *CustomerProductService) Decompose(customerProd models.CustomerProduct) (channelSorts []logic.ChannelSort, err error) {
	var excepts []int64
	var all []int64
	for i := 0; i < 3; i++ {
		channelSorts = append(channelSorts, logic.NewChannelSort())
	}

	channelM := make(map[int64]models.Channel)
	var channelGroup models.ChannelGroup

	if len(customerProd.ChannelIds) != 0 {
		all = append(all, customerProd.ChannelIds...)
	} else {
		if channelGroup, _, err = new(ChannelGroupSrv).FromID(int64(customerProd.ChannelGroupID)); err != nil {
			return
		}
		for _, groupChannelRel := range channelGroup.Rels {
			all = append(all, groupChannelRel.ChannelID)
		}
	}
	all = append(all, customerProd.FirstChannelIds...)
	all = append(all, customerProd.SecondChannelIds...)
	excepts = append(excepts, customerProd.ForbidChannelIds...)

	// if channelM, err = new(ChannelService).GetChannelM(all, excepts); err != nil {
	// 	return
	// }

	if channelM, err = cache.GetOnlineChannelM(all, excepts); err != nil {
		return
	}

	for _, channelID := range customerProd.FirstChannelIds {
		if channel, in := channelM[channelID]; in {
			channelSorts[0].Channels = append(channelSorts[0].Channels, channel.ID)
			channelSorts[0].Percent = append(channelSorts[0].Percent, 1)
		}
	}

	if len(customerProd.ChannelIds) > 0 {
		for _, channelID := range customerProd.ChannelIds {
			if channel, in := channelM[channelID]; in {
				channelSorts[1].Channels = append(channelSorts[1].Channels, channel.ID)
				channelSorts[1].Percent = append(channelSorts[1].Percent, 1)
			}
		}
	} else {
		channelSorts[1].SortType = channelGroup.SortType
		for _, rel := range channelGroup.Rels {
			channel, in := channelM[rel.ChannelID]
			if in {
				channelSorts[1].Channels = append(channelSorts[1].Channels, channel.ID)
				channelSorts[1].Percent = append(channelSorts[1].Percent, int(rel.Percent))
			}
		}

	}

	for _, channelID := range customerProd.SecondChannelIds {
		if channel, in := channelM[channelID]; in {
			channelSorts[2].Channels = append(channelSorts[2].Channels, channel.ID)
			channelSorts[2].Percent = append(channelSorts[2].Percent, 1)
		}
	}
	return
}
