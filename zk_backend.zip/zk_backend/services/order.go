package services

import (
	"application/common/logger"
	"application/conf"
	"application/constant"
	_constant "application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/models/vo/api"
	"application/services/cache"
	"application/utils"
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	OrderService struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewOrderService(ctx *echo.Context) *OrderService {
	bean := &OrderService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *OrderService) List(param vo.OrderListParam) (rsp []resp.OrderRsp, total int64, err error) {

	defer func() {
		if err != nil {
			logger.Log.Error("[OrderService] [Return]", zap.Any("param", param), zap.Error(err))
		}
	}()

	customerID := utils.CustomerID(*srv.Ctx)
	isSuper := utils.IsSuperAdmin(*srv.Ctx)

	if !isSuper {
		if customerID != 0 {
			param.CustomerChoice = customerID
		}
	}
	var orderModels []models.Order
	if orderModels, total, err = partition.GlobalOrderPartition.List(param); err != nil {
		return
	}
	var customerIDList []int64
	var ProductCodeList []string
	var channelIDList []int64
	for _, orderModel := range orderModels {
		customerIDList = append(customerIDList, orderModel.CustomerID)
		ProductCodeList = append(ProductCodeList, orderModel.ProductCode)
		channelIDList = append(channelIDList, orderModel.CurrentChannelID)
	}

	customerM, _ := mysql.Customer.FromIDList(utils.DedupeInt64Slice(customerIDList))
	productM, _ := mysql.Product.FromCodes(utils.DedupeStringSlice(ProductCodeList))
	channelM, _ := mysql.Channel.FromIDList(utils.DedupeInt64Slice(channelIDList))

	for _, orderModel := range orderModels {
		rsp = append(rsp, srv.Fill(orderModel, customerM[orderModel.CustomerID], productM[orderModel.ProductCode], channelM[orderModel.CurrentChannelID]))
	}
	return
}

// 退单操作
func (srv *OrderService) Return(param vo.OrderReturnParam) (affect int64, err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[OrderService] [Return]", zap.Any("param", param), zap.Error(err))
		}
	}()

	_session := daos.Mysql.NewSession()
	defer _session.Close()

	if affect, err = partition.GlobalOrderPartition.UpdateReturn(_session, param.IDList); err != nil {
		return
	}

	for _, id := range param.IDList {
		func() {
			GlobalDispatcherScheduler.RemoveByOrderID(id)
			var order models.Order
			var has bool

			order, has, err = partition.GlobalOrderPartition.FromID(_session, id)
			if err != nil {
				return
			}
			if !has {
				return
			}
			if err := partition.GlobalOrderPartition.Update(_session, order, map[string]any{
				"remark":       "手动退单",
				"has_returned": 2,
			}); err != nil {
				logger.Log.Error("[Dispatcher] [ModifyStatus]", zap.Error(err), zap.Int64("order id", order.ID))
				return
			}
			cache.Save2SetCache(cache.SetReturnOrderTable(), cache.ReturnOrderObj(id))
			// go NewOrderService(srv.Ctx).OrderBackMoney(order)
			// go PublishOrderStuck(order)
		}()
	}
	return
}

func (srv *OrderService) Fill(
	orderModel models.Order,
	customer models.Customer,
	product models.Product,
	channel models.Channel,
) (orderRsp resp.OrderRsp) {
	var take string
	if orderModel.Status == constant.OrderStatusFail || orderModel.Status == constant.OrderStatusManual || orderModel.Status == constant.OrderStatusNoResult || orderModel.Status == constant.OrderStatusSuccess {
		take = utils.TimeSubString(orderModel.FinishTime, orderModel.Created)
	} else {
		take = utils.TimeSubString(time.Now(), orderModel.Created)
	}
	var backMsg string
	var requestInfo string
	if len(orderModel.BackMsg) > 0 {
		backMsg = orderModel.BackMsg[len(orderModel.BackMsg)-1]
		// 将回调参数转换为 JSON 字符串
		jsonBytes, err := json.Marshal(ComposeCallback(orderModel, customer))
		if err != nil {
			log.Printf("Failed to marshal callback params to JSON: %v", err)
			requestInfo = "{}" // 如果失败，返回一个空的 JSON 对象
		} else {
			requestInfo = string(jsonBytes) // 将 JSON 字符串赋值给 requestInfo
		}
	}
	var backTime string
	if !orderModel.CurrentBackTime.IsZero() {
		backTime = orderModel.CurrentBackTime.Format("2006-01-02 15:04:05")
	}

	// var has bool
	// var callbackLength int
	// callbackLength, has = utils.MinInt(len(orderModel.BackStatus), len(orderModel.BackTime), len(orderModel.BackMsg))

	// var callback []string
	// if has {
	// 	for i := 0; i < callbackLength; i++ {
	// 		backStatusString := "失败"
	// 		if orderModel.BackStatus[i] == 2 {
	// 			backStatusString = "成功"
	// 		}
	// 		callback = append(callback, fmt.Sprintf("第%d次回调: 回调时间 %s \n,回调状态 %s \n, 回调信息:%s", i+1, orderModel.BackTime[i].Format("2006-01-02 15:04:05"), backStatusString, orderModel.BackMsg[i]))
	// 	}
	// }
	// 定义格式为 "2006-01-02 15:04:05"
	// var callbackMsg string

	orderRsp = resp.OrderRsp{
		OrderID:         orderModel.ID,
		CustomerOrderID: orderModel.CustomerOrderID,
		Customer:        customer.Name,
		Phone:           orderModel.Phone,
		Area:            orderModel.Area,
		Product:         product.Name,
		Isp:             int64(orderModel.Isp),
		ImportPrice:     orderModel.InPrice,
		OrderStatus:     orderModel.Status,
		CurrentChannel:  channel.Name,
		Created:         orderModel.Created,
		Voucher:         orderModel.Voucher,
		VoucherType:     orderModel.VoucherType,
		Remark:          orderModel.Remark,
		ManualRemark:    orderModel.ManualRemark,
		BackStatus:      orderModel.CurrentBackStatus,
		HasReturned:     int(orderModel.HasReturned),
		FaceValue:       uint(orderModel.FaceValue),
		Province:        orderModel.Province,
		FinishTime:      orderModel.FinishTime,
		SalasPrice:      orderModel.SalePrice,
		Take:            take,
		BackUrl:         orderModel.BackUrl,
		BackTime:        backTime,
		BackTimes:       len(orderModel.BackTime),
		FeedBack:        backMsg,
		RequestInfo:     requestInfo,
	}
	return
}

func (srv *OrderService) FromID(id int64) (order models.Order, has bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = daos.ObjDetailByID(session, id, &order)
	return
}

func (srv *OrderService) FromCustomerOrderID(customerOrderID string) (order models.Order, has bool, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.Get(session, &order, utils.NewWhereCond("customer_order_id", customerOrderID))
	return
}

func (srv *OrderService) UpdateManualRemark(param vo.OrderUpdateManualRemarkParam) (err error) {
	defer func() {
		if err != nil {
			logger.Log.Error("[OrderService] [UpdateManualRemark]", zap.Any("param", param), zap.Error(err))
		}
	}()

	session := daos.Mysql.NewSession()
	defer session.Close()

	return partition.GlobalOrderPartition.UpdateRemark(session, param.ID, param.Remark)
}
func (srv *OrderService) Statistics(params vo.FinanceMonthQueryParams) (result *vo.FinanceOrderStatistics, err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	var orderIDList []int64
	var orders []models.Order
	// 根据日期范围动态获取需要查询的分区表名
	// var start time.Time
	// var end time.Time

	// if start, err = time.Parse(utils.YYMMDDSecondDash, params.StartTime); err != nil {
	// 	return
	// }

	// if end, err = time.Parse(utils.YYMMDDSecondDash, params.EndTime); err != nil {
	// 	return
	// }
	tables, err := partition.GlobalOrderPartition.GetTablesByDateRange(session, params.StartTime, params.EndTime)
	if err != nil {
		logger.Log.Error("[OrderService] [Statistics] - GetTablesByDateRange", zap.Error(err))
		return nil, err
	}

	// 构建动态 SQL 查询
	var queryParts []string
	var queryParams []interface{} // 用来保存所有参数
	for _, table := range tables {
		// 为每个表的查询添加参数
		queryParts = append(queryParts, fmt.Sprintf(
			"SELECT * FROM %s WHERE customer_id = ? AND created BETWEEN ? AND ?",
			table,
		))
		// 添加参数到 queryParams
		queryParams = append(queryParams, params.CustomerID, params.StartTime, params.EndTime)
	}

	// 将多个查询通过 UNION ALL 合并
	query := strings.Join(queryParts, " UNION ALL ")

	// 执行查询并传递参数
	err = session.SQL(query, queryParams...).Find(&orders)
	if err != nil {
		logger.Log.Error("[OrderService] [Statistics] - Query Orders", zap.Error(err))
		return nil, err
	}

	totalSuccessOrders := uint(0)
	totalSuccessFaceValue := 0
	totalSuccessValue := 0.0
	transaction := 0.0

	for _, order := range orders {
		if order.Status == constant.OrderStatusSuccess {
			totalSuccessFaceValue += order.FaceValue
			totalSuccessValue += order.SalePrice
			totalSuccessOrders += 1
		}
		transaction += order.SalePrice
		orderIDList = append(orderIDList, order.ID)
	}

	var finances []models.CustomerFinance
	delayBack := 0.0
	if err = session.Where("customer_id = ? AND business_type = ?  and created>=?",
		params.CustomerID,
		constant.CUSTOMER_FINANCE_TYPE_BACK,
		params.EndTime.Local(),
	).In("order_id", orderIDList).Find(&finances); err != nil {
		logger.Log.Error("[OrderService] [Statistics] - Refund Query", zap.Error(err))
		return nil, err
	}
	for _, finance := range finances {
		delayBack += float64(finance.Amount)
	}

	// 客户开始时间之前下单，对账时间段内退款金额
	var _finance []models.CustomerFinance
	previousOrderRefund := 0.0
	if err = session.Where("customer_id = ? AND business_type = ?  AND created BETWEEN ? AND ?",
		params.CustomerID,
		3,
		params.StartTime.Local(),
		params.EndTime.Local(),
	).NotIn("order_id", orderIDList).Find(&_finance); err != nil {
		logger.Log.Error("[OrderService] [Statistics] - Refund Query", zap.Error(err))
		return nil, err
	}
	for _, finance := range _finance {
		previousOrderRefund += float64(finance.Amount)
	}

	// 计算失效退款金额
	totalInvalidRefund := 0.0
	for _, finance := range finances {
		totalInvalidRefund += finance.Amount
	}

	return &vo.FinanceOrderStatistics{
		Transaction: utils.FloatReserve(transaction, 4),
		Count:       totalSuccessOrders,
		Amount:      utils.FloatReserve(totalSuccessValue, 4),
		Value:       totalSuccessFaceValue,
		BelayBack:   utils.FloatReserve(delayBack, 4),
		Back:        utils.FloatReserve(previousOrderRefund, 4),
	}, nil
}

func (srv *OrderService) ReDispatch(param vo.OrderReDispatcherParam) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	orderMapper, err := partition.GlobalOrderPartition.FromIDList(session, param.IDList)
	for _, id := range param.IDList {
		defer func() {
			if err != nil {
				logger.Log.Error("[ReDispatch] [OrderReDispatcherParam]", zap.Any("id", id), zap.Error(err))
			}
		}()
		if order, in := orderMapper[id]; in {
			// 初始化、处理中才能
			if order.Status == constant.OrderStatusHandle || order.Status == constant.OrderStatusInit {
				err = ReDispatcher(*srv.Ctx, id, 0, nil, 0, 0)
			}
		}
	}
	return
}

func (srv *OrderService) Recharge(params api.CreateOrderParams, checkCustomer bool) (customer models.Customer, customerPro models.CustomerProduct, apiCode _constant.ApiCodeMsg) {
	RechargeConcurrency <- struct{}{}
	defer func() { <-RechargeConcurrency }()

	logger.Log.Info("Recharge params", zap.Any("params", params))
	// 客户检查
	var has bool
	var err error

	customerID, err := strconv.ParseInt(params.SzAgentID, 10, 64)
	if err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiCustomerNotExist)
		return
	}

	// 由于需要查询客户的余额，以数据库为准
	customer, has, err = mysql.Customer.FromID(customerID)
	// has, err = cache.FromModelPk(customer.TableName(), cache.CustomerPk(customerID), &customer)
	if err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAbnormal)
		return
	}
	if !has {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiCustomerNotExist)
		return
	}

	if !customer.ApiFlag && checkCustomer {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderProductApiClose)
		return
	}
	// 客户签名验证
	if checkCustomer && !params.ValidSign(customer.ApiKey) {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiSignErr)
		return
	}

	var product models.Product
	// product, has, err = mysql.Product.FromCode(params.SzProductId)
	has, err = cache.FromModelPk(product.TableName(), cache.ProductPk(params.SzProductId), &product, cache.FromDatabaseGet)
	if err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAbnormal)
		return
	}
	if !has {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderProductOff)
		return
	}
	if product.Online == 0 {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderProductOff)
		return
	}

	has, err = cache.FromModelPk(customerPro.TableName(), cache.CustomerProductPk(customerID, params.SzProductId), &customerPro, cache.FromDatabaseGet)
	// customerPro, has, err = mysql.CustomerProduct.FromCustomerAndPro(customerID, params.SzProductId)
	if err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAbnormal)
		return
	}
	if !has {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderClientProductOff)
		return
	}
	if !customerPro.Available {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderClientProductOff)
		return
	}

	if customer.TotalBalance+customer.Credit < customerPro.SalePrice {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderBalanceInStuff)
		return
	}

	// 黑名单验证
	// if yes, _ := NewBlacklistSvc(srv.Ctx).Contain(params.SzPhoneNum); yes {
	// 	apiCode = _constant.NewApiOrderBlacklistOrLimitMsg("号码在黑名单中")
	// 	return
	// }
	if yes, _ := cache.InSetCache(models.Blacklist{}.TableName(), params.SzPhoneNum); yes {
		apiCode = _constant.NewApiOrderBlacklistOrLimitMsg("号码在黑名单中")
		return
	}

	var checkedRepeat bool
	if customer.MaxOrder > 0 {
		// 充值次数超上限
		rsp, _, _ := partition.GlobalOrderPartition.List(vo.OrderListParam{
			CustomerChoice: customer.ID,
			Base: utils.LimitCond{
				StartTime: time.Now().AddDate(0, -2, 0),
			},
			StatusChoice: constant.OrderStatusSuccess,
			PhoneSearch:  params.SzPhoneNum,
			NoWithCount:  true,
			AreaChoice:   -1,
		})
		if uint(len(rsp)) >= customer.MaxOrder {
			apiCode = _constant.NewApiOrderTimeOverOrStuckMsg("号码提交上限")
			return
		}

		if customer.RepeatTimeout > 0 && len(rsp) > 0 {
			start := time.Now().Add(time.Duration(-customer.RepeatTimeout*uint(time.Second)) * time.Second)
			if rsp[0].Created.After(start) {
				apiCode = _constant.NewApiOrderTimeOverOrStuckMsg(fmt.Sprintf("%s 该号码提交频繁，请稍后再试", params.SzPhoneNum))
				return
			}
		}
		checkedRepeat = true
	}

	if customer.RepeatTimeout > 0 && !checkedRepeat {
		var has bool
		// var order models.Order
		start := time.Now().Add(time.Duration(-customer.RepeatTimeout) * time.Second)
		_, has, _ = partition.GlobalOrderPartition.GetPhoneLatest(params.SzPhoneNum, start)
		if has {
			// start := time.Now().Add(time.Duration(-customer.RepeatTimeout) * time.Second)
			// if order.Created.After(start) {
			apiCode = _constant.NewApiOrderTimeOverOrStuckMsg(fmt.Sprintf("%s 该号码提交频繁，请稍后再试", params.SzPhoneNum))
			return
			// }
		}
	}

	// 白名单检查
	if checkCustomer && !utils.IsBlankString(customer.Ip) && !strings.EqualFold(customer.Ip, "0.0.0.0") {
		c := *srv.Ctx
		if !utils.InCombineString(c.RealIP(), customer.Ip, ";") {
			logger.Log.Info("Recharge",
				zap.String("ip", c.RealIP()),
				zap.String("customer.Ip", customer.Ip),
				zap.Bool("strings.Contains(customer.Ip, ip)", strings.Contains(customer.Ip, c.RealIP())))
			apiCode = _constant.NewApiCodeMsg(_constant.ApiUnbindIp)
			return
		}
	}
	// 检查卡单阀值
	if customer.MaxPendingOrder > 0 && OrderStuckChecker.CustomerStuckCount(customerID) >= int(customer.MaxPendingOrder) {
		logger.Log.Error("[Recharge] [CustomerOrderStuck]",
			zap.Uint("MaxPendingOrder", customer.MaxPendingOrder),
			zap.Int("OrderStuckChecker.CustomerStuckCount(customerID)", OrderStuckChecker.CustomerStuckCount(customerID)),
			zap.Int64("customerID", customerID))
		apiCode = _constant.NewApiOrderTimeOverOrStuckMsg("下单频繁")
		return
	}

	// 设置order的area、province
	orderModel := new(models.Order)
	if area, ok := constant.AreaCodeStringM[int(product.Area)]; ok {
		orderModel.SetArea(area, area)
	}
	orderModel.SetIsp(params.NSortType)
	orderModel.SetByCustomerProd(customerPro)
	orderModel.SetByProduct(product)
	orderModel.SetByParams(params.SzOrderId, params.SzPhoneNum, params.Params, params.ThirdPhone, params.SzNotifyUrl)
	orderModel.SetByCustomer(customer)
	orderModel.Mutate()

	// 区域检查开关是否打开都需要做检查 不要问为什么 java说的
	areaChecked := fmt.Sprintf("%d_%d_%s", customerID, params.NSortType, orderModel.Province)
	// if yes, _ := mysql.AreaSuspend.InSuspend(customerID, int64(params.NSortType), _constant.SuspendTypeCustom, int64(constant.AreaCodeM[orderModel.Province])); yes {
	// 	apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAreaSuspend)
	// 	return
	// }

	areaSuspend := models.AreaSuspend{
		ApplyID: customerID,
		Isp:     int64(params.NSortType),
		Type:    _constant.SuspendTypeCustom,
		Area:    int64(constant.AreaCodeM[orderModel.Province]),
	}
	if yes, _ := cache.InSetCache(models.AreaSuspend{}.TableName(), cache.AreaSuspendObj(areaSuspend)); yes {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAreaSuspend)
		return
	}

	// 根据号段的运营商和地区进行核对检查 不要问为什么 java这么写的
	if customer.AreaFlag || customer.OperatorQueryFlag {
		area, has, err := mysql.AreaSection.Match(params.SzPhoneNum[0:7])
		if err == nil && has {
			if customer.OperatorQueryFlag {
				if area.Isp != params.NSortType {
					apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderIspFail)
					return
				}
			}

			if customer.AreaFlag && fmt.Sprintf("%d_%d_%s", customerID, area.Isp, area.Province) != areaChecked {
				if yes, _ := mysql.AreaSuspend.InSuspend(customerID, int64(area.Isp), _constant.SuspendTypeCustom, int64(constant.AreaCodeM[orderModel.Province])); yes {
					apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAreaPhoneSuspend)
					return
				}
			}
		}
	}

	// 携号转网检查
	var oc _constant.ApiCodeMsg
	var area, province string
	oc, province, area, err = NewSysConfigSrv(srv.Ctx).IspCheck(params.SzPhoneNum, _constant.Isp(params.NSortType), orderModel)
	if err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAbnormal)
		return
	}
	if oc.ApiCode != 0 {
		apiCode = oc
		return
	}
	if area != "" && province != "" {
		orderModel.SetArea(province, area)
		if fmt.Sprintf("%d_%d_%s", customerID, orderModel.Isp, orderModel.Province) != areaChecked {
			apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAreaPhoneSuspend)
			return
		}
	}

	// 面值检查
	if product.FaceValue != params.NMoney {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderFaceValUnValid)
		return
	}

	var dispatcher *Dispatcher
	if dispatcher, err = NewDispatcher(customer, orderModel, customerPro, nil, time.Time{}, 0, *srv.Ctx); err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAbnormal)
		return
	}
	if err = dispatcher.ChannelFilter(ChannelProductMatchFilter, ChannelGroupSortFilter, ChannelDupFilter); err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderAbnormal)
		return
	}

	// 渠道检查
	if !dispatcher.HasChannel() {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiOrderProductOff)
		return
	}

	// 创建订单并且扣款
	if err = OrderWithDeduct(srv.Ctx, orderModel, customerPro); err != nil {
		apiCode = _constant.NewApiCodeMsg(_constant.ApiSysAbnormal)
		return
	}

	go func() {
		financeParam := vo.CustomerFinanceParam{
			CustomerID:      orderModel.CustomerID,
			Amount:          orderModel.SalePrice,
			RechargeAmount:  customerPro.ProductPrice,
			IsRecharging:    true,
			IsFinish:        false,
			Remark:          fmt.Sprintf("订单充值扣款,订单ID: %d", orderModel.ID),
			OrderID:         utils.Violent2String(orderModel.ID),
			CustomerOrderID: orderModel.CustomerOrderID,
		}
		// 扣款失败，则直接将订单置成失败
		if _, err = NewCustomerFinanceService(srv.Ctx).DeductFinance(financeParam); err != nil {
			logger.Log.Error("[SubmitOrder] [CustomerFinanceService] [DeductFinance]", zap.Any("financeParam", financeParam), zap.Error(err))
			dispatcher.Fail(map[string]any{
				"remark":      fmt.Sprintf("扣款失败：%s", err.Error()),
				"finish_time": time.Now(),
			})
			return
		}
		dispatcher.SendToBus(true)
	}()

	apiCode = _constant.NewApiCodeMsg(_constant.ApiSuccess)
	return
}

func (srv *OrderService) Export(params vo.OrderListParam) (filePath string, err error) {
	filePath = fmt.Sprintf("%d订单列表.xlsx", time.Now().Unix())
	if len(params.IDList) != 0 {
		filePath = fmt.Sprintf("%d_%d_%d订单列表.xlsx", time.Now().Unix(), params.IDList[0], params.IDList[len(params.IDList)-1])
	}
	var orderRsp []resp.OrderRsp
	if params.Base.StartTime.IsZero() {
		params.Base.StartTime = time.Now().AddDate(0, -2, 0)
	}
	params.NoWithCount = true
	if orderRsp, _, err = srv.List(params); err != nil {
		return
	}
	if len(orderRsp) == 0 {
		orderRsp = append(orderRsp, resp.OrderRsp{})
	}
	_m := mysql.SysDict.DataValueLabelMapper()
	_m["xj_order"] = map[string]string{
		"1":   "初始化",
		"2":   "处理中",
		"102": "成功",
		"103": "失败",
	}
	err = utils.XlsxModelWriter(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath), "sheet1", orderRsp, _m)
	return
}

func (srv *OrderService) OrderBackMoney(order models.Order) (err error) {

	// var deductFinance []*models.CustomerFinance
	// if _, deductFinance, err = mysql.CustomerFinance.Query(vo.CustomerFinanceQueryParam{
	// 	CustomerID:    order.CustomerID,
	// 	CustomerOrder: utils.Violent2String(order.CustomerOrderID),
	// 	BusinessType:  constant.CUSTOMER_FINANCE_TYPE_DEDUCT,
	// }); err != nil {
	// 	return
	// }

	// var backCount int64
	// if backCount, _, err = mysql.CustomerFinance.Query(vo.CustomerFinanceQueryParam{
	// 	CustomerID:    order.CustomerID,
	// 	CustomerOrder: utils.Violent2String(order.CustomerOrderID),
	// 	BusinessType:  constant.CUSTOMER_FINANCE_TYPE_BACK,
	// }); err != nil {
	// 	return
	// }

	// logger.Log.Info("OrderService deductFinance Query",
	// 	zap.Int64("len(deductFinance)", backCount),
	// 	zap.Int("len(deductFinance)", len(deductFinance)),
	// 	zap.Int64("orderID", order.ID),
	// 	zap.String("customerOrderID", order.CustomerOrderID),
	// )

	// if backCount == 0 && len(deductFinance) > 0 {
	financeParam := vo.CustomerFinanceParam{
		CustomerID:      order.CustomerID,
		Amount:          order.SalePrice,
		OrderID:         utils.Violent2String(order.ID),
		RechargeAmount:  float64(order.FaceValue),
		Remark:          "客户充值失败退款 订单ID: " + utils.Violent2String(order.ID),
		IsRecharging:    true,
		IsFinish:        true,
		CustomerOrderID: order.CustomerOrderID,
	}
	if _, err := NewCustomerFinanceService(srv.Ctx).BackFinance(financeParam); err != nil {
		logger.Log.Error("[SubmitOrder] [CustomerFinanceService] [DeductFinance]", zap.Any("financeParam", financeParam), zap.Error(err))
	}
	// }
	return
}

func OrderWithDeduct(ctx *echo.Context, orderModel *models.Order, customerPro models.CustomerProduct) (err error) {

	createOrderFunc := func() (funcErr error) {
		session := daos.Mysql.NewSession()
		defer session.Close()
		if funcErr = partition.GlobalOrderPartition.Create(session, orderModel); funcErr != nil {
			logger.Log.Error("SubmitOrder Create", zap.Error(funcErr))
			return
		}

		if _, funcErr = daos.CreateObjs(session, &models.CustomerOrderDateMapper{
			CustomerOrderID: orderModel.CustomerOrderID,
			Date:            orderModel.Created,
		}); funcErr != nil {
			partition.GlobalOrderPartition.UnscopeDelete(orderModel.ID, orderModel.CustomerOrderID, false)
			logger.Log.Error("OrderWithDeduct", zap.Error(funcErr))
			return
		}
		return
	}

	if err = createOrderFunc(); err != nil {
		return
	}
	go PublishOrderStuck(*orderModel, int(orderModel.Status))

	return
}
