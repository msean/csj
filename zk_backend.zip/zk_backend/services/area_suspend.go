package services

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services/cache"
	"application/utils"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type AreaSuspendSrv struct {
	Ctx  *echo.Context
	Uuid string
}

func NewAreaSuspendSrv(ctx *echo.Context) *AreaSuspendSrv {
	bean := &AreaSuspendSrv{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
	return bean
}

func (srv *AreaSuspendSrv) Create(params vo.AreaSuspendCreateParam) (succussCount, failCount int64, err error) {
	var objects []models.AreaSuspend

	for _, apply := range params.ChannelList {
		for _, area := range params.AreaList {
			objects = append(objects, models.AreaSuspend{
				ApplyID: apply,
				Type:    2,
				Isp:     params.IspCode,
				Area:    area,
			})
		}
	}

	for _, apply := range params.CustomerList {
		for _, area := range params.AreaList {
			objects = append(objects, models.AreaSuspend{
				ApplyID: apply,
				Type:    1,
				Isp:     params.IspCode,
				Area:    area,
			})
		}
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	succussCount, err = daos.CreateObjs(session, objects)
	if err != nil {
		return
	}
	failCount = int64(len(objects)) - succussCount

	if err = cache.RefreshSuspendArea(); err != nil {
		logger.Log.Error("[AreaSuspendSrv] [Create] [RefreshSuspendArea]", zap.Error(err))
		return
	}

	return
}

func (srv *AreaSuspendSrv) Fill(areaSuspendModel models.AreaSuspend,
	areaDict, ispDict models.SysDictData,
	customer models.Customer,
	Channel models.Channel,
) (rsp resp.AreaSuspendRsp) {
	name := customer.Name
	if areaSuspendModel.Type == 2 {
		name = Channel.Name
	}
	return resp.AreaSuspendRsp{
		ID:   areaSuspendModel.ID,
		Type: areaSuspendModel.Type,
		Isp:  ispDict.Label,
		Area: areaDict.Label,
		Name: name,
	}
}

func (srv *AreaSuspendSrv) List(params vo.AreaSuspendListParam) (rsp []resp.AreaSuspendRsp, total int64, err error) {
	var areaSuspends []models.AreaSuspend
	if areaSuspends, total, err = mysql.AreaSuspend.List(params); err != nil {
		return
	}

	var channelIDList []int64
	var customerIDList []int64
	for _, obj := range areaSuspends {
		switch obj.Type {
		case 1:
			customerIDList = append(customerIDList, obj.ApplyID)
		case 2:
			channelIDList = append(channelIDList, obj.ApplyID)
		}
	}

	channelM := make(map[int64]models.Channel)
	if len(channelIDList) > 0 {
		channelM, _ = mysql.Channel.FromIDList(channelIDList)
	}

	customerM := make(map[int64]models.Customer)
	if len(customerIDList) > 0 {
		customerM, _ = mysql.Customer.FromIDList(customerIDList)
	}

	typeDateM, _ := mysql.SysDict.TypesDataMap(constant.SysIspDictType, constant.SysAreaDictType)

	for _, areaSuspend := range areaSuspends {
		rsp = append(rsp, srv.Fill(areaSuspend,
			typeDateM[constant.SysAreaDictType][utils.Violent2String(areaSuspend.Area)],
			typeDateM[constant.SysIspDictType][utils.Violent2String(areaSuspend.Isp)],
			customerM[areaSuspend.ApplyID], channelM[areaSuspend.ApplyID]))
	}
	return
}

func (srv *AreaSuspendSrv) Delete(params vo.DeleteParams) (err error) {

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, err = daos.DelObjs(session, params.IDList, models.AreaSuspend{})
	if err != nil {
		return
	}

	if err = cache.RefreshSuspendArea(); err != nil {
		logger.Log.Error("[AreaSuspendSrv] [Delete] [RefreshSuspendArea]", zap.Error(err))
	}

	return
}
