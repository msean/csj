package services

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"go.uber.org/zap"
	"gopkg.in/redis.v5"
)

var (
	OrderStuckChecker OrderStuckCheck
	once              sync.Once
)

// 2. 超过48小时的订单如果既不是成功也不是失败的状态就算是卡单，那么卡单阈值就+1。
type (
	OrderStuckCheck struct {
		customerOrderStuckMap map[string]models.OrderStuckInfo // key customer_channel
		channelOrderStuckMap  map[string]models.OrderStuckInfo // key  channel_channelOrder
		OrderMap              map[int64]models.OrderStuckInfo  // key orderID
		ChannelOrderMap       map[int64]models.OrderStuckInfo  // key channelOrderID
		mu                    sync.Mutex
	}
)

func InitOrderStuckChecker() {
	once.Do(func() {
		OrderStuckChecker = OrderStuckCheck{
			OrderMap:              make(map[int64]models.OrderStuckInfo),
			ChannelOrderMap:       make(map[int64]models.OrderStuckInfo),
			customerOrderStuckMap: make(map[string]models.OrderStuckInfo),
			channelOrderStuckMap:  make(map[string]models.OrderStuckInfo),
		}
	})
	session := daos.Mysql.NewSession()
	defer session.Close()

	customerOrderStuckList, err := partition.GlobalOrderPartition.CustomerStuckQry(session, constant.OrderStatusInit, constant.OrderStatusHandle, constant.OrderStatusSuspect)

	if err != nil {
		panic(err)
	}
	for _, orderStuck := range customerOrderStuckList {
		OrderStuckChecker.OrderMap[orderStuck.OrderID] = orderStuck
	}

	var channelOrderStuckList []models.OrderStuckInfo
	channelOrderStuckList, err = partition.GlobalChannelOrderPartition.ChannelStuckQry(session, constant.OrderStatusInit, constant.OrderStatusHandle, constant.OrderStatusSuspect)
	if err != nil {
		panic(err)
	}
	for _, orderStuck := range channelOrderStuckList {
		OrderStuckChecker.ChannelOrderMap[orderStuck.ChannelOrderID] = orderStuck
	}
}

func PublishOrderStuck(order models.Order, status int) {
	OrderStuckChecker.Publish(daos.Rc, models.OrderStuckInfo{
		Type:          1,
		OrderID:       order.ID,
		CustomerID:    order.CustomerID,
		CurrentStatus: status,
		OrderTime:     order.Created,
	})
}

func PublishChannelOrderStuck(order models.ChannelOrder, status int) {
	OrderStuckChecker.Publish(daos.Rc, models.OrderStuckInfo{
		OrderID:          order.OrderID,
		CustomerID:       order.CustomerID,
		CurrentStatus:    status,
		OrderTime:        order.OrderTime,
		ChannelOrderTime: order.Created,
		ChannelID:        order.ChannelID,
		ChannelOrderID:   order.ID,
		Type:             2,
	})
}

func (stuckCheck *OrderStuckCheck) Subscribe(rdb *redis.Client) (err error) {

	var pubsub *redis.PubSub
	if pubsub, err = rdb.Subscribe("order:stuck"); err != nil {
		return
	}
	defer pubsub.Close()

	for {
		msg, subscribeError := pubsub.ReceiveMessage()
		if subscribeError != nil {
			logger.Log.Error("[OrderStuckCheck] [Subscribe] [ReceiveMessage]", zap.Error(subscribeError))
		}
		var orderInfo models.OrderStuckInfo
		if err = json.Unmarshal([]byte(msg.Payload), &orderInfo); err != nil {
			logger.Log.Error("[OrderStuckCheck] [Subscribe] [json.Unmarshal]", zap.Error(err), zap.String("msg", msg.Payload))
		}
		switch orderInfo.Type {
		case 1:
			stuckCheck.mu.Lock()
			OrderStuckChecker.OrderMap[orderInfo.OrderID] = orderInfo
			stuckCheck.mu.Unlock()
		case 2:
			stuckCheck.mu.Lock()
			OrderStuckChecker.ChannelOrderMap[orderInfo.ChannelOrderID] = orderInfo
			stuckCheck.mu.Unlock()
		}
	}
}

func (stuckCheck *OrderStuckCheck) Publish(rdb *redis.Client, orderInfo models.OrderStuckInfo) (err error) {
	stuckCheck.mu.Lock()
	defer stuckCheck.mu.Unlock()
	defer func() {
		if err != nil {
			logger.Log.Error("[OrderStuckCheck] [Publish]", zap.Any("orderMsg", orderInfo))
		}
	}()

	var orderInfoByte []byte
	if orderInfoByte, err = json.Marshal(orderInfo); err != nil {
		return
	}
	err = rdb.Publish("order:stuck", string(orderInfoByte)).Err()
	return
}

func (stuckCheck *OrderStuckCheck) CustomerStuckCount(customerID int64) (count int) {
	stuckCheck.mu.Lock()
	defer stuckCheck.mu.Unlock()
	for customerOrder := range stuckCheck.customerOrderStuckMap {
		splits := strings.Split(customerOrder, "_")
		if splits[0] == fmt.Sprintf("%d", customerID) {
			count++
		}
	}
	return
}

func (stuckCheck *OrderStuckCheck) CustomerStuck() (out map[int64]map[int64]models.OrderStuckInfo, err error) {
	stuckCheck.mu.Lock()
	defer stuckCheck.mu.Unlock()
	out = make(map[int64]map[int64]models.OrderStuckInfo)
	for customerOrder, stuckInfo := range stuckCheck.customerOrderStuckMap {
		splits := strings.Split(customerOrder, "_")
		if len(splits) >= 2 {
			var customerID, orderID int64
			customerIDStr, orderIDStr := splits[0], splits[1]
			customerID, err = strconv.ParseInt(customerIDStr, 10, 64)
			if err != nil {
				return
			}
			orderID, err = strconv.ParseInt(orderIDStr, 10, 64)
			if err != nil {
				return
			}

			if _, ok := out[customerID]; !ok {
				out[customerID] = map[int64]models.OrderStuckInfo{
					orderID: stuckInfo,
				}
			} else {
				out[customerID][orderID] = stuckInfo
			}

		}
	}
	return
}

func (stuckCheck *OrderStuckCheck) ChannelStuck() (out map[int64]map[int64]models.OrderStuckInfo, err error) {
	stuckCheck.mu.Lock()
	defer stuckCheck.mu.Unlock()
	out = make(map[int64]map[int64]models.OrderStuckInfo)
	for customerOrder, stuckInfo := range stuckCheck.channelOrderStuckMap {
		splits := strings.Split(customerOrder, "_")
		if len(splits) >= 2 {
			var channelID, orderID int64
			channelIDStr, orderIDStr := splits[0], splits[1]
			channelID, err = strconv.ParseInt(channelIDStr, 10, 64)
			if err != nil {
				return
			}
			orderID, err = strconv.ParseInt(orderIDStr, 10, 64)
			if err != nil {
				return
			}
			if _, ok := out[channelID]; !ok {
				out[channelID] = map[int64]models.OrderStuckInfo{
					orderID: stuckInfo,
				}
			} else {
				out[channelID][orderID] = stuckInfo
			}
		}
	}
	return
}

func (stuckCheck *OrderStuckCheck) ChannelStuckCount(channelID int64) (count int) {
	for customerOrder := range stuckCheck.channelOrderStuckMap {
		splits := strings.Split(customerOrder, "_")
		if splits[0] == fmt.Sprintf("%d", channelID) {
			count++
		}
	}
	return
}

func (stuckCheck *OrderStuckCheck) Check(rdb *redis.Client) (err error) {

	t := time.NewTicker(60 * 2 * time.Second)
	defer t.Stop()

	for {
		now := time.Now()
		customerCountMap := make(map[string]struct{})
		channelCountMap := make(map[string]struct{})
		select {
		case <-t.C:
			stuckCheck.mu.Lock()
			for orderID, orderInfo := range stuckCheck.OrderMap {
				if orderInfo.CurrentStatus == constant.OrderStatusInit || orderInfo.CurrentStatus == constant.OrderStatusHandle || orderInfo.CurrentStatus == constant.OrderStatusSuspect {
					if orderInfo.OrderTime.Before(now.Add(-48 * time.Hour)) {
						customerOrderKey := fmt.Sprintf("%d_%d", orderInfo.CustomerID, orderInfo.OrderID)
						if _, ok := customerCountMap[customerOrderKey]; !ok {
							stuckCheck.customerOrderStuckMap[customerOrderKey] = orderInfo
						}
					}
				} else {
					delete(stuckCheck.OrderMap, orderID)
				}
			}
			for orderID, orderInfo := range stuckCheck.ChannelOrderMap {
				if orderInfo.CurrentStatus == constant.OrderStatusInit || orderInfo.CurrentStatus == constant.OrderStatusHandle || orderInfo.CurrentStatus == constant.OrderStatusSuspect {
					if orderInfo.ChannelOrderTime.Before(now.Add(-48 * time.Hour)) {
						channelOrderKey := fmt.Sprintf("%d_%d", orderInfo.ChannelID, orderInfo.ChannelOrderID)
						if _, ok := channelCountMap[channelOrderKey]; !ok && orderInfo.ChannelID != 0 {
							stuckCheck.channelOrderStuckMap[channelOrderKey] = orderInfo
						}
					}
				} else {
					delete(stuckCheck.OrderMap, orderID)
				}
			}
			stuckCheck.mu.Unlock()
		}
	}
}
