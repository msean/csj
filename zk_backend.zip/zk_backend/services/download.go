package services

import (
	"application/conf"
	"application/constant"
	"application/daos/mysql"
	"application/models"
	"application/models/vo"
	"application/utils"
	"encoding/json"
	"fmt"
	"time"

	"github.com/labstack/echo"
	"github.com/syndtr/goleveldb/leveldb/errors"
)

type (
	DownloadService struct {
		Ctx  *echo.Context
		Uuid string
	}
)

func NewDownloadService(ctx *echo.Context) *DownloadService {
	return &DownloadService{
		Ctx:  ctx,
		Uuid: utils.GetContextUUID(*ctx),
	}
}

func (s *DownloadService) filePath(filename string) string {
	return fmt.Sprintf("%s/%s", conf.StaticPath(), filename)
}

func (s *DownloadService) genKey(params interface{}) (string, error) {
	str, err := json.Marshal(params)
	if err != nil {
		return "", errors.New("marshal failed, " + err.Error())
	}

	return utils.Md5S(string(str)), nil
}

func (s *DownloadService) save(key string, filename string) (*models.Download, error) {
	obj := &models.Download{
		HashKey:  key,
		Filename: filename,
	}
	if err := mysql.Download.InsertBean(utils.UserId(*s.Ctx), obj); err != nil {
		return nil, errors.New("insert failed, " + err.Error())
	}

	return obj, nil
}

func (s *DownloadService) get(key string) (*models.Download, error) {
	obj, err := mysql.Download.FindByKey(key)
	if err != nil {
		return nil, errors.New("query failed, " + err.Error())
	}

	return obj, nil
}

func (s *DownloadService) CommonDict() utils.TypeFieldMapper {
	return utils.TypeFieldMapper{
		constant.BOOL_DICT_KEY:   constant.BOOL_DICT(),
		constant.STATUS_DICT_KEY: constant.STATUS_DICT(),
		constant.SWITCH_DICT_KEY: constant.SWITCH_DICT(),
	}
}

func (s *DownloadService) LogDict() utils.TypeFieldMapper {
	return utils.TypeFieldMapper{
		constant.STATUS_DICT_KEY: constant.STATUS_DICT(),
		constant.LOG_DICT_KEY:    constant.LOG_OP_DICT(),
		constant.MODULE_DICT_KEY: constant.MODULE_DICT(),
	}
}

func (s *DownloadService) CustomerProductDict() utils.TypeFieldMapper {
	// todo: get channel info from db:
	channelDict := make(map[string]string)
	channels, count, _ := NewChannelService(s.Ctx).List(vo.ChannelListParams{})
	if count > 0 {
		for _, channel := range channels {
			channelDict[fmt.Sprintf("%d", channel.ID)] = channel.Name
		}
		// channelDict["0"] = "无"
	}

	groupDict := make(map[string]string)
	groups, count, _ := NewChannelGroupSrv(s.Ctx).List(vo.ChannelGroupListParams{})
	if count > 0 {
		for _, group := range groups {
			groupDict[fmt.Sprintf("%d", group.ID)] = group.Name
		}
		groupDict["0"] = "无"
	}

	typeDict := make(map[string]string)
	productTypes, count, _ := mysql.SysDict.ListTypeData(vo.SysDictDataListParams{TypeSearch: "xj_bigtype"})
	if count > 0 {
		for _, productType := range productTypes {
			typeDict[productType.Value] = productType.Label
		}
	}

	return utils.TypeFieldMapper{
		constant.CUSTOMER_PRODUCT_TYPE_DICT_KEY:  typeDict,
		constant.CUSTOMER_PRODUCT_CERT_DICT_KEY:  constant.CUSTOMER_PRODUCT_CERT_DICT(),
		constant.SWITCH_DICT_KEY:                 constant.SWITCH_DICT(),
		constant.CUSTOMER_CHANNEL_DICT_KEY:       channelDict,
		constant.CUSTOMER_CHANNEL_GROUP_DICT_KEY: groupDict,
	}
}

func (s *DownloadService) CustomerFinanceDict() utils.TypeFieldMapper {
	return utils.TypeFieldMapper{
		constant.CUSTOMER_FINANCE_DICT_KEY: constant.CUSTOMER_FINANCE_DICT(),
	}
}

func (s *DownloadService) FinanceDict() utils.TypeFieldMapper {
	return utils.TypeFieldMapper{
		constant.FINANCE_TYPE_DICT_KEY: constant.FINANCE_TYPE_DICT(),
	}
}

func (s *DownloadService) Export(params interface{}, data interface{}, tableName string, operator int64, dictMap utils.TypeFieldMapper, checkFile bool) (string, error) {
	key, err := s.genKey(params)
	if err != nil {
		return "", errors.New("get key failed, " + err.Error())
	}

	if checkFile {
		if obj, _ := s.get(key); obj != nil {
			return obj.Filename, nil
			// return s.filePath(obj.Filename), nil
		}
	}

	filename := fmt.Sprintf("%s_%d_%d.xlsx", tableName, operator, time.Now().Unix())
	err = utils.XlsxModelWriter(s.filePath(filename), "sheet1", data, dictMap)
	if err != nil {
		return "", errors.New("write error, " + err.Error())
	}

	obj, err := s.save(key, filename)
	if err != nil {
		return "", errors.New("save error, " + err.Error())
	}

	return obj.Filename, nil
	// return s.filePath(obj.Filename), nil
}

func (s *DownloadService) CheckTime(params vo.FindListParams, limitDay int) error {
	// func (s *DownloadService) CheckTime(startTime string, endTime string, limitDay int) error {
	day, err := utils.TimeSubDay(params.StartTime, params.EndTime)
	if err != nil {
		return err
	}

	if limitDay > 0 && day > limitDay {
		return errors.New("over limit")
	}

	return nil
}
