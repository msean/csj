-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: go_admin
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `a_log_login`
--

DROP TABLE IF EXISTS `a_log_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `a_log_login` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `account` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `success` tinyint(1) DEFAULT NULL,
  `detail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1572 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `a_log_op`
--

DROP TABLE IF EXISTS `a_log_op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `a_log_op` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `module` int DEFAULT NULL,
  `op_type` int DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `func` varchar(255) DEFAULT NULL,
  `req` text,
  `res` text,
  `success` tinyint(1) DEFAULT NULL,
  `detail` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=477 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `a_log_remove`
--

DROP TABLE IF EXISTS `a_log_remove`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `a_log_remove` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `table_type` int DEFAULT NULL,
  `count` int DEFAULT NULL,
  `interval_ms` bigint DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `operator` varchar(255) DEFAULT NULL,
  `success` tinyint(1) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `a_menu`
--

DROP TABLE IF EXISTS `a_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `a_menu` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `menu_name` varchar(255) NOT NULL,
  `menu_type` int DEFAULT NULL,
  `menu_order` int DEFAULT NULL,
  `parent_id` bigint DEFAULT NULL,
  `open_type` int DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `a_role`
--

DROP TABLE IF EXISTS `a_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `a_role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `role_name` varchar(255) NOT NULL,
  `role_order` int NOT NULL,
  `available` tinyint(1) DEFAULT '1',
  `menu` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `is_client` tinyint(1) DEFAULT NULL,
  `is_super` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_a_role_role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `a_user`
--

DROP TABLE IF EXISTS `a_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `a_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `account` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `google_code` varchar(255) NOT NULL,
  `position` int NOT NULL,
  `sex` int DEFAULT NULL,
  `available` tinyint(1) DEFAULT '1',
  `role` bigint NOT NULL,
  `is_client` tinyint(1) DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `is_super` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_a_user_account` (`account`),
  UNIQUE KEY `UQE_a_user_user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_config`
--

DROP TABLE IF EXISTS `sys_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `config_name` varchar(128) DEFAULT NULL COMMENT '参数名称',
  `config_key` varchar(128) DEFAULT NULL COMMENT '参数键名',
  `config_value` varchar(2048) DEFAULT NULL COMMENT '参数键值',
  `config_type` int DEFAULT NULL COMMENT '系统内置（1是 2否',
  `remark` varchar(512) DEFAULT NULL COMMENT 'Remark',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_dict_data`
--

DROP TABLE IF EXISTS `sys_dict_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_data` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `dict_sort` int DEFAULT NULL COMMENT '字典排序',
  `dict_label` varchar(128) DEFAULT NULL COMMENT '字典标签',
  `dict_value` varchar(128) DEFAULT NULL COMMENT '字典键值',
  `type_id` varchar(128) DEFAULT NULL COMMENT '字典类型',
  `status` int DEFAULT NULL COMMENT '状态（1正常 2停用）',
  `css_class` varchar(512) DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(512) DEFAULT NULL COMMENT '表格回显样式',
  `remark` varchar(1024) DEFAULT NULL COMMENT '备注',
  `is_default` varchar(255) DEFAULT 'N' COMMENT '是否默认（Y是 N否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_dict_type`
--

DROP TABLE IF EXISTS `sys_dict_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_type` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `dict_name` varchar(128) DEFAULT NULL COMMENT '字典名称',
  `dict_type` varchar(128) DEFAULT NULL COMMENT '字典类型',
  `status` int DEFAULT '1' COMMENT '状态（1正常 2停用）',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注',
  `effect_type` int DEFAULT '2' COMMENT '实际作用的类型 1 字符串 2 数字',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_area_section`
--

DROP TABLE IF EXISTS `xj_area_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_area_section` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `section` varchar(64) DEFAULT NULL COMMENT '号段',
  `area` varchar(32) DEFAULT NULL COMMENT '地区',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `isp` int DEFAULT NULL COMMENT '运营商',
  `province` varchar(32) DEFAULT NULL COMMENT '省份',
  PRIMARY KEY (`id`),
  KEY `IDX_xj_area_section_section` (`section`),
  KEY `IDX_xj_area_section_area` (`area`),
  KEY `IDX_xj_area_section_remark` (`remark`),
  KEY `IDX_xj_area_section_isp` (`isp`),
  KEY `IDX_xj_area_section_province` (`province`)
) ENGINE=InnoDB AUTO_INCREMENT=212495 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_baseproduct`
--

DROP TABLE IF EXISTS `xj_baseproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_baseproduct` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `code` varchar(255) DEFAULT NULL COMMENT '产品编号',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `charge_type` int DEFAULT '1' COMMENT '产品充值方式，1：直充，  2',
  `detail` varchar(2000) DEFAULT NULL COMMENT '详情',
  `big_type` int DEFAULT NULL COMMENT '产品类型',
  `small_type` int DEFAULT NULL COMMENT '小类   月卡  季卡等',
  `isp` int DEFAULT NULL COMMENT '运营商',
  `face_value` int DEFAULT NULL COMMENT '面值',
  `price` decimal(15,4) DEFAULT NULL COMMENT 'price',
  `online` int DEFAULT '2' COMMENT '开关 1关  2开',
  `area` int DEFAULT NULL COMMENT 'area',
  `voucher_type` int DEFAULT NULL COMMENT 'voucher_type',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2740 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_blacklist`
--

DROP TABLE IF EXISTS `xj_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_blacklist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `phone` varchar(255) DEFAULT NULL COMMENT '号码',
  `type` int DEFAULT NULL COMMENT '类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_channel`
--

DROP TABLE IF EXISTS `xj_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `name` varchar(60) DEFAULT NULL COMMENT '全称',
  `short_name` varchar(40) DEFAULT NULL COMMENT '简称',
  `api_id` varchar(256) DEFAULT NULL COMMENT 'ApiID',
  `api_key` varchar(3096) DEFAULT NULL COMMENT 'ApiKey',
  `submit_url` varchar(256) DEFAULT NULL COMMENT '提交地址',
  `query_url` varchar(256) DEFAULT NULL COMMENT '查单地址',
  `balance_url` varchar(256) DEFAULT NULL COMMENT '余额地址',
  `back_url` varchar(256) DEFAULT NULL COMMENT '回调地址',
  `online` int DEFAULT '2' COMMENT '上架状态 1 下架 2 上架',
  `balance` decimal(15,4) DEFAULT NULL COMMENT '余额',
  `detail` varchar(256) DEFAULT NULL COMMENT '详情',
  `template_name` varchar(128) DEFAULT NULL COMMENT '模版',
  `warn_balance` int DEFAULT '2000' COMMENT '余额预警',
  `stuck_limit` int DEFAULT NULL COMMENT '卡单阀值，-1隐藏-2余额汇总不统计',
  `sort` int DEFAULT '1' COMMENT '排序   -1 删除  0提示关闭',
  `limit_config` text COMMENT '线程设置',
  `manual_process` varchar(1024) DEFAULT '1' COMMENT '人工处理 1 不需要 2 需要',
  `etcone` varchar(1024) DEFAULT NULL COMMENT 'etcone',
  `etctwo` varchar(1024) DEFAULT NULL COMMENT 'etctwo',
  `etcthr` varchar(1024) DEFAULT NULL COMMENT 'etcthr',
  `msg` varchar(255) DEFAULT NULL COMMENT '渠道信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_channelgroup`
--

DROP TABLE IF EXISTS `xj_channelgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_channelgroup` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `code` varchar(255) DEFAULT NULL COMMENT '编码',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `sort_type` int DEFAULT NULL COMMENT '类型',
  `rels` text COMMENT '渠道ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_channelorder`
--

DROP TABLE IF EXISTS `xj_channelorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_channelorder` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `sale_price` decimal(15,4) DEFAULT NULL COMMENT '售价',
  `voucher_type` int DEFAULT NULL COMMENT '凭证类型',
  `customer_id` bigint DEFAULT NULL COMMENT 'customer_id',
  `tax` int DEFAULT NULL COMMENT '含税',
  `back_money` decimal(15,4) DEFAULT NULL COMMENT '后返',
  `isp` int DEFAULT NULL COMMENT '运营商',
  `price` decimal(15,4) DEFAULT NULL COMMENT '市场价',
  `face_value` int DEFAULT NULL COMMENT '面值',
  `big_type` varchar(20) DEFAULT NULL COMMENT '大类类型',
  `small_type` varchar(40) DEFAULT NULL COMMENT '小类类型',
  `product_code` varchar(255) DEFAULT NULL COMMENT '产品编码',
  `current_channel_id` bigint DEFAULT NULL COMMENT '当前渠道',
  `in_price` decimal(15,4) DEFAULT NULL COMMENT '进价',
  `current_back_status` int DEFAULT NULL COMMENT '当前的回调状态',
  `current_back_time` datetime DEFAULT NULL COMMENT '当前的回调时间',
  `back_status` text COMMENT '回调状态1失败2成功',
  `back_time` text COMMENT '回调时间',
  `back_msg` text COMMENT '回调信息',
  `customer_order_id` varchar(60) DEFAULT NULL COMMENT 'customer_order_id',
  `phone` varchar(40) DEFAULT NULL COMMENT 'phone',
  `province` varchar(20) DEFAULT NULL COMMENT 'province',
  `area` varchar(40) DEFAULT NULL COMMENT 'area',
  `channel_id` bigint DEFAULT NULL COMMENT '渠道ID',
  `order_id` bigint DEFAULT NULL COMMENT '主订单',
  `pcode` varchar(40) DEFAULT NULL COMMENT 'pcode',
  `finish_time` datetime DEFAULT NULL COMMENT '完成时间',
  `remark` text COMMENT 'remark',
  `channel_msg` varchar(255) DEFAULT NULL COMMENT 'channel_msg',
  `third_phone` varchar(20) DEFAULT NULL COMMENT 'third_phone',
  `source` int DEFAULT NULL COMMENT '2存疑订单重提',
  `order_time` datetime DEFAULT NULL COMMENT '订单时间',
  `status` int DEFAULT NULL COMMENT '订单状态 0 1 2  10成功 11失败',
  `voucher` varchar(3096) DEFAULT NULL COMMENT '凭证信息',
  PRIMARY KEY (`id`),
  KEY `IDX_xj_channelorder_customer_id` (`customer_id`),
  KEY `IDX_xj_channelorder_channel_id` (`channel_id`),
  KEY `IDX_xj_channelorder_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=67812 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_channelproduct`
--

DROP TABLE IF EXISTS `xj_channelproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_channelproduct` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `channel_id` varchar(40) DEFAULT NULL COMMENT '渠道ID',
  `online` int DEFAULT '2' COMMENT '开关 1 关 2开',
  `voucher_type` int DEFAULT '1' COMMENT '凭证类型',
  `product_code` varchar(255) DEFAULT '1' COMMENT '产品编码',
  `remark` varchar(1024) DEFAULT NULL,
  `actual_price` decimal(15,4) DEFAULT NULL,
  `order_price` decimal(15,4) DEFAULT NULL,
  `pcode` varchar(255) DEFAULT NULL COMMENT '产品参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22452 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_customer`
--

DROP TABLE IF EXISTS `xj_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_customer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `user_id` bigint NOT NULL,
  `account` varchar(255) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `ip_whitelist` varchar(255) DEFAULT NULL,
  `extra` varchar(255) DEFAULT NULL,
  `detail` varchar(255) DEFAULT NULL,
  `short_name` varchar(60) DEFAULT NULL,
  `callback_type` int DEFAULT NULL,
  `max_order` int DEFAULT NULL,
  `max_pending_order` int DEFAULT NULL,
  `repeat_timeout` int DEFAULT NULL,
  `balance` decimal(15,4) DEFAULT NULL,
  `total_balance` decimal(15,4) DEFAULT NULL,
  `recharge_amount` decimal(15,4) DEFAULT NULL,
  `pay_amount` decimal(15,4) DEFAULT NULL,
  `credit` decimal(15,4) DEFAULT NULL,
  `warn_balance` decimal(15,4) DEFAULT NULL,
  `timeout` int DEFAULT '600',
  `slow_timeout` int DEFAULT '4320',
  `slow_recharge_flag` tinyint(1) DEFAULT NULL,
  `slow_cycle_flag` tinyint(1) DEFAULT NULL,
  `all_product_flag` tinyint(1) DEFAULT NULL,
  `operator_query_flag` tinyint(1) DEFAULT NULL,
  `switch_check_flag` tinyint(1) DEFAULT NULL,
  `area_flag` tinyint(1) DEFAULT NULL,
  `api_flag` tinyint(1) DEFAULT '1',
  `recharge_flag` tinyint(1) DEFAULT '1',
  `available` tinyint(1) DEFAULT NULL,
  `etc_one` varchar(1000) DEFAULT NULL,
  `etc_two` varchar(1000) DEFAULT NULL,
  `etc_thr` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_xj_customer_user_id` (`user_id`),
  KEY `IDX_xj_customer_account` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_customer_day_finance_s`
--

DROP TABLE IF EXISTS `xj_customer_day_finance_s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_customer_day_finance_s` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `date` varchar(255) DEFAULT NULL COMMENT '日期',
  `customer_id` bigint DEFAULT NULL COMMENT '客户ID',
  `mobile_count` double DEFAULT NULL COMMENT '移动跑量',
  `mobile_amount` decimal(15,4) DEFAULT NULL COMMENT '移动跑量实际金额',
  `unicom_count` double DEFAULT NULL COMMENT '联通跑量',
  `unicom_amount` decimal(15,4) DEFAULT NULL COMMENT '联通跑量实际金额',
  `telecom_count` double DEFAULT NULL COMMENT '电信跑量',
  `telecom_amount` decimal(15,4) DEFAULT NULL COMMENT '电信跑量实际金额',
  `recharge_amount` decimal(15,4) DEFAULT NULL COMMENT '加款金额',
  `other_amount` decimal(15,4) DEFAULT NULL COMMENT '其他加款金额',
  `balance` decimal(15,4) DEFAULT NULL COMMENT '实际余额',
  `re_order_amount` decimal(15,4) DEFAULT NULL COMMENT '实际余额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1416 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_customer_finance`
--

DROP TABLE IF EXISTS `xj_customer_finance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_customer_finance` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `customer_id` bigint DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `customer_order` varchar(255) DEFAULT NULL,
  `business_type` int DEFAULT NULL,
  `amount` decimal(15,4) DEFAULT NULL,
  `balance` double DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `total_balance` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_xj_customer_finance_business_type` (`business_type`),
  KEY `IDX_xj_customer_finance_customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63310 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_customer_product`
--

DROP TABLE IF EXISTS `xj_customer_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_customer_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `customer_id` bigint DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `cal_type` int DEFAULT NULL,
  `cal_value` double DEFAULT NULL,
  `cert` int DEFAULT NULL,
  `sale_price` decimal(15,4) DEFAULT NULL,
  `back_money` decimal(15,4) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `channel_group_id` bigint DEFAULT NULL,
  `channel_ids` text,
  `first_channel_ids` text,
  `second_channel_ids` text,
  `forbid_channel_ids` text,
  `tax_type` int DEFAULT NULL,
  `available` tinyint(1) DEFAULT '1',
  `available_tick` bigint DEFAULT '0',
  `code` bigint DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `product_price` double DEFAULT NULL,
  `product_value` int DEFAULT NULL,
  `product_area` int DEFAULT NULL,
  `product_type` int DEFAULT NULL,
  `product_sub_type` int DEFAULT NULL,
  `product_isp` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_xj_customer_product_customer_code` (`customer_id`,`code`)
) ENGINE=InnoDB AUTO_INCREMENT=27854 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_delay_task`
--

DROP TABLE IF EXISTS `xj_delay_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_delay_task` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `table` varchar(255) DEFAULT NULL,
  `pk` varchar(255) DEFAULT NULL,
  `sql` text,
  `exec_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_download`
--

DROP TABLE IF EXISTS `xj_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_download` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `hash_key` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_xj_download_hash_key` (`hash_key`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_finance_day`
--

DROP TABLE IF EXISTS `xj_finance_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_finance_day` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `is_customer` tinyint(1) DEFAULT NULL,
  `owner_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `balance` decimal(15,4) DEFAULT NULL,
  `finance_date` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1916 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_order`
--

DROP TABLE IF EXISTS `xj_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `sale_price` decimal(15,4) DEFAULT NULL COMMENT '售价',
  `voucher_type` int DEFAULT NULL COMMENT '凭证类型',
  `customer_id` bigint DEFAULT NULL COMMENT 'customer_id',
  `tax` int DEFAULT NULL COMMENT '含税',
  `back_money` decimal(15,4) DEFAULT NULL COMMENT '后返',
  `isp` int DEFAULT NULL COMMENT '运营商',
  `price` decimal(15,4) DEFAULT NULL COMMENT '市场价',
  `face_value` int DEFAULT NULL COMMENT '面值',
  `big_type` varchar(20) DEFAULT NULL COMMENT '大类类型',
  `small_type` varchar(40) DEFAULT NULL COMMENT '小类类型',
  `product_code` varchar(255) DEFAULT NULL COMMENT '产品编码',
  `current_channel_id` bigint DEFAULT NULL COMMENT '当前渠道',
  `in_price` decimal(15,4) DEFAULT NULL COMMENT '进价',
  `current_back_status` int DEFAULT NULL COMMENT '当前的回调状态',
  `current_back_time` datetime DEFAULT NULL COMMENT '当前的回调时间',
  `back_status` text COMMENT '回调状态1失败2成功',
  `back_time` text COMMENT '回调时间',
  `back_msg` text COMMENT '回调信息',
  `customer_order_id` varchar(60) DEFAULT NULL COMMENT 'customer_order_id',
  `phone` varchar(40) DEFAULT NULL COMMENT 'phone',
  `province` varchar(20) DEFAULT NULL COMMENT 'province',
  `area` varchar(40) DEFAULT NULL COMMENT 'area',
  `name` varchar(255) DEFAULT NULL COMMENT 'name',
  `status` int DEFAULT NULL COMMENT '订单状态 0 1 2  10成功 11失败',
  `pay_status` int DEFAULT NULL COMMENT '付款状态',
  `rnum` int DEFAULT NULL COMMENT 'rnum',
  `finish_time` datetime DEFAULT NULL COMMENT '完成时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `back_url` varchar(255) DEFAULT NULL COMMENT '客户回调地址',
  `third_phone` varchar(40) DEFAULT NULL COMMENT '第三方手机号',
  `source` varchar(40) DEFAULT NULL COMMENT '订单来源0无结果订单补充1成功订单补充',
  `manual_remark` text COMMENT '人工备注',
  `is_slow` int DEFAULT NULL COMMENT '是否是慢充订单  1 是 2 否',
  `has_returned` int DEFAULT NULL COMMENT '是否已经申请了退单',
  `voucher` varchar(3096) DEFAULT NULL COMMENT '凭证信息',
  PRIMARY KEY (`id`),
  KEY `IDX_xj_order_customer_id` (`customer_id`),
  KEY `IDX_xj_order_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=41597 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_order_channel`
--

DROP TABLE IF EXISTS `xj_order_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_order_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `order_id` bigint DEFAULT NULL,
  `type` int DEFAULT NULL,
  `channel_group_id` bigint DEFAULT NULL,
  `channel_ids` text,
  `first_channel_ids` text,
  `second_channel_ids` text,
  `forbid_channel_ids` text,
  `valid_channels` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52077 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_order_return`
--

DROP TABLE IF EXISTS `xj_order_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_order_return` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `order_id` bigint DEFAULT NULL COMMENT '主订单',
  `customer_id` bigint DEFAULT NULL COMMENT '客户ID',
  `customer_order_id` varchar(64) DEFAULT NULL COMMENT '客户订单号',
  `channel_order_id` bigint DEFAULT NULL COMMENT '渠道订单号',
  `area` varchar(40) DEFAULT NULL COMMENT 'area',
  `phone` varchar(40) DEFAULT NULL COMMENT 'phone',
  `channel_id` bigint DEFAULT NULL COMMENT '渠道ID',
  `pcode` varchar(255) DEFAULT NULL COMMENT '产品编码',
  `big_type` varchar(20) DEFAULT NULL COMMENT '大类类型',
  `isp` int DEFAULT NULL COMMENT '运营商',
  `face_value` int DEFAULT NULL COMMENT '面值',
  `in_price` decimal(15,4) DEFAULT NULL COMMENT '进价',
  `sale_price` decimal(15,4) DEFAULT NULL COMMENT '售价',
  `order_time` datetime DEFAULT NULL COMMENT '订单创建时间',
  `voucher_type` int DEFAULT NULL COMMENT '凭证类型',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `type` int DEFAULT NULL COMMENT '返销类型 1客户返销 2渠道后成功 3渠道后失败',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13762 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `xj_suspend`
--

DROP TABLE IF EXISTS `xj_suspend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xj_suspend` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `create_by` bigint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `update_by` bigint DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `deleted` datetime DEFAULT NULL,
  `version` bigint NOT NULL DEFAULT '1',
  `apply_id` bigint DEFAULT NULL COMMENT '渠道ID/客户ID',
  `type` int DEFAULT NULL COMMENT '1 客户 2 渠道',
  `isp` bigint DEFAULT NULL COMMENT '运营商',
  `area` varchar(20) DEFAULT NULL COMMENT '地区',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-29 17:24:03
