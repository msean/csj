package constant

import "time"

const (
	FrequencyBalanceQry = time.Duration(30 * time.Second)
	FrequencyOrderQry   = time.Duration(30 * time.Second)
)
