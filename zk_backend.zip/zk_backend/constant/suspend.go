package constant

const (
	SuspendTypeCustom  = 1
	SuspendTypeChannel = 2
)
