package constant

const (
	FINANCE_TYPE_DICT_KEY = "finance_type"
)

func FINANCE_TYPE_DICT() map[string]string {
	return map[string]string{
		"true":  "客户",
		"false": "渠道",
	}
}
