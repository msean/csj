package constant

type Isp uint

const (
	IspMobile    Isp = 1    // 移动
	IspUniCom    Isp = 2    // 联通
	IspTelCom    Isp = 3    // 电信
	IspVirtual   Isp = 4    // 虚拟运营商
	IspStateGrid Isp = 101  // 国家电网
	IspSouthGrid Isp = 102  // 南方电网
	IspSinopec   Isp = 104  // 中石化
	IspPetro     Isp = 105  // 中石油
	IspTencent   Isp = 1000 // 腾讯
	IspIqiYi     Isp = 1001 // 爱奇艺
	IspYouKu     Isp = 1002 // 优酷
	IspTikTok    Isp = 1031 // 抖音
)

var IspStringM = map[Isp]string{
	IspMobile:    "移动",
	IspUniCom:    "联通",
	IspTelCom:    "电信",
	IspVirtual:   "虚拟运营商",
	IspStateGrid: "国家电网",
	IspSouthGrid: "南方电网",
	IspSinopec:   "中石化",
	IspPetro:     "中石油",
	IspTencent:   "腾讯",
	IspIqiYi:     "爱奇艺",
	IspYouKu:     "优酷",
	IspTikTok:    "抖音",
}

var IspCodeM = func() map[string]Isp {
	ispCodeM := make(map[string]Isp)
	for k, v := range IspStringM {
		ispCodeM[v] = k
	}
	return ispCodeM
}()

func (isp Isp) String() string {
	return IspStringM[isp]
}

func ConvertIsp(isp string) Isp {
	return IspCodeM[isp]
}
