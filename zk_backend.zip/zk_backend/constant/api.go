package constant

import (
	"fmt"
)

type (
	ApiCode    int
	ApiCodeMsg struct {
		ApiCode  ApiCode
		OrderMsg string
	}
)

const (
	ApiOrder        = 1 // 下单
	ApiQueryOrder   = 2 // 查单
	ApiQueryBalance = 3 // 余额
)

const (
	ApiSuccess               ApiCode = 0    // 提交成功
	ApiOrderSysMaintenance   ApiCode = 1000 // 系统接口维护
	ApiParamsFormatErr       ApiCode = 1001 // 参数错误
	ApiOrderTimeOverOrStuck  ApiCode = 1003 // 该号码提交频繁/ 时间超过限制
	ApiSignErr               ApiCode = 1004 // 签名错误
	ApiOrderBalanceInStuff   ApiCode = 1006 // 余额不足
	ApiOrderPhoneErr         ApiCode = 2001 // 号码错误
	ApiOrderOperatorErr      ApiCode = 2002 // 运营商错误
	ApiOrderBlacklistOrLimit ApiCode = 2003 // 号码黑名单或者充值次数上限
	ApiUnbindIp              ApiCode = 2020 // 未绑定IP
	ApiCustomerNotExist      ApiCode = 2021 // 用户不存在
	// ApiOrderProductErr           ApiCode = 2031 // 产品编码有误
	ApiOrderProductApiClose      ApiCode = 2030 // 下单接口关闭
	ApiOrderClientProductOff     ApiCode = 2032 // 客户产品关闭
	ApiOrderProductOff           ApiCode = 2033 // 基础产品关闭
	ApiOrderAreaSuspend          ApiCode = 2034 // 区域维护中
	ApiOrderAreaPhoneSuspend     ApiCode = 2035 // 区域维护中
	ApiOrderIspFail              ApiCode = 2036 // 运营商不一致
	ApiOrderIspCheckInconsistent ApiCode = 2037 // 携号转网运营商不一致
	ApiOrderIspCheckUnSupport    ApiCode = 2038 // 不支持携号转网
	ApiOrderProductClose         ApiCode = 2040 // 客户渠道产品关闭
	ApiOrderFaceValUnValid       ApiCode = 2042 // 面值错误
	// ApiOrderClientProductNotConf ApiCode = 2043 // 客户产品未配置

	ApiOrderDuplicate ApiCode = 3030 // 产品重复
	ApiOrderAbnormal  ApiCode = 2050 // 下单异常
	ApiSysAbnormal    ApiCode = 999  // 系统异常
	ApiOrderNotExist  ApiCode = 5005 // 系统异常
	ApiFrequencyLimit ApiCode = 5002 // 接口频率超过限制

	ApiCustomerNotExist2 ApiCode = 5003
)

var ApiCodeMsgM = map[ApiCode]string{
	ApiSuccess:                   "success",
	ApiOrderSysMaintenance:       "系统对账时间",
	ApiParamsFormatErr:           "%s",
	ApiOrderTimeOverOrStuck:      "%s",
	ApiSignErr:                   "签名错误",
	ApiOrderPhoneErr:             "号码错误",
	ApiOrderOperatorErr:          "时间戳间隔超过1分钟",
	ApiOrderBlacklistOrLimit:     "%s",
	ApiOrderClientProductOff:     "客户产品关闭",
	ApiOrderProductOff:           "基础产品关闭",
	ApiOrderAreaSuspend:          "地区正在维护中，请联系管理员！",
	ApiOrderAreaPhoneSuspend:     "地区正在维护中，请联系管理员！",
	ApiOrderIspFail:              "运营商不一致",
	ApiUnbindIp:                  "未绑定IP",
	ApiCustomerNotExist:          "用户不存在",
	ApiOrderBalanceInStuff:       "余额不足",
	ApiOrderProductApiClose:      "下单接口关闭",
	ApiOrderDuplicate:            "重复订单",
	ApiOrderAbnormal:             "下单异常",
	ApiSysAbnormal:               "系统异常错误",
	ApiOrderFaceValUnValid:       "面值错误",
	ApiOrderIspCheckInconsistent: "携号转网运营商不一致",
	ApiOrderIspCheckUnSupport:    "不支持携号转网",
	ApiOrderProductClose:         "客户渠道产品关闭",
	ApiFrequencyLimit:            "请求接口超过频率限制",
	ApiCustomerNotExist2:         "客户不存在",
	// ApiOrderProductErr:           "产品编码有误",
	// ApiOrderClientProductNotConf: "客户产品未配置",
}

func (oc ApiCode) Msg() string {
	return ApiCodeMsgM[oc]
}

func NewApiCodeMsg(oc ApiCode) ApiCodeMsg {
	return ApiCodeMsg{
		ApiCode:  oc,
		OrderMsg: ApiCodeMsgM[oc],
	}
}

func NewParamsApiCodeMsg(paramsErr string) ApiCodeMsg {
	return ApiCodeMsg{
		ApiCode:  ApiParamsFormatErr,
		OrderMsg: fmt.Sprintf(ApiCodeMsgM[ApiParamsFormatErr], paramsErr),
	}
}

func NewApiOrderBlacklistOrLimitMsg(msg string) ApiCodeMsg {
	return ApiCodeMsg{
		ApiCode:  ApiOrderBlacklistOrLimit,
		OrderMsg: fmt.Sprintf(ApiCodeMsgM[ApiOrderBlacklistOrLimit], msg),
	}
}

func NewApiOrderTimeOverOrStuckMsg(msg string) ApiCodeMsg {
	return ApiCodeMsg{
		ApiCode:  ApiOrderBlacklistOrLimit,
		OrderMsg: fmt.Sprintf(ApiCodeMsgM[ApiOrderTimeOverOrStuck], msg),
	}
}
