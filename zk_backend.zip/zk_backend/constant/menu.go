package constant

const (
	MENU_TYPE_MIN     = 1 // menuType最小值
	MENU_TYPE_DEFAULT = 1 // 菜单
	MENU_TYPE_CATALOG = 2 // 目录
	MENU_TYPE_BUTTON  = 3 // 按钮
	MENU_TYPE_MAX     = 3 // menuType最大值

	MENU_OPEN_MIN    = 1 // openType最小值
	MENU_OPEN_TAB    = 1 // menuItem页签
	MENU_OPEN_WINDOW = 2 // menuBlank新窗口
	MENU_OPEN_MAX    = 2 // openType最大值
)
