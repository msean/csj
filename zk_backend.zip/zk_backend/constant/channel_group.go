package constant

const (
	ChannelGroupRate = 6 // 按照百分比
)
