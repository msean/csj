package constant

const (
	CODE_OK = 0

	CODE_DB_ERROR    = 1
	CODE_REDIS_ERROR = 2
)
