package constant

const (
	CAL_TYPE_PLUS   = 1 // 计算方式-加
	CAL_TYPE_MINUS  = 2 // 计算方式-减
	CAL_TYPE_MUL    = 3 // 计算方式-乘
	CAL_TYPE_DIVIDE = 4 // 计算方式-除
	CAL_TYPE_NONE   = 5 // 计算方式-原数值
)
