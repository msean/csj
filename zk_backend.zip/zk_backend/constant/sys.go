package constant

import "fmt"

const (
	SysConfY = "Y" // 内置
	SysConfN = "N"

	SysConfDefault  = 1 // 内置
	SysConfDefaultN = 2
)

const (
	SysConfDzTimeKey   = "dzTime"
	SysConfDzTimeValue = 300000
	SysConfDzTimeName  = "对账维护时间"

	SysConfIspKey          = "isp.key"
	SysConfIspUrl          = "isp.url"
	SysConfIspFlag         = "isp.flag"
	SysConfBlackListLimit  = "blacklist_phone_limit"
	SysConfCustomerWarning = "customer_warning" // 客户预警开关
)

const (
	SysAreaDictType      = "xj_area"        // 地区
	SysIspDictType       = "xj_isp"         // 运营商
	SysTemplateDictType  = "xj_classes"     // 模版
	SysSmallTypeDictType = "xj_smalltype"   // 小类
	SysBigTypeDictType   = "xj_bigtype"     // 大类
	SysVoucherDictType   = "xj_vouchertype" // 凭证类型
)

var AreaCodeM = map[string]int{
	"山东":  37,
	"全国":  00,
	"海南":  46,
	"宁夏":  64,
	"四川":  51,
	"西藏":  54,
	"青海":  63,
	"广东":  44,
	"贵州":  52,
	"福建":  35,
	"吉林":  22,
	"陕西":  61,
	"内蒙":  15,
	"山西":  14,
	"甘肃":  62,
	"广西":  45,
	"湖北":  42,
	"江西":  36,
	"浙江":  33,
	"江苏":  32,
	"新疆":  65,
	"安徽":  34,
	"湖南":  43,
	"黑龙江": 23,
	"辽宁":  21,
	"云南":  53,
	"河南":  41,
	"河北":  13,
	"重庆":  50,
	"上海":  31,
	"天津":  12,
	"北京":  11,
}

var CodeArea = map[uint]string{
	37: "山东",
	00: "全国",
	46: "海南",
	64: "宁夏",
	51: "四川",
	54: "西藏",
	63: "青海",
	44: "广东",
	52: "贵州",
	35: "福建",
	22: "吉林",
	61: "陕西",
	15: "内蒙",
	14: "山西",
	62: "甘肃",
	45: "广西",
	42: "湖北",
	36: "江西",
	33: "浙江",
	32: "江苏",
	65: "新疆",
	34: "安徽",
	43: "湖南",
	23: "黑龙江",
	21: "辽宁",
	53: "云南",
	41: "河南",
	13: "河北",
	50: "重庆",
	31: "上海",
	12: "天津",
	11: "北京",
}

func GetAreaCode(area string) string {
	if code, in := AreaCodeM[area]; in {
		return fmt.Sprintf("%d", code)
	}
	return "00"
}

var AreaCodeStringM = func() map[int]string {
	areaCodeStringM := make(map[int]string)
	for area, code := range AreaCodeM {
		areaCodeStringM[code] = area
	}
	return areaCodeStringM
}()

var BigTypeMapper = map[string]int{
	"话费":  1,
	"流量":  2,
	"视频":  3,
	"虚拟币": 4,
	"卡券":  5,
	"短信":  6,
	"组合":  7,
	"生活":  8,
}

var SmallTypeMapper = map[string]int{
	"小时":  1,
	"日":   2,
	"3日":  3,
	"7日":  4,
	"月":   5,
	"季":   6,
	"半年":  7,
	"年":   8,
	"红包":  9,
	"2日":  10,
	"企事业": 11,
	"店铺":  12,
	"住宅":  13,
}

var OnlineMapper = map[string]int{
	"下架": 1,
	"上架": 2,
}

var OrderStatusMapper = map[string]int{
	"初始化": OrderStatusInit,
	"处理中": OrderStatusHandle,
	"存疑":  OrderStatusSuspect,
	"无结果": OrderStatusNoResult,
	"成功":  OrderStatusSuccess,
	"失败":  OrderStatusFail,
	// "需人工处理": OrderStatusManual,
}

var CallbackStatusMapper = map[string]int{
	"初始化": OrderNotifyInit,
	"成功":  OrderNotifySuccess,
	"失败":  OrderNotifyFail,
}

/*
case "Upper":
		return NewUpperTemplate(base)
	case "XuanJie":
		return NewXjTemplate(base)
	case "AddSupplyNumber":
		return NewAddSupplyNumberTemplate(base)
	case "ReceiveOrder2":
		return NewReceiveOrder2Tml(base)
	case "Quotient":
		return NewQuotientTml(base)
	case "MorganDesign2":
		return NewMorganDesign2Tml(base)
	case "SM":
		return NewM5Tml(base)
*/

var TemplateMapper = map[string]string{
	"xj_v1":             "XuanJie",
	"add_supply_number": "AddSupplyNumber",
	"upper":             "Upper",
	"receive_order_2":   "ReceiveOrder2",
	"sm":                "SM",
	"quotient":          "Quotient",
	"morgan_design_2":   "MorganDesign2",
	"jupiter":           "Jupiter",
	"xapi":              "Xapi",
	"duxing":            "DuXing",
	"mobile_merchant":   "MobileMerchant",
	"shenlong":          "ShenLong",
}

var VoucherTypeMapper = map[string]int{
	"普通":  1,
	"手支":  2,
	"网厅":  3,
	"电子券": 4,
	"卡密":  5,
}

var BlacklistTypeMapper = map[string]int{
	"永久": 1,
	"临时": 2,
}
