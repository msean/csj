package constant

import "fmt"

const (
	MODULE_START = iota
	MODULE_ROLE
	MODULE_USER
	MODULE_MENU
	MODULE_PRODUCT
	MODULE_AREA_SUSPEND
	MODULE_AREA_SECTION
	MODULE_BLACKLIST
	MODULE_DICT_DATA
	MODULE_DICT_TYPE
	MODULE_SYS_ARG
	MODULE_CHANNEL
	MODULE_CHANNEL_GROUP
	MODULE_CHANNEL_PRODUCT
	MODULE_ORDER
	MODULE_CHANNEL_ORDER
	MODULE_CHANNEL_RETURN_ORDER
	MODULE_CUSTOMER
	MODULE_CUSTOMER_PRODUCT
	MODULE_CUSTOMER_FINANCE
	MODULE_FINANCE
	MODULE_CLIENT_RECHARGE
	MODULE_CLIENT_INTEGRATION
	MODULE_ANNOUNCEMENT
	MODULE_DATA_PRODUCT_CRONJOB
	MODULE_DATA_CRONJOB
	MODULE_DATA_DELETE
	MODULE_END
	MODULE_DICT_KEY = "module"
)

func MODULE_DICT() map[string]string {
	return map[string]string{
		"-1":                                           "所有",
		fmt.Sprintf("%d", MODULE_ROLE):                 "角色",
		fmt.Sprintf("%d", MODULE_USER):                 "用户",
		fmt.Sprintf("%d", MODULE_MENU):                 "菜单",
		fmt.Sprintf("%d", MODULE_PRODUCT):              "基础产品",
		fmt.Sprintf("%d", MODULE_AREA_SUSPEND):         "区域维护",
		fmt.Sprintf("%d", MODULE_AREA_SECTION):         "号段管理",
		fmt.Sprintf("%d", MODULE_BLACKLIST):            "黑名单管理",
		fmt.Sprintf("%d", MODULE_DICT_DATA):            "字典数据管理",
		fmt.Sprintf("%d", MODULE_DICT_TYPE):            "字典类型管理",
		fmt.Sprintf("%d", MODULE_SYS_ARG):              "系统参数",
		fmt.Sprintf("%d", MODULE_CHANNEL):              "渠道",
		fmt.Sprintf("%d", MODULE_CHANNEL_GROUP):        "渠道组",
		fmt.Sprintf("%d", MODULE_CHANNEL_PRODUCT):      "渠道产品",
		fmt.Sprintf("%d", MODULE_ORDER):                "客户订单",
		fmt.Sprintf("%d", MODULE_CHANNEL_ORDER):        "渠道订单",
		fmt.Sprintf("%d", MODULE_CHANNEL_RETURN_ORDER): "返销订单",
		fmt.Sprintf("%d", MODULE_CUSTOMER):             "客户",
		fmt.Sprintf("%d", MODULE_CUSTOMER_PRODUCT):     "客户产品",
		fmt.Sprintf("%d", MODULE_CUSTOMER_FINANCE):     "客户财务",
		fmt.Sprintf("%d", MODULE_FINANCE):              "财务对账",
		fmt.Sprintf("%d", MODULE_CLIENT_INTEGRATION):   "对接信息",
		fmt.Sprintf("%d", MODULE_CLIENT_RECHARGE):      "话费充值",
		fmt.Sprintf("%d", MODULE_ANNOUNCEMENT):         "通知管理",
		fmt.Sprintf("%d", MODULE_DATA_PRODUCT_CRONJOB): "产品定时任务",
		fmt.Sprintf("%d", MODULE_DATA_DELETE):          "数据删除",
	}
}
