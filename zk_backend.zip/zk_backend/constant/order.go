package constant

import "fmt"

// java代码中订单对应的状态码是 10 成功 11 失败
// 初始化 0，处理中 1，存疑 2，成功 10，失败 11
const (
	OrderStatusInit    = 1 // 初始化
	OrderStatusHandle  = 2 // 处理中
	OrderStatusSuspect = 3 // 存疑

	OrderStatusNoResult = 101 // 无结果
	OrderStatusSuccess  = 102 // 成功
	OrderStatusFail     = 103 // 失败
	OrderStatusManual   = 104 // 需要人工处理
)

const (
	OrderQryNoExist          = iota // 订单不存在
	OrderQryParamsErr               // 查询参数错误
	OrderQrySignErr                 // 查询签名错误
	OrderQryCreated                 // 订单生成中
	OrderQryWaiting                 // 等待充值
	OrderQryHandle                  // 处理中
	OrderQrySuccess                 // 成功
	OrderQryFail                    // 失败
	OrderQryApiClose                // 查询接口关闭
	OrderQryApiFrequency            // 查询频繁
	OrderQryApiException            // 查询异常
	OrderQryWaitCheck               // 待检测
	OrderQryCustomerNotExist        // 客户不存在
	OrderQryCustomerClose           // 客户被停用
	OrderQryTimeout                 // 订单超时
	OrderQryCancel                  // 订单取消
	OrderQryConfirmed               // 订单已确认
	OrderQryFailNotified            // 订单失败已通知
)

const (
	OrderReceiveCallbackSuccess   = iota // 订单成功
	OrderReceiveCallbackFail             // 订单失败
	OrderReceiveCallbackCreated          // 订单生成
	OrderReceiveCallbackHandle           // 订单处理中
	OrderReceiveCallbackWaitCheck        // 订单检测中
	OrderReceiveCallbackWait             // 订单等待充值
	OrderReceiveCallbackNoCharge         // 未充值
	OrderReceiveCallbackTimeout          // 订单超时
	OrderReceiveCallbackCancel           // 订单取消
)

func OrderQryStatusString(qryStatus int) string {
	if msg, ok := map[int]string{
		OrderQryNoExist:          "订单不存在",
		OrderQryParamsErr:        "查询参数错误",
		OrderQrySignErr:          "查询签名错误",
		OrderQryCreated:          "订单生成中",
		OrderQryWaiting:          "等待充值",
		OrderQryHandle:           "处理中",
		OrderQrySuccess:          "订单成功",
		OrderQryFail:             "订单失败",
		OrderQryApiClose:         "查询接口关闭",
		OrderQryApiFrequency:     "接口查询频繁",
		OrderQryApiException:     "接口查询异常",
		OrderQryWaitCheck:        "待检测",
		OrderQryCustomerNotExist: "客户不存在",
		OrderQryConfirmed:        "已确认",
		OrderQryFailNotified:     "失败已通知",
		OrderQryTimeout:          "订单超时",
		OrderQryCancel:           "订单已经取消",
		OrderQryCustomerClose:    "客户被停用",
	}[qryStatus]; ok {
		return msg
	}
	return fmt.Sprintf("%d", qryStatus)
}

const (
	OrderSourceRc = 1 // 返销订单补充类型的不需要验证超时
)

// java代码中订单对应的状态码是 10 成功 11 失败
const (
	ROrderTypeCustomer = 1
	ROrderTypeSuccess  = 2
	ROrderTypeFail     = 3
)

const (
	ChannelSubmitSuccess = iota
	ChannelSubmitFail
	ChannelSubmitException
	ChannelSubmitAbnormal            // 提单异常
	ChannelSubmitSignErr             // 签名错误
	ChannelSubmitCustomerErr         // 话商ID有错误 不存在 或者禁用
	ChannelSubmitCustomerClose       // 话商ID配置关闭
	ChannelSubmitFaceValueUnConfig   // 面值未开通
	ChannelSubmitBalanceInsufficient // 余额不足
	ChannelSubmitDup                 // 话商单号重复
	ChannelSubmitUnSupportIsp        // 不支持的运营商
	ChannelSubmitNotInWhiteList      // 不再白名单中
	ChannelSubmitApiLimit            // 接口充值数量过多
	ChannelSubmitOrderExist          // 订单已经存在
	ChannelSubmitProductUnExist      // 产品不存在
	ChannelSubmitProductClose        // 产品没有配置
	ChannelSubmitParamsErr           // 提单参数错误
	ChannelSubmitIPUnbind            // IP没有绑定
	ChannelSubmitApiClose            // API接口关闭
	ChannelSubmitProductForbidden    // 产品禁止购买
	ChannelSubmitProductMatchErr     // 充值号码与所选商品不符合
	ChannelSubmitBusy                //
)

// 回调通知状态
const (
	OrderNotifyInit    = 1
	OrderNotifySuccess = 3
	OrderNotifyFail    = 2
)

const (
	BalanceQrySuccess = iota
	BalanceQryException
	BalanceQryCustomerErr
	BalanceQrySignErr
	BalanceQryFrequency
	BalanceQrySystemErr
)
