package constant

const (
	ROLE_TYPE_ADMIN = 1 // 管理员
	/*ROLE_TYPE_CLIENT    = 2 // 客户
	ROLE_TYPE_BUSINESS  = 3 // 商务
	ROLE_TYPE_OPERATION = 4 // 运营
	ROLE_TYPE_CUSTOMER  = 5 // 客服
	ROLE_TYPE_FINANCE   = 6 // 财务*/

	ROLE_SUPER_NAME = "super" // 超级管理员账号
)
