package constant

import "fmt"

const (
	CUSTOMER_CALLBACK_TYPE_DEFAULT = 1 // 默认
	CUSTOMER_CALLBACK_TYPE_NO      = 2 // 不回调
	CUSTOMER_CALLBACK_TYPE_NO_KEY  = 3 // 无凭证
	CUSTOMER_CALLBACK_TYPE_GET     = 4 // get方式
	CUSTOMER_CALLBACK_TYPE_JSON    = 5 // json方式

	CUSTOMER_PRODUCT_TAX_TYPE_NO      = 1 // 含税类型-无
	CUSTOMER_PRODUCT_TAX_TYPE_DEFAULT = 2 // 含税类型-普票
	CUSTOMER_PRODUCT_TAX_TYPE_SPECIFY = 3 // 含税类型-专票

	CUSTOMER_PRODUCT_CERT_DEFAULT = 1 //  凭证类型-普通
	CUSTOMER_PRODUCT_CERT_SHOP    = 2 //  凭证类型-网厅
	CUSTOMER_PRODUCT_CERT_CARD    = 3 //  凭证类型-卡密
	CUSTOMER_PRODUCT_CERT_VOUCHER = 4 //  凭证类型-电子券
	CUSTOMER_PRODUCT_CERT_PHONE   = 5 //  凭证类型-手支

	CUSTOMER_FINANCE_TYPE_ADD      = 1 //  业务类型-加款
	CUSTOMER_FINANCE_TYPE_DEDUCT   = 2 //  业务类型-扣款
	CUSTOMER_FINANCE_TYPE_BACK     = 3 //  业务类型-退款
	CUSTOMER_FINANCE_TYPE_RE_ORDER = 4 //  业务类型-返销
	CUSTOMER_FINANCE_TYPE_SPECIAL  = 5 //  业务类型-特殊加款

	CUSTOMER_PRODUCT_TYPE_DICT_KEY  = "customer_product_type"
	CUSTOMER_PRODUCT_CERT_DICT_KEY  = "customer_product_cert"
	CUSTOMER_FINANCE_DICT_KEY       = "customer_finance"
	CUSTOMER_CHANNEL_DICT_KEY       = "customer_channel"
	CUSTOMER_CHANNEL_GROUP_DICT_KEY = "customer_channel_group"

	CUSTOMER_DEFAULT_TIMEOUT      = 600
	CUSTOMER_DEFAULT_SLOW_TIMEOUT = 4320
)

func CUSTOMER_PRODUCT_CERT_DICT() map[string]string {
	return map[string]string{
		fmt.Sprintf("%d", CUSTOMER_PRODUCT_CERT_DEFAULT): "普通",
		fmt.Sprintf("%d", CUSTOMER_PRODUCT_CERT_SHOP):    "网厅",
		fmt.Sprintf("%d", CUSTOMER_PRODUCT_CERT_CARD):    "卡密",
		fmt.Sprintf("%d", CUSTOMER_PRODUCT_CERT_VOUCHER): "电子券",
		fmt.Sprintf("%d", CUSTOMER_PRODUCT_CERT_PHONE):   "手支",
	}
}

func CUSTOMER_FINANCE_DICT() map[string]string {
	return map[string]string{
		fmt.Sprintf("%d", CUSTOMER_FINANCE_TYPE_ADD):      "客户加款",
		fmt.Sprintf("%d", CUSTOMER_FINANCE_TYPE_DEDUCT):   "扣款",
		fmt.Sprintf("%d", CUSTOMER_FINANCE_TYPE_BACK):     "退款",
		fmt.Sprintf("%d", CUSTOMER_FINANCE_TYPE_RE_ORDER): "返销加款",
		fmt.Sprintf("%d", CUSTOMER_FINANCE_TYPE_SPECIAL):  "特殊退款",
	}
}
