package constant

const (
	USER_POSITION_CHAIRMAN  = 1 // 董事长
	USER_POSITION_DEVELOPER = 2 // 技术
	USER_POSITION_HR        = 3 // 人事
	USER_POSITION_OPERATION = 4 // 运营
	USER_POSITION_BUSINESS  = 5 // 商务
	USER_POSITION_CUSTOMER  = 6 // 客服
	USER_POSITION_EMPLOYEE  = 7 // 员工
	USER_POSITION_FINANCE   = 8 // 财务

	USER_SEXY_MAN    = 1 // 男
	USER_SEXY_FEMALE = 2 // 女
	USER_SEXY_UNKNOW = 3 // 未知

	USER_SUPER_ACCOUNT = "super"      // 超级管理员-账号
	USER_SUPER_NAME    = "super_user" // 超级管理员-用户名
)
