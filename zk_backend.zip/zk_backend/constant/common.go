package constant

const (
	BOOL_DICT_KEY   = "bool"
	STATUS_DICT_KEY = "status"
	SWITCH_DICT_KEY = "switch"
)

func BOOL_DICT() map[string]string {
	return map[string]string{
		"true":  "是",
		"false": "否",
	}
}

func STATUS_DICT() map[string]string {
	return map[string]string{
		"true":  "成功",
		"false": "失败",
	}
}

func SWITCH_DICT() map[string]string {
	return map[string]string{
		"true":  "开",
		"false": "关",
	}
}
