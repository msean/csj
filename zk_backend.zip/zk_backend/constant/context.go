package constant

const (
	CONTEXT_KEY_USER = "key_user"
	CONTEXT_KEY_UID  = "key_uid"
	CONTEXT_KEY_LOG  = "key_log"
)
