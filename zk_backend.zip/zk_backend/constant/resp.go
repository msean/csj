package constant

const (
	RtnFormatJson = "JSON"
	RtnFormatXml  = "XML"
)
