package constant

const (
	EXPORT_DAY_USER             = 180 // 导出天数限制-用户
	EXPORT_DAY_ROLE             = 180 // 导出天数限制-角色
	EXPORT_DAY_LOG_LOGIN        = 90  // 导出天数限制-登陆日志
	EXPORT_DAY_LOG_OP           = 90  // 导出天数限制-操作日志
	EXPORT_DAY_CUSTOMER         = 180 // 导出天数限制-客户
	EXPORT_DAY_CUSTOMER_PRODUCT = 180 // 导出天数限制-客户产品
	EXPORT_DAY_CUSTOMER_FINANCE = 180 // 导出天数限制-客户财务
	EXPORT_DAY_FINANCE_DAY      = 180 // 导出天数限制-财务对账-每日余额
)
