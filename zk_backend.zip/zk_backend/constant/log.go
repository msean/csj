package constant

import "fmt"

const (
	LOG_OP_CREATE = 1
	LOG_OP_UPDATE = 2
	LOG_OP_DELETE = 3
	LOG_OP_EXPORT = 4
	LOG_OP_GRANT  = 5
	LOG_OP_IMPORT = 6
	LOG_OP_OTHER  = 100

	LOG_DICT_KEY = "log_op_type"
)

func LOG_OP_DICT() map[string]string {
	return map[string]string{
		"-1":                             "所有",
		fmt.Sprintf("%d", LOG_OP_CREATE): "创建",
		fmt.Sprintf("%d", LOG_OP_UPDATE): "更新",
		fmt.Sprintf("%d", LOG_OP_DELETE): "删除",
		fmt.Sprintf("%d", LOG_OP_EXPORT): "导出",
		fmt.Sprintf("%d", LOG_OP_GRANT):  "授权",
		fmt.Sprintf("%d", LOG_OP_OTHER):  "其它",
	}
}
