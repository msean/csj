package constant

const (
	METHOD_GET    = "GET"
	METHOD_POST   = "POST"
	METHOD_PUT    = "PUT"
	METHOD_PATCH  = "PATCH"
	METHOD_DELETE = "DELETE"
)

var methodList = []string{METHOD_GET, METHOD_POST, METHOD_PUT, METHOD_PATCH, METHOD_DELETE}

func CheckMethod(method string) bool {
	if method == "" {
		return true
	}

	for _, m := range methodList {
		if m == method {
			return true
		}
	}

	return false
}
