package constant

const (
	TABLE_CLIENT_ORDER   = 1
	TABLE_CHANNEL_ORDER  = 2
	TABLE_FINANCE_RECORD = 3
)

func GET_TABLE_NAME(tableType uint) string {
	if tableType == TABLE_CLIENT_ORDER {
		return "客户订单表"
	} else if tableType == TABLE_CHANNEL_ORDER {
		return "渠道订单表"
	} else if tableType == TABLE_FINANCE_RECORD {
		return "财务记录表"
	}

	return ""
}
