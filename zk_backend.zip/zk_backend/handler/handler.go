package handler

import (
	"application/common/driver"
	"application/common/logger"
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/services"
	"application/systemSetting"
	"application/template"
	"application/utils/jwt_auth"
	"fmt"
	"os"
	"time"

	"github.com/go-xorm/xorm"
)

func NewInit(configPath string) {
	// 配置参数
	conf.ParseConfig(configPath)
	// 初始化缓存
	systemSetting.CheckInit()
	// 设置log
	logger.InitAdminLog(conf.GetLogFilePath())
	// 设置数据库
	initMysql()
	// 设置redis
	if conf.Config().Rdb.Has {
		initRedis()
	}
	// 设置LevelDB
	if conf.Config().Ldb.Has {
		initLevelDB()
	}

	if conf.Config().Echo.StaticPath != "" {
		initStaticDir()
	}
	services.Init()
	// jwt
	jwt_auth.EXPIRE = time.Duration(conf.Config().Jwt.Expire) * time.Hour
	jwt_auth.SECRET = conf.Config().Jwt.Secret
}

func initMysql() {
	// 获取mysql配置
	engine, err := driver.CreateMysql(conf.GetDataSourceName(), conf.Config().Xdb.ShowSql)
	fmt.Println("_______ debug-db: ", conf.GetDataSourceName())
	if err != nil {
		panic(err)
	}

	engine.SetMaxIdleConns(200)
	engine.SetMaxOpenConns(5000)
	engine.SetLogger(xorm.NewSimpleLogger(logger.Xlogger))
	engine.ShowExecTime(true)
	// engine.ShowSQL(true)
	engine.ShowSQL(conf.Config().Xdb.ShowSql)
	engine.SetConnMaxLifetime(time.Minute)
	// engine.SetConnMaxLifetime(time.Second * 20)

	daos.SetMysql(engine)
	if conf.Config().Xdb.Migrate {
		mysql.Migrate()
		if err := mysql.InitSysDict(); err != nil {
			panic(err)
		}
		if err := mysql.InitSysConf(); err != nil {
			panic(err)
		}
		mysql.InitSuperAdmin()
	}

	template.InitTemplateConfigDescription()
	if conf.Config().Xdb.MigratePartition {
		mysql.MigrateOrderData()
	}

	initConfig()
}

func initRedis() {
	// 获取redis配置
	rc, err := driver.CreateRedis(conf.GetRedisAddr(), conf.Config().Rdb.Password, conf.Config().Rdb.DB)
	if err != nil {
		panic(err)
	}
	daos.SetRedis(rc)
}

func initLevelDB() {
	leveldb, err := driver.CreateLevelDB(conf.Config().Ldb.Path)
	if err != nil {
		panic(err)
	}
	daos.SetLevelDB(leveldb)
}

func initStaticDir() {
	dir := conf.Config().Echo.StaticPath
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		err := os.MkdirAll(dir, os.ModePerm)
		if err != nil {
			panic(err)
		}
		fmt.Printf("Directory created: %s\n", dir)
	}
}

func initConfig() {

	session := daos.Mysql.NewSession()
	defer session.Close()

	_, has, err := mysql.SysArgConfig.FromKey(session, constant.SysConfCustomerWarning)
	if err != nil {
		logger.Log.Error("init warning config failed, query failed, " + err.Error())
		return
	}

	if !has {
		data := models.SysArgConfig{
			Name:   constant.SysConfCustomerWarning,
			Key:    constant.SysConfCustomerWarning,
			Value:  fmt.Sprintf("%v", false),
			Typ:    1,
			Remark: "system config, auto insert",
		}

		if _, err = daos.CreateObjs(session, &data); err != nil {
			logger.Log.Error("init warning config failed, insert failed, " + err.Error())
			return
		}

		logger.Log.Info("init warning config success")
	}
}
