package systemSetting

import "fmt"

func CheckInit() {
	fmt.Println("初始化检查")
}
