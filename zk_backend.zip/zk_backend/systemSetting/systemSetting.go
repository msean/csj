package systemSetting

var (
	UserMenus map[string]struct{}
)

func init() {
	UserMenus = make(map[string]struct{})
}
