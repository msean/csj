package main

import (
	_cpu "application/common/cpu"
	"application/common/logger"
	"application/conf"
	"application/handler"
	"application/middlewares"
	"application/router"
	"flag"
	"fmt"
	"log"
	"runtime"

	"net/http"
	_ "net/http/pprof"

	"go.uber.org/zap"
)

var (
	cfg = flag.String("c", "config.yaml", "The path of configuration file")
)

func init() {
	_cpu.GroRuntimeMaxCpu()
	flag.Parse()
	handler.NewInit(*cfg)
	middlewares.Init()
	logger.Log.Info("Server tag: add_shenlong_template")
}

func main() {
	defer func() {
		if err := recover(); err != nil {
			var stackBuf [1024]byte
			stackBufLen := runtime.Stack(stackBuf[:], false)
			logger.Log.Error(fmt.Sprintf("recover from panic: %v， %v", err, string(stackBuf[:stackBufLen])))
		}
	}()

	errs := make(chan error)
	go func() {
		log.Println(http.ListenAndServe("localhost:6060", nil))
	}()
	router.RunHttpServer(conf.Config().Echo.Bind)
	select {
	case err := <-errs:
		logger.Log.Fatal("application: Run Server failed, err", zap.Error(err))
	}

}
