## 中控项目部署文档

### 1.基础环境

注:当前文档为单节点部署示例,所有服务均在单台服务器。

#### docker部署

##### (1)卸载旧版本的docker环境

```sh
sudo yum -y remove docker \
           docker-client \
           docker-client-latest \
           docker-common \
           docker-latest \
           docker-latest-logrotate \
           docker-logrotate \
           docker-engine
```



##### (2)添加docker的软件源

```sh
sudo yum -y install yum-utils
sudo yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo
```



##### (3)安装docker-ce软件包

```sh
sudo yum -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin
```



##### (4)启动docker服务并设置开机自启动

```sh
sudo systemctl --now enable docker 
```



##### (5)配置容器加速

```sh
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://<你的加速地址>.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```



##### (6)测试docker环境是否安装成功

```sh
systemctl status docker
运行命令，显示 Active: active (running)即可。
```



### 2.中间件部署

#### mysql部署

##### (1)拉取镜像

```sh
#拉取镜像
docker pull mysql:8.0
```



##### (2)准备数据

```sh
#启动镜像,用于拷贝配置文件到宿主机
#密码按照需求修改MYSQL_ROOT_PASSWORD的值即可
docker run   --name   mysql   -p 3306:3306 --name mysql -e MYSQL_ROOT_PASSWORD=E376CR4Ky?, -d mysql:8.0 --lower_case_table_names=1

#查看是否启动成功
docker ps -a

#新建挂载目录并拷贝配置文件
sudo mkdir -p /mysqldata/mysql
sudo docker cp  mysql:/etc/mysql /mysqldata/mysql/conf.d
sudo docker cp  mysql:/var/lib/mysql/ /mysqldata/mysql/data

#授权目录权限
sudo chown -R 644 /mysqldata

#删除原有镜像
docker rm -f mysql
```



##### (3)优化配置文件

```sh
cd /mysqldata/mysql/conf.d

#在 my.cnf的[mysqld]模块中添加以下内容
...
log_error =  /var/lib/mysql/error.log  #配置错误日志路径 
slow_query_log = 1    #开启慢查询日志
slow_query_log_file = /mysqldata/mysql/logs/slow.log   #配置慢查询日志路径
long_query_time = 2   #控制慢查询的时间阈值
default-time-zone = 'Asia/Shanghai'   #配置时区为上海
max_connections = 200  #配置mysql最大连接数
...
```



##### (4)启动

```sh
#创建桥接网络
docker network create adminer-net

#启动mysql ，挂载配置文件，数据持久化到宿主主机
#注意密码和上个步骤中的密码相同
docker run \
-p 3306:3306 \
--name mysql \
--restart=always \
--network adminer-net \
-e LANG="en_US.UTF-8" \
-e LC_ALL="en_US.UTF-8" \
-v /mysqldata/mysql/conf.d:/etc/mysql \
-v /mysqldata/mysql/data:/var/lib/mysql \
-v /mysqldata/my.cnf:/etc/my.cnf \
-v /usr/share/zoneinfo/Asia/Shanghai:/usr/share/zoneinfo/Asia/Shanghai \
-v /etc/localtime:/etc/localtime \
-e MYSQL_ROOT_PASSWORD=E376CR4Ky?, \
-d mysql:8.0  --lower_case_table_names=1
```



##### (5)创建库

```sh
#登陆语句
docker exec -it mysql mysql -uroot -pE376CR4Ky?,

#建库语句
CREATE DATABASE `go_admin` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
```



##### (6)adminer部署

```sh
#拉取镜像
docker pull adminer

#部署adminer，后续可通过adminer访问mysql
sudo docker run -itd --name adminer \
  -v /home/azureuser/adminer_custom.php:/var/www/html/adminer.php \
  --restart=always \
  -e LANG=C.UTF-8 \
  -e LANGUAGE=en_US.UTF-8 \
  -e LC_ALL=C.UTF-8 \
  -p 7880:8080 --network adminer-net adminer
```



#### redis部署

##### (1)拉取镜像

```sh
docker pull redis:6.0
```



##### (2)准备数据

```sh
#启动容器
docker run --name redis  -p 16379:6379  -d redis:6.0

#创建目录
mkdir -p /redisdata/{conf,data}

#拷贝数据
docker cp  redis:/etc/redis /redisdata/conf
docker cp  redis:/data /redisdata/data

#删除容器
docker rm -f redis
```



##### (3)修改配置文件

```sh
#直接复制执行即可
#根绝需求更改端口和密码
cat >> /redisdata/conf/redis.conf << 'KOF'
bind 0.0.0.0
protected-mode yes
port 6379
tcp-backlog 511
timeout 0
tcp-keepalive 0
loglevel notice
logfile ""
databases 16
save 900 1
save 300 10
save 60 10000
stop-writes-on-bgsave-error yes
rdbcompression yes
rdbchecksum yes
dbfilename dump.rdb
dir ./
slave-serve-stale-data yes
slave-read-only yes
repl-diskless-sync no
repl-diskless-sync-delay 5
repl-disable-tcp-nodelay no
slave-priority 100
appendonly no
appendfilename "appendonly.aof"
appendfsync everysec
no-appendfsync-on-rewrite no
auto-aof-rewrite-percentage 100
auto-aof-rewrite-min-size 64mb
aof-load-truncated yes
lua-time-limit 5000
slowlog-log-slower-than 10000
slowlog-max-len 128
latency-monitor-threshold 0
notify-keyspace-events ""
hash-max-ziplist-entries 512
hash-max-ziplist-value 64
list-max-ziplist-size -2
list-compress-depth 0
set-max-intset-entries 512
zset-max-ziplist-entries 128
zset-max-ziplist-value 64
hll-sparse-max-bytes 3000
activerehashing yes
client-output-buffer-limit normal 0 0 0
client-output-buffer-limit slave 256mb 64mb 60
client-output-buffer-limit pubsub 32mb 8mb 60
hz 10
aof-rewrite-incremental-fsync yes
requirepass E376CR4Ky?,
KOF
```



##### (4)启动

```sh
docker run -p 16379:6379 --name redis \
--restart=always \
-v /redisdata/conf:/etc/redis/ \
-v /redisdata/data:/data \
-d redis:6.0  redis-server /etc/redis/redis.conf --appendonly yes
```



#### nginx部署

##### (1)拉取镜像

```sh
docker pull nginx:1.24.0
```



##### (2)准备数据

```sh
#启动容器
sudo docker run -p 80:80 -d --name nginx nginx:1.24.0

#创建目录
sudo mkdir -p /nginx/{conf,log,html}

#拷贝数据
sudo docker cp  nginx:/etc/nginx/* /nginx/conf/

#删除容器
sudo docker rm -f nginx
```



##### (3)修改配置文件

```sh
#修改主配置文件，在events模块中添加如下参数
vim /nginx/conf/nginx.conf
...
worker_connections  10240;
...
```



###### 项目配置文件

```sh
cat >> /nginx/conf/conf.d/zk.conf << 'KOF'
server {
   listen 80;
   server_name 0.0.0.0;
   location / {
   root /usr/share/nginx/html;
   index index.html index.htm;
    gzip_static on;
    gzip_proxied any;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml text/javascript;
    gzip_vary on;
   }
   
   location /api {

   #proxy_pass http://127.0.0.1:6677;   
   #proxy_pass http://118.178.180.134:6677;   
   proxy_pass http://172.27.41.61:6677;   

   proxy_set_header Host $http_host; 
   proxy_http_version 1.1;        
   proxy_set_header Connection "";      

   proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
   
   proxy_connect_timeout 100;
   proxy_send_timeout 120; 
   proxy_read_timeout 120;
   
   proxy_buffering on; 
   proxy_buffer_size 32k;
   proxy_buffers 4 128k;
   }
}
KOF
```



###### 静态配置文件

```sh
cat >  static.conf   << 'KOF'
server {
    listen 88;
    server_name static.com;  # 替换为你的域名或IP地址
    root /usr/share/nginx/html/zkstatic;

    location / {
        #alias /etc/zk/static/;  # 下载目录的路径
        charset utf-8,gbk; 
        autoindex off;                # 开启目录浏览
        autoindex_exact_size off;    # 显示文件大小（可选）
        autoindex_localtime on;      # 显示本地时间（可选）
    }

    location ~* \.txt$ {
        allow all;
        add_header Content-Disposition "attachment; filename=$1.txt";
        add_header Content-Type application/octet-stream;
    }
    # 只允许访问具体的文件类型
    location ~* \.(\w+)$ {
        allow all;
    }

    deny all;  # 禁止其他所有文件类型的访问
}
KOF
```



##### (4)配置前端文件

```sh
#把前端文件放到/nginx/html目录即可
示例： cp -r  dist/* /nginx/html
```



##### (5)启动

```sh
docker run \
-p 80:80 \
-p 88:88 \
--name nginx \
--restart=always \
-v /nginx/conf/:/etc/nginx/ \
-v /nginx/log:/var/log/nginx \
-v /nginx/html:/usr/share/nginx/html \
-v /etc/zk/static:/usr/share/nginx/html/zkstatic \
-d nginx:1.24.0
```



### 3.服务部署

#### (1)准备dockerfile

```sh
mkdir  /root/ser
cat  >> /root/ser/Dockerfile  << 'KOF'
From alpine:latest

RUN apk update && apk add tzdata

COPY myapp /usr/local/bin/

WORKDIR /

COPY config.yaml /etc/zk/config.yaml

ENV CONF=/etc/zk/config.yaml

RUN mkdir /static/ 

RUN chmod +644 /static

STOPSIGNAL SIGRTMIN+3

ENTRYPOINT myapp -c $CONF
KOF
```



#### (2)准备配置文件

```sh
#根据实际情况进行修改
cat  >> /root/ser/config.yaml  << 'KOF'
echo:
  bind: :6677
  static_path: /etc/zk/static

jwt:
  expire: 24
  secret: 10fc4956fb1d4f0f963d8cc2a3bf86e9

mysql:
  host: 172.27.41.61
  port: 13306
  username: root
  password: E376CR4Ky?,
  dbname: go_admin
  show_sql: true
  migrate: true

redis:
  has: true
  host: 172.27.41.61 
  port: 16379
  password: E376CR4Ky?,
  db: 1

leveldb:
  has: false
  path: ./leveldb_data

log:
  path: /etc/zk/log
  name: admin.log

url:
  order: "http://118.178.180.134/api/submit_order"
  check: "http://118.178.180.134/api/query_order"
  balance: "http://118.178.180.134/api/query_balance"
  callback_prefix: "http://118.178.180.134/api/notify"
KOF
```



#### (3)准备执行脚本

```sh
cat  >> /root/ser/start.sh  << 'KOF'
#!/bin/bash
echo "停止容器..."
docker stop zkapp
docker rm  -f zkapp
sleep 2

echo "删除镜像..."
docker rmi zk_app
rm -rf /root/ser/myapp
sleep 3

echo "打包镜像..."
cd /root/ser/ && docker build -t zk_app .

echo "运行容器..."
docker run -p 6677:6677 \
-e TZ=Asia/Shanghai \
-v /etc/localtime:/etc/localtime \
-v  /etc/zk:/etc/zk \
-v  /var/zk/log:/var/log/zk/log \
-v  /var/zk/static:/var/zk/static \
--restart=always \
--name zkapp \
-it  -d zk_app > /dev/null 2>&  1 &

sleep 2
echo "deploy success.."
KOF
```



#### (4)拷贝后端文件

```sh
#创建日志和静态文件目录 
mkdir -p /etc/zk/{log,static}
sudo chmod -R 755 /etc/zk/

#拷贝编译好的文件至/root/ser中
示例：mv zkapp /root/ser

#执行启动脚本
sh /root/ser/start.sh
```



### 4.验证

```sh
#至此，已经部署完成
#浏览器输入ip+端口进行访问即可

默认账号密码：
super
qwe123a
```











