package utils

import (
	"application/constant"
	"application/models"
	"errors"
	"fmt"
	"strings"

	"github.com/labstack/echo"
)

func SetUser(ctx echo.Context, user *models.User) {
	ctx.Set(constant.CONTEXT_KEY_USER, user)
}

func User(ctx echo.Context) *models.User {
	v := ctx.Get(constant.CONTEXT_KEY_USER)
	if v != nil {
		return ctx.Get(constant.CONTEXT_KEY_USER).(*models.User)
	}

	return nil
}

func UserId(ctx echo.Context) int64 {
	user := User(ctx)
	if user != nil {
		return user.ID
	}

	return 0
}

func Username(ctx echo.Context) string {
	user := User(ctx)
	if user != nil {
		return user.Username
	}
	return ""
}

func IsClient(ctx echo.Context) (bool, error) {
	user := User(ctx)
	if user != nil {
		return user.IsClient, nil
	}

	return false, errors.New("invalid user")
}

func CustomerID(ctx echo.Context) int64 {
	user := User(ctx)
	if user != nil {
		return user.CustomerID
	}

	return 0
}

func Company(ctx echo.Context) string {
	user := User(ctx)
	if user != nil {
		return user.Company
	}
	return ""
}

func SetContextUUID(ctx echo.Context, uuid string) {
	ctx.Set(constant.CONTEXT_KEY_UID, uuid)
}

func GetContextUUID(ctx echo.Context) string {
	data := ctx.Get(constant.CONTEXT_KEY_UID)
	if data != nil {
		return data.(string)
	}
	return ""
}

func IsSuperAdmin(ctx echo.Context) bool {
	user := User(ctx)
	if user != nil {
		return user.IsSuper
	}

	return false
}

func RoleID(ctx echo.Context) int64 {
	user := User(ctx)
	if user != nil {
		return user.Role
	}

	return 0
}

/*func IsAdmin(user *models.User) bool {
	// return true // todo : test --------------------------------------
	return user.Role == constant.ROLE_TYPE_ADMIN
}

func IsSuperAdmin(roleID int) bool {
	return roleID == 0
}*/

func MakePassword(password string) string {
	return Md5S(fmt.Sprintf("%s_%s_%s", constant.AUTH_PASSWORD_CODE1, password, constant.AUTH_PASSWORD_CODE2))
}

func CheckPassword(checkPassword string, userPassword string) bool {
	return MakePassword(checkPassword) == userPassword
}

/*func SetLog(ctx echo.Context, data *vo.LogRequestData) {
	ctx.Set(constant.CONTEXT_KEY_LOG, data)
}

func GetLog(ctx echo.Context) *vo.LogRequestData {
	data := ctx.Get(constant.CONTEXT_KEY_LOG)
	if data != nil {
		return data.(*vo.LogRequestData)
	}
	return nil
}*/

/*func SetContextData(ctx *echo.Context, key string, val interface{}) error {
	// 添加不让篡改的key
	if key == constant.CONTEXT_KEY_UID {
		return errors.New("context key 不合法")
	}
	if ctx != nil {
		c := *ctx
		c.Set(key, val)
	} else {
		return errors.New("context is nil")
	}
	return nil
}

func GetContextData(ctx *echo.Context, key string) (bool, interface{}) {
	var val interface{}
	if ctx != nil {
		c := *ctx
		val = c.Get(key)
	} else {
		return false, nil
	}
	// 上下文中取不到值
	if val == nil {
		return false, nil
	}
	return true, val
}*/

func ParseToken(ctx echo.Context) (token string, err error) {
	tokenPrefix := "Bearer"
	token = ctx.Request().Header.Get("Authorization")

	index := strings.Index(token, tokenPrefix)
	if index != 0 {
		err = errors.New("Error Token Format")
		return
	}
	return
}
