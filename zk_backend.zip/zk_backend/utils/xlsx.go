package utils

import (
	"application/common/logger"
	"fmt"
	"reflect"
	"strings"
	"time"

	"github.com/tealeg/xlsx"
	"go.uber.org/zap"
)

type TypeFieldMapper map[string]map[string]string

// XlsxModelWriter
// objs 必须是struct类型的列表
func XlsxModelWriter(filePath, sheetName string, objs any, fieldMapper TypeFieldMapper) (err error) {

	_mapper := make(TypeFieldMapper)
	if fieldMapper != nil {
		_mapper = fieldMapper
	}

	defer func() {
		if r := recover(); r != nil {
			logger.Log.Error("XlsxModelWriter", zap.Any("err", r))
			err = fmt.Errorf("xlsx err: %v", r)
		}
	}()

	objValue := reflect.ValueOf(objs)
	if objValue.Kind() != reflect.Slice {
		return fmt.Errorf("expected a slice, got %s", objValue.Kind())
	}

	if objValue.Len() == 0 {
		return fmt.Errorf("slice is empty")
	}

	elemType := objValue.Index(0).Type()
	if elemType.Kind() == reflect.Ptr {
		elemType = elemType.Elem()
	}

	file := xlsx.NewFile()
	sheet := new(xlsx.Sheet)
	sheet, err = file.AddSheet(sheetName)
	if err != nil {
		return
	}

	titleRow := sheet.AddRow()
	for i := 0; i < elemType.NumField(); i++ {
		fieldType := elemType
		if tag := fieldType.Field(i).Tag.Get("xlsx"); tag != "" && tag != "-" {
			parts := strings.Split(tag, " ")
			title := strings.TrimSpace(parts[0])
			titleRow.AddCell().Value = title
		}
	}

	for index := 0; index < objValue.Len(); index++ {
		structVal := objValue.Index(index)
		if structVal.Kind() == reflect.Ptr {
			structVal = structVal.Elem()
		}
		row := sheet.AddRow()
		for i := 0; i < structVal.NumField(); i++ {
			originalValue := structVal.Field(i).Interface()
			if t, ok := originalValue.(time.Time); ok {
				originalValue = t.Format("2006-01-02 15:04:05")
			}

			if tag := elemType.Field(i).Tag.Get("xlsx"); tag != "" && tag != "-" {
				parts := strings.Split(tag, " ")
				cell := row.AddCell()
				if len(parts) == 1 {
					// 假如是一个就是标题
					cell.Value = fmt.Sprintf("%v", originalValue)
					continue
				}

				var fromPart string      // from/()
				var fieldTypePart string // 类型 list
				if len(parts) > 1 {
					for index, part := range parts[1:] {
						if strings.Contains(part, "from:") || strings.HasSuffix(part, ")") {
							if strings.Contains(tag, "from:") {
								fromPart = part
							} else if strings.HasSuffix(part, ")") {
								if index-1 >= 0 {
									fromPart = fmt.Sprintf("%s %s", parts[1:][index-1], parts[1:][index])
								}
							}
						}
						if strings.Contains(tag, "type:") {
							fieldTypePart = part
						}
					}
				}

				if fromPart == "" {
					continue
				}

				replacements := make(map[string]string)
				if strings.HasSuffix(fromPart, ")") {
					mapping := strings.TrimSpace(strings.TrimSuffix(fromPart, ")"))
					mapping = strings.TrimSpace(strings.TrimPrefix(mapping, "("))
					for _, item := range strings.Split(mapping, " ") {
						kv := strings.Split(strings.TrimSpace(item), ":")
						if len(kv) == 2 {
							replacements[strings.TrimSpace(kv[0])] = strings.TrimSpace(kv[1])
						}
					}
				}

				if strings.Contains(fromPart, "from:") {
					fromPart = strings.TrimSpace(fromPart)
					fromPart = strings.TrimPrefix(fromPart, "from:")
					replacements = _mapper[fromPart]
				}

				if fieldTypePart != "" {
					fieldTypePart = strings.TrimPrefix(fieldTypePart, "type:")
					switch fieldTypePart {
					case "list":
						values := fmt.Sprintf("%v", originalValue)
						values = strings.TrimPrefix(values, "[")
						values = strings.TrimSuffix(values, "]")
						var valueList []string
						if strings.Contains(values, ",") {
							valueList = strings.Split(values, ",")
						} else {
							valueList = strings.Split(values, " ")
						}

						var fromList []string
						for _, value := range valueList {
							if _v, ok := replacements[value]; ok {
								fromList = append(fromList, _v)
							} else {
								fromList = append(fromList, fmt.Sprintf("%v", originalValue))
							}
						}
						cell.Value = strings.Join(fromList, ",")
					}
				} else {
					var s string
					value := fmt.Sprintf("%v", originalValue)
					if _v, ok := replacements[value]; ok {
						s = _v
					} else {
						s = value
					}
					cell.Value = s
				}
			}
		}
	}

	return file.Save(filePath)
}
