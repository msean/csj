package utils

import (
	"fmt"
	"time"

	"github.com/go-xorm/xorm"
)

const (
	LikeTypeLeft    = 1
	LikeTypeRight   = 2
	LikeTypeBetween = 3
)

const (
	CommonIDKey = "id"
)

type (
	Cond interface {
		Cond(db *xorm.Session) *xorm.Session
	}
	BaseCond struct {
		cond string
	}
	CmpCond struct {
		key    string
		value  any
		symbol string
	}
	WhereCond struct {
		key   string
		value any
	}

	InCond struct {
		key    string
		values []any
	}
	NotInCond struct {
		key    string
		values []any
	}
	OrderByCond struct {
		order string
	}
	WhereLikeCond struct {
		key   string
		value any
	}
	LimitCond struct {
		PageSize  int       `json:"page_size" form:"page_size"`
		PageNum   int       `json:"page" form:"page"`
		StartTime time.Time `json:"start_time" form:"start_time"`
		EndTime   time.Time `json:"end_time" form:"end_time"`
	}
	LimitCondAlternative struct {
		PageSize  int    `json:"page_size" form:"page_size"`
		PageNum   int    `json:"page" form:"page"`
		StartTime string `json:"start_time" form:"start_time"`
		EndTime   string `json:"end_time" form:"end_time"`
	}
	PageLimitCond struct {
		PageSize int `json:"page_size" form:"page_size"`
		PageNum  int `json:"page" form:"page"`
	}
	TimeLimitCond struct {
		StartTime time.Time `json:"start_time" form:"start_time"`
		EndTime   time.Time `json:"end_time" form:"end_time"`
	}

	FindFromArrayCond struct {
		Key   string
		Value interface{}
	}
)

func (alternative LimitCondAlternative) ToLimitCond() (limitCond LimitCond, err error) {
	loc, _ := time.LoadLocation("Asia/Shanghai")
	var st, et time.Time
	if alternative.StartTime != "" {
		st, err = time.ParseInLocation("2006-01-02 15:04:05", alternative.StartTime, loc)
		if err != nil {
			return
		}
	}
	if alternative.EndTime != "" {
		et, err = time.ParseInLocation("2006-01-02 15:04:05", alternative.StartTime, loc)
		if err != nil {
			return
		}
	}

	limitCond = LimitCond{
		PageSize:  alternative.PageSize,
		PageNum:   alternative.PageNum,
		StartTime: st,
		EndTime:   et,
	}
	return
}

func NewWhereLikeCond(key, value string, likeType int) Cond {
	var likeValue string
	switch likeType {
	case LikeTypeLeft:
		likeValue = fmt.Sprintf("'%s%s'", "%", value)
	case LikeTypeRight:
		likeValue = fmt.Sprintf("'%s%s'", value, "%")
	case LikeTypeBetween:
		likeValue = fmt.Sprintf("'%s%s%s'", "%", value, "%")
	}
	return WhereLikeCond{
		key:   key,
		value: likeValue,
	}
}

func NewBaseCond(cond string) Cond {
	return BaseCond{
		cond: cond,
	}
}

func (wl WhereLikeCond) Cond(db *xorm.Session) *xorm.Session {
	db = db.Where(fmt.Sprintf("%s like %s", wl.key, wl.value))
	return db
}

func NewWhereCond(key string, value any) Cond {
	return WhereCond{
		key:   key,
		value: value,
	}
}

func (w WhereCond) Cond(db *xorm.Session) *xorm.Session {
	db = db.Where(fmt.Sprintf("%s=?", w.key), w.value)
	return db
}

func NewInCond(key string, values ...any) Cond {
	return InCond{
		key:    key,
		values: values,
	}
}

func (i InCond) Cond(db *xorm.Session) *xorm.Session {
	db = db.In(i.key, i.values...)
	return db
}

func NewCmpCond(key string, symbol string, value any) Cond {
	return CmpCond{
		key:    key,
		value:  value,
		symbol: symbol,
	}
}

func (c CmpCond) Cond(db *xorm.Session) *xorm.Session {
	db = db.Where(fmt.Sprintf("%s %s ?", c.key, c.symbol), c.value)
	return db
}

func (base BaseCond) Cond(db *xorm.Session) *xorm.Session {
	db = db.Where(base.cond)
	return db
}

func MutateLimitCond(in LimitCond) (timeLimit TimeLimitCond, pageLimit PageLimitCond) {
	pageLimit = PageLimitCond{
		PageSize: in.PageSize,
		PageNum:  in.PageNum,
	}
	timeLimit = TimeLimitCond{
		StartTime: in.StartTime,
		EndTime:   in.EndTime,
	}

	if pageLimit.PageNum >= 1 {
		pageLimit.PageNum = pageLimit.PageNum - 1
	}
	return
}

func (l PageLimitCond) Mutate() PageLimitCond {
	if l.PageNum >= 1 {
		l.PageNum = l.PageNum - 1
	}
	return l
}

func (l PageLimitCond) Cond(db *xorm.Session) *xorm.Session {
	if l.PageSize > 0 {
		db = db.Limit(l.PageSize, l.PageSize*l.PageNum)
	}
	return db
}

func (tL TimeLimitCond) Cond(db *xorm.Session) *xorm.Session {
	if !tL.StartTime.IsZero() {
		db = db.Where("created >= ?", tL.StartTime.Local())
	}
	if !tL.EndTime.IsZero() {
		db = db.Where("created <= ?", tL.EndTime.Local())
	}
	return db
}

func (l LimitCond) Cond(db *xorm.Session) *xorm.Session {
	if l.PageSize > 0 {
		db = db.Limit(l.PageSize, l.PageNum)
	}

	if !l.StartTime.IsZero() {
		db = db.Where("created >= ?", l.StartTime.Local())
	}
	if !l.EndTime.IsZero() {
		db = db.Where("created <= ?", l.EndTime.Local())
	}
	return db
}

func NewNotInCond(key string, values []any) Cond {
	return NotInCond{
		key:    key,
		values: values,
	}
}

func (o NotInCond) Cond(db *xorm.Session) *xorm.Session {
	db = db.NotIn(o.key, o.values...)
	return db
}

func NewOrderByCond(order string) Cond {
	return OrderByCond{
		order: order,
	}
}

func (o OrderByCond) Cond(db *xorm.Session) *xorm.Session {
	db = db.OrderBy(o.order)
	return db
}

func (o FindFromArrayCond) Cond(db *xorm.Session) *xorm.Session {
	cond := fmt.Sprintf("%s like ? ", o.Key)
	db = db.Where(cond, "%"+fmt.Sprintf("[%v,", o.Value)+"%").
		Or(cond, "%"+fmt.Sprintf(",%v]", o.Value)+"%").
		Or(cond, "%"+fmt.Sprintf(",%v,", o.Value)+"%").
		Or(cond, fmt.Sprintf("[%v]", o.Value))
	return db
}

func Find(session *xorm.Session, dst any, conds ...Cond) error {
	for _, cond := range conds {
		session = cond.Cond(session)
	}
	return session.Find(dst)
}

func Get(session *xorm.Session, dst any, conds ...Cond) (has bool, err error) {
	for _, cond := range conds {
		session = cond.Cond(session)
	}
	return session.Get(dst)
}

func Create(session *xorm.Session, obj ...any) (count int64, err error) {
	count, err = session.Insert(obj...)
	return
}

func IDCond(val any) Cond {
	return NewWhereCond(CommonIDKey, val)
}

func TotalByConds(session *xorm.Session, model any, conds ...Cond) (total int64, err error) {
	for _, cond := range conds {
		session = cond.Cond(session)
	}
	return session.Count(model)
}

func Update(session *xorm.Session, updates map[string]any, conds ...Cond) (total int64, err error) {
	for _, cond := range conds {
		session = cond.Cond(session)
	}
	return session.Update(updates)
}
