package utils

import (
	"testing"
	"time"
)

func TestXlsx(t *testing.T) {
	type Bean struct {
		ID int64
	}
	type structTest struct {
		Bean
		IntVal     int     `xlsx:"IntVal (16:完成 17:失败 18:不确定)"`
		StringVal  string  `xlsx:"StringVal from:hello"`
		FloatVal   float64 `xlsx:"FloatVal"`
		IgnoredVal int
		BoolVal    bool      `xlsx:"BoolVal (yes:是 false:否)"`
		TypeVal    string    `xlsx:"TypeVal from:hello type:list"`
		Time       time.Time `xlsx:"Time"`
	}

	structVals := []*structTest{
		{
			IntVal:     17,
			StringVal:  "you",
			FloatVal:   2222.0,
			IgnoredVal: 10,
			BoolVal:    false,
			TypeVal:    "[you me]",
			Time:       time.Now(),
		},
	}

	XlsxModelWriter("output.xlsx", "sheet", structVals, nil)
}
