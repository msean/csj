package utils

import (
	"bytes"
	"encoding/xml"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"net/url"
	"time"

	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
)

const (
	ReqTypeGet      = 1
	ReqTypePost     = 2
	ReqTypePostForm = 3
)

const (
	EncodingUTF8   = "UTF-8"
	EncodingGB2312 = "GB2312"
)

type Request struct {
	reqType  int
	url      string
	headers  map[string]string
	timeout  time.Duration
	payload  []byte
	params   map[string]string
	retries  int
	encoding string
}

func NewRequest() *Request {
	return &Request{
		headers:  make(map[string]string),
		params:   map[string]string{},
		retries:  3,
		timeout:  60 * time.Second,
		encoding: EncodingUTF8, // 默认 UTF-8
	}
}

func (r *Request) Get() *Request {
	r.reqType = ReqTypeGet
	return r
}

func (r *Request) Timeout(timeout time.Duration) *Request {
	r.timeout = timeout
	return r
}

func (r *Request) Post() *Request {
	r.reqType = ReqTypePost
	return r
}

func (r *Request) PostForm() *Request {
	r.reqType = ReqTypePostForm
	return r
}

func (r *Request) Url(url string) *Request {
	r.url = url
	return r
}

func (r *Request) Payload(body []byte) *Request {
	r.payload = body
	return r
}

func (r *Request) Params(params map[string]string) *Request {
	r.params = params
	return r
}

func (r *Request) Header(headers map[string]string) *Request {
	r.headers = headers
	return r
}

func (r *Request) Retry(retries int) *Request {
	r.retries = retries
	return r
}

func (r *Request) Encoding(encoding string) *Request {
	r.encoding = encoding
	return r
}

func utf8ToGB2312(input string) ([]byte, error) {
	encoder := simplifiedchinese.GB18030.NewEncoder()
	return encoder.Bytes([]byte(input))
}

func gb2312ToUTF8(input []byte) ([]byte, error) {
	decoder := simplifiedchinese.GB18030.NewDecoder()
	return decoder.Bytes(input)
}

// post json body 或者get form-data
func (r *Request) Do() (code int, body []byte, err error) {
	var request *http.Request

	// 处理 GET 请求
	if r.reqType == ReqTypeGet {
		values := url.Values{}
		for k, v := range r.params {
			values.Add(k, v)
		}
		r.url += "?" + values.Encode()
		r.headers["Content-Type"] = "application/x-www-form-urlencoded"
		request, err = http.NewRequest("GET", r.url, nil)
		if err != nil {
			return
		}
	}

	// 处理 POST 请求
	if r.reqType == ReqTypePost {
		r.headers["Content-Type"] = "application/json"
		request, err = http.NewRequest("POST", r.url, bytes.NewBuffer(r.payload))
		if err != nil {
			return
		}
	}

	// 处理 POST 表单请求
	if r.reqType == ReqTypePostForm {
		r.headers["Content-Type"] = "application/x-www-form-urlencoded"
		formData := url.Values{}
		for k, v := range r.params {
			formData.Set(k, v)
		}
		encodedData := []byte(formData.Encode())
		if r.encoding == EncodingGB2312 {
			r.headers["Content-Type"] = "application/x-www-form-urlencoded; charset=GB2312"
			encodedData, err = utf8ToGB2312(formData.Encode())
			if err != nil {
				return 0, nil, fmt.Errorf("GB2312 encode error: %w", err)
			}
		}
		request, err = http.NewRequest("POST", r.url, bytes.NewReader(encodedData))
		if err != nil {
			return
		}
		if err != nil {
			return
		}
	}

	for k, v := range r.headers {
		request.Header.Set(k, v)
	}

	client := &http.Client{
		Timeout: r.timeout,
	}

	var resp *http.Response
	for index := 0; index < r.retries; index++ {
		resp, err = client.Do(request)
		if err != nil {
			continue
		}
		defer resp.Body.Close()

		code = resp.StatusCode
		body, err = ioutil.ReadAll(resp.Body)
		if err != nil {
			return
		}
		return
	}

	return 0, nil, fmt.Errorf("failed to execute request after %d retries: %w", r.retries, err)
}

func Gb2312CharsetReader(charset string, input io.Reader) (io.Reader, error) {
	if charset == "gb2312" || charset == "GB2312" {
		return transform.NewReader(input, simplifiedchinese.GB18030.NewDecoder()), nil
	}
	return input, fmt.Errorf("unsupported charset: %s", charset)
}

func ParseXML(body []byte, result interface{}) error {
	decoder := xml.NewDecoder(bytes.NewReader(body))
	decoder.CharsetReader = Gb2312CharsetReader
	return decoder.Decode(result)
}
