package utils

import (
	"errors"
	"fmt"
	"strings"
	"time"
)

func TimeParseDay(str string) (*time.Time, error) {
	timeStr := str
	if splits := strings.Split(str, " "); len(splits) > 0 {
		timeStr = splits[0]
	}

	res, err := time.Parse("2006-01-02", timeStr)
	if err != nil {
		return nil, err
	}

	return &res, nil
}

func TimeSubDay(startTime string, endTime string) (int, error) {
	start, err := TimeParseDay(startTime)
	if err != nil {
		return 0, errors.New("error start time, " + err.Error())
	}

	end, err := TimeParseDay(endTime)
	if err != nil {
		return 0, errors.New("error end time, " + err.Error())
	}

	return int(end.Sub(*start).Hours() / 24), nil
}

func TimeSubString(end, start time.Time) (take string) {
	if end.After(start) {
		duration := end.Sub(start)
		hours := int(duration.Hours())
		minutes := int(duration.Minutes()) % 60
		seconds := int(duration.Seconds()) % 60
		if hours > 0 {
			take = fmt.Sprintf("%d小时%d分钟%d秒", hours, minutes, seconds)
		} else if minutes > 0 {
			take = fmt.Sprintf("%d分钟%d秒", minutes, seconds)
		} else {
			take = fmt.Sprintf("%d秒", seconds)
		}
	}
	return
}

func MonthDays(year int, month int) int {
	firstDay := time.Date(year, time.Month(month), 1, 0, 0, 0, 0, time.UTC)
	return firstDay.AddDate(0, 1, -1).Day()
}

var (
	YYMMDD           = "20060102"
	YYMMDDDash       = "2006-01-02"
	YYMMDDSecondDash = "2006-01-02 15:04:05"
)
