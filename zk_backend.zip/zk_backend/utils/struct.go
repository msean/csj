package utils

import (
	"reflect"
)

func StructToMap(pack any) (result map[string]any) {
	result = make(map[string]any)
	val := reflect.ValueOf(pack)
	typ := reflect.TypeOf(pack)

	if typ.Kind() != reflect.Struct {
		return
	}

	for i := 0; i < val.NumField(); i++ {
		field := typ.Field(i)
		jsonTag := field.Tag.Get("json")
		if jsonTag != "" {
			result[jsonTag] = val.Field(i).Interface()
		}
	}

	return result
}
