package jwt_auth

import (
	"errors"
	"time"

	"github.com/dgrijalva/jwt-go"
)

var (
	EXPIRE time.Duration
	SECRET string
)

type JWTClaims struct {
	Uuid    int64  `json:"uuid"`
	Account string `json:"account"`
	jwt.StandardClaims
}

func GenToken(id int64, account string) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, JWTClaims{
		id,
		account,
		jwt.StandardClaims{
			ExpiresAt: time.Now().Add(EXPIRE).Unix(),
		},
	})

	return token.SignedString([]byte(SECRET))
}

func ParseToken(token string) (*JWTClaims, error) {
	data, err := jwt.ParseWithClaims(token, &JWTClaims{},
		func(token *jwt.Token) (i interface{}, err error) {
			return []byte(SECRET), nil
		})

	if err != nil {
		return nil, err
	}

	if claims, ok := data.Claims.(*JWTClaims); ok && data.Valid {
		return claims, nil
	}

	return nil, errors.New("invalid token")
}
