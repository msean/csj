package utils

import (
	"github.com/labstack/echo"
)

func ParamsCheck(c echo.Context, params any) (err error) {
	if err = c.Bind(params); err != nil {
		return
	}
	if err = c.Validate(params); err != nil {
		return
	}
	return
}
