package utils

import (
	"application/constant"
	"fmt"
	"math"
	"strconv"
	"strings"
)

func IntSecurityDiv(numerator int, denominator int, reserve uint) (_f float64) {
	if denominator == 0 {
		return 0
	}
	return FloatReserve(float64(numerator)/float64(denominator), reserve)
}

func Float64SecurityDiv(numerator float64, denominator float64, reserve uint) (_f float64) {
	if denominator == 0 {
		return 0
	}
	return FloatReserve(float64(numerator)/float64(denominator), reserve)
}

func FloatReserve(f float64, reserve uint) float64 {
	factor := math.Pow(10, float64(reserve))
	rounded := math.Round(f*factor) / factor

	roundedStr := fmt.Sprintf("%.*f", reserve, rounded)

	_f, _ := strconv.ParseFloat(roundedStr, 64)
	return _f
}

func FloatReserveString(f float64, reserve int) string {
	formatted := strconv.FormatFloat(f*100, 'f', reserve, 64)
	formatted = strings.TrimRight(strings.TrimRight(formatted, "0"), ".")
	return formatted + "%"
}

func FloatReserveStr(f float64, reserve int) string {
	formatted := strconv.FormatFloat(f, 'f', reserve, 64)
	formatted = strings.TrimRight(strings.TrimRight(formatted, "0"), ".")
	return formatted
}

func CalByType(baseValue float64, calValue float64, calType uint8) float64 {
	if calType == constant.CAL_TYPE_PLUS {
		return baseValue + calValue
	}

	if calType == constant.CAL_TYPE_MINUS {
		return baseValue - calValue
	}

	if calType == constant.CAL_TYPE_MUL {
		return baseValue * calValue
	}

	if calType == constant.CAL_TYPE_DIVIDE && calValue != 0 {
		return baseValue / calValue
	}

	if calType == constant.CAL_TYPE_NONE {
		return calValue
	}

	return 0
}

func FormatFloat(value float64) float64 {
	value, _ = strconv.ParseFloat(fmt.Sprintf("%.2f", value), 64)
	return value
}

func LessThanWithPrecision(a, b, epsilon float64) bool {
	return (b - a) > epsilon
}
