package utils

import (
	"time"

	"github.com/google/uuid"
	"gopkg.in/redis.v5"
)

type Lock struct {
	key           string
	value         string
	expire        time.Duration
	redisCli      *redis.Client
	retryCount    int
	retryInterval time.Duration
}

func NewLock(key string,
	expire time.Duration,
	rds *redis.Client,
	retryCount int,
	retryInterval time.Duration,

) *Lock {
	return &Lock{
		retryCount:    retryCount,
		retryInterval: retryInterval,
		key:           key,
		expire:        expire,
		redisCli:      rds,
	}
}

func (lock *Lock) Lock() bool {
	uniqueID := uuid.New().String()

	for i := 0; i <= lock.retryCount; i++ {
		ok, err := lock.redisCli.SetNX(lock.key, uniqueID, lock.expire).Result()
		if err != nil {
			return false
		}
		if ok {
			lock.value = uniqueID
			return true
		}

		time.Sleep(lock.retryInterval)
	}

	return false
}

func (lock *Lock) Unlock() (err error) {
	script := `
    if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
    else
        return 0
    end`
	_, err = lock.redisCli.Eval(script, []string{lock.key}, lock.value).Result()
	return
}
