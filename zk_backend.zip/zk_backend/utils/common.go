package utils

import (
	"fmt"
	"net"
	"runtime"
	"time"

	"golang.org/x/exp/rand"
)

func GetCurrentFuncName() string {
	pc := make([]uintptr, 1)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	return f.Name()
}

func RandomByNow() uint64 {
	now := uint64(time.Now().UnixNano())
	rand.Seed(now)
	return rand.New(rand.NewSource(now)).Uint64()
}

func MakeOrderID(extra string) string {
	rand.Seed(uint64(time.Now().UnixNano()))
	return fmt.Sprintf("%s%s%04d", time.Now().Format("20060102150405"), extra, rand.Intn(10000))
}

func DedupeInt64Slice(input []int64) []int64 {
	seen := make(map[int64]struct{})
	var result []int64

	for _, value := range input {
		if _, exists := seen[value]; !exists {
			seen[value] = struct{}{}
			result = append(result, value)
		}
	}
	return result
}

func DedupeStringSlice(input []string) []string {
	seen := make(map[string]struct{})
	var result []string

	for _, value := range input {
		if _, exists := seen[value]; !exists {
			seen[value] = struct{}{}
			result = append(result, value)
		}
	}
	return result
}

func SliceToAny(slice []int64) []interface{} {
	interfaceSlice := make([]interface{}, len(slice))
	for i, v := range slice {
		interfaceSlice[i] = v
	}
	return interfaceSlice
}

func StringSliceToAny(slice []string) []interface{} {
	interfaceSlice := make([]interface{}, len(slice))
	for i, v := range slice {
		interfaceSlice[i] = v
	}
	return interfaceSlice
}

func IsValidIP(ip string) bool {
	return net.ParseIP(ip) != nil
}
