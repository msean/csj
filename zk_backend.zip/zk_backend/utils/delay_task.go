package utils

import (
	"sync"
	"time"
)

// type (
// 	DelayTaskFunc func() error
// 	DelayTask     struct {
// 		execTime time.Time
// 		exec     DelayTaskFunc
// 		done     func()
// 	}
// 	DelayTaskScheduler struct {
// 		taskCh chan DelayTask
// 		stop   chan struct{}
// 	}
// )

// func (s *DelayTaskScheduler) Run() {
// 	for {
// 		select {
// 		case t := <-s.taskCh:
// 			durationUntilExec := time.Until(t.execTime)
// 			if durationUntilExec <= 0 {
// 				if err := t.exec(); err == nil {
// 					t.done()
// 				}
// 			} else {
// 				go func(task DelayTask) {
// 					defer func() {
// 						if r := recover(); r != nil {
// 							logger.Log.Error("DelayTaskScheduler panic recovered", zap.Any("error", r))
// 						}
// 					}()
// 					<-time.After(durationUntilExec)
// 					if err := task.exec(); err == nil {
// 						t.done()
// 					}
// 				}(t)
// 			}

// 		case <-s.stop:
// 			return
// 		}
// 	}
// }

// func NewDelayTaskScheduler() *DelayTaskScheduler {
// 	return &DelayTaskScheduler{
// 		taskCh: make(chan DelayTask, 100),
// 		stop:   make(chan struct{}),
// 	}
// }

// func NewDelayTask(t time.Time, f DelayTaskFunc, done func()) DelayTask {
// 	return DelayTask{
// 		execTime: t,
// 		exec:     f,
// 		done:     done,
// 	}
// }

// func (s *DelayTaskScheduler) Add(task DelayTask) {
// 	s.taskCh <- task
// }

type (
	DelayTaskFunc func() error

	DelayTask struct {
		ID       int64
		ExecTime time.Time
		Exec     DelayTaskFunc
		Done     func()
		Status   int // 1 正常  2 作废
	}

	DelayTaskScheduler struct {
		tasks  map[int64]*DelayTask
		mu     sync.Mutex
		ticker *time.Ticker
		stop   chan struct{}
	}
)

func NewDelayTaskScheduler() *DelayTaskScheduler {
	s := &DelayTaskScheduler{
		tasks:  make(map[int64]*DelayTask),
		ticker: time.NewTicker(1 * time.Minute),
		stop:   make(chan struct{}),
	}
	go s.Run()
	return s
}

func (s *DelayTaskScheduler) Add(task DelayTask, id int64) {
	s.mu.Lock()
	defer s.mu.Unlock()

	task.ID = id
	s.tasks[id] = &task
}

func (s *DelayTaskScheduler) Delete(taskID int64) {
	s.mu.Lock()
	defer s.mu.Unlock()

	delete(s.tasks, taskID)
}

func (s *DelayTaskScheduler) Discard(taskID int64) {
	s.mu.Lock()
	defer s.mu.Unlock()

	var task *DelayTask
	var exist bool

	if exist, task = s.Get(taskID); exist {
		task.Status = 2
	}
}

func (s *DelayTaskScheduler) Get(taskID int64) (bool, *DelayTask) {
	s.mu.Lock()
	defer s.mu.Unlock()

	task, exists := s.tasks[taskID]
	return exists, task
}

func (s *DelayTaskScheduler) Run() {
	for {
		select {
		case <-s.ticker.C:
			s.checkAndRunTasks()
		case <-s.stop:
			return
		}
	}
}

func (s *DelayTaskScheduler) checkAndRunTasks() {
	s.mu.Lock()
	defer s.mu.Unlock()

	now := time.Now()
	for id, task := range s.tasks {
		if (task.ExecTime.Before(now) || task.ExecTime.Equal(now)) && task.Status != 2 {
			go func(t DelayTask) {
				if err := t.Exec(); err == nil {
					t.Done()
				}
			}(*task)
			delete(s.tasks, id)
		}
	}
}

func (s *DelayTaskScheduler) Stop() {
	close(s.stop)
	s.ticker.Stop()
}

func NewDelayTask(execTime time.Time, f DelayTaskFunc, done func()) DelayTask {
	return DelayTask{
		ExecTime: execTime,
		Exec:     f,
		Done:     done,
		Status:   1,
	}
}
