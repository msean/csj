package utils

import "strings"

func ParseAgent(agent string) (browser, os string) {
	ua := strings.ToLower(agent)

	if strings.Contains(ua, "msie") || strings.Contains(ua, "trident") {
		browser = "Internet Explorer"
	} else if strings.Contains(ua, "edge") {
		browser = "Microsoft Edge"
	} else if strings.Contains(ua, "firefox") {
		browser = "Mozilla Firefox"
	} else if strings.Contains(ua, "chrome") {
		browser = "Google Chrome"
	} else if strings.Contains(ua, "safari") {
		browser = "Apple Safari"
	} else {
		browser = "Unknown"
	}

	if strings.Contains(ua, "windows") {
		os = "Windows"
	} else if strings.Contains(ua, "mac os x") {
		os = "macOS"
	} else if strings.Contains(ua, "linux") {
		os = "Linux"
	} else if strings.Contains(ua, "android") {
		os = "Android"
	} else if strings.Contains(ua, "ios") {
		os = "iOS"
	} else {
		os = "Unknown"
	}

	return browser, os
}
