package utils

import (
	"encoding/base64"
	"fmt"
	"github.com/skip2/go-qrcode"
	"golang.org/x/exp/rand"
	"time"
)

const (
	_GOOGLE_AUTH_RANDOM_STR = "00wwSS00wSDJWs223sKf3dWIE23381293DHSD"
	_GOOGLE_AUTH_STR        = "otpauth://totp/%s?secret=%s&issuer=%d"
)

func GenerateGoogleCode() string {
	now := uint64(time.Now().UnixNano())
	rand.Seed(now)
	randNum := rand.New(rand.NewSource(now)).Uint64()
	index1 := rand.Intn(len(_GOOGLE_AUTH_RANDOM_STR))
	strLen := rand.Intn(len(_GOOGLE_AUTH_RANDOM_STR) - index1)
	str := _GOOGLE_AUTH_RANDOM_STR[index1 : index1+strLen]
	return base64.StdEncoding.EncodeToString([]byte(fmt.Sprintf("%d_%s_%d", now, str, randNum)))
}

func GenerateGoogleQrCode(userName string, department int8, googleCode string) string {
	return fmt.Sprintf(_GOOGLE_AUTH_STR, userName, googleCode, department)
}

func GenerateGoogleQrCodeBase64(content string) (string, error) {
	imageBuff, err := qrcode.Encode(content, qrcode.Medium, 256)
	if err != nil {
		return "", err
	}

	return base64.StdEncoding.EncodeToString(imageBuff), nil
}
