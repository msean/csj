package utils

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"io"
)

// Md5S md5加密
func Md5S(str string) string {
	w := md5.New()
	io.WriteString(w, str)
	md5str := fmt.Sprintf("%x", w.Sum(nil))
	return md5str
}

func Md5KvArray(array [][2]any, connSymbol string) string {
	var hashContent string
	for i, vs := range array {
		if i == 0 {
			hashContent += fmt.Sprintf("%v=%v", vs[0], vs[1])
		} else {
			hashContent += fmt.Sprintf("%s%v=%v", connSymbol, vs[0], vs[1])
		}
	}

	hash := md5.New()
	hash.Write([]byte(hashContent))
	hashed := hash.Sum(nil)

	return hex.EncodeToString(hashed)
}
