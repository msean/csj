package utils

import (
	"strconv"
)

func RemoveIntSliceElement(slice []int, elements ...int) []int {
	toRemove := make(map[int]struct{})
	for _, e := range elements {
		toRemove[e] = struct{}{}
	}

	result := make([]int, 0, len(slice))
	for _, v := range slice {
		if _, found := toRemove[v]; !found {
			result = append(result, v)
		}
	}
	return result
}

func ConvertIntFromString(s string, dst *int) (err error) {
	var number int
	if number, err = strconv.Atoi(s); err != nil {
		return
	}
	*dst = number
	return
}
func ConvertInt64FromString(s string, dst *int64) (err error) {
	var number int64
	if number, err = strconv.ParseInt(s, 10, 64); err != nil {
		return
	}
	*dst = number
	return
}
func MinInt(items ...int) (min int, has bool) {
	has = true
	if len(items) == 0 {
		has = false
		return
	}

	min = items[0]
	for _, item := range items[1:] {
		if item < min {
			min = item
		}
	}
	return
}
