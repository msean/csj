package utils

import (
	"application/common/logger"
	"errors"
	"fmt"
	"os"
	"runtime/debug"
)

func ReadFile(filename string) (string, error) {
	var file *os.File
	defer func() {
		if file != nil {
			err := file.Close()
			if err != nil {
				logger.Log.Error(fmt.Sprintf("close file[%s] failed, %v", filename, err))
			}
		}

		if r := recover(); r != nil {
			logger.Log.Error(fmt.Sprintf("read file[%s] failed, %v, %v", filename, r, string(debug.Stack())))
		}
	}()

	if filename == "" {
		logger.Log.Warn(fmt.Sprintf("read file[%s] failed, invalid filename", filename))
		return "", errors.New("invalid filename")
	}

	file, err := os.Open(filename)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("read file[%s] failed, open failed, %v", filename, err))
		return "", err
	}

	var content []byte
	buf := make([]byte, 1024*1024)
	for {
		n, err := file.Read(buf)
		if n <= 0 || err != nil {
			break
		}

		content = append(content, buf[:n]...)
	}

	return string(content), nil
}
