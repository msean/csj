package utils

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"sort"
	"strings"
	"testing"
	"time"
)

func TestFloatReserve(t *testing.T) {
	fmt.Println(FloatReserve(156.1590002, 4))
}

func TestFloatReserveStr(t *testing.T) {
	fmt.Println(FloatReserveStr(156.1590002, 4))
}
func TestRequestTest(t *testing.T) {
	_, bytes, err := NewRequest().Get().Url("https://hima.auto/wenjie/").Do()
	fmt.Println(">>>>>>>>>>>>>>", string(bytes), err)
}

func TestRange(t *testing.T) {
	chars := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	fmt.Println(">>>>>>>>>>>", RandomFromRange(chars, 5))
}

// {
//     "szAgentId": "6",
//     "szOrderId": "111111111",
//     "szPhoneNum":  "15112534872",
//     "nMoney": 1,
//     "nSortType": 1,
//     "nProductClass": 1,
//     "nProductType":"1",
//     "szProductId": "1000001",
//     "szVerifyString": 1,
//     "szNotifyUrl": "http://47.97.155.182:6677/api/notify/4",
//     "szFormat": "JSON"
// }

func TestOrder(t *testing.T) {
	layout := "2006-01-02 15:04:05"
	params := map[string]string{
		"szAgentId":     "40",
		"szOrderId":     "cs_1111",
		"szPhoneNum":    "15112534872",
		"nMoney":        "20",
		"nSortType":     "1",
		"nProductClass": "1",
		"nProductType":  "1",
		"szProductId":   "1000020",
		"szTimeStamp":   time.Now().Format(layout),
		"szKey":         "5f27d53e8a368d95bf8d05cb766ead98",
	}

	sign := Md5KvArray([][2]any{
		{"szAgentId", params["szAgentId"]},
		{"szOrderId", params["szOrderId"]},
		{"szPhoneNum", params["szPhoneNum"]},
		{"nMoney", params["nMoney"]},
		{"nSortType", params["nSortType"]},
		{"nProductClass", params["nProductClass"]},
		{"nProductType", params["nProductType"]},
		{"szTimeStamp", params["szTimeStamp"]},
		{"szKey", params["szKey"]}}, "&")
	params["szVerifyString"] = sign
	// code, body, err := NewRequest().Url("http://47.97.155.182:6677/api/submitorder").Params(params).PostForm().Do()
	code, body, err := NewRequest().Url("http://154.91.84.12/api/submit_order").Params(params).PostForm().Do()
	fmt.Println(">>>>>>>>>>>code", code)
	fmt.Println(">>>>>>>>>>>body", string(body))
	fmt.Println(">>>>>>>>>>>err", err)
}

func TestConvertIntFromString(t *testing.T) {
	var dst int
	err := ConvertIntFromString("11", &dst)
	fmt.Println(">>>>>>>>>>", dst, err)
}

func sign1(params map[string]string, key string) string {

	keys := make([]string, 0, len(params))
	for k := range params {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	var sb string
	for _, k := range keys {
		sb += fmt.Sprintf("%s=%s&", k, params[k])
	}

	sb += fmt.Sprintf("key=%s", key)

	hash := md5.New()
	hash.Write([]byte(sb))
	return hex.EncodeToString(hash.Sum(nil))
}

func sign2(requestParams map[string]any, apiSecret string) string {
	var keys []string
	for key := range requestParams {
		keys = append(keys, key)
	}
	sort.Strings(keys)

	var strBuilder strings.Builder
	for _, key := range keys {
		value := requestParams[key]
		if value != nil && value != "" {
			strBuilder.WriteString(fmt.Sprintf("%s=%v&", key, value))
		}
	}

	toSign := strBuilder.String() + "key=" + apiSecret

	md5Hash := md5.Sum([]byte(toSign))
	signResult := hex.EncodeToString(md5Hash[:])
	return signResult
}

// {"customerOrderID": "",
// "callback_rsp": {"appId":"uUEYHm","thirdOrderNo":"00058-12552-00019","_sign":"a879d7f8209b8c0e6aedad2226c98743","time":1731656726,"amount":"10.000000","certNo":"","queryUrl":"","rechargeStatus":4,"phone":"15112534872"}, "sign": "bOQrqaOeqcBOe75asL8o5raWvX3LU37N"}
func TestCallbackSign(t *testing.T) {
	type CallBackRsp struct {
		AppID          string `json:"appId" form:"appId"`
		ThirdOrderNo   string `json:"thirdOrderNo" form:"thirdOrderNo"`
		Sign           string `json:"_sign" form:"_sign"`
		Time           int    `json:"time" form:"time"`
		Amount         string `json:"amount" form:"amount"`
		CertNo         string `json:"certNo" form:"certNo"`
		QueryUrl       string `json:"queryUrl" form:"queryUrl"`
		RechargeStatus int    `json:"rechargeStatus" form:"rechargeStatus"` // 支付状态  2充值成功，3充值失败，4订单超时，5已取消
		Phone          string `json:"phone" form:"phone"`
	}

	callback := CallBackRsp{
		AppID:          "uUEYHm",
		ThirdOrderNo:   "00058-12552-00019",
		Sign:           "a879d7f8209b8c0e6aedad2226c98743",
		Time:           1731656726,
		Amount:         "10.000000",
		CertNo:         "",
		QueryUrl:       "",
		RechargeStatus: 4,
		Phone:          "15112534872",
	}

	_sign1 := sign1(map[string]string{
		"appId":          callback.AppID,
		"thirdOrderNo":   callback.ThirdOrderNo,
		"time":           Violent2String(callback.Time),
		"amount":         callback.Amount,
		"certNo":         callback.CertNo,
		"queryUrl":       callback.QueryUrl,
		"rechargeStatus": Violent2String(callback.RechargeStatus),
		"phone":          callback.Phone,
	}, "bOQrqaOeqcBOe75asL8o5raWvX3LU37N")
	fmt.Println(">>>>>>>>>>_sign1", _sign1)

	_sign2 := sign2(map[string]any{
		"appId":          callback.AppID,
		"thirdOrderNo":   callback.ThirdOrderNo,
		"time":           callback.Time,
		"amount":         callback.Amount,
		"certNo":         callback.CertNo,
		"queryUrl":       callback.QueryUrl,
		"rechargeStatus": callback.RechargeStatus,
		"phone":          callback.Phone,
	}, "bOQrqaOeqcBOe75asL8o5raWvX3LU37N")
	fmt.Println(">>>>>>>>>>_sign2", _sign2)
}
