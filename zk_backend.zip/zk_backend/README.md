后台基础框架 
echo,jwt,xorm,lumberjack,redis,leveldb

### application

参数过滤拦截服务

### 部署文档

##### 项目打包后把打包后的文件（application）和配置文件（config.yaml）上传到服务器上，赋权限

``````
chmod +x application
``````



##### 更改config.yaml配置文件

```

```

#### 一、docker部署

上传start.sh、Dockerfile文件，赋权限

``````
chmod +x start.sh Dockerfile
``````

执行启动命令

``````
./start.sh
``````



#### 二、直接部署

``````
nohup ./application > nohub.out 2>&1 &
``````



#### 三、守护程序部署

上传守护程序文件deamon，赋权限

``````
chmod +x deamon
``````

执行启动命令

``````
nohup ./deamon -p ./application > nohub.out 2>&1 &
``````

