package adminlog

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"
	"strconv"
	"strings"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	g := eg.Group("/adminlog")
	{
		g.POST("/find", s.Find)
		g.POST("/del", s.Del)
	}
}

func (s *Svc) Find(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	params := &vo.FindListParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	vo.InitPage(params)
	uid := utils.UserId(c)
	total, list, err := services.NewServiceAdminlog(&c).FindAdminlog(uid, params)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 查询用户列表 失败 [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c, &resp.ResultTotalList{
		Total: total,
		List:  list,
	})
}

func (s *Svc) Del(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	var params struct {
		Ids string `json:"ids"`
	}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	if "" == params.Ids {
		return resp.Fail(c, "参数错误")
	}
	logIds := make([]int64, 0)
	split := strings.Split(params.Ids, ",")
	for _, id := range split {
		logId, err := strconv.Atoi(id)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 删除管理员日志 失败 [%s]", uuid, params.Ids), zap.Error(err))
			return resp.Fail(c, "参数错误")
		}
		logIds = append(logIds, int64(logId))
	}
	services.NewServiceAdminlog(&c).DeleteAdminlogByIds(logIds)
	return resp.OK(c)
}
