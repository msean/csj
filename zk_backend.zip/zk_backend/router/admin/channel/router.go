package channel

import (
	"application/constant"
	"application/middlewares"

	"github.com/labstack/echo"
)

func Register(eg *echo.Group) {

	{
		// channel := eg.Group("/channel")
		channel := middlewares.GroupWithLog{
			Group:  eg.Group("/channel"),
			Module: constant.MODULE_CHANNEL,
		}
		{
			channelSrv := ChannelSrv{}
			channel.POST("/list", channelSrv.List)
			channel.POSTWithLog("/create", channelSrv.Create, constant.LOG_OP_CREATE)
			channel.POSTWithLog("/update", channelSrv.Update, constant.LOG_OP_UPDATE)
			channel.POSTWithLog("/delete", channelSrv.Del, constant.LOG_OP_DELETE)
			channel.GET("/detail/:id", channelSrv.Detail)
			channel.POSTWithLog("/export", channelSrv.Export, constant.LOG_OP_EXPORT)
			channel.POSTWithLog("/update_thread", channelSrv.UpdateThreadConf, constant.LOG_OP_UPDATE)
			channel.POST("/template_description/list", channelSrv.TemplateDescribe)
			// channel.POST("/template_description/update", channelSrv.TemplateUpdateParams)
			// channel.POST("/template_description/delete", channelSrv.TemplateDeleteParams)
		}

		// channelProd := eg.Group("/channel_product")
		channelProd := middlewares.GroupWithLog{
			Group:  eg.Group("/channel_product"),
			Module: constant.MODULE_CHANNEL_PRODUCT,
		}
		{
			channelGroupSrv := ChannelProdSrv{}
			channelProd.POSTWithLog("/create", channelGroupSrv.Create, constant.LOG_OP_CREATE)
			channelProd.POSTWithLog("/update", channelGroupSrv.Update, constant.LOG_OP_UPDATE)
			channelProd.POSTWithLog("/update_pcode", channelGroupSrv.UpdatePcode, constant.LOG_OP_UPDATE)
			channelProd.GET("/detail/:id", channelGroupSrv.Detail)
			channelProd.POSTWithLog("/batch_opr", channelGroupSrv.BatchOperate, constant.LOG_OP_UPDATE)
			channelProd.POST("/list", channelGroupSrv.List)
			channelProd.POSTWithLog("/export", channelGroupSrv.Export, constant.LOG_OP_EXPORT)
			channelProd.POSTWithLog("/import", channelGroupSrv.Import, constant.LOG_OP_IMPORT)
		}

		// channelGroup := eg.Group("/channel_group")
		channelGroup := middlewares.GroupWithLog{
			Group:  eg.Group("/channel_group"),
			Module: constant.MODULE_CHANNEL_GROUP,
		}
		{
			channelGroupSrv := ChannelGroupSrv{}
			channelGroup.POSTWithLog("/create", channelGroupSrv.Create, constant.LOG_OP_CREATE)
			channelGroup.POSTWithLog("/update", channelGroupSrv.Update, constant.LOG_OP_UPDATE)
			channelGroup.GET("/detail/:id", channelGroupSrv.Detail)
			channelGroup.POSTWithLog("/delete", channelGroupSrv.Delete, constant.LOG_OP_DELETE)
			channelGroup.POST("/list", channelGroupSrv.List)
		}
	}
}
