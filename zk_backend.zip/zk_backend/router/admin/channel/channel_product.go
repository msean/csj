package channel

import (
	"application/common/logger"
	"application/conf"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"

	"github.com/labstack/echo"
	"github.com/tealeg/xlsx"
	"go.uber.org/zap"
)

type ChannelProdSrv struct{}

func (s *ChannelProdSrv) Create(c echo.Context) error {
	params := vo.ChannelProdCreateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	successCount, failCount, err := services.NewChannelProdSrv(&c).Create(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"fail_count":    failCount,
		"succuss_count": successCount,
	})
}

func (s *ChannelProdSrv) Update(c echo.Context) error {
	params := vo.ChannelProdUpdateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	batchOprParam := vo.ChannelProdBatchOprParams{
		IDList:                  []int64{params.ID},
		ChannelProdUpdateParams: params,
		OprType:                 4,
	}
	err := services.NewChannelProdSrv(&c).BatchOperate(batchOprParam)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "更新失败"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *ChannelProdSrv) Detail(c echo.Context) error {
	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, fmt.Sprintf("请求参数错误:"+err.Error()))
	}
	channel, has, err := services.NewChannelProdSrv(&c).Detail(id)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, fmt.Sprintf("查询失败:"+err.Error()))
	}
	if !has {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "该渠道不存在")
	}
	return resp.OK(c, channel)
}

func (s *ChannelProdSrv) BatchOperate(c echo.Context) error {
	params := vo.ChannelProdBatchOprParams{}

	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, fmt.Sprintf("请求参数错误:"+err.Error()))
	}
	err := services.NewChannelProdSrv(&c).BatchOperate(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, fmt.Sprintf("查询失败:"+err.Error()))
	}
	return resp.OK(c, nil)
}

func (s *ChannelProdSrv) List(c echo.Context) error {
	params := vo.ChannelProdListParams{}

	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, fmt.Sprintf("请求参数错误:"+err.Error()))
	}
	list, total, err := services.NewChannelProdSrv(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, fmt.Sprintf("查询失败:"+err.Error()))
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *ChannelProdSrv) Export(c echo.Context) error {
	params := vo.ChannelProdListParams{}

	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, fmt.Sprintf("请求参数错误:"+err.Error()))
	}
	filePath, err := services.NewChannelProdSrv(&c).Export(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, fmt.Sprintf("查询失败:"+err.Error()))
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

func (s *ChannelProdSrv) UpdatePcode(c echo.Context) error {
	params := vo.ChannelProdUpdatePcodeParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	err := services.NewChannelProdSrv(&c).UpdatePcode(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "更新失败"+err.Error())
	}
	return resp.OK(c, nil)
}

// getCellValue is a helper function to safely get a cell value from a row.
func getCellValue(row *xlsx.Row, colIndex int) (string, bool) {
	if colIndex >= len(row.Cells) {
		return "", false
	}
	return row.Cells[colIndex].String(), true
}

func (s *ChannelProdSrv) Import(c echo.Context) error {
	file, err := c.FormFile("file")
	if err != nil {
		return resp.Fail(c, fmt.Sprintf("文件上传失败: %v", err))
	}

	src, err := file.Open()
	if err != nil {
		return resp.Fail(c, fmt.Sprintf("文件读取失败: %v", err))
	}
	defer src.Close()

	savePath := fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, file.Filename)

	// 保存上传文件到指定路径
	dst, err := os.Create(savePath)
	if err != nil {
		return resp.Fail(c, fmt.Sprintf("创建文件失败: %v", err))
	}
	defer dst.Close()

	if _, err := io.Copy(dst, src); err != nil {
		return resp.Fail(c, fmt.Sprintf("保存文件失败: %v", err))
	}

	// 打开并解析 Excel 文件
	f, err := xlsx.OpenFile(savePath)
	if err != nil {
		return resp.Fail(c, fmt.Sprintf("解析 Excel 文件失败: %v", err))
	}

	sheet := f.Sheet["sheet1"]
	if sheet == nil {
		return resp.Fail(c, "未找到指定工作表: sheet1")
	}

	if len(sheet.Rows) < 2 {
		return resp.Fail(c, "表格内容为空或无数据")
	}

	// 解析表头
	headerMap := make(map[string]int)
	for i, cell := range sheet.Rows[0].Cells {
		headerMap[cell.String()] = i
	}

	requiredHeaders := []string{"ID", "渠道ID", "上架状态", "凭证", "产品编码", "原价", "排序价格", "参数"}
	for _, header := range requiredHeaders {
		if _, ok := headerMap[header]; !ok {
			return resp.Fail(c, fmt.Sprintf("缺少必要的表头: %s", header))
		}
	}

	// 渠道映射
	var channels []models.Channel
	var channelMapper = make(map[int64]struct{})
	if channels, err = mysql.Channel.All(); err != nil {
		return resp.Fail(c, err.Error())
	}
	for _, channel := range channels {
		channelMapper[channel.ID] = struct{}{}
	}

	// 解析表格内容
	var products []models.ChannelProduct
	for _, row := range sheet.Rows[1:] {
		product := models.ChannelProduct{}

		if value, ok := getCellValue(row, headerMap["ID"]); ok {
			if product.ID, err = strconv.ParseInt(value, 10, 64); err != nil {
				continue
			}
		}
		if value, ok := getCellValue(row, headerMap["渠道ID"]); ok {
			if product.ChannelID, err = strconv.ParseInt(value, 10, 64); err != nil {
				return resp.Fail(c, fmt.Sprintf("ID: %d 渠道ID: %s无法解析成整数", product.ID, value))
			}
			if _, ok := channelMapper[product.ChannelID]; !ok {
				return resp.Fail(c, fmt.Sprintf("ID: %d 渠道ID: 不存在该渠道ID %s", product.ID, value))
			}
		}
		if value, ok := getCellValue(row, headerMap["上架状态"]); ok {
			onlineMapper := map[string]int{
				"开": 2,
				"关": 1,
			}
			if _, ok := onlineMapper[value]; !ok {
				return resp.Fail(c, fmt.Sprintf("ID: %d 上架状态 必须为开/关", product.ID))
			}
			product.Online = uint(onlineMapper[value])
		}
		if value, ok := getCellValue(row, headerMap["凭证"]); ok {
			if _, ok := constant.VoucherTypeMapper[value]; !ok {
				var validVoucher []string
				for k := range constant.VoucherTypeMapper {
					validVoucher = append(validVoucher, k)
				}
				return resp.Fail(c, fmt.Sprintf("ID: %d 凭证: 有误, 合法的凭证为 %s", product.ID, strings.Join(validVoucher, "、")))
			}
			product.VoucherType = uint(constant.VoucherTypeMapper[value])
		}
		if value, ok := getCellValue(row, headerMap["产品编码"]); ok {
			product.ProductCode = value
		}
		if value, ok := getCellValue(row, headerMap["原价"]); ok {
			if product.ActualPrice, err = strconv.ParseFloat(value, 64); err != nil {
				return resp.Fail(c, fmt.Sprintf("ID: %d 原价: %s无法解析成浮点型", product.ID, value))
			}
		}
		if value, ok := getCellValue(row, headerMap["排序价格"]); ok {
			if product.OrderPrice, err = strconv.ParseFloat(value, 64); err != nil {
				return resp.Fail(c, fmt.Sprintf("ID: %d 排序价格: %s无法解析成浮点型", product.ID, value))
			}
		}
		if value, ok := getCellValue(row, headerMap["参数"]); ok {
			product.Pcode = value
		}

		products = append(products, product)
	}

	// 保存解析后的数据到数据库
	session := daos.Mysql.NewSession()
	defer session.Close()
	for _, product := range products {
		if _, err = utils.Update(session.Table(models.ChannelProduct{}.TableName()), map[string]any{
			"channel_id":   product.ChannelID,
			"online":       product.Online,
			"voucher_type": product.VoucherType,
			"product_code": product.ProductCode,
			"actual_price": product.ActualPrice,
			"order_price":  product.OrderPrice,
			"pcode":        product.Pcode,
		}, utils.IDCond(product.ID)); err != nil {
			logger.Log.Info("[ChannelProdSrv] [Import] [Update]", zap.Any("product", product), zap.Error(err))
		}
	}

	return resp.OK(c, nil)
}
