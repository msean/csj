package channel

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"
	"strconv"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type ChannelGroupSrv struct{}

func (s *ChannelGroupSrv) Create(c echo.Context) error {
	params := vo.ChannelGroupCreateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	_, err := services.NewChannelGroupSrv(&c).Create(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *ChannelGroupSrv) Update(c echo.Context) error {
	params := vo.ChannelGroupUpdateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	if err := services.NewChannelGroupSrv(&c).Update(params); err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "更新失败"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *ChannelGroupSrv) Detail(c echo.Context) error {
	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, fmt.Sprintf("请求参数错误:"+err.Error()))
	}
	channel, has, err := services.NewChannelGroupSrv(&c).Detail(id)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, fmt.Sprintf("查询失败:"+err.Error()))
	}
	if !has {
		return resp.Fail(c, "该渠道不存在")
	}
	return resp.OK(c, channel)
}

func (s *ChannelGroupSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	if err := services.NewChannelGroupSrv(&c).Delete(params.IDList); err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	} else {
		return resp.OK(c, nil)
	}
}

func (s *ChannelGroupSrv) List(c echo.Context) error {
	params := vo.ChannelGroupListParams{}

	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, fmt.Sprintf("请求参数错误:"+err.Error()))
	}
	list, total, err := services.NewChannelGroupSrv(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, fmt.Sprintf("查询失败:"+err.Error()))
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}
