package channel

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"
	"strconv"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type ChannelSrv struct {
}

func (s *ChannelSrv) List(c echo.Context) error {
	params := vo.ChannelListParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	list, total, err := services.NewChannelService(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查找失败:"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *ChannelSrv) Create(c echo.Context) error {
	params := vo.ChannelCreateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	channel, err := services.NewChannelService(&c).Create(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败:"+err.Error())
	}
	return resp.OK(c, channel)
}

func (s *ChannelSrv) Update(c echo.Context) error {
	params := vo.ChannelUpdateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	_, err := services.NewChannelService(&c).Update(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *ChannelSrv) Del(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, err.Error())
	}

	err := services.NewChannelService(&c).Delete(params.IDList)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c, nil)
}

func (s *ChannelSrv) Detail(c echo.Context) error {
	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, fmt.Sprintf("请求参数错误:"+err.Error()))
	}
	channel, has, err := services.NewChannelService(&c).FromID(id)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, fmt.Sprintf("查询失败:"+err.Error()))
	}
	if !has {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "该渠道不存在")
	}
	return resp.OK(c, channel)
}

func (s *ChannelSrv) Export(c echo.Context) error {
	params := vo.ChannelListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	filePath, err := services.NewChannelService(&c).Export(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败")
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

func (s *ChannelSrv) UpdateThreadConf(c echo.Context) error {
	params := vo.ChannelThreadUpdateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	err := services.NewChannelService(&c).UpdateThreadConfig(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "更新线程失败"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *ChannelSrv) TemplateDescribe(c echo.Context) error {
	rsp, err := services.NewChannelService(&c).TemplateDescriptions()
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取模版配置描述失败"+err.Error())
	}
	return resp.OK(c, rsp)
}

// func (s *ChannelSrv) TemplateUpdateParams(c echo.Context) error {
// 	params := vo.TemplateUpdateParams{}
// 	if err := c.Bind(&params); err != nil {
// 		return resp.Fail(c, err.Error())
// 	}
// 	err := services.NewChannelService(&c).UpdateTemplateDescription(params)
// 	if err != nil {
// 		logger.Log.Error("err", zap.Error(err))
// 		return resp.Fail(c, "获取模版配置描述失败"+err.Error())
// 	}
// 	return resp.OK(c, nil)
// }

// func (s *ChannelSrv) TemplateDeleteParams(c echo.Context) error {
// 	params := vo.DeleteParams{}
// 	if err := c.Bind(&params); err != nil {
// 		return resp.Fail(c, err.Error())
// 	}
// 	err := services.NewChannelService(&c).DeleteTemplateDescription(params)
// 	if err != nil {
// 		logger.Log.Error("err", zap.Error(err))
// 		return resp.Fail(c, "获取模版配置描述失败"+err.Error())
// 	}
// 	return resp.OK(c, nil)
// }
