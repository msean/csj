package statistic

import (
	"application/constant"
	"application/middlewares"

	"github.com/labstack/echo"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &StatisticSrv{}
	// statistic := eg.Group("/statistic")
	statistic := middlewares.GroupWithLog{
		Group: eg.Group("/statistic"),
	}
	{
		statistic.POST("/customer_day_finance", s.CustomerDayFinance)
		statistic.WithModule(constant.MODULE_FINANCE).POSTWithLog("/customer_day_finance/export", s.CustomerDayFinanceExport, constant.LOG_OP_EXPORT)
		statistic.POST("/customer_day_finance/manual", s.CustomerDayFinanceManual)
		statistic.POST("/customer_order/analysis", s.CustomerOrder)
		statistic.POST("/channel_order/analysis", s.ChannelOrder)
		statistic.POST("/customer_order/success_rate", s.SuccessRate)
	}
}
