package statistic

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services/statistic"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

func (svc *StatisticSrv) CustomerOrder(c echo.Context) error {
	params := vo.CustomerOrderAnalysisReq{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	rsp, err := statistic.NewOrderAnalysisSvc(&c).CustomerOrderList(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err), zap.Any("[StatisticSrv] [CustomerOrder]", params))
		return resp.Fail(c, "查询失败"+err.Error())
	}
	return resp.OK(c, rsp)
}

func (svc *StatisticSrv) ChannelOrder(c echo.Context) error {
	params := vo.CustomerOrderAnalysisReq{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	rsp, err := statistic.NewOrderAnalysisSvc(&c).ChannelOrderList(params)
	if err != nil {
		logger.Log.Error("err",
			zap.Error(err),
			zap.Any("[StatisticSrv] [ChannelOrder]", params))
		return resp.Fail(c, "查询失败"+err.Error())
	}
	return resp.OK(c, rsp)
}

func (svc *StatisticSrv) SuccessRate(c echo.Context) error {
	params := vo.CustomerOrderSuccessRateReq{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	rsp, err := statistic.NewOrderAnalysisSvc(&c).SuccessRate(params)
	if err != nil {
		logger.Log.Error("err",
			zap.Error(err),
			zap.Any("[StatisticSrv] [ChannelOrder]", params))
		return resp.Fail(c, "查询失败"+err.Error())
	}

	return resp.OK(c, rsp)
}
