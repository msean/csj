package statistic

import (
	"application/common/logger"
	"application/constant"
	"application/models/resp"
	"application/models/vo"
	"application/services/statistic"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type StatisticSrv struct{}

func (s *StatisticSrv) CustomerDayFinance(c echo.Context) error {
	params := vo.CustomerFinanceDayStatisticReq{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	rsp, total, err := statistic.NewCustomerDayFinanceSvc(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, rsp)
}

func (s *StatisticSrv) CustomerDayFinanceExport(c echo.Context) error {
	params := vo.CustomerFinanceDayStatisticReq{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	params.QryTotal = -1
	filePath, err := statistic.NewCustomerDayFinanceSvc(&c).Export(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "导出失败"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

func (s *StatisticSrv) CustomerDayFinanceManual(c echo.Context) error {
	params := vo.CustomerFinanceDayStatisticManualReq{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	err := statistic.NewCustomerDayFinanceSvc(&c).Statistic(params.Date, []int{constant.OrderStatusSuccess})
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "手工财务统计"+err.Error())
	}
	return resp.OK(c, nil)
}
