package order

import (
	"application/constant"
	"application/middlewares"

	"github.com/labstack/echo"
)

type Svc struct{}

func Register(eg *echo.Group) {

	// orderGroup := eg.Group("/order")
	orderGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/order"),
		Module: constant.MODULE_ORDER,
	}
	{
		orderSvc := &OrderSvc{}
		orderGroup.POST("/list", orderSvc.List)
		orderGroup.POSTWithLog("/return", orderSvc.Return, constant.LOG_OP_UPDATE)
		orderGroup.POSTWithLog("/update_manual_remark", orderSvc.UpdateManualRemark, constant.LOG_OP_UPDATE)
		orderGroup.POSTWithLog("/re_dispatcher", orderSvc.ReDispatcher, constant.LOG_OP_UPDATE)
		orderGroup.POSTWithLog("/notify", orderSvc.Notify, constant.LOG_OP_UPDATE)
		orderGroup.POSTWithLog("/export", orderSvc.Export, constant.LOG_OP_EXPORT)
	}

	// channelOrderGroup := eg.Group("/channel_order")
	channelOrderGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/channel_order"),
		Module: constant.MODULE_CHANNEL_ORDER,
	}
	{
		channelOrderSvc := &ChannelOrderSvc{}
		channelOrderGroup.POST("/list", channelOrderSvc.List)
		channelOrderGroup.POSTWithLog("/update_isp", channelOrderSvc.UpdateIsp, constant.LOG_OP_UPDATE)
		channelOrderGroup.POSTWithLog("/update_remark", channelOrderSvc.UpdateRemark, constant.LOG_OP_UPDATE)
		channelOrderGroup.POSTWithLog("/manual_fail", channelOrderSvc.ManualFail, constant.LOG_OP_UPDATE)
		channelOrderGroup.POSTWithLog("/manual_success", channelOrderSvc.ManualSuccess, constant.LOG_OP_UPDATE)
		channelOrderGroup.POSTWithLog("/adjust_channel", channelOrderSvc.AdjustChannel, constant.LOG_OP_UPDATE)
		channelOrderGroup.POSTWithLog("/export", channelOrderSvc.Export, constant.LOG_OP_EXPORT)
		channelOrderGroup.POST("/query", channelOrderSvc.Query)
		channelOrderGroup.POSTWithLog("/dispatcher_next", channelOrderSvc.DispatcherNext, constant.LOG_OP_UPDATE)
	}

	// returnOrderGroup := eg.Group("/return_order")
	returnOrderGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/return_order"),
		Module: constant.MODULE_CHANNEL_RETURN_ORDER,
	}
	{
		returnOrderSvc := &ReturnOrderSvc{}
		returnOrderGroup.POST("/list", returnOrderSvc.List)
		returnOrderGroup.POSTWithLog("/export", returnOrderSvc.Export, constant.LOG_OP_UPDATE)
	}
}
