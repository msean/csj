package order

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type ReturnOrderSvc struct{}

func (s *ReturnOrderSvc) List(c echo.Context) error {
	params := vo.ReturnOrderListParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	list, total, err := services.NewReturnOrderSvc(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败")
	}

	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *ReturnOrderSvc) Export(c echo.Context) error {
	params := vo.ReturnOrderListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	filePath, err := services.NewReturnOrderSvc(&c).Export(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "下载失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}
