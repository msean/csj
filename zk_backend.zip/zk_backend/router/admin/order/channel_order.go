package order

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type ChannelOrderSvc struct{}

func (s *ChannelOrderSvc) List(c echo.Context) error {
	params := vo.ChannelOrderListParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	list, total, err := services.NewChannelOrderService(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败")
	}

	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *ChannelOrderSvc) ManualSuccess(c echo.Context) error {
	params := vo.ChannelOrderManualSuccessParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	err := services.NewChannelOrderService(&c).ManualSuccess(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败")
	}

	return resp.OK(c, nil)
}

func (s *ChannelOrderSvc) UpdateIsp(c echo.Context) error {
	params := vo.ChannelOrderUpdateIspParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	err := services.NewChannelOrderService(&c).UpdateIsp(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "修改失败"+err.Error())
	}

	return resp.OK(c, nil)
}

func (s *ChannelOrderSvc) UpdateRemark(c echo.Context) error {
	params := vo.ChannelOrderUpdateRemarkParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	err := services.NewChannelOrderService(&c).UpdateRemark(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "修改失败"+err.Error())
	}

	return resp.OK(c, nil)
}

func (s *ChannelOrderSvc) ManualFail(c echo.Context) error {
	params := vo.ChannelOrderModifyFailParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	err := services.NewChannelOrderService(&c).ManualFail(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "修改失败"+err.Error())
	}

	return resp.OK(c, nil)
}

func (s *ChannelOrderSvc) AdjustChannel(c echo.Context) error {
	params := vo.ChannelOrderAdjustParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	err := services.NewChannelOrderService(&c).AdjustChannel(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "修改失败"+err.Error())
	}

	return resp.OK(c, nil)
}

func (s *ChannelOrderSvc) Export(c echo.Context) error {
	params := vo.ChannelOrderListParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	filePath, err := services.NewChannelOrderService(&c).Export(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "下载失败"+err.Error())
	}

	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

// 调到下个渠道
func (s *ChannelOrderSvc) DispatcherNext(c echo.Context) error {
	params := vo.ChannelOrderNextParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	err := services.NewChannelOrderService(&c).DispatcherNext(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "修改失败"+err.Error())
	}

	return resp.OK(c, nil)
}

func (s *ChannelOrderSvc) Query(c echo.Context) error {
	params := vo.ChannelOrderQueryParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	rsp, err := services.NewChannelOrderService(&c).Query(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, err.Error())
	}

	return resp.OK(c, rsp)
}
