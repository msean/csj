package order

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type OrderSvc struct{}

func (s *OrderSvc) List(c echo.Context) error {
	params := vo.OrderListParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	list, total, err := services.NewOrderService(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败:"+err.Error())
	}

	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *OrderSvc) Return(c echo.Context) error {
	params := vo.OrderReturnParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	affect, err := services.NewOrderService(&c).Return(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "修改失败:"+err.Error())
	}

	return resp.OK(c, map[string]any{
		"success_count": affect,
		"fail_count":    len(params.IDList) - int(affect),
	})
}

func (s *OrderSvc) UpdateManualRemark(c echo.Context) error {
	params := vo.OrderUpdateManualRemarkParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	err := services.NewOrderService(&c).UpdateManualRemark(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "修改失败"+err.Error())
	}

	return resp.OK(c, nil)
}

func (s *OrderSvc) ReDispatcher(c echo.Context) error {
	params := vo.OrderReDispatcherParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	err := services.NewOrderService(&c).ReDispatch(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "分发失败"+err.Error())
	}

	return resp.OK(c, nil)
}

func (s *OrderSvc) Export(c echo.Context) error {
	params := vo.OrderListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	filePath, err := services.NewOrderService(&c).Export(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "下载失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

func (s *OrderSvc) Notify(c echo.Context) error {
	params := vo.OrderNotifyParam{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}
	err := services.NewCallbackSvc(&c).NotifyOrderList(params.IDList)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "回调失败"+err.Error())
	}

	return resp.OK(c, nil)
}
