package menu

import (
	"application/common/logger"
	"application/constant"
	"application/middlewares"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	// g := eg.Group("/menu")
	g := middlewares.GroupWithLog{
		Group:  eg.Group("/menu"),
		Module: constant.MODULE_MENU,
	}
	{
		g.GET("/query", s.Query)
		g.GET("/me", s.QueryMyMenu)
		g.POST("/role", s.QueryRoleMenu)
		// g.POST("/create", s.Create)
		g.POSTWithLog("/create", s.Create, constant.LOG_OP_CREATE)
		// g.POST("/update", s.Update)
		g.POSTWithLog("/update", s.Update, constant.LOG_OP_UPDATE)
		// g.POST("/remove", s.Remove)
		g.POSTWithLog("/remove", s.Remove, constant.LOG_OP_DELETE)
	}
}

func (s *Svc) Query(c echo.Context) error {
	list, err := services.NewServiceMenu(&c).FindFullMenu()
	if err != nil {
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c, &resp.ResultList{List: list})
}

func (s *Svc) QueryMyMenu(c echo.Context) error {
	list, err := services.NewServiceMenu(&c).FindMenu(utils.RoleID(c))
	if err != nil {
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c, &resp.ResultList{List: list})
}

func (s *Svc) QueryRoleMenu(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	var params struct {
		RoleID int64 `json:"role_id" form:"role_id"`
	}
	if err := ctx.Bind(&params); err != nil || params.RoleID <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] query role menu failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	list, err := services.NewServiceMenu(&ctx).FindMenu(params.RoleID)
	if err != nil {
		return resp.Fail(ctx, err.Error())
	}
	return resp.OK(ctx, &resp.ResultList{List: list})
}

func (s *Svc) Create(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.MenuParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create menu failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	service := services.NewServiceMenu(&ctx)
	if err := service.CheckMenu(params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create menu failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	menu, err := service.CreateMenu(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create menu failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	logger.Log.Info(fmt.Sprintf("[%s] create menu success, %s", uuid, convertor.ToString(menu)))
	return resp.OK(ctx, menu)
}

func (s *Svc) Update(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.MenuParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update menu failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	if params.Id <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] update menu failed, invalid ID, %s", uuid, convertor.ToString(params)))
		return resp.InvalidParams(ctx)
	}

	service := services.NewServiceMenu(&ctx)
	if err := service.CheckMenu(params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create menu failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	menu, err := service.UpdateMenu(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update menu failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, menu)
}

func (s *Svc) Remove(ctx echo.Context) error {
	var params struct {
		ID int64 `json:"id" form:"id"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove menu failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	count, err := services.NewServiceMenu(&ctx).RemoveMenu(params.ID)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove menu failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, count)
}

/*
role, err := mysql.Role.GetBeanByNameOrOrder(params.RoleName, params.RoleOrder)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] create role failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.DBError(ctx, err.Error())
	}

	if role != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create role failed, already exist, %s", uuid, convertor.ToString(params)))
		return resp.Exist(ctx, fmt.Sprintf("%s or %d", params.RoleName, params.RoleOrder))
	}

	obj, err := services.NewServiceRole(&ctx).CreateRole(&params)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] create role failed, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, err.Error())
	}

	logger.Log.Info(fmt.Sprintf("[%s] create role success, %s", uuid, convertor.ToString(obj)))
	return resp.OK(ctx, obj)*/

/*func (s *Svc) Edit(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	params := &vo.MenuParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	uid := utils.UserId(c)
	err := services.NewServiceMenu(&c).UpdateMenu(uid, params)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 添加或修改菜单 失败 [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c)
}

func (s *Svc) Del(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	var params struct {
		Ids string `json:"ids"`
	}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	if "" == params.Ids {
		return resp.Fail(c, "参数错误")
	}
	menuIds := make([]int64, 0)
	split := strings.Split(params.Ids, ",")
	for _, id := range split {
		userId, err := strconv.Atoi(id)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 删除菜单 失败 [%s]", uuid, params.Ids), zap.Error(err))
			return resp.Fail(c, "参数错误")
		}
		menuIds = append(menuIds, int64(userId))
	}
	err := services.NewServiceMenu(&c).DeleteMenuByIds(menuIds)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 删除菜单 失败 [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c)
}*/
