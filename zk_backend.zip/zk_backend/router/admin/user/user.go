package user

import (
	"application/common/logger"
	"application/constant"
	"application/daos/mysql"
	"application/middlewares"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	// g := eg.Group("/user")
	g := middlewares.GroupWithLog{
		Group:  eg.Group("/user"),
		Module: constant.MODULE_USER,
	}
	{
		g.GET("/me", s.Me)
		// g.POST("/export", s.Export)
		g.POSTWithLog("/export", s.Export, constant.LOG_OP_EXPORT)
		g.POST("/query", s.Query)
		// g.POST("/create", s.Create)
		g.POSTWithLog("/create", s.Create, constant.LOG_OP_CREATE)
		// g.POST("/update", s.Update)
		g.POSTWithLog("/update", s.Update, constant.LOG_OP_UPDATE)
		// g.POST("/remove", s.Remove)
		g.POSTWithLog("/remove", s.Remove, constant.LOG_OP_DELETE)
		// g.POST("/reset_password", s.ResetPassword)
		g.POSTWithLog("/reset_password", s.ResetPassword, constant.LOG_OP_OTHER)
		// g.POST("/reset_google_code", s.ResetGoogleCode)
		g.POSTWithLog("/reset_google_code", s.ResetGoogleCode, constant.LOG_OP_OTHER)
		/*g.POST("/edit_pwd", s.EditPwd) // 修改登录人密码
		g.POST("/edit_me", s.EditMe)   // 修改登录人信息
		g.POST("/find", s.Find)
		g.POST("/edit", s.Edit)
		g.POST("/del", s.Del)*/
		g.POST("/online_list", s.OnlineList)
		g.POST("/force_quit", s.ForceQuit)
	}
}

func (s *Svc) Me(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	obj := utils.User(ctx)
	if obj == nil {
		logger.Log.Warn(fmt.Sprintf("[%s] get user info failed, none", uuid))
		return resp.Fail(ctx, "none")
	}

	if obj.CustomerID > 0 {
		customer, err := mysql.Customer.GetBeanById(obj.CustomerID)
		if err != nil {
			logger.Log.Warn(fmt.Sprintf("[%s] get user info failed, error customer data, %d", uuid, obj.CustomerID))
			return resp.Fail(ctx, "error customer data")
		}

		return resp.OK(ctx, services.NewServiceUser(&ctx).MakeUserVo(obj, customer))
	}

	return resp.OK(ctx, services.NewServiceUser(&ctx).MakeUserVo(obj, nil))
}

func (s *Svc) Export(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.UserQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_USER); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	params.Base.PageSize = 0
	data, err := services.NewServiceUser(&ctx).QueryUsers(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export failed, query failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export failed, none, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Users, models.User{}.TableNameCH(), utils.UserId(ctx), nil, false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) Query(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.UserQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query user failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	vo.InitPage(&params.Base)
	res, err := services.NewServiceUser(&ctx).QueryUsers(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query user failed, %s", uuid, err), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) Create(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.UserParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create user failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	// todo: temp, update password rule -----------------------
	if len(params.Password) <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] create user failed, invalid password, %s", uuid, convertor.ToString(params)))
		return resp.InvalidParams(ctx)
	}

	service := services.NewServiceUser(&ctx)
	isOk, role, err := service.CheckParams(params, false)
	if err != nil || !isOk {
		logger.Log.Warn(fmt.Sprintf("[%s] create user failed, check error, %s, %v", uuid, convertor.ToString(params), err))
		return resp.InvalidParamsEx(ctx, fmt.Sprintf("err: %v", err))
	}

	_, obj, err := service.CreateUser(nil, params, role)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create user failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, obj)
}

func (s *Svc) Update(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.UserParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update user failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	service := services.NewServiceUser(&ctx)
	isOk, role, err := service.CheckParams(params, false)
	if err != nil || !isOk {
		logger.Log.Warn(fmt.Sprintf("[%s] update user failed, check error, %s, %v", uuid, convertor.ToString(params), err))
		return resp.InvalidParamsEx(ctx, fmt.Sprintf("err: %v", err))
	}

	obj, err := service.UpdateUser(nil, params, role, false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update user failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, obj)
}

func (s *Svc) Remove(ctx echo.Context) error {
	var params struct {
		IDs []int64 `json:"ids" form:"ids[]"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove user failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	count, err := services.NewServiceUser(&ctx).RemoveUser(nil, params.IDs, false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove user failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, count)
}

func (s *Svc) ResetPassword(ctx echo.Context) error {
	var params struct {
		ID       int64  `json:"id" form:"id"`
		Password string `json:"password" form:"password"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] reset password failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	err := services.NewServiceUser(&ctx).ResetPassword(params.ID, params.Password, false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] reset password failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx)
}

func (s *Svc) ResetGoogleCode(ctx echo.Context) error {
	var params struct {
		ID int64 `json:"id" form:"id"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] reset google code failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	res, err := services.NewServiceUser(&ctx).ResetGoogleCode(params.ID, false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] reset google code failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) OnlineList(ctx echo.Context) error {
	params := vo.ListOnlineUserReq{}
	if err := ctx.Bind(&params); err != nil {
		return resp.InvalidParams(ctx)
	}

	if rsp, total, err := services.NewServiceUser(&ctx).ListOnlineUser(params); err != nil {
		return resp.Fail(ctx, err.Error())
	} else {
		return resp.OKWithList(ctx, int(total), params.Base.PageSize, params.Base.PageNum, rsp)
	}
}

func (s *Svc) ForceQuit(ctx echo.Context) error {
	params := vo.ForceQuitReq{}
	if err := ctx.Bind(&params); err != nil {
		return resp.InvalidParams(ctx)
	}

	if err := services.NewServiceUser(&ctx).ForceQuit(params.Tokens); err != nil {
		return resp.Fail(ctx, err.Error())
	} else {
		return resp.OK(ctx, nil)
	}
}

/*func (s *Svc) GetMe(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	userId := utils.UserId(c)
	user, err := services.NewServiceUser(&c).GetBeanById(userId)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 获取自己信息 失败 [%d]", uuid, userId), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c, user)
	return resp.OK(c)
}

func (s *Svc) EditPwd(c echo.Context) error {
	var params struct {
		PwdOld string `json:"pwd_old"`
		PwdNew string `json:"pwd_new"`
	}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	if "" == params.PwdOld || "" == params.PwdNew {
		return resp.Fail(c, "参数错误")
	}
	userId := utils.UserId(c)
	user, err := mysql.User.GetBeanById(userId)
	if err != nil {
		return resp.Fail(c, err.Error())
	}
	if user.Password != utils.Md5S(params.PwdOld) {
		return resp.Fail(c, "旧密码不正确")
	}
	user.Password = utils.Md5S(params.PwdNew)
	err = mysql.User.UpdateBean(userId, user)
	if err != nil {
		return resp.Fail(c, "密码修改失败")
	}
	return resp.OK(c, "操作成功，请重新登录")
}

func (s *Svc) EditMe(c echo.Context) error {
	var params struct {
		UserName    string `json:"user_name"`
		Email       string `json:"email"`
		Phonenumber string `json:"phonenumber"`
		PwdOld      string `json:"pwd_old"`
		PwdNew      string `json:"pwd_new"`
	}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	if "" == params.UserName {
		return resp.Fail(c, "参数错误")
	}
	userId := utils.UserId(c)
	user, err := mysql.User.GetBeanById(userId)
	if err != nil {
		return resp.Fail(c, err.Error())
	}
	user.Username = params.UserName
	user.Email = params.Email
	user.Phonenumber = params.Phonenumber
	if "" != params.PwdOld && "" != params.PwdNew {
		if user.Password != utils.Md5S(params.PwdOld) {
			return resp.Fail(c, "旧密码不正确")
		}
		user.Password = utils.Md5S(params.PwdNew)
	}
	err = mysql.User.UpdateBean(userId, user)
	if err != nil {
		return resp.Fail(c, "操作失败")
	}
	return resp.OK(c, "操作成功，请重新登录")
}

func (s *Svc) Find(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	params := &vo.FindListParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	vo.InitPage(params)
	uid := utils.UserId(c)
	total, list, err := services.NewServiceUser(&c).FindUser(uid, params)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 查询用户列表 失败 [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c, &resp.ResultTotalList{
		Total: total,
		List:  list,
	})
	return resp.OK(c)
}

func (s *Svc) Edit(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	params := &vo.UserParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	uid := utils.UserId(c)
	if params.Id == uid {
		return resp.Fail(c, "不可修改")
	}
	if 0 == params.Id && "" == params.Password {
		return resp.Fail(c, "新增用户，密码为必填项")
	}
	err := services.NewServiceUser(&c).EditUser(uid, params)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 添加或修改用户 失败 [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c)
}

func (s *Svc) Del(c echo.Context) error {
	uuid := GetContextUUID(c)
	var params struct {
		Ids string `json:"ids"`
	}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	if "" == params.Ids {
		return resp.Fail(c, "参数错误")
	}
	uid := utils.UserId(c)
	userIds := make([]int64, 0)
	split := strings.Split(params.Ids, ",")
	for _, id := range split {
		userId, err := strconv.Atoi(id)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 删除用户 失败 [%s]", uuid, params.Ids), zap.Error(err))
			return resp.Fail(c, "参数错误")
		}
		if int64(userId) == uid {
			return resp.Fail(c, "不可以删除自己")
		}
		userIds = append(userIds, int64(userId))
	}
	services.NewServiceUser(&c).DeleteUserByIds(userIds)
	return resp.OK(c)
}*/
