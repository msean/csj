package role

import (
	"application/common/logger"
	"application/constant"
	"application/daos/mysql"
	"application/middlewares"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	// g := eg.Group("/role")
	g := middlewares.GroupWithLog{
		Group:  eg.Group("/role"),
		Module: constant.MODULE_ROLE,
	}
	{
		// g.POST("/export", s.Export)
		g.POSTWithLog("/export", s.Export, constant.LOG_OP_EXPORT)
		g.POST("/query", s.Query)
		// g.POST("/create", s.Create)
		g.POSTWithLog("/create", s.Create, constant.LOG_OP_CREATE)
		// g.POST("/update", s.Update)
		g.POSTWithLog("/update", s.Update, constant.LOG_OP_UPDATE)
		// g.POST("/remove", s.Remove)
		g.POSTWithLog("/remove", s.Remove, constant.LOG_OP_DELETE)
		// g.POST("/grant", s.Grant)
		g.POSTWithLog("/grant", s.Grant, constant.LOG_OP_GRANT)
		g.POST("/users", s.QueryUser)
	}
}

func (s *Svc) Export(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.RoleQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export role failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_ROLE); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export role failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	data, err := services.NewServiceRole(&ctx).QueryRole(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export role failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export role failed, none, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Roles, models.Role{}.TableNameCH(), utils.UserId(ctx), downloadService.CommonDict(), false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export role failed, export error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) Query(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.RoleQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query role failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	vo.InitPage(&params.Base)
	res, err := services.NewServiceRole(&ctx).QueryRole(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query role failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) Create(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.RoleParams{}

	// isSuccess := false
	// defer func() {
	// 	ctx.Set(constant.CONTEXT_KEY_LOG, &vo.LogRequestData{
	// 		Module:  constant.MODULE_ROLE,
	// 		OpType:  constant.LOG_OP_CREATE,
	// 		Func:    utils.GetCurrentFuncName(),
	// 		Success: isSuccess,
	// 	})
	// }()

	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create role failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	role, err := mysql.Role.FindBeanByNameOrOrder(params.RoleName, params.RoleOrder)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create role failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.DBError(ctx, err.Error())
	}

	if role != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create role failed, already exist, %s", uuid, convertor.ToString(params)))
		return resp.Exist(ctx, fmt.Sprintf("%s or %d", params.RoleName, params.RoleOrder))
	}

	obj, err := services.NewServiceRole(&ctx).CreateRole(&params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create role failed, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, err.Error())
	}

	logger.Log.Info(fmt.Sprintf("[%s] create role success, %s", uuid, convertor.ToString(obj)))
	return resp.OK(ctx, obj)
}

func (s *Svc) Update(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.RoleParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update role failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	if params.Id <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] update role failed, invalid ID, %s", uuid, convertor.ToString(params)))
		return resp.InvalidParams(ctx)
	}

	obj, err := services.NewServiceRole(&ctx).UpdateRole(&params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update role failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	logger.Log.Info(fmt.Sprintf("[%s] update role success, %s", uuid, convertor.ToString(params)))
	return resp.OK(ctx, obj)
}

func (s *Svc) Remove(ctx echo.Context) error {
	var params struct {
		IDs []int64 `json:"ids" form:"ids[]"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove role failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	count, err := services.NewServiceRole(&ctx).RemoveRole(params.IDs)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove role failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	logger.Log.Info(fmt.Sprintf("[%s] remove role success, %v, %v", uuid, convertor.ToString(params), count))
	return resp.OK(ctx, count)
}

func (s *Svc) Grant(ctx echo.Context) error {
	var params struct {
		RoleID  int64   `json:"role_id" form:"role_id"`
		UserIDs []int64 `json:"user_ids" form:"user_ids[]"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] grant role failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	if len(params.UserIDs) <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] grant role failed, none user, %s", uuid, convertor.ToString(params)))
		return resp.InvalidParams(ctx)
	}

	if params.RoleID > 0 {
		if _, err := mysql.Role.GetBeanById(params.RoleID); err != nil {
			logger.Log.Warn(fmt.Sprintf("[%s] grant role failed, query role error, %s", uuid, convertor.ToString(params)), zap.Error(err))
			return resp.InvalidParams(ctx)
		}
	}

	count, err := mysql.User.UpdateRole(params.UserIDs, params.RoleID)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] grant role failed, update error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, count)
}

func (s *Svc) QueryUser(ctx echo.Context) error {
	params := vo.QueryRoleUserParams{}
	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query user failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	res, err := services.NewServiceUser(&ctx).QueryByRole(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query user failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

/*func (s *Svc) Edit(c echo.Context) error {
	uuid := utils.GetContextUUID(&c)
	params := &vo.RoleParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	if params.Id == 0 && params.ParentId == 0 {
		return resp.Fail(c, "参数错误")
	}
	uid := utils.UserId(c)
	err := services.NewServiceRole(&c).EditRole(uid, params)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 添加或修改角色 失败 [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c)
}

func (s *Svc) Del(c echo.Context) error {
	uuid := utils.GetContextUUID(&c)
	var params struct {
		Ids string `json:"ids"`
	}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	if "" == params.Ids {
		return resp.Fail(c, "参数错误")
	}
	roleIds := make([]int64, 0)
	split := strings.Split(params.Ids, ",")
	for _, id := range split {
		roleId, err := strconv.Atoi(id)
		if err != nil {
			logger.Log.Error(fmt.Sprintf("[%s] 删除角色 失败 [%s]", uuid, params.Ids), zap.Error(err))
			return resp.Fail(c, "参数错误")
		}
		if roleId == 1 {
			return resp.Fail(c, "参数错误")
		}
		roleIds = append(roleIds, int64(roleId))
	}
	err := services.NewServiceRole(&c).DeleteRoleByIds(roleIds)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 删除角色 失败 [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(c, err.Error())
	}
	return resp.OK(c)
}*/
