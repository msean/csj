package log

import (
	"application/common/logger"
	"application/constant"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	g := eg.Group("/log")
	{
		g.POST("/export_login", s.ExportLogin)
		g.POST("/export_op", s.ExportOp)
		g.POST("/login", s.QueryLoginLog)
		g.POST("/remove_login", s.RemoveLoginLog)
		g.POST("/op", s.QueryOpLog)
		g.POST("/remove", s.QueryRemoveLog)
		g.GET("/search_option", s.SearchOption)
	}
}

func (s *Svc) ExportLogin(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.LogLoginQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export login log failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_LOG_LOGIN); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export login log failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	data, err := services.NewServiceLog(&ctx).QueryLoginLog(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export login log failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export login log failed, none, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Data, models.LogLogin{}.TableNameCH(), utils.UserId(ctx), downloadService.LogDict(), true)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export login log failed, export error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) ExportOp(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.LogOpQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export op log failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_LOG_OP); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export op log failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	data, err := services.NewServiceLog(&ctx).QueryOpLog(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export op log failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export op log failed, none, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Data, models.LogOp{}.TableNameCH(), utils.UserId(ctx), downloadService.LogDict(), true)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export op log failed, export error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) QueryLoginLog(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.LogLoginQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query login log failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	vo.InitPage(&params.Base)
	res, err := services.NewServiceLog(&ctx).QueryLoginLog(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query login log failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) RemoveLoginLog(ctx echo.Context) error {
	var params struct {
		IDs []int64 `json:"ids" form:"ids[]"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove login log failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	count, err := services.NewServiceLog(&ctx).RemoveLoginLog(params.IDs)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove login log failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, count)
}

func (s *Svc) QueryOpLog(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.LogOpQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query op log failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	vo.InitPage(&params.Base)
	res, err := services.NewServiceLog(&ctx).QueryOpLog(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query op log failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) QueryRemoveLog(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.LogRemoveQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query remove log failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	vo.InitPage(&params.Base)
	res, err := services.NewServiceLog(&ctx).QueryRemoveLog(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query remove log failed, remove failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) SearchOption(ctx echo.Context) error {
	f := func(m map[string]string) []vo.Option {
		opts := []vo.Option{}
		for k, v := range m {
			opts = append(opts, vo.Option{
				Value: utils.StrToInt(k),
				Title: v,
			})
		}
		return opts
	}
	statusOps := map[string]string{
		"1":  "成功",
		"0":  "失败",
		"-1": "所有",
	}
	return resp.OK(ctx, map[string]any{
		"module_option":   f(constant.MODULE_DICT()),
		"operator_option": f(constant.LOG_OP_DICT()),
		"status_option":   f(statusOps),
	})
}
