package usage

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type AreaSuspendSrv struct{}

func (s *AreaSuspendSrv) Create(c echo.Context) error {
	params := vo.AreaSuspendCreateParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	successCount, failCount, err := services.NewAreaSuspendSrv(&c).Create(params)
	if err != nil {
		return resp.Fail(c, "创建失败:"+err.Error())
	}

	return resp.OK(c, map[string]any{
		"success_count": successCount,
		"fail_count":    failCount,
	})
}

func (s *AreaSuspendSrv) List(c echo.Context) error {
	params := vo.AreaSuspendListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	rsp, total, err := services.NewAreaSuspendSrv(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, rsp)
}

func (s *AreaSuspendSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewAreaSuspendSrv(&c).Delete(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OK(c, nil)
}
