package usage

import (
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"

	"github.com/labstack/echo"
)

type DelayTaskSrv struct{}

func (s *DelayTaskSrv) List(c echo.Context) error {
	params := vo.DelayTaskListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	objects, total, err := services.NewDelayTaskSrv(&c).List(params)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, objects)
}

func (s *DelayTaskSrv) Update(c echo.Context) error {
	params := vo.DelayTaskUpdateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewDelayTaskSrv(&c).Update(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *DelayTaskSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewDelayTaskSrv(&c).Delete(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *DelayTaskSrv) Export(c echo.Context) error {
	params := vo.DelayTaskListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	filePath, err := services.NewDelayTaskSrv(&c).Export(params)
	if err != nil {
		return resp.Fail(c, "导出失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}
