package usage

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type WhiteListSrv struct{}

func (s *WhiteListSrv) Create(c echo.Context) error {
	params := vo.WhiteListCreateParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	successCount, err := services.NewWhiteListSrv(&c).Create(params)
	if err != nil {
		return resp.Fail(c, "创建失败:"+err.Error())
	}

	return resp.OK(c, map[string]any{
		"success_count": successCount,
	})
}

func (s *WhiteListSrv) List(c echo.Context) error {
	params := vo.WhiteListPageParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	rsp, total, err := services.NewWhiteListSrv(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, rsp)
}

func (s *WhiteListSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewWhiteListSrv(&c).Delete(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *WhiteListSrv) Export(c echo.Context) error {
	params := vo.WhiteListPageParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	filePath, err := services.NewWhiteListSrv(&c).Export(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

func (s *WhiteListSrv) Update(c echo.Context) error {
	params := vo.WhiteListUpdateParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewWhiteListSrv(&c).Update(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OK(c, nil)
}
