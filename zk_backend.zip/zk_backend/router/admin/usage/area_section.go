package usage

import (
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"strconv"

	"github.com/labstack/echo"
)

type AreaSectionSrv struct{}

func (s *AreaSectionSrv) Create(c echo.Context) error {
	params := vo.AreaSectionCreateParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	if err := services.NewAreaSectionSrv(&c).Create(params); err != nil {
		return resp.Fail(c, "创建失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *AreaSectionSrv) List(c echo.Context) error {
	params := vo.AreaSectionListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	objects, total, err := services.NewAreaSectionSrv(&c).List(params)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, objects)
}

func (s *AreaSectionSrv) Update(c echo.Context) error {
	params := vo.AreaSectionUpdateParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewAreaSectionSrv(&c).Update(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *AreaSectionSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewAreaSectionSrv(&c).Delete(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *AreaSectionSrv) Detail(c echo.Context) error {

	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	object, has, err := services.NewAreaSectionSrv(&c).Detail(id)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	if !has {
		return resp.Fail(c, "该记录不存在")
	}
	return resp.OK(c, object)
}

func (s *AreaSectionSrv) Export(c echo.Context) error {

	params := vo.AreaSectionListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	filePath, err := services.NewAreaSectionSrv(&c).Export(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}
