package usage

import (
	"application/constant"
	"application/middlewares"

	"github.com/labstack/echo"
)

func Register(eg *echo.Group) {

	// areaSuspendGroup := eg.Group("/area_suspend")
	areaSuspendGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/area_suspend"),
		Module: constant.MODULE_AREA_SUSPEND,
	}
	{
		areaSuspendSrv := &AreaSuspendSrv{}
		areaSuspendGroup.POST("/list", areaSuspendSrv.List)
		areaSuspendGroup.POSTWithLog("/create", areaSuspendSrv.Create, constant.LOG_OP_CREATE)
		areaSuspendGroup.POSTWithLog("/delete", areaSuspendSrv.Delete, constant.LOG_OP_DELETE)
	}

	// areaSectionGroup := eg.Group("/area_section")
	areaSectionGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/area_section"),
		Module: constant.MODULE_AREA_SECTION,
	}
	{
		areaSectionSrv := &AreaSectionSrv{}
		areaSectionGroup.POST("/list", areaSectionSrv.List)
		areaSectionGroup.POSTWithLog("/create", areaSectionSrv.Create, constant.LOG_OP_CREATE)
		areaSectionGroup.POSTWithLog("/update", areaSectionSrv.Update, constant.LOG_OP_UPDATE)
		areaSectionGroup.POSTWithLog("/delete", areaSectionSrv.Delete, constant.LOG_OP_DELETE)
		areaSectionGroup.GET("/detail/:id", areaSectionSrv.Detail)
		areaSectionGroup.POSTWithLog("/export", areaSectionSrv.Export, constant.LOG_OP_EXPORT)
	}

	// blacklistGroup := eg.Group("/blacklist")
	blacklistGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/blacklist"),
		Module: constant.MODULE_BLACKLIST,
	}
	{
		blacklistSrv := &BlacklistSrv{}
		blacklistGroup.POST("/list", blacklistSrv.List)
		blacklistGroup.GET("/limit_count", blacklistSrv.LimitCount)
		blacklistGroup.POSTWithLog("/update/limit", blacklistSrv.UpdateLimitCount, constant.LOG_OP_UPDATE)
		blacklistGroup.POSTWithLog("/create", blacklistSrv.Create, constant.LOG_OP_CREATE)
		blacklistGroup.POSTWithLog("/update", blacklistSrv.Update, constant.LOG_OP_UPDATE)
		blacklistGroup.POSTWithLog("/delete", blacklistSrv.Delete, constant.LOG_OP_DELETE)
		blacklistGroup.GET("/detail/:id", blacklistSrv.Detail)
		blacklistGroup.POSTWithLog("/export", blacklistSrv.Export, constant.LOG_OP_EXPORT)
	}

	AnnouncementGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/announcement"),
		Module: constant.MODULE_ANNOUNCEMENT,
	}
	{
		Announcement := &AnnouncementSrv{}
		AnnouncementGroup.POST("/list", Announcement.List)
		AnnouncementGroup.POSTWithLog("/create", Announcement.Create, constant.LOG_OP_CREATE)
		AnnouncementGroup.POSTWithLog("/update", Announcement.Update, constant.LOG_OP_UPDATE)
		AnnouncementGroup.POSTWithLog("/delete", Announcement.Delete, constant.LOG_OP_DELETE)
		// AnnouncementGroup.POSTWithLog("/publish", Announcement.Publish, constant.LOG_OP_OTHER)
	}
	DelayTaskGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/delay_task"),
		Module: constant.MODULE_DATA_PRODUCT_CRONJOB,
	}
	{
		delayTaskSrv := &DelayTaskSrv{}
		DelayTaskGroup.POST("/list", delayTaskSrv.List)
		DelayTaskGroup.POSTWithLog("/update", delayTaskSrv.Update, constant.LOG_OP_UPDATE)
		DelayTaskGroup.POSTWithLog("/delete", delayTaskSrv.Delete, constant.LOG_OP_DELETE)
		DelayTaskGroup.POSTWithLog("/export", delayTaskSrv.Export, constant.LOG_OP_EXPORT)
	}
	WhiteListGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/white_list"),
		Module: constant.MODULE_ANNOUNCEMENT,
	}
	{
		whiteList := &WhiteListSrv{}
		WhiteListGroup.POST("/list", whiteList.List)
		WhiteListGroup.POSTWithLog("/create", whiteList.Create, constant.LOG_OP_CREATE)
		WhiteListGroup.POSTWithLog("/update", whiteList.Update, constant.LOG_OP_UPDATE)
		WhiteListGroup.POSTWithLog("/delete", whiteList.Delete, constant.LOG_OP_DELETE)
		WhiteListGroup.POSTWithLog("/export", whiteList.Export, constant.LOG_OP_EXPORT)
	}
	CrontabGroup := middlewares.GroupWithLog{
		Group:  eg.Group("/crontab"),
		Module: constant.MODULE_DATA_CRONJOB,
	}
	{
		crontabSrv := &CrontabSrv{}
		CrontabGroup.POST("/list", crontabSrv.List)
		CrontabGroup.POSTWithLog("/update", crontabSrv.Update, constant.LOG_OP_UPDATE)
		CrontabGroup.POSTWithLog("/exec", crontabSrv.Exec, constant.LOG_OP_OTHER)
		CrontabGroup.POSTWithLog("/export", crontabSrv.Export, constant.LOG_OP_EXPORT)
		CrontabGroup.POST("/log_list", crontabSrv.LogList)
		CrontabGroup.POST("/log_delete", crontabSrv.LogList)
	}
}
