package usage

import (
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"strconv"

	"github.com/labstack/echo"
)

type BlacklistSrv struct{}

func (s *BlacklistSrv) Create(c echo.Context) error {
	params := vo.BlacklistCreateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	success, fail, err := services.NewBlacklistSvc(&c).Create(params)
	if err != nil {
		return resp.Fail(c, "创建失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"success_count": success,
		"fail_count":    fail,
	})
}

func (s *BlacklistSrv) List(c echo.Context) error {
	params := vo.BlacklistParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	objects, total, err := services.NewBlacklistSvc(&c).List(params)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, objects)
}

func (s *BlacklistSrv) LimitCount(c echo.Context) error {
	count, err := services.NewBlacklistSvc(&c).LimitCount()
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"count": count,
	})
}

func (s *BlacklistSrv) UpdateLimitCount(c echo.Context) error {
	params := vo.UpdateBlacklistPhoneLimitParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	err := services.NewBlacklistSvc(&c).UpdateBlacklistPhoneLimit(params)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *BlacklistSrv) Update(c echo.Context) error {
	params := vo.BlacklistUpdateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewBlacklistSvc(&c).Update(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *BlacklistSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewBlacklistSvc(&c).Delete(params.IDList)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *BlacklistSrv) Detail(c echo.Context) error {

	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	object, has, err := services.NewBlacklistSvc(&c).FromID(id)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	if !has {
		return resp.Fail(c, "该记录不存在")
	}
	return resp.OK(c, object)
}

func (s *BlacklistSrv) Export(c echo.Context) error {

	params := vo.BlacklistParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	filePath, err := services.NewBlacklistSvc(&c).Export(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}
