package usage

import (
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"

	"github.com/labstack/echo"
)

type AnnouncementSrv struct{}

func (s *AnnouncementSrv) Create(c echo.Context) error {
	params := vo.AnnouncementCreateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	if err := services.NewAnnouncementSrv(&c).Create(params); err != nil {
		return resp.Fail(c, "创建失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *AnnouncementSrv) List(c echo.Context) error {
	params := vo.AnnouncementListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	objects, total, err := services.NewAnnouncementSrv(&c).List(params)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, objects)
}

func (s *AnnouncementSrv) Update(c echo.Context) error {
	params := vo.AnnouncementUpdateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewAnnouncementSrv(&c).Update(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *AnnouncementSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewAnnouncementSrv(&c).Delete(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}
