package usage

import (
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"

	"github.com/labstack/echo"
)

type CrontabSrv struct{}

func (s *CrontabSrv) List(c echo.Context) error {
	params := vo.CrontabListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	rsp, err := services.NewCrontabService(&c).List(params)
	if err != nil {
		return resp.Fail(c, "获取失败:"+err.Error())
	}
	return resp.OK(c, rsp)
}

func (s *CrontabSrv) Update(c echo.Context) error {
	params := vo.CrontabUpdateParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewCrontabService(&c).Update(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *CrontabSrv) Export(c echo.Context) error {
	params := vo.CrontabListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	filePath, err := services.NewCrontabService(&c).Export(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

func (s *CrontabSrv) Exec(c echo.Context) error {
	params := vo.CrontabExecOnceParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	err := services.NewCrontabService(&c).ExecOnce(params)
	if err != nil {
		return resp.Fail(c, "执行:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *CrontabSrv) LogList(c echo.Context) error {
	params := vo.CrontabLogListParam{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	rsp, err := services.NewCrontabService(&c).LogList(params)
	if err != nil {
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, rsp)
}

func (s *CrontabSrv) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	return resp.Response(c, services.NewCrontabService(&c).Delete(params))
}
