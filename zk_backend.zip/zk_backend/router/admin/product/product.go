package product

import (
	"application/common/logger"
	"application/constant"
	"application/middlewares"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"strconv"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	// product := eg.Group("/product")
	product := middlewares.GroupWithLog{
		Group:  eg.Group("/product"),
		Module: constant.MODULE_PRODUCT,
	}
	{
		product.POST("/list", s.List)
		// product.POST("/create", s.Create)
		product.POSTWithLog("/create", s.Create, constant.LOG_OP_CREATE)
		// egLoggerGroup.POST("/delete", s.Delete)
		product.POSTWithLog("/delete", s.Delete, constant.LOG_OP_DELETE)
		product.POSTWithLog("/update", s.Update, constant.LOG_OP_UPDATE)
		product.GET("/detail/:id", s.Detail)
		product.POSTWithLog("/export", s.Export, constant.LOG_OP_EXPORT)
	}
}

func (s *Svc) List(c echo.Context) error {
	params := vo.ProductListParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	list, total, err := services.NewProductSrv(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "获取失败:"+err.Error())
	}

	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *Svc) Create(c echo.Context) error {
	params := vo.ProductCreateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		logger.Log.Error("参数错误:", zap.Error(err))
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	if product, err := services.NewProductSrv(&c).Create(params); err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败:"+err.Error())
	} else {
		return resp.OK(c, product)
	}
}

func (s *Svc) Delete(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	if err := services.NewProductSrv(&c).Delete(params.IDList); err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败:"+err.Error())
	} else {
		return resp.OK(c, nil)
	}
}

func (s *Svc) Update(c echo.Context) error {
	params := vo.ProductUpdateParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, err.Error())
	}

	if product, err := services.NewProductSrv(&c).Update(params); err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败:"+err.Error())
	} else {
		return resp.OK(c, product)
	}
}

func (s *Svc) Detail(c echo.Context) error {
	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}

	if product, err := services.NewProductSrv(&c).FromID(id); err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败:"+err.Error())
	} else {
		return resp.OK(c, product)
	}
}

func (s *Svc) Export(c echo.Context) error {
	params := vo.ProductListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误:"+err.Error())
	}
	filePath, err := services.NewProductSrv(&c).Export(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败:"+err.Error())
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}
