package sysmanager

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"strconv"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type SysArgSrv struct {
}

func (s *SysArgSrv) List(c echo.Context) error {
	params := vo.SysArgListParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	list, total, err := services.NewSysConfigSrv(&c).List(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查找失败")
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *SysArgSrv) Create(c echo.Context) error {
	params := vo.SysArgCreateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	sysDict, err := services.NewSysConfigSrv(&c).Create(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	}
	return resp.OK(c, sysDict)
}

func (s *SysArgSrv) Update(c echo.Context) error {
	params := vo.SysArgUpdateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	sysDict, err := services.NewSysConfigSrv(&c).Update(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	}
	return resp.OK(c, sysDict)
}

func (s *SysArgSrv) Del(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	err := services.NewSysConfigSrv(&c).Delete(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	}
	return resp.OK(c, nil)
}

func (s *SysArgSrv) Detail(c echo.Context) error {
	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, "参数错误")
	}
	dictType, has, err := services.NewSysConfigSrv(&c).FormID(id)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败")
	}
	if !has {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "该类型不存在")
	}
	return resp.OK(c, dictType)
}

func (s *SysArgSrv) Export(c echo.Context) error {
	params := vo.SysArgListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	filePath, err := services.NewSysConfigSrv(&c).DataExport(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败")
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}
