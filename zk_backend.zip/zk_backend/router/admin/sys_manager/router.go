package sysmanager

import (
	"application/constant"
	"application/middlewares"

	"github.com/labstack/echo"
)

func Register(eg *echo.Group) {

	g := eg.Group("/sys_mamanger")
	{
		// dictGroup := g.Group("/dict")
		dictGroup := middlewares.GroupWithLog{
			Group:  g.Group("/dict"),
			Module: constant.MODULE_DICT_TYPE,
		}
		{
			sysDictSrv := SysDictSrv{}
			dictGroup.POST("/type_list", sysDictSrv.ListDictType)
			dictGroup.POSTWithLog("/type_create", sysDictSrv.CreateType, constant.LOG_OP_CREATE)
			dictGroup.POSTWithLog("/type_update", sysDictSrv.UpdateType, constant.LOG_OP_UPDATE)
			dictGroup.POSTWithLog("/type_update_effect_type", sysDictSrv.UpdateEffectType, constant.LOG_OP_UPDATE)
			dictGroup.POSTWithLog("/type_delete", sysDictSrv.DelType, constant.LOG_OP_DELETE)
			dictGroup.GET("/type_detail/:id", sysDictSrv.DictTypeDetail)
			dictGroup.POSTWithLog("/type_export", sysDictSrv.TypeExport, constant.LOG_OP_EXPORT)

			dictGroup.WithModule(constant.MODULE_DICT_DATA).POST("/typedata_list", sysDictSrv.ListTypeData)
			dictGroup.WithModule(constant.MODULE_DICT_DATA).POSTWithLog("/typedata_create", sysDictSrv.CreateTypeData, constant.LOG_OP_CREATE)
			dictGroup.WithModule(constant.MODULE_DICT_DATA).POSTWithLog("/typedata_update", sysDictSrv.UpdateTypeData, constant.LOG_OP_UPDATE)
			dictGroup.WithModule(constant.MODULE_DICT_DATA).POSTWithLog("/typedata_delete", sysDictSrv.DelTypeData, constant.LOG_OP_DELETE)
			dictGroup.WithModule(constant.MODULE_DICT_DATA).GET("/typedata_detail/:id", sysDictSrv.TypeDataDetail)
			dictGroup.WithModule(constant.MODULE_DICT_DATA).GETWithLog("/data_export", sysDictSrv.DataExport, constant.LOG_OP_EXPORT)
		}

		// argGroup := g.Group("/arg")
		argGroup := middlewares.GroupWithLog{
			Group:  g.Group("/arg"),
			Module: constant.MODULE_SYS_ARG,
		}
		{
			sysDictSrv := SysArgSrv{}
			argGroup.POST("/list", sysDictSrv.List)
			argGroup.POSTWithLog("/create", sysDictSrv.Create, constant.LOG_OP_CREATE)
			argGroup.POSTWithLog("/update", sysDictSrv.Update, constant.LOG_OP_UPDATE)
			argGroup.POSTWithLog("/delete", sysDictSrv.Del, constant.LOG_OP_DELETE)
			argGroup.GET("/detail/:id", sysDictSrv.Detail)
			argGroup.POSTWithLog("/export", sysDictSrv.Export, constant.LOG_OP_EXPORT)
		}
	}
}
