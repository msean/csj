package sysmanager

import (
	"application/common/logger"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"strconv"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type SysDictSrv struct {
}

func (s *SysDictSrv) ListDictType(c echo.Context) error {
	params := vo.SysDictTypeListParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	list, total, err := services.NewSysDictSrv(&c).ListType(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查找失败")
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, list)
}

func (s *SysDictSrv) CreateType(c echo.Context) error {
	params := vo.SysDictTypeCreateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	params.Mutate()

	sysDict, err := services.NewSysDictSrv(&c).CreateType(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	}
	return resp.OK(c, sysDict)
}

func (s *SysDictSrv) UpdateType(c echo.Context) error {
	params := vo.SysDictTypeUpdateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	sysDict, err := services.NewSysDictSrv(&c).UpdateType(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	}
	return resp.OK(c, sysDict)
}

func (s *SysDictSrv) UpdateEffectType(c echo.Context) error {
	params := vo.SysDictUpdateEffectTypeParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	err := services.NewSysDictSrv(&c).UpdateEffectType(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "更新失败:"+err.Error())
	}
	return resp.OK(c, nil)
}

func (s *SysDictSrv) DelType(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	err := services.NewSysDictSrv(&c).DelType(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	}
	return resp.OK(c, nil)
}

func (s *SysDictSrv) DictTypeDetail(c echo.Context) error {
	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, "参数错误")
	}
	dictType, has, err := services.NewSysDictSrv(&c).TypeFromID(id)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败")
	}
	if !has {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "该类型不存在")
	}
	return resp.OK(c, dictType)
}

func (s *SysDictSrv) TypeExport(c echo.Context) error {
	params := vo.SysDictTypeListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	filePath, err := services.NewSysDictSrv(&c).TypeExport(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败")
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}

func (s *SysDictSrv) CreateTypeData(c echo.Context) error {
	params := vo.SysDictDataCreateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	params.Mutate()
	sysDict, err := services.NewSysDictSrv(&c).CreateTypeData(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "创建失败")
	}
	return resp.OK(c, sysDict)
}

func (s *SysDictSrv) ListTypeData(c echo.Context) error {
	params := vo.SysDictDataListParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	typeList, total, err := services.NewSysDictSrv(&c).ListTypeData(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查找失败")
	}
	return resp.OKWithList(c, int(total), params.Base.PageNum, params.Base.PageSize, typeList)
}

func (s *SysDictSrv) UpdateTypeData(c echo.Context) error {
	params := vo.SysDictDataUpdateParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	sysDict, err := services.NewSysDictSrv(&c).UpdateTypeData(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "更新失败")
	}
	return resp.OK(c, sysDict)
}

func (s *SysDictSrv) DelTypeData(c echo.Context) error {
	params := vo.DeleteParams{}
	if err := c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误")
	}

	err := services.NewSysDictSrv(&c).DelTypeData(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "删除失败")
	}
	return resp.OK(c, nil)
}

func (s *SysDictSrv) TypeDataDetail(c echo.Context) error {
	idStr := c.Param("id")

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		return resp.Fail(c, "参数错误")
	}
	dictType, has, err := services.NewSysDictSrv(&c).TypeDataFromID(id)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败")
	}
	if !has {
		return resp.Fail(c, "该类型数据不存在")
	}
	return resp.OK(c, dictType)
}

func (s *SysDictSrv) DataExport(c echo.Context) error {
	params := vo.SysDictDataListParams{}
	if err := utils.ParamsCheck(c, &params); err != nil {
		return resp.Fail(c, "参数错误")
	}
	filePath, err := services.NewSysDictSrv(&c).DataExport(params)
	if err != nil {
		logger.Log.Error("err", zap.Error(err))
		return resp.Fail(c, "查询失败")
	}
	return resp.OK(c, map[string]any{
		"file_path": filePath,
	})
}
