package admin

import (
	"application/router/admin/adminlog"
	"application/router/admin/channel"
	"application/router/admin/log"
	"application/router/admin/menu"
	"application/router/admin/order"
	"application/router/admin/product"
	"application/router/admin/role"
	"application/router/admin/statistic"
	sysManager "application/router/admin/sys_manager"
	"application/router/admin/usage"
	"application/router/admin/user"

	"github.com/labstack/echo"
)

type Svc struct{}

func Register(eg *echo.Group) {

	// 不进行接口过滤
	// no.Register(eg)

	// 接口过滤
	g := eg.Group("")
	user.Register(g)
	menu.Register(g)
	role.Register(g)
	adminlog.Register(eg)
	usage.Register(eg)
	product.Register(eg)
	sysManager.Register(eg)
	channel.Register(eg)
	order.Register(eg)
	log.Register(eg)
	statistic.Register(eg)
}
