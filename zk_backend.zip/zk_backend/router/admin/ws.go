package admin

import (
	"application/middlewares"
	"application/models/resp"
	"application/services/ws"

	"github.com/labstack/echo"
)

type WsSrv struct{}

func (s *WsSrv) Handle(c echo.Context) error {
	var err error
	if err = middlewares.WsAuthCheck(c); err != nil {
		return resp.Response(c, err)
	}
	return resp.Response(c, ws.WsServer.HandleWebSocket(c))
}
