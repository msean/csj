package no

import (
	"application/common/logger"
	"application/models/resp"
	"application/services"
	"application/utils"
	"fmt"
	"github.com/labstack/echo"
	"go.uber.org/zap"
	"strconv"
)

type Svc struct{}

func Register(eg *echo.Group) {
	/*s := &Svc{}
	g := eg.Group("/no")
	{
		//g.GET("/roletree", s.RoleTree)                 // 获取角色树
		//g.GET("/find_menu/:mid", s.FindMenuByParentId) // 根据菜单id获取子菜单列表
		g.GET("/menu", s.Menu)               // 获取菜单树
		g.GET("/role", s.Role)               // 获取角色列表
		g.GET("/role_menu/:rid", s.RoleMenu) // 根据角色获取菜单
	}*/
}

func (s *Svc) Menu(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	userId := utils.UserId(c)
	list, err := services.NewServiceMenu(&c).FindMenu(userId)
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 获取菜单树 失败 [%d]", uuid, userId), zap.Error(err))
		return resp.Fail(c, "获取失败")
	}
	return resp.OK(c, &resp.ResultList{List: list})
}

func (s *Svc) RoleMenu(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	param := c.Param("rid")
	rid, err := strconv.Atoi(param)
	if err != nil {
		return resp.Fail(c, "参数错误")
	}
	list, err := services.NewServiceMenu(&c).GetRoleMenuTree()
	// list, err := services.NewServiceMenu(&c).GetRoleMenuTree(int64(rid))
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 获取角色菜单树 失败 [%d]", uuid, rid), zap.Error(err))
		return resp.Fail(c, "获取失败")
	}
	return resp.OK(c, &resp.ResultList{List: list})
}

//func (s *Svc) RoleTree(c echo.Context) error {
//	uuid := utils.GetContextUUID(&c)
//	userId := utils.UserId(c)
//	list, err := services.NewServiceRole(&c).GetRoleTree(userId, "0")
//	if err != nil {
//		logger.Log.Error(fmt.Sprintf("[%s] 获取角色树 失败 [%d]", uuid, userId), zap.Error(err))
//		return resp.Fail(c, "获取失败")
//	}
//	return resp.OK(c, &resp.ResultList{List: list})
//}

/*func (s *Svc) Role(c echo.Context) error {
	uuid := utils.GetContextUUID(c)
	userId := utils.UserId(c)
	list, err := services.NewServiceRole(&c).FindRole(userId, "0")
	if err != nil {
		logger.Log.Error(fmt.Sprintf("[%s] 获取角色 失败 [%d]", uuid, userId), zap.Error(err))
		return resp.Fail(c, "获取失败")
	}
	return resp.OK(c, &resp.ResultList{List: list})
}*/

//func (s *Svc) FindMenuByParentId(c echo.Context) error {
//	uuid := utils.GetContextUUID(&c)
//	param := c.Param("mid")
//	mid, err := strconv.Atoi(param)
//	if err != nil {
//		return resp.Fail(c, "参数错误")
//	}
//	userId := utils.UserId(c)
//	list, err := services.NewServiceMenu(&c).FindMenuByParentId(userId, int64(mid))
//	if err != nil {
//		logger.Log.Error(fmt.Sprintf("[%s] 获取子菜单 失败 [%d]", uuid, mid), zap.Error(err))
//		return resp.Fail(c, "获取失败")
//	}
//	return resp.OK(c, &resp.ResultList{List: list})
//}
