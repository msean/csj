package customer

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/middlewares"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/services/cache"
	"application/utils"
	"fmt"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	// g := eg.Group("/customer")
	g := middlewares.GroupWithLog{
		Group:  eg.Group("/customer"),
		Module: constant.MODULE_CUSTOMER,
	}
	{

		g.POSTWithLog("/export", s.Export, constant.LOG_OP_EXPORT)
		g.POST("/query", s.Query)
		g.POST("/users", s.Users)
		g.POSTWithLog("/create", s.Create, constant.LOG_OP_CREATE)
		g.POSTWithLog("/update", s.Update, constant.LOG_OP_UPDATE)
		g.POSTWithLog("/update_timeout", s.UpdateTimeout, constant.LOG_OP_UPDATE)
		g.POSTWithLog("/update_flag", s.UpdateFlag, constant.LOG_OP_UPDATE)
		g.POSTWithLog("/update_password", s.UpdatePassword, constant.LOG_OP_UPDATE)
		g.POSTWithLog("/remove", s.Remove, constant.LOG_OP_DELETE)
		g.POSTWithLog("/update_warning", s.UpdateWarning, constant.LOG_OP_UPDATE)

		g.WithModule(constant.MODULE_CUSTOMER_PRODUCT).POSTWithLog("/product/export", s.ExportProduct, constant.LOG_OP_EXPORT)
		g.WithModule(constant.MODULE_CUSTOMER_PRODUCT).POST("/product/query", s.QueryProduct)
		g.WithModule(constant.MODULE_CUSTOMER_PRODUCT).POSTWithLog("/product/create", s.CreateProduct, constant.LOG_OP_CREATE)
		g.WithModule(constant.MODULE_CUSTOMER_PRODUCT).POSTWithLog("/product/update", s.UpdateProduct, constant.LOG_OP_UPDATE)
		g.WithModule(constant.MODULE_CUSTOMER_PRODUCT).POSTWithLog("/product/remove", s.RemoveProduct, constant.LOG_OP_DELETE)
		g.WithModule(constant.MODULE_CUSTOMER_PRODUCT).POSTWithLog("/product/batch_update", s.BatchUpdateProduct, constant.LOG_OP_UPDATE)
		g.WithModule(constant.MODULE_CUSTOMER_PRODUCT).POSTWithLog("/product/batch_switch", s.BatchSwitchProduct, constant.LOG_OP_UPDATE)

		g.WithModule(constant.MODULE_FINANCE).POSTWithLog("/finance/export", s.ExportFinance, constant.LOG_OP_EXPORT)
		g.WithModule(constant.MODULE_FINANCE).POST("/finance/query", s.QueryFinance)
		g.WithModule(constant.MODULE_FINANCE).POSTWithLog("/finance/add", s.AddFinance, constant.LOG_OP_CREATE)
		g.WithModule(constant.MODULE_FINANCE).POSTWithLog("/finance/update_remark", s.UpdateFinanceRemark, constant.LOG_OP_UPDATE)
	}
}

func (s *Svc) Export(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	/*if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_CUSTOMER); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}*/

	data, err := services.NewCustomerService(&ctx).QueryCustomer(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer failed, none, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Customers, models.Customer{}.TableNameCH(), utils.UserId(ctx), downloadService.CommonDict(), false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer failed, export error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) Query(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	vo.InitPage(&params.Base)
	res, err := services.NewCustomerService(&ctx).QueryCustomer(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) Users(ctx echo.Context) error {
	var params struct {
		Ids []int64 `json:"ids" form:"ids"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer users failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	res, err := services.NewServiceUser(&ctx).QueryUsers(vo.UserQueryParams{Ids: params.Ids, Available: -1, IsClient: 1})
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer users failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) Create(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	customerService := services.NewCustomerService(&ctx)
	if err := customerService.CheckParams(params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, check failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	role, err := mysql.Role.FindClientRole()
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, find role failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = session.Begin(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, begin session failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	userService := services.NewServiceUser(&ctx)
	user, _, err := userService.CreateUser(session, vo.UserParams{
		Account:     params.Account,
		UserName:    params.Name,
		PhoneNumber: params.PhoneNumber,
		Email:       params.Email,
		Password:    params.Password,
		Available:   params.Available,
		Role:        role.ID,
		Remark:      "auto create by customer",
	}, role)
	if err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, create user failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	customer, err := customerService.CreateCustomer(session, params, user.ID)
	if err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, new customer, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if _, err = userService.SetCustomer(session, user, customer.ID); err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, update user failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if err = session.Commit(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, customer)
}

func (s *Svc) Update(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	customerService := services.NewCustomerService(&ctx)
	if err := customerService.CheckParams(params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer failed, check failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer failed, begin session failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	customer, err := customerService.UpdateCustomer(session, params.Id, vo.CustomerUpdateParam{Base: &params})
	if err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] update customer failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	updateParam := vo.UserParams{
		Id:          customer.UserID,
		UserName:    params.Name,
		PhoneNumber: params.PhoneNumber,
		Email:       params.Email,
		Available:   params.Available,
	}
	if _, err = services.NewServiceUser(&ctx).UpdateUser(session, updateParam, nil, true); err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] update customer failed, update user failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if err = cache.UpdateCacheModelPk(customer.TableName(), cache.CustomerPk(customer.ID), customer, false); err != nil {
		session.Rollback()
		return resp.Fail(ctx, err.Error())
	}

	if err = session.Commit(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer failed, session commit failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, customer)
}

func (s *Svc) UpdateTimeout(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerTimeoutParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer timeout failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	customer, err := services.NewCustomerService(&ctx).UpdateCustomer(nil, params.Id, vo.CustomerUpdateParam{Timeout: &params})
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer timeout failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if err = cache.UpdateCacheModelPk(customer.TableName(), cache.CustomerPk(customer.ID), &models.Customer{}, true); err != nil {
		cache.DelCacheModelPk(customer.TableName(), cache.CustomerPk(customer.ID))
	}
	return resp.OK(ctx, customer)
}

func (s *Svc) UpdateFlag(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerFlagParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer flag failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	customer, err := services.NewCustomerService(&ctx).UpdateCustomer(nil, params.Id, vo.CustomerUpdateParam{Flag: &params})
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer flag failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if err = cache.UpdateCacheModelPk(customer.TableName(), cache.CustomerPk(customer.ID), &models.Customer{}, true); err != nil {
		cache.DelCacheModelPk(customer.TableName(), cache.CustomerPk(customer.ID))
	}
	return resp.OK(ctx, customer)
}

func (s *Svc) UpdatePassword(ctx echo.Context) error {
	var params struct {
		Id       int64  `json:"id" form:"id"`
		Password string `json:"password" form:"password"`
		ApiKey   string `json:"api_key" form:"api_key"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer password failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer password failed, begin session failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	customerID := params.Id
	if customerID <= 0 {
		customerID = utils.CustomerID(ctx)
	}

	obj, err := services.NewCustomerService(&ctx).UpdateCustomer(session, customerID, vo.CustomerUpdateParam{ApiKey: params.ApiKey})
	if err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] update customer password failed, update failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if params.Password != "" {
		if err = services.NewServiceUser(&ctx).ResetPassword(obj.UserID, params.Password, true); err != nil {
			err1 := session.Rollback()
			logger.Log.Warn(fmt.Sprintf("[%s] update customer password failed, update user failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
			return resp.Fail(ctx, err.Error())
		}
	}

	if err = cache.UpdateCacheModelPk(models.Customer{}.TableName(), cache.CustomerPk(customerID), obj, false); err != nil {
		session.Rollback()
		return resp.Fail(ctx, err.Error())
	}

	if err = session.Commit(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer password failed, commit failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, nil)
}

func (s *Svc) Remove(ctx echo.Context) error {
	var params struct {
		Ids []int64 `json:"ids" form:"ids"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove customer failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	userIds, err := mysql.Customer.QueryUserByIds(params.Ids)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove customer failed, find customer failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	if err = session.Begin(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove customer failed, begin session failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	_, err = services.NewServiceUser(&ctx).RemoveUser(session, userIds, true)
	if err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] remove customer failed, remove user failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	count, err := services.NewCustomerService(&ctx).RemoveCustomer(session, params.Ids)
	if err != nil {
		err1 := session.Rollback()
		logger.Log.Warn(fmt.Sprintf("[%s] remove customer failed, %s, %v", uuid, convertor.ToString(params), err1), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	for _, id := range params.Ids {
		if err = cache.DelCacheModelPk(models.Customer{}.TableName(), cache.CustomerPk(id)); err != nil {
			session.Rollback()
			return resp.Fail(ctx, err.Error())
		}
	}

	if err = session.Commit(); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove customer failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, count)
}

func (s *Svc) UpdateWarning(ctx echo.Context) error {
	var params struct {
		Value bool `json:"value" form:"value"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update warning config failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	obj, has, err := mysql.SysArgConfig.FromKey(session, constant.SysConfCustomerWarning)
	if err != nil || !has {
		logger.Log.Warn(fmt.Sprintf("[%s] update warning config failed, find config failed, %s, %v", uuid, convertor.ToString(params), err))
		return resp.Fail(ctx, fmt.Sprintf("find config failed, %v", err))
	}

	obj.Value = fmt.Sprintf("%v", params.Value)

	_, err = daos.UpdateObjWithVersion(session, obj, nil)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update warning config failed, update failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, fmt.Sprintf("find config failed, %v", err))
	}

	services.NewServiceCache().UpdateCustomerWarning(params.Value)
	return resp.OK(ctx, obj.Value)
}

func (s *Svc) ExportProduct(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerProductQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer product failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	/*if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_CUSTOMER_PRODUCT); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer product failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}*/

	data, err := services.NewCustomerProdSrv(&ctx).QueryCustomerProduct(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer product failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer product failed, none, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Products, models.CustomerProduct{}.TableNameCH(), utils.UserId(ctx), downloadService.CustomerProductDict(), false)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer product failed, export error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) QueryProduct(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerProductQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer product failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	isClient, err := utils.IsClient(ctx)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer product failed, invalid user, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if isClient {
		customerID := utils.CustomerID(ctx)
		if customerID <= 0 {
			logger.Log.Warn(fmt.Sprintf("[%s] query customer product failed, invalid customerID, %s", uuid, convertor.ToString(params)), zap.Error(err))
			return resp.Fail(ctx, "invalid customerID")
		}

		params.CustomerIds = []int64{customerID}
	}

	vo.InitPage(&params.Base)
	res, err := services.NewCustomerProdSrv(&ctx).QueryCustomerProduct(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer product failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) CreateProduct(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerProductCreateParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer product failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	proService := services.NewCustomerProdSrv(&ctx)
	err := proService.CheckProductParams(params.CustomerProductParam)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer product failed, check failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	customer, err := services.NewCustomerService(&ctx).FindCustomer(params.CustomerID)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create customer product failed, can't find customer, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	objs, errs := proService.CreateCustomerProduct(customer, params)
	return resp.OK(ctx, map[string]interface{}{
		"success": objs,
		"err":     errs,
	})
}

func (s *Svc) UpdateProduct(ctx echo.Context) error {
	var params struct {
		Id int64 `json:"id" form:"id"` // 客户产品ID
		vo.CustomerProductParam
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer product failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	proService := services.NewCustomerProdSrv(&ctx)
	err := proService.CheckProductParams(params.CustomerProductParam)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer product failed, check failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	obj, err := proService.UpdateCustomerProduct(params.Id, params.CustomerProductParam)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer product failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	// cache.OprCustomerProductCache([]int64{params.Id}, 1)

	return resp.OK(ctx, obj)
}

func (s *Svc) RemoveProduct(ctx echo.Context) error {
	var params struct {
		Ids []int64 `json:"ids" form:"ids"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove customer product failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	count, err := services.NewCustomerProdSrv(&ctx).RemoveCustomerProduct(params.Ids)
	if err != nil {
		return resp.Fail(ctx, err.Error())
	}

	cache.OprCustomerProductCache(params.Ids, 2)
	return resp.OK(ctx, count)
}

func (s *Svc) BatchUpdateProduct(ctx echo.Context) error {
	var params struct {
		Ids []int64 `json:"ids" form:"ids"` // 客户产品ID
		vo.CustomerProductParam
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] batch update customer product failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	proService := services.NewCustomerProdSrv(&ctx)
	err := proService.CheckProductParams(params.CustomerProductParam)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] batch update customer product failed, check failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	var objs []*models.CustomerProduct
	var errs []string
	for _, id := range params.Ids {
		obj, err := proService.UpdateCustomerProduct(id, params.CustomerProductParam)
		if err != nil {
			errs = append(errs, err.Error())
		} else {
			objs = append(objs, obj)
		}
	}

	// cache.OprCustomerProductCache(params.Ids, 1)
	/*count, err := mysql.CustomerProduct.BatchUpdate(utils.UserId(ctx), params.Ids, params.CustomerProductParam)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] batch update customer product failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}*/

	return resp.OK(ctx, map[string]interface{}{
		"success": objs,
		"err":     errs,
	})
}

func (s *Svc) BatchSwitchProduct(ctx echo.Context) error {
	var params struct {
		Ids       []int64 `json:"ids" form:"ids"`
		Available bool    `json:"available" form:"available"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] batch switch customer product failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	count, err := mysql.CustomerProduct.BatchSwitch(params.Ids, params.Available)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] batch switch customer product failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	cache.OprCustomerProductCache(params.Ids, 1)
	return resp.OK(ctx, count)
}

func (s *Svc) ExportFinance(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerFinanceQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_CUSTOMER_FINANCE); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer finance failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	data, err := services.NewCustomerFinanceService(&ctx).QueryCustomerFinance(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer finance failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer finance failed, none, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Records, models.CustomerFinance{}.TableNameCH(), utils.UserId(ctx), downloadService.CustomerFinanceDict(), true)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export customer finance failed, export error, %s", uuid, convertor.ToString(params)))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) QueryFinance(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerFinanceQueryParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	isClient, err := utils.IsClient(ctx)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer finance failed, invalid user, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if isClient {
		customerID := utils.CustomerID(ctx)
		if customerID <= 0 {
			logger.Log.Warn(fmt.Sprintf("[%s] query customer finance failed, invalid customerID, %s", uuid, convertor.ToString(params)), zap.Error(err))
			return resp.Fail(ctx, "invalid customerID")
		}

		params.CustomerID = customerID
	}

	vo.InitPage(&params.Base)
	res, err := services.NewCustomerFinanceService(&ctx).QueryCustomerFinance(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer finance failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) AddFinance(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.CustomerFinanceParam{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] add customer finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	res, err := services.NewCustomerFinanceService(&ctx).AddFinance(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] add customer finance failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) UpdateFinanceRemark(ctx echo.Context) error {
	var params struct {
		Id     int64  `json:"id" form:"id"`
		Remark string `json:"remark" form:"remark"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer finance remark failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	res, err := services.NewCustomerFinanceService(&ctx).UpdateRemark(params.Id, params.Remark)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer finance remark failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}
