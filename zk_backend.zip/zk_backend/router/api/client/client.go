package client

import (
	"application/common/logger"
	"application/constant"
	"application/daos/mysql"
	"application/middlewares"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/models/vo/api"
	"application/services"
	"application/services/cache"
	"application/utils"
	"fmt"
	"sync"

	"github.com/duke-git/lancet/v2/convertor"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	// g := eg.Group("/client")
	g := middlewares.GroupWithLog{
		Group: eg.Group("/client"),
	}
	{
		g.WithModule(constant.MODULE_CLIENT_RECHARGE).POSTWithLog("/recharge", s.Recharge, constant.MODULE_CLIENT_RECHARGE)
		g.POST("/query_other", s.QueryOther)
		g.WithModule(constant.MODULE_CLIENT_INTEGRATION).POSTWithLog("/update_whitelist", s.UpdateWhitelist, constant.LOG_OP_UPDATE)
	}
}

func (s *Svc) Recharge(ctx echo.Context) (err error) {
	params := vo.ClientRechargeParam{}

	if err := ctx.Bind(&params); err != nil {
		logger.Log.Error("[Recharge] params", zap.Error(err))
		return resp.Fail(ctx, "参数错误"+err.Error())
	}

	// 判断在对账维护中
	if yes, _ := new(services.SysConfigSrv).InReconMaintenance(); yes {
		return resp.Fail(ctx, "在对账维护中")
	}

	customerID := utils.User(ctx).CustomerID
	isSuper := utils.IsSuperAdmin(ctx)
	if (isSuper || customerID == 0) && params.CustomerID != 0 {
		customerID = params.CustomerID
	}

	var has bool
	var customer models.Customer
	if has, err = cache.FromModelPk(models.Customer{}.TableName(), cache.CustomerPk(customerID), &customer, cache.FromDatabaseGet); err != nil {
		resp.Fail(ctx, err.Error())
		return
	}

	if !has {
		resp.Fail(ctx, "客户不存在")
		return
	}

	if !customer.RechargeFlag {
		resp.Fail(ctx, "充值接口关闭")
		return
	}

	var rsp []vo.ClientRechargeRsp
	var rspMutex sync.Mutex

	var customerProductMapper map[string]models.CustomerProduct
	if customerProductMapper, err = mysql.CustomerProduct.AllMapperByCustomer(customerID); err != nil {
		resp.Fail(ctx, err.Error())
		return
	}

	wg := sync.WaitGroup{}
	for index, recharge := range params.Body {
		wg.Add(1)
		go func(index int, recharge vo.ClientRechargeInfo) {
			defer wg.Done()

			customerOrderID := utils.MakeOrderID(fmt.Sprintf("%d", customerID))

			var isp int
			var productCode string

			// 单充逻辑
			if params.Type == 1 && index == 0 {
				// isp = int(params.CustomerID)
				var province int
				areaSection, has, matchErr := mysql.AreaSection.Match(recharge.PhoneNumber)
				if matchErr != nil {
					resp.Fail(ctx, matchErr.Error())
					return
				}
				if !has {
					isp = int(constant.IspCodeM[recharge.Operator])
					province = 0
				} else {
					isp = areaSection.Isp
					province = constant.AreaCodeM[areaSection.Province]
				}
				productCode = utils.ProductCode(isp, province, recharge.Value)
				// isp = int(constant.IspCodeM[recharge.Operator])
				// productCode = utils.ProductCode(isp, 0, recharge.Value)
			}

			// 批量充值 产品编码是会传的
			if params.Type == 2 {
				productCode = recharge.ProductCode
			}

			if params.Type == 3 && index == 0 {
				var customerProd models.CustomerProduct
				var ok bool
				if customerProd, ok = customerProductMapper[recharge.ProductCode]; !ok {
					logger.Log.Error("[Recharge] params err", zap.String("operator", recharge.ProductCode), zap.Int64("customerID", customerID))
					err = fmt.Errorf("没有找到对应的客户产品")
					return
				}
				isp = int(customerProd.ProductIsp)
				if recharge.AreaByProduct {
					productCode = recharge.ProductCode
				} else {
					if _code, ok := constant.AreaCodeM[recharge.Province]; ok {
						productCode = utils.ProductCode(isp, _code, recharge.Value)
					} else {
						areaSection, has, matchErr := mysql.AreaSection.Match(recharge.PhoneNumber)
						if matchErr != nil {
							resp.Fail(ctx, matchErr.Error())
							return
						}
						if !has {
							isp = int(constant.IspCodeM[recharge.Operator])
							_code = 0
						} else {
							isp = areaSection.Isp
							_code = constant.AreaCodeM[areaSection.Province]
						}
						productCode = utils.ProductCode(isp, _code, recharge.Value)
					}
				}
			}

			// 如何没有对应的客户产品，可以用全国产品替代
			if _, in := customerProductMapper[productCode]; !in {
				logger.Log.Info("[Recharge]",
					zap.String("productCode replace", productCode),
					zap.String("phone", recharge.PhoneNumber))
				productCode = utils.ProductCode(isp, 0, recharge.Value)
			}

			if utils.IsBlankString(productCode) {
				productCode = recharge.ProductCode
			}

			if isp == 0 {
				isp = int(constant.ConvertIsp(recharge.Operator))
			}
			if isp == 0 {
				logger.Log.Error("[Recharge] params err", zap.String("operator", recharge.Operator))
				return
			}

			_, _, apiCode := services.NewOrderService(&ctx).Recharge(api.CreateOrderParams{
				SzPhoneNum:  recharge.PhoneNumber,
				NMoney:      recharge.Value,
				NSortType:   isp,
				SzProductId: productCode,
				SzAgentID:   fmt.Sprintf("%d", customerID),
				SzOrderId:   customerOrderID,
			}, false)

			// 单充立即返回
			if index == 0 && (params.Type == 1 || params.Type == 3) {
				if apiCode.ApiCode == constant.ApiSuccess {
					resp.OK(ctx, "ok")
				} else {
					resp.Fail(ctx, apiCode.OrderMsg)
				}
				return
			}

			submitResult := "成功"
			if apiCode.ApiCode != 0 {
				submitResult = apiCode.OrderMsg
			}
			result := vo.ClientRechargeRsp{
				ClientRechargeInfo: recharge,
				SubmitResult:       submitResult,
				CustomerOrderID:    customerOrderID,
			}

			rspMutex.Lock()
			rsp = append(rsp, result)
			rspMutex.Unlock()
		}(index, recharge)
	}

	wg.Wait()

	if params.Type == 2 {
		return resp.OK(ctx, map[string]any{
			"result": rsp,
		})
	}
	return
}

func (s *Svc) QueryOther(ctx echo.Context) error {
	var params struct {
		Password string `json:"password" form:"password"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer other failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	data, err := services.NewCustomerService(&ctx).QueryOther(utils.User(ctx).CustomerID, params.Password)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query customer other failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, data)
}

func (s *Svc) UpdateWhitelist(ctx echo.Context) error {
	var params struct {
		// Id        int64  `json:"id" form:"id"`
		Password  string `json:"password" form:"password"`
		Whitelist string `json:"whitelist" form:"whitelist"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer whilelist failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	data, err := services.NewCustomerService(&ctx).UpdateWhitelist(utils.User(ctx).CustomerID, params.Password, params.Whitelist)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update customer whilelist failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, data)
}
