package api

import (
	"application/common/logger"
	"application/constant"
	_constant "application/constant"
	"application/daos/mysql"
	"application/daos/redis"
	"application/models"
	"application/models/resp"
	"application/models/vo/api"
	"application/utils"
	"strconv"
	"strings"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type balanceSvc struct{}

func (srv *balanceSvc) QueryBalance(c echo.Context) (err error) {

	var params api.QueryBalanceParams
	defer func() {
		if err != nil {
			logger.Log.Error("[QueryBalance] err message:", zap.Error(err))
		}
	}()

	if err = c.Bind(&params); err != nil {
		return resp.FailBalanceQryApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewParamsApiCodeMsg("参数有错误:"+err.Error()))
	}

	if params.SzFormat == "" {
		params.SzFormat = constant.RtnFormatJson
	}

	// 客户检查
	var customerID int64
	var customer models.Customer
	var has bool
	customerID, err = strconv.ParseInt(params.SzAgentID, 10, 64)
	if err != nil {
		return resp.FailBalanceQryApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiCustomerNotExist))
	}
	customer, has, err = mysql.Customer.FromID(customerID)
	if err != nil {
		return resp.FailBalanceQryApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiSysAbnormal))
	}
	if !has {
		return resp.FailBalanceQryApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiCustomerNotExist))
	}

	// 检查IP
	if !utils.IsBlankString(customer.Ip) && !strings.EqualFold(customer.Ip, "0.0.0.0") {
		if !utils.InCombineString(c.RealIP(), customer.Ip, ";") {
			logger.Log.Info("QueryBalance",
				zap.String("ip", c.RealIP()),
				zap.String("customer.Ip", customer.Ip),
				zap.Bool("strings.Contains(customer.Ip, ip)", strings.Contains(customer.Ip, c.RealIP())))
			return resp.FailBalanceQryApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiUnbindIp))
		}
	}

	// 客户签名验证
	if !params.ValidSign(customer.ApiKey) {
		return resp.FailBalanceQryApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiSignErr))
	}

	var limit bool
	if limit, _ = redis.ApiFrequencyCheck(redis.BalanceQryCacheKey(customerID), _constant.FrequencyBalanceQry); limit {
		return resp.FailBalanceQryApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiFrequencyLimit))
	}

	return resp.ApiRsp(c, params.SzFormat, resp.BalanceResult{
		Code:    int(_constant.ApiSuccess),
		Agent:   params.SzAgentID,
		Balance: customer.Balance,
		Credit:  float32(customer.Credit),
		CodeMsg: "success",
	})
}
