package finance

import (
	"application/common/logger"
	"application/constant"
	"application/middlewares"
	"application/models"
	"application/models/resp"
	"application/models/vo"
	"application/services"
	"application/utils"
	"fmt"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(eg *echo.Group) {
	s := &Svc{}
	// g := eg.Group("/finance")
	g := middlewares.GroupWithLog{
		Group:  eg.Group("/finance"),
		Module: constant.MODULE_FINANCE,
	}
	{
		g.POSTWithLog("/export", s.Export, constant.LOG_OP_EXPORT)
		g.POST("/query", s.Query)
		g.POSTWithLog("/create", s.Create, constant.LOG_OP_CREATE)
		g.POSTWithLog("/update", s.Update, constant.LOG_OP_UPDATE)
		g.POSTWithLog("/remove", s.Remove, constant.LOG_OP_DELETE)
		g.POST("/month_query", s.MonthQuery)
	}
}

func (s *Svc) Export(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.FinanceDayQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export day finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	downloadService := services.NewDownloadService(&ctx)
	if err := downloadService.CheckTime(params.Base, constant.EXPORT_DAY_FINANCE_DAY); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export day finance failed, invalid date, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	data, err := services.NewFinanceDayService(&ctx).QueryRecords(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export day finance failed, query error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	if data.Count <= 0 {
		logger.Log.Warn(fmt.Sprintf("[%s] export day finance failed, none, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, "none")
	}

	filePath, err := downloadService.Export(params, data.Records, models.FinanceDay{}.TableNameCH(), utils.UserId(ctx), downloadService.FinanceDict(), true)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] export day finance failed, export error, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, filePath)
}

func (s *Svc) Query(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.FinanceDayQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query day finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	vo.InitPage(&params.Base)
	res, err := services.NewFinanceDayService(&ctx).QueryRecords(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query day finance failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) Create(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := models.FinanceDay{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create day finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	res, err := services.NewFinanceDayService(&ctx).CreateRecord(&params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] create day finance failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) Update(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := models.FinanceDay{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update day finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	res, err := services.NewFinanceDayService(&ctx).UpdateRecord(&params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] update day finance failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, res)
}

func (s *Svc) Remove(ctx echo.Context) error {
	var params struct {
		Ids []int64 `json:"ids" form:"ids"`
	}

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove day finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	count, err := services.NewFinanceDayService(&ctx).RemoveRecord(params.Ids)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] remove day finance failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	return resp.OK(ctx, count)
}

func (s *Svc) MonthQuery(ctx echo.Context) error {
	uuid := utils.GetContextUUID(ctx)
	params := vo.FinanceMonthQueryParams{}
	if err := ctx.Bind(&params); err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query month finance failed, invalid params, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	customerStatistics, err := services.NewCustomerFinanceService(&ctx).Statistics(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query month finance failed, query customer failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	orderStatistics, err := services.NewOrderService(&ctx).Statistics(params)
	if err != nil {
		logger.Log.Warn(fmt.Sprintf("[%s] query month finance failed, query order failed, %s", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	res := vo.FinanceMonthQueryRes{
		Customer: customerStatistics,
		Order:    orderStatistics,
	}
	return resp.OK(ctx, res)
}
