package api

import (
	"application/common/logger"
	"application/constant"
	_constant "application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/daos/redis"
	"application/models"
	"application/models/resp"
	"application/models/vo/api"
	"application/services"
	"application/utils"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type orderSvc struct{}

func (srv *orderSvc) SubmitOrder(c echo.Context) error {
	var params api.CreateOrderParams

	if err := c.Bind(&params); err != nil {
		logger.Log.Error("[orderSvc] [SubmitOrder]", zap.Error(err))
		return resp.FailOrderApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiOrderAbnormal))
	}

	if params.SzFormat == "" {
		params.SzFormat = constant.RtnFormatJson
	}

	// 判断在对账维护中
	if yes, _ := services.NewSysConfigSrv(&c).InReconMaintenance(); yes {
		return resp.FailOrderApiRsp(c, params.SzFormat, params.SzAgentID, _constant.NewApiCodeMsg(_constant.ApiOrderSysMaintenance))
	}

	// 参数检查
	if oc := params.Check(); oc.ApiCode != 0 {
		return resp.FailOrderApiRsp(c, params.SzFormat, params.SzAgentID, oc)
	}

	customer, customerProd, apiResult := services.NewOrderService(&c).Recharge(params, true)
	logger.Log.Info("SubmitOrder", zap.Any("apiResult", apiResult))
	if apiResult.ApiCode == _constant.ApiSuccess {
		return resp.ApiRsp(c, params.SzFormat, resp.OrderResult{
			Code:      0,
			OrderID:   params.SzOrderId,
			SalePrice: customerProd.SalePrice,
			Balance:   customer.TotalBalance,
			CodeMsg:   "success",
		})
	} else {
		return resp.FailOrderApiRsp(c, params.SzFormat, params.SzAgentID, apiResult)
	}
}

func (srv *orderSvc) Callback(c echo.Context) (err error) {

	channelIDStr := c.Param("channel_id")
	logger.Log.Info("[Callback] receive", zap.String("channel_id", channelIDStr))

	var channelID int64
	channelID, err = strconv.ParseInt(channelIDStr, 10, 64)
	if err != nil {
		return resp.Resp(c, false, 500, "ok", nil)
	}

	return services.NewCallbackSvc(&c).Receive(channelID)
}

func (srv *orderSvc) OrderQuery(c echo.Context) (err error) {
	var params api.QryOrderParams

	defer func() {
		if err != nil {
			logger.Log.Error("[QueryBalance]", zap.Any("err", err))
		}
	}()

	if err = c.Bind(&params); err != nil {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewParamsApiCodeMsg("参数有错误"))
	}

	if params.SzFormat == "" {
		params.SzFormat = constant.RtnFormatJson
	}

	// 客户检查
	var customerID int64
	var customer models.Customer
	var has bool
	customerID, err = strconv.ParseInt(params.SzAgentID, 10, 64)
	if err != nil {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiCustomerNotExist))
	}
	customer, has, err = mysql.Customer.FromID(customerID)
	if err != nil {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiSysAbnormal))
	}
	if !has {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiCustomerNotExist))
	}

	// 检查IP
	if !utils.IsBlankString(customer.Ip) && !strings.EqualFold(customer.Ip, "0.0.0.0") {
		if !utils.InCombineString(c.RealIP(), customer.Ip, ";") {
			logger.Log.Info("OrderQuery",
				zap.String("ip", c.RealIP()),
				zap.String("customer.Ip", customer.Ip),
				zap.Bool("strings.Contains(customer.Ip, ip)", strings.Contains(customer.Ip, c.RealIP())))
			return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiUnbindIp))
		}
	}

	// 客户签名验证
	if !params.ValidSign(customer.ApiKey) {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiSignErr))
	}

	// 验证接口频率 todo redis查询失败？要不要限制？
	var limit bool
	if limit, _ = redis.ApiFrequencyCheck(redis.BalanceQryCacheKey(customerID), time.Duration(_constant.FrequencyBalanceQry)); limit {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiFrequencyLimit))
	}

	// var orderID int64
	var order models.Order
	// if orderID, err = strconv.ParseInt(params.SzOrderId, 10, 64); err != nil {
	// 	return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewParamsApiCodeMsg("SzOrderId错误"))
	// }
	session := daos.Mysql.NewSession()
	defer session.Close()
	order, has, err = partition.GlobalOrderPartition.FromCustomerOrderID(session, params.SzOrderId, time.Now().AddDate(0, -6, 0))
	if err != nil {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiSysAbnormal))
	}
	if !has {
		return resp.FailOrderQryApiRsp(c, params.SzFormat, params.SzOrderId, _constant.NewApiCodeMsg(_constant.ApiOrderNotExist))
	}

	switch order.Status {
	// 订单失败状态
	case _constant.OrderStatusFail:
		return resp.ApiRsp(c, params.SzFormat, resp.OrderQryResult{
			Code:       5013,
			OrderID:    params.SzOrderId,
			SalasPrice: order.SalePrice,
			CodeMsg:    "fail",
		})

	case _constant.OrderStatusSuccess:
		return resp.ApiRsp(c, params.SzFormat, resp.OrderQryResult{
			Code:       5012,
			OrderID:    params.SzOrderId,
			SalasPrice: order.SalePrice,
			CodeMsg:    "success",
		})
	default:
		return resp.ApiRsp(c, params.SzFormat, resp.OrderQryResult{
			Code:       5011,
			OrderID:    params.SzOrderId,
			SalasPrice: order.SalePrice,
			CodeMsg:    "processing",
		})
	}
}

func (srv *orderSvc) OrderStuckQuery(c echo.Context) (err error) {
	var params api.OrderStuckQueryParams

	defer func() {
		if err != nil {
			logger.Log.Error("[QueryBalance]", zap.Any("err", err))
		}
	}()

	if err = c.Bind(&params); err != nil {
		return resp.Fail(c, "参数错误"+err.Error())
	}

	switch params.Type {
	case 1:
		var customerStuckMapper map[int64]map[int64]models.OrderStuckInfo
		if customerStuckMapper, err = services.OrderStuckChecker.CustomerStuck(); err != nil {
			return
		}
		return resp.OK(c, customerStuckMapper)
	case 2:
		var channelStuckMapper map[int64]map[int64]models.OrderStuckInfo
		if channelStuckMapper, err = services.OrderStuckChecker.ChannelStuck(); err != nil {
			return
		}
		return resp.OK(c, channelStuckMapper)
	}
	return resp.Fail(c, "不支持的查询类型")
}
