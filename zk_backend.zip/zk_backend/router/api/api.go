package api

import (
	"application/router/admin"
	"application/router/api/client"
	"application/router/api/customer"
	"application/router/api/finance"

	"github.com/labstack/echo"
)

func Register(eg *echo.Group, authMiddleware echo.MiddlewareFunc) {
	orderSvc := orderSvc{}
	{
		eg.POST("/submit_order", orderSvc.SubmitOrder)
		eg.POST("/notify/:channel_id", orderSvc.Callback)
		eg.GET("/notify/:channel_id", orderSvc.Callback)
		eg.POST("/query_order", orderSvc.OrderQuery)
		eg.GET("/stuck", orderSvc.OrderStuckQuery)
	}
	balanceSrv := balanceSvc{}
	{
		eg.POST("/query_balance", balanceSrv.QueryBalance)
	}

	wsSrv := admin.WsSrv{}
	eg.GET("/ws", wsSrv.Handle)

	eg.Use(authMiddleware)
	customer.Register(eg)
	finance.Register(eg)
	client.Register(eg)

}
