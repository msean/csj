package auth

import (
	"application/common/logger"
	"application/daos/mysql"
	"application/middlewares"
	"application/models/resp"
	"application/services"
	"application/utils"
	"fmt"
	"strings"

	"github.com/duke-git/lancet/v2/convertor"
	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Svc struct{}

func Register(e *echo.Group) {
	s := &Svc{}
	e.POST("/login_admin", s.Login)
	e.POST("/logout", s.LoginOut, middlewares.AuthLogin())
}

func (s *Svc) Login(ctx echo.Context) (err error) {
	var params struct {
		Account  string `json:"account" form:"account" validate:"required"`
		Password string `json:"password" form:"password" validate:"required"`
	}

	isSuccess := false
	remark := ""
	token := ""
	defer func() {
		services.NewServiceLog(&ctx).Login(params.Account, isSuccess, remark, token)
	}()

	uuid := utils.GetContextUUID(ctx)
	if err := ctx.Bind(&params); err != nil {
		remark = err.Error()
		logger.Log.Warn(fmt.Sprintf("login failed, invalid params, %s", convertor.ToString(params)), zap.Error(err))
		return resp.InvalidParams(ctx)
	}

	token, err = services.NewServiceUser(&ctx).AdminLogin(params.Account, params.Password, ctx.RealIP())
	if err != nil {
		remark = err.Error()
		logger.Log.Error(fmt.Sprintf("[%s] login [%s]", uuid, convertor.ToString(params)), zap.Error(err))
		return resp.Fail(ctx, err.Error())
	}

	isSuccess = true
	return resp.OK(ctx, map[string]interface{}{
		"token": token,
	})
}

func (s *Svc) LoginOut(ctx echo.Context) error {
	token := strings.TrimSpace(strings.ReplaceAll(ctx.Request().Header.Get("Authorization"), "Bearer", ""))
	err := mysql.OnlineUser.Logout(token)
	if err != nil {
		return resp.Fail(ctx, err.Error())
	}
	return resp.OK(ctx, nil)
}
