package router

import (
	"application/common/logger"
	"application/conf"
	"application/middlewares"
	"application/router/admin"
	"application/router/api"
	"application/router/auth"
	"application/router/common"
	"application/services"
	"time"

	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
)

func RunHttpServer(bing string) {
	e := echo.New()
	e.Validator = &middlewares.CustomValidator{}

	e.Use(middleware.LoggerWithConfig(middleware.LoggerConfig{
		Format: "ip=${remote_ip} time=${time_rfc3339}, method=${method}, uri=${uri}, status=${status}, latency_human=${latency_human}\n",
		Output: logger.EchoLog,
	}))
	e.Use(middleware.CORSWithConfig(
		middleware.CORSConfig{
			AllowOrigins:     []string{"*"},
			AllowMethods:     []string{echo.POST, echo.GET, echo.OPTIONS, echo.PATCH, echo.DELETE},
			AllowCredentials: true,
			MaxAge:           int(time.Hour) * 24,
		}))
	e.Use(middlewares.RequestLog())

	if conf.Config().Echo.ApiMetrics {
		e.Use(middlewares.ApiStatisticMiddleware())
	}

	e.Use(middleware.BodyDumpWithConfig(middlewares.DefaultBodyDumpConfig))

	services.NewServiceCache().Init()

	registRouter := func(fn func(*echo.Group)) {
		if fn != nil {
			fn(e.Group(""))
		}
	}

	registRouter(func(eg *echo.Group) {
		common.Register(eg)
	})

	// 登录
	registRouter(func(eg *echo.Group) {
		g := eg.Group("/api")
		auth.Register(g)
	})

	// 常规接口
	registRouter(func(eg *echo.Group) {
		g := eg.Group("/api")
		api.Register(g, middlewares.AuthLogin())
	})

	// 后台接口
	registRouter(func(eg *echo.Group) {
		g := eg.Group("/api/admin")
		g.Use(middlewares.AuthLogin())
		// g.Use(middlewares.AuthPermission())	// todo: after test
		g.Use(middlewares.LoggerMiddleware())
		admin.Register(g)
	})

	e.Logger.Fatal(e.Start(bing))
}
