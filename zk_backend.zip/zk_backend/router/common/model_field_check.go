package common

import (
	"application/daos"
	"application/models"
	"application/models/resp"
	"application/utils"
	"reflect"

	"github.com/labstack/echo"
)

func (this *Svc) CheckField(ctx echo.Context) error {
	type Body struct {
		Model string `json:"model"`
		Field string `json:"field"`
		Value string `json:"value"`
	}
	params := Body{}
	var err error
	if err = ctx.Bind(&params); err != nil {
		return resp.Fail(ctx, "参数错误:"+err.Error())
	}

	var modelType reflect.Type
	switch params.Model {
	case "Product":
		modelType = reflect.TypeOf(&models.Product{})
	case "Channel":
		modelType = reflect.TypeOf(&models.Channel{})
	default:
		return resp.Fail(ctx, "不支持的模型类型: "+params.Model)
	}

	newModel := reflect.New(modelType.Elem()).Interface()

	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()

	has, err = utils.Get(session, newModel, utils.NewWhereCond(params.Field, params.Value))
	if err != nil {
		return resp.Fail(ctx, "获取失败:"+err.Error())
	}
	return resp.OK(ctx, map[string]any{
		"has": has,
	})
}
