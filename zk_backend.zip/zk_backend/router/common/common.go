package common

import (
	"net/http"

	"github.com/labstack/echo"
)

type Svc struct{}

func Register(e *echo.Group) {
	s := &Svc{}
	e.GET("/", s.Index)
	e.GET("/api/download", s.DownLoad)
	e.POST("/api/check_field", s.CheckField)
	e.HEAD("/ping", s.Ping)
}

func (this *Svc) Index(c echo.Context) error {
	return c.String(http.StatusOK, "hello world")
}
