package common

import (
	"application/conf"
	"fmt"
	"net/http"
	"os"

	"github.com/labstack/echo"
)

func (this *Svc) DownLoad(c echo.Context) error {
	filePath := c.QueryParam("file_path")

	file, err := os.Open(fmt.Sprintf("%s/%s", conf.Config().Echo.StaticPath, filePath))
	if err != nil {
		return echo.NewHTTPError(http.StatusNotFound, "File not found")
	}
	defer file.Close()

	c.Response().Header().Set("Content-Type", "application/octet-stream")
	c.Response().Header().Set("Content-Disposition", "attachment; filename="+file.Name())

	return c.Stream(http.StatusOK, "application/octet-stream", file)
}
