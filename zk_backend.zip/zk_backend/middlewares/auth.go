package middlewares

import (
	"application/common/logger"
	"application/daos/mysql"
	"application/models/resp"
	"application/services"
	"application/utils"
	"application/utils/jwt_auth"
	"fmt"
	"strings"

	"github.com/labstack/echo"
)

func AuthLogin() echo.MiddlewareFunc {
	// todo: super role just check password(ignore google code)
	return func(handlerFunc echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) (err error) {
			tokenPrefix := "Bearer"
			token := c.Request().Header.Get("Authorization")

			if in, _ := mysql.OnlineUser.InForceQuitList(token); in {
				return resp.InvalidToken(c)
			}
			index := strings.Index(token, tokenPrefix)
			if index != 0 {
				logger.Log.Warn(fmt.Sprintf("auth login failed, invalid token, [%v]", token))
				return resp.InvalidToken(c)
			}

			jwt, err := jwt_auth.ParseToken(strings.TrimSpace(token[len(tokenPrefix):]))
			if err != nil {
				logger.Log.Warn("auth login failed, parse token failed, " + err.Error())
				return resp.InvalidToken(c)
			}

			// logger.Log.Info(fmt.Sprintf("_________debug-GetBeanByAccount:  start auto user"))

			user, err := mysql.User.GetBeanByAccount(jwt.Account)
			if err != nil || user == nil || !user.Available {
				logger.Log.Warn(fmt.Sprintf("auth login failed, invalid user, user: %v, err: %v", user, err))
				return resp.InvalidToken(c)
			}

			if jwt.Uuid != user.ID {
				logger.Log.Warn(fmt.Sprintf("auth login failed, check failed, user: %v, jwt: %v", user, jwt))
				return resp.InvalidToken(c)
			}

			utils.SetUser(c, user)
			go mysql.OnlineUser.RefreshLatestView(token)
			logger.Log.Info(fmt.Sprintf("auth login success, user[%d, %s]", user.ID, user.Account))
			return handlerFunc(c)
		}
	}
}

func WsAuthCheck(c echo.Context) (err error) {
	tokenPrefix := "Bearer"
	token := c.QueryParam("Authorization")

	if in, _ := mysql.OnlineUser.InForceQuitList(token); in {
		return resp.InvalidToken(c)
	}
	index := strings.Index(token, tokenPrefix)
	if index != 0 {
		logger.Log.Warn(fmt.Sprintf("auth login failed, invalid token, [%v]", token))
		return resp.InvalidToken(c)
	}

	jwt, err := jwt_auth.ParseToken(strings.TrimSpace(token[len(tokenPrefix):]))
	if err != nil {
		logger.Log.Warn("auth login failed, parse token failed, " + err.Error())
		return resp.InvalidToken(c)
	}

	user, err := mysql.User.GetBeanByAccount(jwt.Account)
	if err != nil || user == nil || !user.Available {
		logger.Log.Warn(fmt.Sprintf("auth login failed, invalid user, user: %v, err: %v", user, err))
		return resp.InvalidToken(c)
	}

	if jwt.Uuid != user.ID {
		logger.Log.Warn(fmt.Sprintf("auth login failed, check failed, user: %v, jwt: %v", user, jwt))
		return resp.InvalidToken(c)
	}

	utils.SetUser(c, user)
	go mysql.OnlineUser.RefreshLatestView(token)
	return
}

func AuthPermission() echo.MiddlewareFunc {
	return func(handlerFunc echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) (err error) {
			if !utils.IsSuperAdmin(c) {
				method := c.Request().Method
				url := c.Request().RequestURI
				menuId := services.NewServiceCache().FindMenuByUrl(url, method)
				if menuId <= 0 {
					return resp.InvalidPermission(c)
				}

				if !services.NewServiceCache().CheckRoleMenu(utils.RoleID(c), menuId) {
					return resp.InvalidPermission(c)
				}
			}

			return handlerFunc(c)
		}
	}
}
