package middlewares

import (
	"application/constant"
	"application/models/vo"
	"reflect"
	"runtime"

	"github.com/labstack/echo"
)

func OperatorLogger(handler echo.HandlerFunc, opts vo.LogRequestData) echo.HandlerFunc {
	return func(ctx echo.Context) error {
		ctx.Set(constant.CONTEXT_KEY_LOG, &opts)
		return handler(ctx)
	}
}

type GroupWithLog struct {
	*echo.Group
	Module uint
}

func (g *GroupWithLog) POSTWithLog(path string, handler echo.HandlerFunc, opType uint) {
	g.Group.POST(path, OperatorLogger(handler, vo.LogRequestData{
		Module: g.Module,
		OpType: opType,
		Func:   runtime.FuncForPC(reflect.ValueOf(handler).Pointer()).Name(),
	}))
}

func (g *GroupWithLog) GETWithLog(path string, handler echo.HandlerFunc, opType uint) {
	g.Group.GET(path, OperatorLogger(handler, vo.LogRequestData{
		Module: g.Module,
		OpType: opType,
		Func:   runtime.FuncForPC(reflect.ValueOf(handler).Pointer()).Name(),
	}))
}

func (g *GroupWithLog) WithModule(moduleName uint) *GroupWithLog {
	g.Module = moduleName
	return g
}
