package middlewares

import (
	"application/common/logger"
	"application/conf"
	"sync"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type Metrics struct {
	TotalDuration time.Duration
	RequestCount  int64
	Timestamps    []time.Time
	Mutex         sync.Mutex
}

var apiMetrics = make(map[string]*Metrics)
var metricsMutex sync.Mutex

func startMetricsLogger() {
	go func() {
		ticker := time.NewTicker(time.Duration(conf.Config().Echo.ApiMetricsReportInterval) * time.Second) // 确保间隔为 1 秒
		defer ticker.Stop()

		for range ticker.C {
			metricsMutex.Lock()
			for api, metric := range apiMetrics {
				metric.Mutex.Lock()

				now := time.Now()
				ago := now.Add(-time.Duration(conf.Config().Echo.ApiMetricsReportInterval) * time.Second)
				validTimestamps := make([]time.Time, 0, len(metric.Timestamps))

				for _, ts := range metric.Timestamps {
					if ts.After(ago) || ts.Equal(ago) {
						validTimestamps = append(validTimestamps, ts)
					}
				}

				qps := float64(len(validTimestamps)) / float64(conf.Config().Echo.ApiMetricsReportInterval)
				metric.Timestamps = validTimestamps

				averageDuration := time.Duration(0)
				if metric.RequestCount > 0 {
					averageDuration = metric.TotalDuration / time.Duration(metric.RequestCount)
				}

				logger.Log.Info("API Metrics",
					zap.String("API", api),
					zap.Float64("QPS", qps),
					zap.Int64("RequestCount", metric.RequestCount),
					zap.Duration("AverageResponseTime", averageDuration))

				metric.Mutex.Unlock()
			}
			metricsMutex.Unlock()
		}
	}()
}

func ApiStatisticMiddleware() echo.MiddlewareFunc {
	return func(handlerFunc echo.HandlerFunc) echo.HandlerFunc {
		return func(context echo.Context) error {
			startTime := time.Now()
			apiPath := context.Path()
			if apiPath == "" {
				apiPath = "unknown"
			}

			metricsMutex.Lock()
			if _, exists := apiMetrics[apiPath]; !exists {
				apiMetrics[apiPath] = &Metrics{}
			}
			metric := apiMetrics[apiPath]
			metricsMutex.Unlock()

			logger.Log.Debug("Middleware Activated", zap.String("Path", apiPath))

			err := handlerFunc(context)
			duration := time.Since(startTime)

			metric.Mutex.Lock()
			metric.TotalDuration += duration
			metric.RequestCount++
			metric.Timestamps = append(metric.Timestamps, time.Now())
			logger.Log.Debug("Timestamp Added", zap.String("API", apiPath), zap.Int("Total Timestamps", len(metric.Timestamps)))
			metric.Mutex.Unlock()

			return err
		}
	}
}

func ResetApiMetrics() {
	metricsMutex.Lock()
	defer metricsMutex.Unlock()
	apiMetrics = make(map[string]*Metrics)
}

func Init() {
	if conf.Config().Echo.ApiMetrics {
		startMetricsLogger()
	}
}
