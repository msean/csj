package middlewares

import (
	"application/common/logger"
	"application/constant"
	"application/models"
	"application/models/vo"
	"application/services"
	"application/utils"
	"bytes"
	"fmt"
	"io"
	"runtime/debug"
	"strings"

	"github.com/google/uuid"
	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
	"go.uber.org/zap"
)

var DefaultBodyDumpConfig = middleware.BodyDumpConfig{
	Skipper: BodyDumpDefaultSkipper,
	Handler: func(context echo.Context, bytes []byte, bytes2 []byte) {
		if !strings.HasPrefix(context.Path(), "/api/") && !strings.HasPrefix(context.Path(), "/openapi/") {
			return
		}
		uid := utils.GetContextUUID(context)

		logData := context.Get(constant.CONTEXT_KEY_LOG)
		if logData != nil {
			services.NewServiceLog(&context).Op(logData.(*vo.LogRequestData), string(bytes), string(bytes2))
		}

		logger.Log.Info("请求结束", zap.String("请求UID", uid), zap.String("请求IP", context.RealIP()))
	},
}

func BodyDumpDefaultSkipper(c echo.Context) bool {
	if !strings.HasPrefix(c.Path(), "/api/") && !strings.HasPrefix(c.Path(), "/openapi/") {
		return true
	}
	return false
}

func RequestLog() echo.MiddlewareFunc {
	return func(handlerFunc echo.HandlerFunc) echo.HandlerFunc {
		return func(context echo.Context) error {
			defer func() {
				if err := recover(); err != nil {
					fmt.Println("------ RequestLog-crash: err = ", err, string(debug.Stack()))

					// todo: test------------------------------------------------------------------------
					/*stack := make([]byte, 4<<10)
					length := runtime.Stack(stack, false)
					logger.Log.Error("system error", zap.String("崩溃日志", string(stack[:length])))*/
				}
			}()

			if !strings.HasPrefix(context.Path(), "/api/") && !strings.HasPrefix(context.Path(), "/openapi/") {
				logger.Log.Info("New Request", zap.Any(context.Request().RequestURI, "website request"))
				return handlerFunc(context)
			}

			uid := uuid.New().String()
			utils.SetContextUUID(context, uid)
			logger.Log.Info("New ApiRequest", zap.Any(context.Request().RequestURI, uid))
			err := handlerFunc(context)

			return err
		}
	}
}

func LoggerMiddleware() echo.MiddlewareFunc {
	return func(handlerFunc echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) (err error) {
			bean := &models.Adminlog{
				Method:    c.Request().Method,
				Url:       c.Request().RequestURI,
				Params:    "",
				Ip:        c.RealIP(),
				UserAgent: c.Request().UserAgent(),
			}
			if c.Request().Body != nil {
				all, _ := io.ReadAll(c.Request().Body)
				c.Request().Body = io.NopCloser(bytes.NewBuffer(all))
				bean.Params = string(all)
			}
			bean.CreateBy = utils.UserId(c)
			bean.UserName = utils.Username(c)
			go func() {
				services.AdminLogChan <- bean
			}()
			return handlerFunc(c)
		}
	}
}
