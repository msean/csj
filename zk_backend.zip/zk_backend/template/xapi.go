package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

// channelProduct pcode字段 作为话单有效时间
// channel的 Etctwo 作为 IsSlow字段 1 慢充 2 快充
// channel的 Etcone 作为 获取时间的时间戳的链接地址
// 话单有效时间（秒）如果传则按这个时间设置话单过期时间，如果不传则按照系统商户配置快慢单有效期设置过期时间

type (
	XApiTemplate struct {
		Base
	}
)

var _ TemplateInterface = new(XApiTemplate)

func NewXApiTemplate(base Base) (tml *XApiTemplate) {
	return &XApiTemplate{
		Base: base,
	}
}

// getSign 生成签名字符串
func (tml *XApiTemplate) sign(requestParams map[string]any, apiSecret string) string {
	var keys []string
	for key := range requestParams {
		keys = append(keys, key)
	}
	sort.Strings(keys)

	var strBuilder strings.Builder
	for _, key := range keys {
		value := requestParams[key]
		if value != nil {
			strBuilder.WriteString(fmt.Sprintf("%s=%v&", key, value))
		}
	}

	toSign := strBuilder.String() + "key=" + apiSecret

	md5Hash := md5.Sum([]byte(toSign))
	signResult := hex.EncodeToString(md5Hash[:])
	return signResult
}

// http://网关地址/api/createOrder

/*
90029 全国联通话费30元直充
90030 全国联通话费50元直充
90031 全国联通话费100元直充
90032 全国联通话费200元直充

全国移动，费率958
90012 全国移动话费30元直充
90013 全国移动话费50元直充
90014 全国移动话费100元直充
90015 全国移动话费200元直充
*/

func (tml *XApiTemplate) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	var err error
	defer func() {
		if err != nil {
			rsp.Err = err.Error()
		}
	}()
	loc, _ := time.LoadLocation("Asia/Shanghai")
	now := time.Now().In(loc)

	productID := tml.Base.option.Pcode
	if utils.IsBlankString(productID) {
		switch channelOrder.Isp {
		case int(constant.IspUniCom):
			switch channelOrder.FaceValue {
			case 30:
				productID = "90029"
			case 50:
				productID = "90030"
			case 100:
				productID = "90031"
			case 200:
				productID = "90032"
			}
		case int(constant.IspMobile):
			switch channelOrder.FaceValue {
			case 30:
				productID = "90012"
			case 50:
				productID = "90013"
			case 100:
				productID = "90014"
			case 200:
				productID = "90015"
			}
		}
	}

	if utils.IsBlankString(productID) {
		rsp.Err = "不支持的产品编码"
		return
	}

	params := map[string]string{
		"merchantid":      tml.channel.ApiID,
		"merchantorderid": tml.SetChannelOrderID(channelOrder),
		"productid":       productID,
		"phone":           channelOrder.Phone,
		"amount":          fmt.Sprintf("%d", channelOrder.FaceValue),
		"notifyUrl":       tml.channel.BackUrl,
		"timestamp":       fmt.Sprintf("%d", now.UnixNano()/int64(time.Millisecond)),
	}
	params["sign"] = tml.sign(map[string]any{
		"merchantid":      params["merchantid"],
		"merchantorderid": params["merchantorderid"],
		"productid":       params["productid"],
		"phone":           params["phone"],
		"amount":          params["amount"],
		"notifyUrl":       params["notifyUrl"],
		"timestamp":       params["timestamp"],
	}, tml.channel.ApiKey)

	logger.Log.Info("[XApiTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		// Data struct {
		// 	MerchantOrderid int `json:"merchantorderid"`
		// 	Orderid         int `json:"orderid"`
		// } `json:"data"`
	}{}
	if _, body, err = utils.NewRequest().PostForm().Params(params).Url(tml.channel.SubmitUrl).Do(); err != nil {
		return
	}
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	logger.Log.Info("[XApiTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("body", string(body)))

	if httpResult.Code == 0 {
		rsp.Code = constant.ChannelSubmitSuccess
	} else {
		rsp.Code = constant.ChannelSubmitFail
	}
	rsp.Err = httpResult.Msg
}

func (tml *XApiTemplate) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type CallBackRsp struct {
		MerchantID      int64  `json:"merchantid" form:"merchantid"`
		Orderid         int64  `json:"orderid" form:"orderid"`
		MerchantOrderID string `json:"merchantorderid" form:"merchantorderid"`
		Status          string `json:"status" form:"status"`
		Voucher         string `json:"voucher" form:"voucher"`
		Amount          string `json:"amount" form:"amount"`
		Sign            string `json:"sign" form:"sign"`
	}

	var callbackRsp CallBackRsp
	if err = ctx.Bind(&callbackRsp); err != nil {
		resp.Resp(ctx, false, 500, "参数错误:"+err.Error(), nil)
		return
	}

	_sign := tml.sign(map[string]any{
		"merchantid":      callbackRsp.MerchantID,
		"orderid":         callbackRsp.Orderid,
		"merchantorderid": callbackRsp.MerchantOrderID,
		"status":          callbackRsp.Status,
		"voucher":         callbackRsp.Voucher,
		"amount":          callbackRsp.Amount,
	}, tml.channel.ApiKey)

	logger.Log.Info("[XApiTemplate] [Callback]",
		zap.Any("rsp", callbackRsp),
		zap.Any("sign", tml.channel.ApiKey),
	)
	if _sign != callbackRsp.Sign {
		logger.Log.Error("[XApiTemplate] [Callback]", zap.Any("callback sign", callbackRsp), zap.String("_sign", _sign))
		resp.Resp(ctx, false, 500, "回调加密错误", nil)
		return
	}

	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callbackRsp.MerchantOrderID); err != nil {
		resp.Resp(ctx, false, 500, err.Error(), nil)
		return
	}

	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		resp.Resp(ctx, false, 500, "订单不存在", nil)
		return
	}

	rsp.Cert = callbackRsp.Voucher
	switch callbackRsp.Status {
	case "2":
		rsp.Status = constant.OrderQrySuccess
	case "9":
		rsp.Status = constant.OrderQryFail
	}
	resp.Resp(ctx, true, 200, "ok", nil)
	return
}

// http://网关地址/api/queryOrder
func (tml XApiTemplate) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	loc, _ := time.LoadLocation("Asia/Shanghai")
	now := time.Now().In(loc)

	params := map[string]string{
		"merchantid":      tml.channel.ApiID,
		"merchantorderid": tml.SetChannelOrderID(channelOrder),
		"timestamp":       fmt.Sprintf("%d", now.UnixNano()/int64(time.Millisecond)),
	}
	params["sign"] = tml.sign(map[string]any{
		"merchantid":      params["merchantid"],
		"merchantorderid": params["merchantorderid"],
		"timestamp":       params["timestamp"],
	}, tml.channel.ApiKey)

	var body []byte
	httpResult := struct {
		Code   int             `json:"code"`
		Msg    string          `json:"msg"`
		Result json.RawMessage `json:"data"`
	}{}

	data := struct {
		Status  int    `json:"status"`
		Voucher string `json:"voucher"`
	}{}

	if _, body, err = utils.NewRequest().Params(params).Url(tml.channel.QueryUrl).PostForm().Do(); err != nil {
		return
	}
	if err = json.Unmarshal(body, &httpResult); err != nil {
		logger.Log.Error("XApiTemplate QryOrder", zap.Error(err))
		return
	}

	if err = json.Unmarshal(httpResult.Result, &data); err != nil {
		logger.Log.Error("XApiTemplate QryOrder", zap.Error(err))
		return
	}
	rsp.Cert = data.Voucher

	switch data.Status {
	case 1:
		rsp.Status = constant.OrderQryHandle
	case 2:
		rsp.Status = constant.OrderQrySuccess
	case 9:
		rsp.Status = constant.OrderQryFail
	}
	return
}

func (tml *XApiTemplate) QryBalance() (result resp.ClientFinanceResult, err error) {
	loc, _ := time.LoadLocation("Asia/Shanghai")
	now := time.Now().In(loc)

	params := map[string]string{
		"merchantid": tml.channel.ApiID,
		"timestamp":  fmt.Sprintf("%d", now.UnixNano()/int64(time.Millisecond)),
	}
	params["sign"] = tml.sign(map[string]any{
		"merchantid":      params["merchantid"],
		"merchantorderid": params["merchantorderid"],
		"timestamp":       params["timestamp"],
	}, tml.channel.ApiKey)

	var body []byte
	httpResult := struct {
		Code int             `json:"code"`
		Msg  string          `json:"msg"`
		Data json.RawMessage `json:"data"`
	}{}

	data := struct {
		Balance     json.Number `json:"balance"`
		MerchantID  string      `json:"merchantid"`
		CreditLimit json.Number `json:"creditLimit"`
	}{}

	if _, body, err = utils.NewRequest().Params(params).Url(tml.channel.BalanceUrl).PostForm().Do(); err != nil {
		logger.Log.Error("XApiTemplate QryBalance", zap.Error(err))
		return
	}

	logger.Log.Info("[XApiTemplate QryBalance",
		zap.String("result", string(body)), zap.Error(err))

	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	if err = json.Unmarshal(httpResult.Data, &data); err != nil {
		logger.Log.Error("XApiTemplate QryBalance", zap.Error(err))
		return
	}

	balance, err := data.Balance.Float64()
	if err != nil {
		return result, fmt.Errorf("failed to parse balance: %v", err)
	}

	creditLimit, err := data.CreditLimit.Float64()
	if err != nil {
		logger.Log.Error("XApiTemplate QryBalance", zap.Error(err))
		return result, fmt.Errorf("failed to parse creditLimit: %v", err)
	}

	result.Amount = utils.FloatReserve(balance, 4)
	result.CreditAmount = utils.FloatReserve(creditLimit, 4)
	result.Msg = httpResult.Msg

	return
}

func (tml *XApiTemplate) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： SM",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：有",
	// }
	return `<p>模版： XAPI</p>
	<p>APPID(客户提供)：代理商编号</p>
	<p>APIKEY(客户提供)：密钥</p>
	<p>是否存存余额地址：有</p>`
}
