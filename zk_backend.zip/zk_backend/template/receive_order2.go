package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/labstack/echo"
	"github.com/tidwall/gjson"
	"go.uber.org/zap"
)

// 有凭证
type ReceiveOrder2Template struct {
	Base
}

var _ TemplateInterface = new(ReceiveOrder2Template)

func NewReceiveOrder2Tml(base Base) (tml *ReceiveOrder2Template) {
	return &ReceiveOrder2Template{
		Base: base,
	}
}

func (tml ReceiveOrder2Template) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	var ispType int
	switch channelOrder.Isp {
	case int(constant.IspMobile):
		ispType = 2
	case int(constant.IspUniCom):
		ispType = 1
	case int(constant.IspTelCom):
		ispType = 3
	}
	params := map[string]string{
		"partner_id":       tml.channel.ApiID,
		"partner_order_no": tml.SetChannelOrderID(channelOrder),
		"phone":            channelOrder.Phone,
		"amount":           utils.Violent2String(channelOrder.FaceValue * 100),
		"type":             utils.Violent2String(ispType),
		"notify_url":       tml.channel.BackUrl,
	}
	var info string
	info += fmt.Sprintf("%v", params["partner_id"])
	info += fmt.Sprintf("%v", params["partner_order_no"])
	info += fmt.Sprintf("%v", params["phone"])
	info += fmt.Sprintf("%v", params["amount"])
	info += fmt.Sprintf("%v", params["type"])
	info += fmt.Sprintf("%v", params["notify_url"])
	info += tml.channel.ApiKey

	hash := md5.New()
	hash.Write([]byte(info))
	params["sign"] = hex.EncodeToString(hash.Sum(nil))

	logger.Log.Info("[ReceiveOrder2Template] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var err error
	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
	}{}
	if _, body, err = utils.NewRequest().PostForm().Params(params).Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[ReceiveOrder2Template] [Submit]", zap.Error(err))
		rsp.Err = "提交异常:" + err.Error()
		return
	}

	logger.Log.Info("[ReceiveOrder2Template] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}

	switch httpResult.Code {
	case 1:
		rsp.Code = constant.ChannelSubmitSuccess
	default:
		rsp.Code = constant.ChannelSubmitFail
		rsp.Err = httpResult.Msg
	}
}

func (tml ReceiveOrder2Template) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type Callback struct {
		Status          string `json:"status" form:"status"`
		PartnerID       string `json:"partner_id" form:"partner_id"`
		PartnerOrderNo  string `json:"partner_order_no" form:"partner_order_no"`
		Phone           string `json:"phone" form:"phone"`
		Amount          int    `json:"amount" form:"amount"`
		Type            int    `json:"type" form:"type"`
		OfficialOrderNo string `json:"official_order_no" form:"official_order_no"`
		Sign            string `json:"sign" form:"sign"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[ReceiveCallback] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("ReceiveOrder2Template Receive callback",
		zap.Any("params", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.PartnerOrderNo); err != nil {
		logger.Log.Error("[ReceiveOrder2Template] [Callback]",
			zap.String("callback.OrderID", callback.PartnerOrderNo),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[AddSupplyNumberTemplate] [Callback]",
			zap.String("callback.OrderID", callback.PartnerOrderNo),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	var info string
	info += fmt.Sprintf("%v", callback.Status)
	info += fmt.Sprintf("%v", callback.PartnerID)
	info += fmt.Sprintf("%v", callback.PartnerOrderNo)
	info += fmt.Sprintf("%v", callback.Phone)
	info += fmt.Sprintf("%v", callback.Amount)
	info += fmt.Sprintf("%v", callback.Type)
	info += fmt.Sprintf("%v", callback.OfficialOrderNo)
	info += tml.channel.ApiKey

	hash := md5.New()
	hash.Write([]byte(info))
	sign := hex.EncodeToString(hash.Sum(nil))

	if sign != callback.Sign {
		err = fmt.Errorf("签名错误")
		logger.Log.Error("[QuotientTml] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.String("callback.OrderID", callback.PartnerOrderNo),
			zap.Error(err),
			zap.String("callback sign", callback.Sign),
			zap.String("selfSign", sign))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	rsp.Cert = callback.OfficialOrderNo
	switch callback.Status {
	case "-1":
		rsp.Status = constant.OrderReceiveCallbackFail
	case "1":
		rsp.Status = constant.OrderReceiveCallbackSuccess
	case "0":
		rsp.Status = constant.OrderReceiveCallbackNoCharge
	}
	resp.Resp(ctx, true, 200, "success", nil)
	return
}

func (tml ReceiveOrder2Template) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	params := map[string]string{
		"partner_id":       tml.channel.ApiID,
		"partner_order_no": tml.SetChannelOrderID(channelOrder),
	}

	var info strings.Builder
	info.WriteString(params["partner_id"])
	info.WriteString(params["partner_order_no"])
	info.WriteString(tml.channel.ApiKey)

	// 计算 MD5 签名
	hash := md5.Sum([]byte(info.String()))
	sign := hex.EncodeToString(hash[:])

	// 添加签名到参数
	params["sign"] = sign

	logger.Log.Info("[ReceiveOrder2Template] [QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var body []byte

	if _, body, err = utils.NewRequest().PostForm().Params(params).Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("[ReceiveOrder2Template] [QryOrder]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		return
	}

	logger.Log.Info("[ReceiveOrder2Template] [QryOrder] [result]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.String("apiKey", tml.channel.ApiKey))

	_body := string(body)
	code := gjson.Get(_body, "code").Int()
	switch code {
	case 1:
		_status := gjson.Get(_body, "data.status").Int()
		switch _status {
		case 1:
			rsp.Status = constant.OrderQrySuccess
		case -1:
			rsp.Status = constant.OrderQryFail
		case 0:
			rsp.Status = constant.OrderQryHandle
		}
	case 101:
		rsp.Status = constant.OrderQryParamsErr
	case 105:
		rsp.Status = constant.OrderQrySignErr
	}

	rsp.Cert = gjson.Get(_body, "official_order_no").String()
	rsp.ChannelMsg = gjson.Get(_body, "msg").String()
	return
}

func (tml ReceiveOrder2Template) QryBalance() (result resp.ClientFinanceResult, err error) {
	return
}

func (tml *ReceiveOrder2Template) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： ReceiveOrder2",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：无",
	// }
	return `<p>渠道简称: ReceiveOrder2</p>
<p>模版: receive_order_2</p>
<p>APPID(客户提供)：代理商编号</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：有</p>`
}
