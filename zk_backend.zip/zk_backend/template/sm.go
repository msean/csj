package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type SMTml struct {
	Base
}

var _ TemplateInterface = new(SMTml)

func NewM5Tml(base Base) (tml *SMTml) {
	return &SMTml{
		Base: base,
	}
}

func (tml SMTml) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	var apiID int
	var err error
	if err = utils.ConvertIntFromString(tml.channel.ApiID, &apiID); err != nil {
		return
	}

	params := map[string]string{
		"UserId":        utils.Violent2String(apiID),
		"UserOrderId":   tml.SetChannelOrderID(channelOrder),
		"ChargeAccount": channelOrder.Phone,
		"ProductType":   utils.Violent2String(1),
		"Parvalue":      utils.Violent2String(channelOrder.FaceValue),
		"IspType":       utils.Violent2String(channelOrder.Isp),
		"CallbackUrl":   tml.channel.BackUrl,
	}

	signStr := fmt.Sprintf(
		"UserId%vUserOrderId%vChargeAccount%vParvalue%vProductType%vCallbackUrl%v%v",
		params["UserId"],
		params["UserOrderId"],
		params["ChargeAccount"],
		params["Parvalue"],
		params["ProductType"],
		params["CallbackUrl"],
		tml.channel.ApiKey,
	)

	hasher := md5.New()
	hasher.Write([]byte(signStr))
	params["Sign"] = hex.EncodeToString(hasher.Sum(nil))
	logger.Log.Info("[SMTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", params),
		zap.String("apikey", tml.channel.ApiKey),
	)

	var body []byte
	httpResult := struct {
		Code string `json:"code"`
		Msg  string `json:"message"`
	}{}

	if _, body, err = utils.NewRequest().Params(params).PostForm().Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[SMTml Submit err]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		rsp.Err = "提交异常:" + err.Error()
		return
	}

	logger.Log.Info("[SMTml Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}

	switch httpResult.Code {
	case "0000":
		rsp.Code = constant.ChannelSubmitSuccess
	case "0001":
		rsp.Code = constant.ChannelSubmitOrderExist
	case "0002":
		rsp.Code = constant.ChannelSubmitProductUnExist
	case "0003":
		rsp.Code = constant.ChannelSubmitProductClose
	case "0004":
		rsp.Code = constant.ChannelSubmitBalanceInsufficient
	case "0005", "0006", "0007":
		rsp.Code = constant.ChannelSubmitParamsErr
	case "0008":
		rsp.Code = constant.ChannelSubmitCustomerErr
	case "0009":
		rsp.Code = constant.ChannelSubmitSignErr
	case "0011":
		rsp.Code = constant.ChannelSubmitIPUnbind
	case "0015":
		rsp.Code = constant.ChannelSubmitApiClose
	}
	rsp.Err = httpResult.Msg
}

func (tml SMTml) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type Callback struct {
		UserID      int    `json:"UserId" form:"UserId"`
		UserOrderID string `json:"UserOrderId" form:"UserOrderId"`
		OrderID     int    `json:"OrderId" form:"OrderId"`
		OrderStatus string `json:"Status" form:"Status"`
		ParValue    int    `json:"Parvalue" form:"Parvalue"`
		Sign        string `json:"sign" form:"sign"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[SMTml] [ReceiveCallback] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("SMTml Receive callback",
		zap.Any("callback", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.UserOrderID); err != nil {
		logger.Log.Error("[SMTml] [Callback]",
			zap.String("callback.OrderID", callback.UserOrderID),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[QuotientTml] [Callback]",
			zap.String("callback.OrderID", callback.UserOrderID),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	_sign := fmt.Sprintf("UserId%dUserOrderId%sOrderId%dStatus%sParvalue%d%s",
		callback.UserID,
		callback.UserOrderID,
		callback.OrderID,
		callback.OrderStatus,
		callback.ParValue,
		tml.channel.ApiKey,
	)

	if _sign != callback.Sign {
		resp.Fail(ctx, "签名错误")
		return
	}
	switch callback.OrderStatus {
	case "1":
		rsp.Status = constant.OrderReceiveCallbackSuccess
	case "2":
		rsp.Status = constant.OrderReceiveCallbackFail
	}
	resp.Resp(ctx, true, 200, "success", nil)
	return
}

func (tml SMTml) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	var apiID int
	if err = utils.ConvertIntFromString(tml.channel.ApiID, &apiID); err != nil {
		return
	}

	var body []byte
	httpResult := struct {
		Code string `json:"code"`
		Msg  string `json:"message"`
		Data struct {
			SupOrderID  string `json:"SupOrderId"`
			OrderStatus int    `json:"status"`
		} `json:"data"`
	}{}

	params := map[string]string{
		"UserId":      utils.Violent2String(apiID),
		"UserOrderId": tml.SetChannelOrderID(channelOrder),
	}
	_sign := fmt.Sprintf(
		"UserId%vUserOrderId%v%v",
		params["UserId"],
		params["UserOrderId"],
		tml.channel.ApiKey,
	)

	hasher := md5.New()
	hasher.Write([]byte(_sign))
	params["Sign"] = hex.EncodeToString(hasher.Sum(nil))
	logger.Log.Info("[SMTml] [QryOrder4]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params),
		zap.String("sign", _sign))
	if _, body, err = utils.NewRequest().Params(params).PostForm().Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("[SMTml] [QryOrder3]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		return
	}

	logger.Log.Info("[SMTml] [QryOrder4] [result]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))

	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	rsp.Cert = httpResult.Data.SupOrderID
	if httpResult.Code == "0000" {
		switch httpResult.Data.OrderStatus {
		case 0:
			rsp.Status = constant.OrderQryHandle
		case 1:
			rsp.Status = constant.OrderQrySuccess
		case 2:
			rsp.Status = constant.OrderQryFail
		}
	}
	rsp.ChannelMsg = httpResult.Msg
	return
}

func (tml SMTml) QryBalance() (result resp.ClientFinanceResult, err error) {
	var apiID int
	if err = utils.ConvertIntFromString(tml.channel.ApiID, &apiID); err != nil {
		return
	}
	params := map[string]string{
		"UserId": utils.Violent2String(apiID),
	}
	_sign := fmt.Sprintf(
		"UserId{%v}%v",
		params["UserId"],
		tml.channel.ApiKey,
	)
	hash := md5.Sum([]byte(_sign))
	params["sign"] = hex.EncodeToString(hash[:])

	var body []byte
	httpResult := struct {
		Code string `json:"code"`
		Msg  string `json:"message"`
		Data struct {
			Balance float64 `json:"balance"`
		} `json:"data"`
	}{}

	if _, body, err = utils.NewRequest().Params(params).PostForm().Url(tml.channel.BalanceUrl).Do(); err != nil {
		logger.Log.Error("[SMTml] [QryBalance]",
			zap.Any("params", params),
			zap.Error(err))
		return
	}

	logger.Log.Info("[SMTml] [QryBalance] [result]",
		zap.String("result", string(body)))

	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	if httpResult.Code == "0000" {
		result.Amount = httpResult.Data.Balance
	}
	result.Msg = httpResult.Msg
	return
}

func (tml *SMTml) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： SM",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：有",
	// }
	return `<p>渠道简称: SM</p>
<p>模版: sm</p>
<p>APPID(客户提供)：代理商编号</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：有</p>`
}

// func (tml SMTml) Submit(channelOrder models.ChannelOrder, rsp *resp.OrderSubmitResult) {
// 	var apiID int
// 	var err error
// 	if err = utils.ConvertIntFromString(tml.channel.ApiID, &apiID); err != nil {
// 		return
// 	}
// 	payload := map[string]any{
// 		"UserId":        apiID,
// 		"UserOrderId":   tml.SetChannelOrderID(channelOrder),
// 		"ChargeAccount": channelOrder.Phone,
// 		"ProductType":   1,
// 		"Parvalue":      channelOrder.FaceValue,
// 		"IspType":       channelOrder.Isp,
// 		"CallbackUrl":   tml.channel.BackUrl,
// 	}

// 	_sign := fmt.Sprintf(
// 		"UserId{%v}UserOrderId{%v}ChargeAccount{%v}Parvalue{%v}ProductType{%v}CallbackUrl{%v}%v",
// 		payload["UserId"],
// 		payload["UserOrderId"],
// 		payload["ChargeAccount"],
// 		payload["Parvalue"],
// 		payload["ProductType"],
// 		payload["CallbackUrl"],
// 		tml.channel.ApiKey,
// 	)
// 	hash := md5.Sum([]byte(_sign))
// 	payload["Sign"] = hex.EncodeToString(hash[:])
// 	logger.Log.Info("[SMTml] [Submit]",
// 		zap.Int64("channelOrderID", channelOrder.ID),
// 		zap.String("customerOrderID", channelOrder.CustomerOrderID),
// 		zap.Any("payload", payload))

// 	var payloadByte []byte
// 	if payloadByte, err = json.Marshal(payload); err != nil {
// 		logger.Log.Error("[SMTml] Submit json Marshal", zap.Error(err))
// 		rsp.Err = err.Error()
// 		return
// 	}

// 	var body []byte
// 	httpResult := struct {
// 		Code string `json:"code"`
// 		Msg  string `json:"message"`
// 	}{}
// 	spew.Dump(">>>>>>>>>>>>", string(payloadByte))
// 	spew.Dump(">>>>>>>>>>>>", tml.channel.SubmitUrl)
// 	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.SubmitUrl).Do(); err != nil {
// 		logger.Log.Error("[SMTml] [Submit]",
// 			zap.Int64("channelOrderID", channelOrder.ID),
// 			zap.String("customerOrderID", channelOrder.CustomerOrderID),
// 			zap.Error(err))
// 		rsp.Err = "提交异常:" + err.Error()
// 		return
// 	}

// 	logger.Log.Info("[SMTml] [Submit]",
// 		zap.Int64("channelOrderID", channelOrder.ID),
// 		zap.String("customerOrderID", channelOrder.CustomerOrderID),
// 		zap.String("result", string(body)))
// 	if err = json.Unmarshal(body, &httpResult); err != nil {
// 		rsp.Err = err.Error()
// 		return
// 	}

// 	switch httpResult.Code {
// 	case "0000":
// 		rsp.Code = constant.ChannelSubmitSuccess
// 	case "0001":
// 		rsp.Code = constant.ChannelSubmitOrderExist
// 	case "0002":
// 		rsp.Code = constant.ChannelSubmitOrderExist
// 	case "0003":
// 		rsp.Code = constant.ChannelSubmitProductClose
// 	case "0004":
// 		rsp.Code = constant.ChannelSubmitBalanceInsufficient
// 	case "0005", "0006", "0007":
// 		rsp.Code = constant.ChannelSubmitParamsErr
// 	case "0008":
// 		rsp.Code = constant.ChannelSubmitCustomerErr
// 	case "0009":
// 		rsp.Code = constant.ChannelSubmitSignErr
// 	case "0011":
// 		rsp.Code = constant.ChannelSubmitIPUnbind
// 	case "0015":
// 		rsp.Code = constant.ChannelSubmitApiClose
// 	}
// 	rsp.Err = httpResult.Msg
// }

// func (tml SMTml) QryOrder(channelOrder models.ChannelOrder) (status int, cert string, channelMsg string, err error) {
// 	var apiID int
// 	if err = utils.ConvertIntFromString(tml.channel.ApiID, &apiID); err != nil {
// 		return
// 	}
// 	payload := map[string]any{
// 		"UserId":      apiID,
// 		"UserOrderId": tml.SetChannelOrderID(channelOrder),
// 	}
// 	_sign := fmt.Sprintf(
// 		"UserId{%v}UserOrderId{%v}%v",
// 		payload["UserId"],
// 		payload["UserOrderId"],
// 		tml.channel.ApiKey,
// 	)
// 	hash := md5.Sum([]byte(_sign))
// 	payload["sign"] = hex.EncodeToString(hash[:])
// 	logger.Log.Info("[SMTml] [QryOrder]",
// 		zap.Int64("channelOrderID", channelOrder.ID),
// 		zap.String("customerOrderID", channelOrder.CustomerOrderID),
// 		zap.Any("payload", payload))

// 	var payloadByte []byte
// 	if payloadByte, err = json.Marshal(payload); err != nil {
// 		logger.Log.Error("SMTml Submit json Marshal", zap.Error(err))
// 		return
// 	}

// 	var body []byte
// 	httpResult := struct {
// 		Code string `json:"code"`
// 		Msg  string `json:"message"`
// 		Data struct {
// 			OrderStatus int `json:"status"`
// 		} `json:"data"`
// 	}{}
// 	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.QueryUrl).Do(); err != nil {
// 		logger.Log.Error("[SMTml] [Submit]",
// 			zap.Int64("channelOrderID", channelOrder.ID),
// 			zap.String("customerOrderID", channelOrder.CustomerOrderID),
// 			zap.Error(err))
// 		return
// 	}

// 	logger.Log.Info("[SMTml] [QryOrder] [result]",
// 		zap.Int64("channelOrderID", channelOrder.ID),
// 		zap.String("customerOrderID", channelOrder.CustomerOrderID),
// 		zap.String("result", string(body)))

// 	if err = json.Unmarshal(body, &httpResult); err != nil {
// 		return
// 	}

// 	if httpResult.Code == "0000" {
// 		switch httpResult.Data.OrderStatus {
// 		case 0:
// 			status = constant.OrderQryHandle
// 		case 1:
// 			status = constant.OrderQrySuccess
// 		case 2:
// 			status = constant.OrderQryFail
// 		}
// 	}
// 	channelMsg = httpResult.Msg
// 	return
// }
