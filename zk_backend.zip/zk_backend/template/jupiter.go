package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

// 有凭证
// 对应java Deer
type JupiterTml struct {
	Base
}

var _ TemplateInterface = new(JupiterTml)

func NewAddJupiterTml(base Base) (tml *JupiterTml) {
	return &JupiterTml{
		Base: base,
	}
}

func (tml JupiterTml) GetAreaCode(province, phone string) (code string, err error) {
	if province == "全国" {
		var areaSection models.AreaSection
		var has bool
		areaSection, has, err = mysql.AreaSection.Match(phone)
		if !has {
			err = fmt.Errorf("无法获取所在的地区")
		}
		if err != nil {
			return
		}
		province = areaSection.Province
	}
	areaCodeMapper := map[string]string{
		"北京市":    "110000",
		"天津市":    "120000",
		"河北省":    "130000",
		"山西省":    "140000",
		"内蒙古自治区": "150000",
		"辽宁省":    "210000",
		"吉林省":    "220000",
		"黑龙江省":   "230000",
		"上海市":    "310000",
		"江苏省":    "320000",
		"浙江省":    "330000",
		"安徽省":    "340000",
		"福建省":    "350000",
		"江西省":    "360000",
		"山东省":    "370000",
		"河南省":    "410000",
		"湖北省":    "420000",
		"湖南省":    "430000",
		"广东省":    "440000",
		"广西自治区":  "450000",
		"海南省":    "460000",
		"重庆市":    "500000",
		"四川省":    "510000",
		"贵州省":    "520000",
		"云南省":    "530000",
		"西藏自治区":  "540000",
		"陕西省":    "610000",
		"甘肃省":    "620000",
		"青海省":    "630000",
		"宁夏自治区":  "640000",
		"新疆自治区":  "650000",
	}
	for _province, _code := range areaCodeMapper {
		if strings.Contains(_province, province) {
			code = _code
			return
		}
	}
	return
}

func (tml JupiterTml) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	ispMapper := map[constant.Isp]string{
		constant.IspMobile: "cmcc",
		constant.IspUniCom: "cucc",
		constant.IspTelCom: "ctcc",
	}
	var carrierCode string
	var ok bool
	if carrierCode, ok = ispMapper[constant.Isp(channelOrder.Isp)]; !ok {
		rsp.Err = "不支持该运营商"
		return
	}
	var code string
	var err error
	if code, err = tml.GetAreaCode(channelOrder.Province, channelOrder.Phone); err != nil {
		rsp.Err = err.Error()
		return
	}

	payload := map[string]any{
		"version":      "1.0",
		"signType":     "md5",
		"reqTime":      utils.Violent2String(time.Now().UnixNano() / int64(time.Millisecond)),
		"appid":        tml.channel.ApiID,
		"phone":        channelOrder.Phone,
		"regionCode":   code,
		"chargeAmount": utils.Violent2String(channelOrder.FaceValue * 100),
		"carrierCode":  carrierCode,
		"mchBatchNo":   tml.SetChannelOrderID(channelOrder),
		"notifyUrl":    tml.channel.BackUrl,
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[JupiterTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("JupiterTml Submit json Marshal", zap.Error(err))
		rsp.Err = err.Error()
		return
	}

	var body []byte
	httpResult := struct {
		ResultCode string `json:"resultCode"`
		ResultMsg  string `json:"resultMsg"`
	}{}
	start := time.Now()
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[JupiterTml] [Submit]", zap.Error(err), zap.Duration("duration", time.Since(start)))
		rsp.Err = "提交异常:" + err.Error()
		return
	}
	logger.Log.Info("[JupiterTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.Duration("duration", time.Since(start)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}
	switch httpResult.ResultCode {
	case "0000":
		rsp.Code = int(constant.ChannelSubmitSuccess)
	default:
		rsp.Code = int(constant.ChannelSubmitFail)
		rsp.Err = httpResult.ResultMsg
	}
}

func (tml JupiterTml) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type Callback struct {
		MchBatchNo     string `json:"mchBatchNo" form:"mchBatchNo"`
		CarrierTradeNo string `json:"carrierTradeNo" form:"carrierTradeNo"`
		SystemBatchNo  string `json:"systemBatchNo" form:"systemBatchNo"`
		Appid          string `json:"appid" form:"appid"`
		ChargeTime     string `json:"chargeTime" form:"chargeTime"`
		Sign           string `json:"sign" form:"sign"`
		ChargeAmount   string `json:"chargeAmount" form:"chargeAmount"`
		ChargeStatus   string `json:"chargeStatus" form:"chargeStatus"`
		Timestamp      string `json:"timestamp" form:"timestamp"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[ReceiveCallback] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("JupiterTml Receive callback",
		zap.Any("params", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.MchBatchNo); err != nil {
		logger.Log.Error("[JupiterTml] [Callback]",
			zap.String("callback.OrderID", callback.MchBatchNo),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[JupiterTml] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.String("callback.OrderID", callback.MchBatchNo),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	signMapper := utils.StructToMap(callback)
	delete(signMapper, "sign")
	selfSign := tml.sign(signMapper, tml.channel.ApiKey)
	if selfSign != callback.Sign {
		err = fmt.Errorf("签名错误")
		logger.Log.Error("[JupiterTml] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.String("callback.OrderID", callback.MchBatchNo),
			zap.Error(err),
			zap.String("callback sign", callback.Sign),
			zap.String("selfSign", selfSign))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	switch callback.ChargeStatus {
	case "charge_success":
		rsp.Status = constant.OrderReceiveCallbackSuccess
		rsp.Cert = callback.CarrierTradeNo
	case "charge_fail":
		rsp.Status = constant.OrderReceiveCallbackFail
	case "charge_cancel":
		rsp.Status = constant.OrderReceiveCallbackFail
	}
	resp.Resp(ctx, true, 200, "success", nil)
	return
}

func (tml JupiterTml) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	payload := map[string]any{
		"version":    "1.0",
		"signType":   "md5",
		"reqTime":    utils.Violent2String(time.Now().UnixNano() / int64(time.Millisecond)),
		"appid":      tml.channel.ApiID,
		"mchBatchNo": tml.SetChannelOrderID(channelOrder),
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[JupiterTml] [QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("[JupiterTml] [Submit] json Marshal", zap.Error(err))
		return
	}

	var body []byte
	httpResult := struct {
		SystemBatchNo  string `json:"systemBatchNo"`
		MchBatchNo     string `json:"mchBatchNo"`
		CarrierTradeNo string `json:"carrierTradeNo"`
		ChargeStatus   string `json:"chargeStatus"`
		ResultCode     string `json:"resultCode"`
		ResultMsg      string `json:"resultMsg"`
	}{}
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("[JupiterTml] [Submit]", zap.Error(err))
		return
	}

	logger.Log.Info("[JupiterTml] [QryOrder] [result]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.String("apiKey", tml.channel.ApiKey))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	rsp.Cert = httpResult.CarrierTradeNo
	switch httpResult.ResultCode {
	case "0000":
		switch httpResult.ChargeStatus {
		case "wait_charge":
			rsp.Status = constant.OrderQryHandle
		case "charge_success":
			rsp.Status = constant.OrderQrySuccess
		case "charge_cancel":
			rsp.Status = constant.OrderQryCancel
		case "charge_fail":
			rsp.Status = constant.OrderQryFail
		}
	case "9993":
		rsp.Status = constant.OrderQryNoExist
	}
	return
}

func (tml JupiterTml) sign(params map[string]any, key string) string {
	if len(params) == 0 {
		return ""
	}

	keys := make([]string, 0, len(params))
	for key := range params {
		keys = append(keys, key)
	}
	sort.Strings(keys)

	var sb strings.Builder
	for _, key := range keys {
		value := params[key]
		sb.WriteString(fmt.Sprintf("%s=%v&", key, value))
	}
	sb.WriteString("key=" + key)

	signString := sb.String()
	hash := md5.Sum([]byte(signString))
	return hex.EncodeToString(hash[:])
}

// 无
func (tml JupiterTml) QryBalance() (result resp.ClientFinanceResult, err error) {
	return
}

func (tml *JupiterTml) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： Jupiter",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：无",
	// }
	return `<p>模版： Jupiter</p>
	<p>APPID(客户提供)：代理商编号</p>
	<p>APIKEY(客户提供)：密钥</p>
	<p>是否存存余额地址：无</p>	`
}
