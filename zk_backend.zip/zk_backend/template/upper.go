package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

// channelProduct pcode字段 作为话单有效时间
// channel的 Etctwo 作为 IsSlow字段 1 慢充 2 快充
// channel的 Etcone 作为 获取时间的时间戳的链接地址
// 话单有效时间（秒）如果传则按这个时间设置话单过期时间，如果不传则按照系统商户配置快慢单有效期设置过期时间

type (
	UpperTemplate struct {
		Base
	}
)

var _ TemplateInterface = new(UpperTemplate)

func NewUpperTemplate(base Base) (tml *UpperTemplate) {
	return &UpperTemplate{
		Base: base,
	}
}

// getSign 生成签名字符串
func (tml *UpperTemplate) sign(requestParams map[string]any, apiSecret string) string {
	var keys []string
	for key := range requestParams {
		keys = append(keys, key)
	}
	sort.Strings(keys)

	var strBuilder strings.Builder
	for _, key := range keys {
		value := requestParams[key]
		if value != nil {
			strBuilder.WriteString(fmt.Sprintf("%s=%v&", key, value))
		}
	}

	toSign := strBuilder.String() + "key=" + apiSecret

	md5Hash := md5.Sum([]byte(toSign))
	signResult := hex.EncodeToString(md5Hash[:])
	return signResult
}

func (tml *UpperTemplate) getTime() (t string) {
	t = fmt.Sprintf("%d", time.Now().Unix())
	_url := tml.channel.Etcone
	if !utils.IsValidURL(_url) {
		return
	}
	var body []byte
	var err error
	result := struct {
		Code   int `json:"code"`
		Result struct {
			Time int `json:"time"`
		} `json:"result"`
	}{}
	if _, body, err = utils.NewRequest().Get().Url(_url).Timeout(500 * time.Millisecond).Do(); err != nil {
		return
	}
	if err = json.Unmarshal(body, &result); err != nil {
		return
	}
	if result.Code == http.StatusOK {
		return fmt.Sprintf("%d", result.Result.Time)
	}
	return
}

func (tml *UpperTemplate) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	var err error
	defer func() {
		if err != nil {
			rsp.Err = err.Error()
		}
	}()
	isSlow := 2
	if _isSlow, _err := strconv.Atoi(tml.channel.Etctwo); _err == nil {
		isSlow = _isSlow
	}
	submitValidDuration := 180
	if _submitValidDuration, _err := strconv.Atoi(tml.option.Pcode); _err == nil {
		submitValidDuration = _submitValidDuration
	}
	params := map[string]string{
		"appId":        tml.channel.ApiID,
		"thirdOrderNo": tml.SetChannelOrderID(channelOrder),
		"time":         tml.getTime(),
		"operator":     fmt.Sprintf("%d", channelOrder.Isp),
		"amount":       fmt.Sprintf("%d", channelOrder.FaceValue),
		"phone":        channelOrder.Phone,
		"createdTime":  fmt.Sprintf("%d", time.Now().Unix()),
		"duration":     fmt.Sprintf("%d", submitValidDuration),
		"isSlow":       fmt.Sprintf("%d", isSlow),
	}
	params["_sign"] = tml.sign(map[string]any{
		"appId":        params["appId"],
		"thirdOrderNo": params["thirdOrderNo"],
		"time":         params["time"],
		"operator":     params["operator"],
		"amount":       params["amount"],
		"phone":        params["phone"],
		"createdTime":  params["createdTime"],
		"duration":     params["duration"],
		"isSlow":       params["isSlow"],
	}, tml.channel.ApiKey)

	logger.Log.Info("[UpperTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		// Result struct {
		// 	ThirdOrderNo int `json:"thirdOrderNo"`
		// } `json:"result"`
	}{}
	if _, body, err = utils.NewRequest().PostForm().Params(params).Url(tml.channel.SubmitUrl).Do(); err != nil {
		return
	}
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	logger.Log.Info("[UpperTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("body", string(body)))

	if httpResult.Code == http.StatusOK {
		rsp.Code = constant.ChannelSubmitSuccess
	}
	if httpResult.Code == http.StatusBadRequest {
		rsp.Code = constant.ChannelSubmitFail
		if httpResult.Msg == "号码在黑名单内" {
			rsp.Err = "400-->号码在黑名单内"
		}
	}
	rsp.Err = httpResult.Msg
}

func (tml *UpperTemplate) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type CallBackRsp struct {
		AppID          string `json:"appId" form:"appId"`
		ThirdOrderNo   string `json:"thirdOrderNo" form:"thirdOrderNo"`
		Sign           string `json:"_sign" form:"_sign"`
		Time           int    `json:"time" form:"time"`
		Amount         string `json:"amount" form:"amount"`
		CertNo         string `json:"certNo" form:"certNo"`
		QueryUrl       string `json:"queryUrl" form:"queryUrl"`
		RechargeStatus int    `json:"rechargeStatus" form:"rechargeStatus"` // 支付状态  2充值成功，3充值失败，4订单超时，5已取消
		Phone          string `json:"phone" form:"phone"`
	}

	var callbackRsp CallBackRsp
	if err = ctx.Bind(&callbackRsp); err != nil {
		resp.Resp(ctx, false, 500, "参数错误:"+err.Error(), nil)
		return
	}

	if callbackRsp.AppID != tml.channel.ApiID {
		logger.Log.Error("[UpperTemplate] [Callback]", zap.String("callback appid", callbackRsp.AppID), zap.String("tml.channel.ApiID", tml.channel.ApiID))
		resp.Resp(ctx, false, 500, "回调商户ID错误", nil)
		return
	}
	_sign := tml.sign(map[string]any{
		"appId":          callbackRsp.AppID,
		"thirdOrderNo":   callbackRsp.ThirdOrderNo,
		"time":           callbackRsp.Time,
		"amount":         callbackRsp.Amount,
		"certNo":         callbackRsp.CertNo,
		"queryUrl":       callbackRsp.QueryUrl,
		"rechargeStatus": callbackRsp.RechargeStatus,
		"phone":          callbackRsp.Phone,
	}, tml.channel.ApiKey)

	logger.Log.Info("[UpperTemplate] [Callback]",
		zap.Any("callback_rsp", callbackRsp),
		zap.Any("sign", tml.channel.ApiKey),
	)
	if _sign != callbackRsp.Sign {
		logger.Log.Error("[UpperTemplate] [Callback]", zap.Any("callback sign", callbackRsp), zap.String("_sign", _sign))
		resp.Resp(ctx, false, 500, "回调加密错误", nil)
		return
	}

	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callbackRsp.ThirdOrderNo); err != nil {
		resp.Resp(ctx, false, 500, err.Error(), nil)
		return
	}

	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		resp.Resp(ctx, false, 500, "订单不存在", nil)
		return
	}

	rsp.Cert = callbackRsp.CertNo
	switch callbackRsp.RechargeStatus {
	case 2:
		rsp.Status = constant.OrderReceiveCallbackSuccess
	case 3:
		rsp.Status = constant.OrderReceiveCallbackFail
	case 4:
		rsp.Status = constant.OrderReceiveCallbackTimeout
	case 5:
		rsp.Status = constant.OrderReceiveCallbackCancel
	default:
		rsp.Status = constant.OrderStatusManual
	}
	resp.Resp(ctx, true, 200, "ok", nil)
	return
}

func (tml UpperTemplate) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	params := map[string]string{
		"appId":        tml.channel.ApiID,
		"thirdOrderNo": tml.SetChannelOrderID(channelOrder),
		"time":         tml.getTime(),
	}
	params["_sign"] = tml.sign(map[string]any{
		"appId":        params["appId"],
		"thirdOrderNo": params["thirdOrderNo"],
		"time":         params["time"],
	}, tml.channel.ApiKey)

	var body []byte
	httpResult := struct {
		Code   int    `json:"code"`
		Msg    string `json:"msg"`
		Result struct {
			RechargeStatus int    `json:"rechargeStatus"`
			ThirdOrderNo   string `json:"thirdOrderNo"`
			CertNo         string `json:"certNo"`
		} `json:"result"`
	}{}
	if _, body, err = utils.NewRequest().Params(params).Url(tml.channel.QueryUrl).Get().Do(); err != nil {
		return
	}
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	rsp.Cert = httpResult.Result.CertNo
	switch httpResult.Result.RechargeStatus {
	case 0:
		rsp.Status = constant.OrderQryCreated
	case 1:
		rsp.Status = constant.OrderQryHandle
	case 2:
		rsp.Status = constant.OrderQrySuccess
	case 3:
		rsp.Status = constant.OrderQryFail
	case 4:
		rsp.Status = constant.OrderQryTimeout
	case 5:
		rsp.Status = constant.OrderQryCancel
	}
	return
}

// QryBalance  文档中没有查询余额接口
func (tml *UpperTemplate) QryBalance() (result resp.ClientFinanceResult, err error) {
	return
}

func (tml *UpperTemplate) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： Upper",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：无",
	// 	"备用2：配置是否是慢充订单 1 慢单 2快单，默认是2",
	// 	"产品编码：配置话单过期时间 单位 秒，默认 180 ",
	// }
	return `<p>渠道简称: Upper</p>
	<p>模版: upper</p>
	<p>APPID(客户提供)：代理商编号</p>
	<p>APIKEY(客户提供)：密钥</p>
	<p>是否存存余额地址：无</p>`
}
