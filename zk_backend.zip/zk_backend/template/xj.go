package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"encoding/json"
	"fmt"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type XjTemplate struct {
	Base
}

var _ TemplateInterface = new(XjTemplate)

func NewXjTemplate(base Base) (tml *XjTemplate) {
	return &XjTemplate{
		Base: base,
	}
}

func (tml XjTemplate) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	productType := 1
	if dict, _, _ := mysql.SysDict.DataByTypeAndValue(constant.SysBigTypeDictType, channelOrder.BigType); dict.ID != 0 {
		// 流量类型
		if dict.Label == "流量" {
			productType = 200
		}
	}

	var loc *time.Location
	var err error
	loc, err = time.LoadLocation("Asia/Shanghai")
	if err != nil {
		fmt.Println("Error loading location:", err)
		return
	}
	params := map[string]string{
		"szAgentId":     utils.Violent2String(tml.channel.ApiID),
		"szOrderId":     tml.SetChannelOrderID(channelOrder),
		"szPhoneNum":    channelOrder.Phone,
		"nMoney":        utils.Violent2String(channelOrder.FaceValue),
		"nSortType":     utils.Violent2String(channelOrder.Isp),
		"nProductType":  utils.Violent2String(productType),
		"nProductClass": utils.Violent2String(1),
		"szProductId":   channelOrder.ProductCode,
		"szTimeStamp":   time.Now().In(loc).Format("2006-01-02 15:04:05"),
		"szFormat":      "JSON",
		"szNotifyUrl":   tml.channel.BackUrl,
	}
	params["szVerifyString"] = utils.Md5KvArray([][2]any{
		{"szAgentId", params["szAgentId"]},
		{"szOrderId", params["szOrderId"]},
		{"szPhoneNum", params["szPhoneNum"]},
		{"nMoney", params["nMoney"]},
		{"nSortType", params["nSortType"]},
		{"nProductClass", params["nProductClass"]},
		{"nProductType", params["nProductType"]},
		{"szTimeStamp", params["szTimeStamp"]},
		{"szKey", tml.channel.ApiKey},
	}, "&")
	// spew.Dump(params)
	// todo 其他参数补充
	// if channelOrder.Isp == int(constant.IspPetro) {
	// 	params["thirdphone"] = channelOrder.ThirdPhone
	// }
	// if channelOrder.Isp == int(constant.IspStateGrid) || channelOrder.Isp == int(constant.IspSouthGrid) {

	// 	params["params"] = channelOrder.ThirdPhone
	// }
	var body []byte
	httpResult := struct {
		NRtn       int     `json:"nRtn"`
		SzOrderId  string  `json:"szOrderId"`
		FNBalance  float64 `json:"fNBalance"`
		FSalePrice float64 `json:"fSalePrice"`
		SzRtnCode  string  `json:"szRtnCode"`
	}{}

	if _, body, err = utils.NewRequest().Params(params).PostForm().Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[XjTemplate] [Submit]",
			zap.Error(err),
			zap.Any("params", params))
		rsp.Err = err.Error()
		return
	}

	logger.Log.Info("[XjTemplate] [Submit]",
		zap.String("result", string(body)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}

	if httpResult.NRtn == 0 {
		rsp.Code = constant.ChannelSubmitSuccess
	}

	rsp.Err = fmt.Errorf("%s", httpResult.SzRtnCode).Error()
}

func (tml XjTemplate) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	var callback resp.CallBack
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[XjTemplate] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("ReceiveCallback", zap.Any("callback", callback))
	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.OrderID); err != nil {
		logger.Log.Error("[XjTemplate] [Callback]", zap.String("callback.OrderID", callback.OrderID), zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[XjTemplate] [Callback]", zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("XjTemplate Receive callback",
		zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
		zap.Int("callback code", callback.Code))

	switch callback.Code {
	case 2:
		rsp.Status = constant.OrderReceiveCallbackSuccess
	case 3:
		rsp.Status = constant.OrderReceiveCallbackFail
	}
	rsp.Cert = callback.Msg
	resp.Resp(ctx, true, 200, "ok", nil)
	return
}

func (tml XjTemplate) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {

	params := map[string]string{
		"szAgentId": utils.Violent2String(tml.channel.ApiID),
		"szOrderId": tml.SetChannelOrderID(channelOrder),
		"szFormat":  "JSON",
	}
	params["szVerifyString"] = utils.Md5KvArray([][2]any{
		{"szAgentId", params["szAgentId"]},
		{"szOrderId", params["szOrderId"]},
		{"szKey", tml.channel.ApiKey},
	}, "&")

	var body []byte
	httpResult := struct {
		NRtn       int     `json:"nRtn"`
		SzOrderId  string  `json:"szOrderId"`
		FSalePrice float64 `json:"fSalePrice"`
		SzRtnCode  string  `json:"szRtnCode"`
		SzRtnMsg   string  `json:"szRtnMsg"`
	}{}
	if _, body, err = utils.NewRequest().Params(params).PostForm().Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("[XjTemplate] [QryOrder]",
			zap.Any("params", params),
			zap.String("url", tml.channel.QueryUrl),
			zap.Int64("channel_order_id", channelOrder.ID),
			zap.Int64("order_id", channelOrder.OrderID),
			zap.String("customer_order_id", channelOrder.CustomerOrderID),
			zap.Error(err))
		return
	}

	logger.Log.Info("[XjTemplate] [QryOrder] [result]",
		zap.String("result", string(body)),
		zap.Any("params", params),
		zap.String("CustomerOrderID", channelOrder.CustomerOrderID),
	)
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	switch httpResult.NRtn {
	case 5001:
		rsp.Status = constant.OrderQryApiClose
	case 5002:
		rsp.Status = constant.OrderQryApiFrequency
	case 5003:
		rsp.Status = constant.OrderQryParamsErr
	case 5004:
		rsp.Status = constant.OrderQrySignErr
	case 5011:
		rsp.Status = constant.OrderQryHandle
	case 5012:
		rsp.Status = constant.OrderQrySuccess
	case 5013:
		rsp.Status = constant.OrderQryFail
	case 5019:
		rsp.Status = constant.OrderQryHandle
	case 999:
		rsp.Status = constant.OrderQryApiException
	case 5005:
		rsp.Status = constant.OrderQryNoExist
	}
	rsp.Cert = httpResult.SzRtnMsg
	rsp.ChannelMsg = httpResult.SzRtnCode
	return
}

func (tml *XjTemplate) QryBalance() (result resp.ClientFinanceResult, err error) {
	params := map[string]string{
		"szAgentId": utils.Violent2String(tml.channel.ApiID),
		"szFormat":  "JSON",
	}
	params["szVerifyString"] = utils.Md5KvArray([][2]any{
		{"szAgentId", params["szAgentId"]},
		{"szKey", tml.channel.ApiKey},
	}, "&")

	httpResult := struct {
		NRtn      int     `json:"nRtn"`
		FBalance  float64 `json:"fBalance"`
		FCredit   float64 `json:"fCredit"`
		SzRtnCode string  `json:"szRtnCode"`
	}{}

	var body []byte
	if _, body, err = utils.NewRequest().Params(params).PostForm().Url(tml.channel.BalanceUrl).Do(); err != nil {
		logger.Log.Error("[XjTemplate] [QryBalance]",
			zap.Any("params", params),
			zap.String("url", tml.channel.BalanceUrl),
			zap.Int64("channel_id", tml.channel.ID),
			zap.Error(err))
		return
	}

	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	logger.Log.Info("[XjTemplate] [QryBalance]",
		zap.Any("result", httpResult),
		zap.Int64("channel_id", tml.channel.ID),
	)
	switch httpResult.NRtn {
	case 0:
		result.Status = constant.BalanceQrySuccess
		result.Amount = httpResult.FBalance
		result.CreditAmount = httpResult.FCredit
	case 1:
		result.Status = constant.BalanceQryException
		result.Msg = httpResult.SzRtnCode
	case 5002:
		result.Status = constant.BalanceQryFrequency
		result.Msg = httpResult.SzRtnCode
	case 999:
		result.Status = constant.BalanceQrySystemErr
		result.Msg = httpResult.SzRtnCode
	default:
		result.Status = constant.BalanceQryException
		result.Msg = httpResult.SzRtnCode
	}
	return
}

func (tml *XjTemplate) DefaultConfigDescribe() string {
	return `<p>渠道简称: Xuanjie</p>
<p>模版: xj_v1</p>
<p>APPID(客户提供)：代理商编号</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：有</p>`
}
