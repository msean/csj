package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

// 有凭证
// 已经调试 ok

type AddSupplyNumberTemplate struct {
	Base
}

var _ TemplateInterface = new(AddSupplyNumberTemplate)

func NewAddSupplyNumberTemplate(base Base) (tml *AddSupplyNumberTemplate) {
	return &AddSupplyNumberTemplate{
		Base: base,
	}
}

func (tml AddSupplyNumberTemplate) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	var mchID int
	var err error
	if mchID, err = strconv.Atoi(tml.channel.ApiID); err != nil {
		logger.Log.Error("AddSupplyNumberTemplate Submit ApiID", zap.String("ApiID", tml.channel.ApiID), zap.Error(err))
		rsp.Err = err.Error()
		return
	}
	var ispType int
	switch channelOrder.Isp {
	case int(constant.IspMobile):
		ispType = 2
	case int(constant.IspTelCom):
		ispType = 1
	case int(constant.IspUniCom):
		ispType = 3
	}
	payload := map[string]any{
		"mchId":      mchID,
		"mchOrderNo": tml.SetChannelOrderID(channelOrder),
		"number":     channelOrder.Phone,
		"amount":     channelOrder.FaceValue * 100,
		"operator":   ispType,
		"notifyUrl":  tml.channel.BackUrl,
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[AddSupplyNumberTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("AddSupplyNumberTemplate Submit json Marshal", zap.Error(err))
		rsp.Err = err.Error()
		return
	}

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
	}{}
	var httpStatusCode int
	start := time.Now()
	if httpStatusCode, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[AddSupplyNumberTemplate] [Submit]", zap.Error(err), zap.Duration("duration", time.Since(start)))
		rsp.Err = "提交异常:" + err.Error()
		return
	}
	logger.Log.Info("[AddSupplyNumberTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.Duration("duration", time.Since(start)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}

	if httpStatusCode == 200 {
		if httpResult.Code == 0 {
			rsp.Code = int(constant.ChannelSubmitSuccess)
		} else {
			rsp.Code = int(constant.ChannelSubmitFail)
			rsp.Err = httpResult.Msg
		}
	} else {
		rsp.Err = "提交异常:" + utils.Violent2String(httpStatusCode)
	}
}

// /api/notify/16?amount=1000&mchId=250119&mchOrderNo=00056-12781-00016&mobile=&sign=01FD50D62052570A49A264E7241BBD5A&paymentUrl=&operator=2&number=15112534872&thirdOrderNo=&directStatus=2": "b516786f-f996-4da7-8f49-5b01292580ec
func (tml AddSupplyNumberTemplate) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	params := map[string]string{}
	ctx.Request().ParseForm()
	for key, values := range ctx.Request().Form {
		if len(values) > 0 {
			params[key] = values[0]
		}
	}

	mchOrderNo := params["mchOrderNo"]
	directStatus := params["directStatus"]
	paymentUrl := params["paymentUrl"]
	thirdOrderNo := params["thirdOrderNo"]
	sign := params["sign"]

	if paymentUrl != "" && !strings.Contains(paymentUrl, "%3A%2F%2F") {
		encodedUrl := url.QueryEscape(paymentUrl)
		params["paymentUrl"] = encodedUrl
	}

	reqSign := getSign(params, tml.channel.ApiKey)

	if reqSign != strings.ToUpper(sign) {
		err = fmt.Errorf("签名错误")
		logger.Log.Error("[QuotientTml] [Callback]",
			zap.String("callback.OrderID", mchOrderNo),
			zap.Error(err),
			zap.String("callback sign", sign),
			zap.String("selfSign", reqSign))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(mchOrderNo); err != nil {
		logger.Log.Error("[AddSupplyNumberTemplate] [Callback]",
			zap.String("callback.OrderID", mchOrderNo),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}
	var has bool

	session := daos.Mysql.NewSession()
	defer session.Close()
	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[AddSupplyNumberTemplate] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.Int64("callback.OrderID", channelOrderID),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	var callbackStatus int
	if err = utils.ConvertIntFromString(directStatus, &callbackStatus); err != nil {
		resp.Resp(ctx, false, 500, "fail", err)
		return
	}
	switch callbackStatus {
	case 0:
		rsp.Status = constant.OrderReceiveCallbackCreated
	case 1:
		rsp.Status = constant.OrderReceiveCallbackCreated
	case 2:
		rsp.Status = constant.OrderReceiveCallbackFail
	case 4:
		rsp.Status = constant.OrderReceiveCallbackHandle
	case 5:
		rsp.Status = constant.OrderReceiveCallbackSuccess
	case 9:
		rsp.Status = constant.OrderReceiveCallbackWaitCheck
	}
	rsp.Cert = thirdOrderNo
	// resp.Resp(ctx, true, 0, mchOrderNo, nil)
	ctx.String(http.StatusOK, "success")
	return
}

func getSign(params map[string]string, apiSecret string) string {
	keys := make([]string, 0, len(params))
	for key := range params {
		if key == "sign" {
			continue
		}
		keys = append(keys, key)
	}
	sort.Strings(keys)

	var preSignStr strings.Builder
	for _, key := range keys {
		value := params[key]
		if value != "" {
			preSignStr.WriteString(fmt.Sprintf("%s=%s&", key, value))
		}
	}
	preSignStr.WriteString(fmt.Sprintf("key=%s", apiSecret))

	sign := strings.ToUpper(fmt.Sprintf("%x", md5.Sum([]byte(preSignStr.String()))))
	return sign
}

func (tml AddSupplyNumberTemplate) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	var mchID int
	if mchID, err = strconv.Atoi(tml.channel.ApiID); err != nil {
		logger.Log.Error("AddSupplyNumberTemplate Submit ApiID", zap.String("ApiID", tml.channel.ApiID), zap.Error(err))
		return
	}
	payload := map[string]any{
		"mchId":      mchID,
		"mchOrderNo": tml.SetChannelOrderID(channelOrder),
		"timestamp":  time.Now().UnixMilli(),
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[AddSupplyNumberTemplate] [QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("AddSupplyNumberTemplate Submit json Marshal", zap.Error(err))
		return
	}

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		Data struct {
			PaymentUrl   string `json:"paymentUrl"`
			ThirdOrderNo string `json:"thirdOrderNo"`
			DirectStatus int    `json:"directStatus"`
		} `json:"data"`
	}{}
	var httpStatusCode int
	if httpStatusCode, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("[AddSupplyNumberTemplate] [Submit]", zap.Error(err))
		return
	}

	logger.Log.Info("[AddSupplyNumberTemplate] [QryOrder] [result]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.String("apiKey", tml.channel.ApiKey))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	if httpStatusCode == 200 {
		switch httpResult.Code {
		case 0:
			switch httpResult.Data.DirectStatus {
			case 0: // 订单生成
				rsp.Status = constant.OrderQryCreated
			case 1: // 等待充值
				rsp.Status = constant.OrderQryWaiting
			case 2: // 充值失败
				rsp.Status = constant.OrderQryFail
			case 4: // 充值中
				rsp.Status = constant.OrderQryHandle
			case 5: // 充值成功
				rsp.Status = constant.OrderQrySuccess
			case 9: // 待检测
				rsp.Status = constant.OrderQryWaitCheck
			}
		case 80011:
			rsp.Status = constant.OrderQryNoExist
		case 80001:
			rsp.Status = constant.OrderQryCustomerNotExist
		}
		rsp.ChannelMsg = httpResult.Msg
	} else {
		logger.Log.Info("[AddSupplyNumberTemplate] [QryOrder] [result]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Int("httpStatusCode", httpStatusCode))
	}
	return
}

func (tml AddSupplyNumberTemplate) sign(params map[string]any, key string) string {
	keys := make([]string, 0, len(params))
	for k := range params {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	var sb strings.Builder
	for _, k := range keys {
		value := params[k]
		if value == nil {
			sb.WriteString(fmt.Sprintf("%s=&", k))
		} else {
			sb.WriteString(fmt.Sprintf("%s=%v&", k, value))
		}
	}

	sb.WriteString(fmt.Sprintf("key=%s", key))

	hash := md5.New()
	hash.Write([]byte(sb.String()))
	return hex.EncodeToString(hash.Sum(nil))
}

func (tml AddSupplyNumberTemplate) QryBalance() (result resp.ClientFinanceResult, err error) {
	return
}

func (tml *AddSupplyNumberTemplate) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： AddsupplyNumber",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：无",
	// }
	return `<p>渠道简称: AddsupplyNumber</p>
<p>模版: add_supply_number</p>
<p>APPID(客户提供)：代理商编号</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：无</p>`
}
