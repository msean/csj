package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"strings"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type MobileMerchantTml struct {
	Base
}

var _ TemplateInterface = new(MobileMerchantTml)

func NewMobileMerchantTml(base Base) (tml *MobileMerchantTml) {
	return &MobileMerchantTml{
		Base: base,
	}
}

func (tml MobileMerchantTml) sign(params map[string]string, key string) string {
	keys := make([]string, 0, len(params))
	for k, v := range params {
		if v != "" {
			keys = append(keys, k)
		}
	}

	sort.Strings(keys)

	var sb strings.Builder
	for _, k := range keys {
		sb.WriteString(fmt.Sprintf("%s=%s&", k, params[k]))
	}

	sb.WriteString(fmt.Sprintf("key=%s", key))

	hash := md5.New()
	hash.Write([]byte(sb.String()))
	signValue := strings.ToUpper(hex.EncodeToString(hash.Sum(nil)))

	return signValue
}

func (tml MobileMerchantTml) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	_type := 1
	if tml.channel.Etcone == "慢充" {
		_type = 0
	}
	params := map[string]string{
		"merchant_name":   utils.Violent2String(tml.channel.ApiID),
		"order_no":        tml.SetChannelOrderID(channelOrder),
		"mobile_phone":    channelOrder.Phone,
		"recharge_amount": fmt.Sprintf("%d", channelOrder.FaceValue),
		"type":            utils.Violent2String(_type),
	}
	params["sign"] = tml.sign(params, tml.channel.ApiKey)

	logger.Log.Info("[MobileMerchantTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var body []byte
	httpResult := struct {
		Status string `json:"status"`
		Msg    string `json:"message"`
	}{}
	var err error
	if _, body, err = utils.NewRequest().PostForm().Params(params).Url(tml.channel.SubmitUrl).Do(); err != nil {
		return
	}
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}
	switch httpResult.Status {
	case "success":
		rsp.Code = int(constant.ChannelSubmitSuccess)
	default:
		rsp.Err = httpResult.Msg
		rsp.Code = int(constant.ChannelSubmitFail)
	}
}

func (tml MobileMerchantTml) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type Callback struct {
		Status         string `json:"status" form:"status"`
		OrderNo        string `json:"order_no" form:"order_no"`
		SystemName     string `json:"system_name" form:"system_name"`
		MobilePhone    string `json:"mobile_phone" form:"mobile_phone"`
		RechargeAmount string `json:"recharge_amount" form:"recharge_amount"`
		TradeNo        string `json:"trade_no" form:"trade_no"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Error("MobileMerchantTml Callback", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("MobileMerchantTml Callback", zap.Any("params", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.OrderNo); err != nil {
		logger.Log.Error("MobileMerchantTml Callback",
			zap.String("callback.OrderID", callback.OrderNo),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[MobileMerchantTml] [Callback]",
			zap.String("callback.OrderID", callback.OrderNo),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	switch callback.Status {
	case "success":
		rsp.Status = int(constant.ChannelSubmitSuccess)
		rsp.Cert = callback.TradeNo
	default:
		rsp.Status = int(constant.ChannelSubmitFail)
	}
	return
}

func (tml MobileMerchantTml) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	params := map[string]string{
		"merchant_name": tml.channel.ApiID,
		"order_no":      tml.SetChannelOrderID(channelOrder),
	}
	params["sign"] = tml.sign(params, tml.channel.ApiKey)

	logger.Log.Info("MobileMerchantTml QryOrder",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.Int64("OrderID", channelOrder.OrderID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var body []byte
	httpResult := struct {
		Status  string `json:"status"`
		Message string `json:"message"`
		Data    struct {
			Status     string `json:"status"`
			SystemName string `json:"system_name"`
			TradeNo    string `json:"trade_no"`
		} `json:"data"`
	}{}
	if _, body, err = utils.NewRequest().PostForm().Params(params).Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("MobileMerchantTml QryOrder", zap.Error(err))
		return
	}
	logger.Log.Info("MobileMerchantTml QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))

	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	if httpResult.Status == "success" {
		switch httpResult.Data.Status {
		case "已充值":
			rsp.Status = constant.OrderQrySuccess
			rsp.Cert = httpResult.Data.TradeNo
		case "已作废":
			rsp.Status = constant.OrderQryFail
		case "待充值":
			rsp.Status = constant.OrderQryHandle
		}
	} else {
		rsp.Status = constant.OrderQryHandle
		rsp.ChannelMsg = httpResult.Message
	}
	return
}

func (tml MobileMerchantTml) QryBalance() (result resp.ClientFinanceResult, err error) { return }

func (tml MobileMerchantTml) DefaultConfigDescribe() string {
	return `<p>渠道简称: MobileMerchant</p>
<p>模版: mobile_merchant</p>
<p>APPID(客户提供)：话商账号名「登录系统的用户名」</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：无</p>`
}
