package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/xml"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type DuXingTemplate struct {
	Base
}

var _ TemplateInterface = new(DuXingTemplate)

func NewDuXingTemplate(base Base) (tml *DuXingTemplate) {
	return &DuXingTemplate{
		Base: base,
	}
}

func (tml DuXingTemplate) sign(params [][2]string, apiKey string) string {

	var builder strings.Builder
	for i, pairs := range params {
		builder.WriteString(fmt.Sprintf("%s=%s", pairs[0], pairs[1]))
		if i < len(params)-1 {
			builder.WriteString("&")
		}
	}

	builder.WriteString("&key=")
	builder.WriteString(apiKey)

	hash := md5.Sum([]byte(builder.String()))
	return strings.ToUpper(hex.EncodeToString(hash[:])) // 转大写以匹配 Java `toUpperCase()`
}

// http://平台服务地址:9086/onlinepay.do
func (tml DuXingTemplate) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	isp := "yd"
	switch channelOrder.Isp {
	case int(constant.IspUniCom):
		isp = "lt"
	case int(constant.IspTelCom):
		isp = "dx"
	}
	productid := tml.Base.option.Pcode
	if utils.IsBlankString(productid) {
		switch isp {
		case "yd":
			switch channelOrder.FaceValue {
			case 50:
				productid = "101688"
			case 100:
				productid = "101689"
			case 200:
				productid = "101690"
			}
		case "lt":
			switch channelOrder.FaceValue {
			case 30:
				productid = "101705"
			case 50:
				productid = "101706"
			case 100:
				productid = "101707"
			case 200:
				productid = "101708"
			}
		}
	}
	params := map[string]string{
		"userid":      tml.channel.ApiID,
		"productid":   tml.Base.option.Pcode,
		"price":       utils.Violent2String(channelOrder.FaceValue),
		"num":         utils.Violent2String(1),
		"mobile":      channelOrder.Phone,
		"spordertime": time.Now().Format("20060102150405"),
		"sporderid":   tml.SetChannelOrderID(channelOrder),
	}
	sign := tml.sign([][2]string{
		{"userid", params["userid"]},
		{"productid", params["productid"]},
		{"price", params["price"]},
		{"num", params["num"]},
		{"mobile", params["mobile"]},
		{"spordertime", params["spordertime"]},
		{"sporderid", params["sporderid"]},
	}, tml.channel.ApiKey)
	params["sign"] = sign
	params["back_url"] = tml.channel.BackUrl
	params["paytype"] = isp
	params["gascardtel"] = ""
	params["gascardname"] = ""

	logger.Log.Info("[DuXingTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var err error
	var body []byte
	httpResult := struct {
		XMLName            xml.Name `xml:"order"`
		OrderID            string   `xml:"orderid"`
		ProductID          string   `xml:"productid"`
		Num                string   `xml:"num"`
		OrderCash          float64  `xml:"ordercash"`
		ProductName        string   `xml:"productname"`
		SpOrderID          string   `xml:"sporderid"`
		Mobile             string   `xml:"mobile"`
		MerchantSubmitTime string   `xml:"merchantsubmittime"`
		ResultNo           string   `xml:"resultno"`
		Remark1            string   `xml:"remark1"`
		FundBalance        string   `xml:"fundbalance"`
	}{}
	start := time.Now()
	if _, body, err = utils.NewRequest().PostForm().Params(params).Encoding(utils.EncodingGB2312).Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[ReceiveOrder2Template] [Submit]", zap.Error(err))
		rsp.Err = "提交异常:" + err.Error()
		return
	}
	logger.Log.Info("[DuXingTemplate] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.Duration("duration", time.Since(start)))

	if err := utils.ParseXML(body, &httpResult); err != nil {
		logger.Log.Error("[DuXingTemplate] [Submit] XML解析失败", zap.Error(err))
		rsp.Err = "解析失败:" + err.Error()
		return
	}

	if (httpResult.ResultNo == "0" || httpResult.ResultNo == "2") && httpResult.OrderID == "" {
		httpResult.ResultNo = "9999"
	}

	switch httpResult.ResultNo {
	case "0", "2": // 提交成功
		rsp.Code = int(constant.ChannelSubmitSuccess)
	case "5001":
		rsp.Err = "代理商不存在"
		rsp.Code = constant.ChannelSubmitFail
	case "5002":
		rsp.Err = "代理商余额不足"
		rsp.Code = constant.ChannelSubmitFail
	case "5003":
		rsp.Err = "此商品暂时不可购买"
		rsp.Code = constant.ChannelSubmitFail
	case "5004":
		rsp.Err = "充值号码与所选商品不符"
		rsp.Code = constant.ChannelSubmitFail
	case "5005":
		rsp.Err = "充值请求验证错误"
		rsp.Code = constant.ChannelSubmitFail
	case "5006":
		rsp.Err = "代理商订单号重复"
		rsp.Code = constant.ChannelSubmitFail
	case "5009":
		rsp.Err = "IP不符"
		rsp.Code = constant.ChannelSubmitFail
	case "5010":
		rsp.Err = "商品编号与充值金额不符"
		rsp.Code = constant.ChannelSubmitFail
	case "5011":
		rsp.Err = "商品数量不支持"
		rsp.Code = constant.ChannelSubmitFail
	case "5012":
		rsp.Err = "缺少必要参数或参数值不合法"
		rsp.Code = constant.ChannelSubmitFail
	case "7001":
		rsp.Err = "充值中订单数量超限"
		rsp.Code = constant.ChannelSubmitFail
	case "9999":
		rsp.Err = "未知错误,提交平台技术判定"
		rsp.Code = constant.ChannelSubmitFail
	default:
		rsp.Code = constant.ChannelSubmitFail
		rsp.Err = httpResult.Remark1
	}
	return
}

func (tml DuXingTemplate) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type Callback struct {
		UserID             string `json:"userid" form:"userid"`
		OrderID            string `json:"orderId" form:"orderId"`
		SporderID          string `json:"sporderid" form:"sporderid"`
		MerchantSubmitTime string `json:"merchantsubmittime" form:"merchantsubmittime"`
		ResultNo           string `json:"resultno" form:"resultno"`
		Sign               string `json:"sign" form:"sign"`
		ParValue           string `json:"parvalue" form:"parvalue"`
		FundBalance        string `json:"fundbalance" form:"fundbalance"`
		Remark1            string `json:"remark1" form:"remark1"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[DuXingTemplate] [ReceiveCallback] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("DuXingTemplate Receive callback", zap.Any("params", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.SporderID); err != nil {
		logger.Log.Error("[DuXingTemplate] [Callback]",
			zap.String("callback.OrderID", callback.SporderID),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[DuXingTemplate] [Callback]",
			zap.String("callback.OrderID", callback.OrderID),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	selfSign := tml.sign([][2]string{
		{"userid", callback.UserID},
		{"orderid", callback.OrderID},
		{"sporderid", callback.SporderID},
		{"merchantsubmittime", callback.MerchantSubmitTime},
		{"resultno", callback.ResultNo},
	}, tml.channel.ApiKey)

	if selfSign != callback.Sign {
		logger.Log.Error("[MorganDesign2Tml] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.String("callback.OrderID", callback.OrderID),
			zap.String("callback sign", callback.Sign),
			zap.String("self sign", selfSign),
		)
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	rsp.Cert = callback.Remark1
	switch callback.ResultNo {
	case "1":
		rsp.Status = constant.OrderReceiveCallbackSuccess
	case "9":
		rsp.Status = constant.OrderReceiveCallbackFail
	default:
		ctx.JSON(http.StatusOK, map[string]any{
			"code":    "fail",
			"message": "失败",
		})
		return
	}
	ctx.JSON(http.StatusOK, map[string]any{
		"code":    "OK ",
		"message": "成功",
	})
	return
}

func (tml DuXingTemplate) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	params := map[string]string{
		"userid":    tml.channel.ApiID,
		"sporderid": tml.SetChannelOrderID(channelOrder),
	}

	sign := tml.sign([][2]string{
		{"userid", params["userid"]},
		{"sporderid", params["sporderid"]},
	}, tml.channel.ApiKey)

	params["sign"] = sign

	logger.Log.Info("[DuXingTemplate] [QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.Int64("OrderID", channelOrder.OrderID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("params", params))

	var body []byte
	httpResult := struct {
		XMLName            xml.Name `xml:"order"`
		OrderID            string   `xml:"orderid"`
		ProductID          string   `xml:"productid"`
		Num                string   `xml:"num"`
		OrderCash          float64  `xml:"ordercash"`
		ProductName        string   `xml:"productname"`
		SpOrderID          string   `xml:"sporderid"`
		Mobile             string   `xml:"mobile"`
		MerchantSubmitTime string   `xml:"merchantsubmittime"`
		ResultNo           string   `xml:"resultno"`
		Remark1            string   `xml:"remark1"`
		FundBalance        string   `xml:"fundbalance"`
	}{}
	if _, body, err = utils.NewRequest().PostForm().Params(params).Encoding(utils.EncodingGB2312).Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("DuXingTemplate QryOrder]", zap.Error(err))
		return
	}
	logger.Log.Info("DuXingTemplate QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))

	if err = utils.ParseXML(body, &httpResult); err != nil {
		logger.Log.Error("[DuXingTemplate] [Submit] XML解析失败", zap.Error(err))
		return
	}

	logger.Log.Info("DuXingTemplate QryOrder result",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))

	switch httpResult.ResultNo {
	case "1":
		rsp.Status = constant.OrderQrySuccess
	case "9":
		rsp.Status = constant.OrderQryFail
	case "5007":
		rsp.Status = constant.OrderQryNoExist
	default:
		rsp.Status = constant.OrderQryHandle
	}

	rsp.Cert = httpResult.Remark1
	return
}

func (tml DuXingTemplate) QryBalance() (result resp.ClientFinanceResult, err error) {
	params := map[string]string{
		"userid": tml.channel.ApiID,
	}

	sign := tml.sign([][2]string{
		{"userid", params["userid"]},
	}, tml.channel.ApiKey)

	params["sign"] = sign

	logger.Log.Info("DuXingTemplate QryBalance",
		zap.Any("params", params))

	var body []byte
	httpResult := struct {
		XMLName  xml.Name `xml:"user"`
		UserID   string   `xml:"userid"`
		Balance  string   `xml:"balance"`
		ResultNo string   `xml:"resultno"`
	}{}
	if _, body, err = utils.NewRequest().PostForm().Params(params).Encoding(utils.EncodingGB2312).Url(tml.channel.BalanceUrl).Do(); err != nil {
		logger.Log.Error("DuXingTemplate QryOrder]", zap.Error(err))
		return
	}
	logger.Log.Info("DuXingTemplate QryBalance]",
		zap.String("result", string(body)))

	if err = utils.ParseXML(body, &httpResult); err != nil {
		logger.Log.Error("[DuXingTemplate] [Submit] XML解析失败", zap.Error(err))
		return
	}

	logger.Log.Info("DuXingTemplate QryOrder result",
		zap.String("result", string(body)))

	floatValue, err := strconv.ParseFloat(httpResult.Balance, 64)
	if err != nil {
		logger.Log.Error("DuXingTemplate QryBalance]", zap.Error(err), zap.String("balance", httpResult.Balance))
		return
	}
	result.Amount = floatValue
	return
}

func (tml DuXingTemplate) DefaultConfigDescribe() string {
	return `<p>渠道简称: 笃行</p>
<p>模版: duxing</p>
<p>APPID(客户提供)：代理商编号</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：有</p>
<p>产品参数配置：
	101688    全国移动话费50元
	101689    全国移动话费100元
	101690    全国移动话费200元
	101705    全国联通话费30元
	101706    全国联通话费50元
	101707    全国联通话费100元
	101708    全国联通话费200元
</p>`
}
