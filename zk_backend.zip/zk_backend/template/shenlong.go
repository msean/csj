package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type ShenLongTemplate struct {
	Base
}

func NewShenLongTemplate(base Base) (tml *ShenLongTemplate) {
	return &ShenLongTemplate{
		Base: base,
	}
}

var _ TemplateInterface = new(ShenLongTemplate)

func (tml ShenLongTemplate) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	isp := "yd"
	switch channelOrder.Isp {
	case int(constant.IspUniCom):
		isp = "lt"
	case int(constant.IspTelCom):
		isp = "dx"
	}
	payload := map[string]any{
		"supplierId": tml.channel.ApiID,
		"orderNo":    tml.SetChannelOrderID(channelOrder),
		"company":    isp,
		"amount":     utils.Violent2String(channelOrder.FaceValue),
		"phoneNo":    channelOrder.Phone,
		"notifyUrl":  tml.channel.BackUrl,
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[ShenLongTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	var err error
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("[ShenLongTml] Submit json Marshal", zap.Error(err))
		rsp.Err = err.Error()
		return
	}

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
	}{}
	start := time.Now()
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[ShenLongTml] [Submit]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		rsp.Err = "提交异常:" + err.Error()
		return
	}

	logger.Log.Info("[ShenLongTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.Duration("duration", time.Since(start)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}

	switch httpResult.Code {
	case 200:
		rsp.Code = constant.ChannelSubmitSuccess
	case 500:
		// rsp.Code = constant.ChannelSubmitException
		rsp.Err = "	未知异常"
	case 501:
		// rsp.Code = constant.ChannelSubmitCustomerErr
		rsp.Err = "	供货商编号错误"
	case 503:
		// rsp.Code = constant.ChannelSubmitProductClose
		rsp.Err = "面额未开通"
	case 502:
		// rsp.Code = constant.ChannelSubmitSignErr
		rsp.Err = "签名错误"
	case 504:
		// rsp.Code = constant.ChannelSubmitDup
		rsp.Err = "订单号重复"
	case 505:
		// rsp.Code = constant.ChannelSubmitBalanceInsufficient
		rsp.Err = "	余额不足"
	case 521:
		// rsp.Code = constant.ChannelSubmitBalanceInsufficient
		rsp.Err = "当前面额待处理订单过多，请稍后再试！"
	}
}

func (tml ShenLongTemplate) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	// {"params": {"amount":"10.00","orderNo":"00132-71714685811968-00064","supplierId":"113","orderId":"S202503212151129102509781113",
	// "notifyTime":"1742565075196","sign":"7464df9ae942c3878e6c1d800bdb9a90","discountAmount":"0.60","phoneNo":"13953541902","queryUrl":"","payType":"","ticketNo":"","company":"yd","status":"0"}}
	type Callback struct {
		Amount         string `json:"amount" form:"amount"`
		OrderNo        string `json:"orderNo" form:"orderNo"`
		SupplierId     string `json:"supplierId" form:"supplierId"`
		OrderId        string `json:"orderId" form:"orderId"`
		NotifyTime     string `json:"notifyTime" form:"notifyTime"`
		Sign           string `json:"sign" form:"sign"`
		DiscountAmount string `json:"discountAmount" form:"discountAmount"`
		PhoneNo        string `json:"phoneNo" form:"phoneNo"`
		QueryUrl       string `json:"queryUrl" form:"queryUrl"`
		PayType        string `json:"payType" form:"payType"`
		TicketNo       string `json:"ticketNo" form:"ticketNo"`
		Company        string `json:"company" form:"company"`
		Status         string `json:"status" form:"status"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[ReceiveCallback] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("ShenLongTemplate Receive callback",
		zap.Any("params", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.OrderNo); err != nil {
		logger.Log.Error("ShenLongTemplate Callback",
			zap.String("callback.OrderID", callback.OrderNo),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[ShenLongTemplate] [Callback]",
			zap.String("callback.OrderID", callback.OrderNo),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	signMapper := utils.StructToMap(callback)
	delete(signMapper, "sign")
	sign := tml.sign(signMapper, tml.channel.ApiKey)

	if sign != callback.Sign {
		err = fmt.Errorf("签名错误")
		logger.Log.Error("[ShenLongTemplate] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.String("callback.OrderID", callback.OrderNo),
			zap.Error(err),
			zap.String("callback sign", callback.Sign),
			zap.String("selfSign", sign))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	rsp.Cert = callback.TicketNo
	switch callback.Status {
	case "2":
		rsp.Status = constant.OrderReceiveCallbackSuccess
	case "1", "0", "3":
		rsp.Status = constant.OrderReceiveCallbackFail
	}
	ctx.String(http.StatusOK, "success")
	return
}

func (tml ShenLongTemplate) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	isp := "yd"
	switch channelOrder.Isp {
	case int(constant.IspUniCom):
		isp = "lt"
	case int(constant.IspTelCom):
		isp = "dx"
	}
	payload := map[string]any{
		"supplierId": utils.Violent2String(tml.channel.ApiID),
		"orderNo":    tml.SetChannelOrderID(channelOrder),
		"company":    isp,
		"phoneNo":    channelOrder.Phone,
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("ShenLongTemplate QryOrder",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("ShenLongTemplate] Submit json Marshal", zap.Error(err))
		return
	}

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		Data struct {
			TicketNo string `json:"ticketNo"`
			Status   string `json:"status"`
		} `json:"data"`
	}{}
	start := time.Now()
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("ShenLongTemplate QryOrder",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		return
	}

	logger.Log.Info("ShenLongTemplate QryOrder",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.Duration("duration", time.Since(start)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	switch httpResult.Code {
	case 200:
		switch httpResult.Data.Status {
		case "0", "1":
			rsp.Status = constant.OrderQryCreated
		case "2":
			rsp.Status = constant.OrderQrySuccess
			rsp.Cert = httpResult.Data.TicketNo
		case "3":
			rsp.Status = constant.OrderQryFail
			rsp.ChannelMsg = "缴费失败"
		}

	case 500:
		rsp.Status = constant.OrderQryApiException
	case 501:
		rsp.Status = constant.OrderQryFail
		rsp.ChannelMsg = "供货商编号错误"
	case 502:
		rsp.Status = constant.OrderQryFail
		rsp.ChannelMsg = "签名错误"
	case 510:
		rsp.Status = constant.ChannelSubmitDup
		rsp.ChannelMsg = "订单不存在"
	}
	return
}

func (tml ShenLongTemplate) QryBalance() (result resp.ClientFinanceResult, err error) {
	payload := map[string]any{
		"supplierId": utils.Violent2String(tml.channel.ApiID),
		"queryTime":  time.Now().Format("2006-01-02 15:04:05"),
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("ShenLongTemplate QryBalance",
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("ShenLongTemplate Submit json Marshal", zap.Error(err))
		return
	}

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		Data struct {
			Amount float64 `json:"amount"`
		} `json:"data"`
	}{}
	start := time.Now()
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.BalanceUrl).Do(); err != nil {
		logger.Log.Error("ShenLongTemplate QryBalance",
			zap.Any("payload", payload),
			zap.Error(err))
		return
	}

	logger.Log.Info("ShenLongTemplate QryBalance",
		zap.String("result", string(body)),
		zap.Duration("duration", time.Since(start)))

	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	switch httpResult.Code {
	case 200:
		result.Amount = httpResult.Data.Amount
	case 500:
		result.Status = constant.BalanceQryException
		result.Msg = "未知异常"
	case 501:
		result.Status = constant.BalanceQryCustomerErr
		result.Msg = "供货商编号错误"
	case 502:
		result.Status = constant.BalanceQrySignErr
		result.Msg = "签名错误"
	}
	return
}

func (tml ShenLongTemplate) DefaultConfigDescribe() string { return "" }

func (tml ShenLongTemplate) sign(param map[string]any, key string) string {

	var keys []string
	for k, v := range param {
		if utils.Violent2String(v) != "" {
			keys = append(keys, k)
		}
	}

	sort.Strings(keys)

	var sb strings.Builder
	for _, k := range keys {
		_v := utils.Violent2String(param[k])
		if k == "queryUrl" {
			sb.WriteString(url.QueryEscape(_v))
		} else {
			sb.WriteString(_v)
		}
	}

	sb.WriteString(key)

	h := md5.New()
	h.Write([]byte(sb.String()))
	sign := hex.EncodeToString(h.Sum(nil))

	return strings.ToLower(sign)
}
