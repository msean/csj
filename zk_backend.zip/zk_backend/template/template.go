package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql"
	"application/models"
	"application/models/resp"
	"application/utils"
	"fmt"
	"strconv"
	"strings"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

type (
	Option struct {
		Pcode string
	}
	TemplateInterface interface {
		Submit(models.ChannelOrder, *resp.ClientOrderSubmitResult)
		ReceiveCallback(ctx echo.Context) (resp.ClientOrderCallbackResult, error)
		QryOrder(channelOrder models.ChannelOrder) (resp.ClientOrderQryResult, error)
		QryBalance() (result resp.ClientFinanceResult, err error)
		DefaultConfigDescribe() string
	}
	Base struct {
		channel *models.Channel
		option  Option
	}
)

type NilTemplate struct {
	Base
}

func NewNilTemplate(base Base) (tml *NilTemplate) {
	return &NilTemplate{
		Base: base,
	}
}

var _ TemplateInterface = new(NilTemplate)

func (tml NilTemplate) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {}

func (tml NilTemplate) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	return
}

func (tml NilTemplate) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	return
}

func (tml NilTemplate) QryBalance() (result resp.ClientFinanceResult, err error) { return }

func (tml NilTemplate) DefaultConfigDescribe() string { return "" }

func (base *Base) SetChannelOrderID(channelOrder models.ChannelOrder) string {
	return fmt.Sprintf("%05d-%d-%05d", channelOrder.CustomerID, channelOrder.ID, channelOrder.ChannelID)
}

func (base *Base) ParseOrderID(orderID string) (channelOrderID int64, err error) {
	splits := strings.Split(orderID, "-")
	if len(splits) != 3 {
		logger.Log.Error("[Template] [Callback]", zap.String("thirdOrderID", orderID))
		err = fmt.Errorf("err order ID")
		return
	}

	if channelOrderID, err = strconv.ParseInt(splits[1], 10, 64); err != nil {
		logger.Log.Error("[Template] [Callback]", zap.String("thirdOrderID", orderID))
		err = fmt.Errorf("err order ID")
	}
	return
}

func NewTemplateWithBase(templateName string, base Base) (TemplateInterface, error) {
	switch templateName {
	case "Upper":
		return NewUpperTemplate(base), nil
	case "XuanJie":
		return NewXjTemplate(base), nil
	case "AddSupplyNumber":
		return NewAddSupplyNumberTemplate(base), nil
	case "ReceiveOrder2":
		return NewReceiveOrder2Tml(base), nil
	case "Quotient":
		return NewQuotientTml(base), nil
	case "MorganDesign2":
		return NewMorganDesign2Tml(base), nil
	case "SM":
		return NewM5Tml(base), nil
	case "Jupiter":
		return NewAddJupiterTml(base), nil
	case "Xapi": // 中
		return NewXApiTemplate(base), nil
	case "DuXing":
		return NewDuXingTemplate(base), nil
	case "MobileMerchant":
		return NewMobileMerchantTml(base), nil
	case "ShenLong":
		return NewShenLongTemplate(base), nil
	}
	return nil, fmt.Errorf("不支持的模版")
}

func NewTemplate(channel *models.Channel, option Option) (TemplateInterface, error) {
	base := Base{
		channel: channel,
		option:  option,
	}
	return NewTemplateWithBase(channel.TemplateName, base)
}

func QryChannelFinance(channel *models.Channel) (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()
	var tml TemplateInterface
	if tml, err = NewTemplate(channel, Option{}); err != nil {
		utils.Update(
			session.Table(models.Channel{}.TableName()),
			map[string]any{
				"balance": 0,
				"msg":     err.Error(),
			},
			utils.IDCond(channel.ID),
		)
		return
	}

	var result resp.ClientFinanceResult
	if result, err = tml.QryBalance(); err != nil {
		utils.Update(
			session.Table(models.Channel{}.TableName()),
			map[string]any{
				"balance": 0,
				"msg":     err.Error(),
			},
			utils.IDCond(channel.ID),
		)
		return
	}

	msg := result.Msg
	if msg != "" && result.CreditAmount > 0 {
		msg = fmt.Sprintf("%s, 授信额度: %s", msg, utils.FloatReserveStr(result.CreditAmount, 4))
	}

	if msg == "" && result.CreditAmount > 0 {
		msg = fmt.Sprintf("授信额度: %s", utils.FloatReserveStr(result.CreditAmount, 4))
	}

	utils.Update(
		session.Table(models.Channel{}.TableName()),
		map[string]any{
			"balance": result.Amount,
			"msg":     msg,
		},
		utils.IDCond(channel.ID),
	)
	return
}

func ScanChannelFinance() {
	var channels []models.Channel
	var err error
	if channels, err = mysql.Channel.All(); err != nil {
		logger.Log.Error("[template] [Init] [load channels]", zap.Error(err))
		return
	}
	for _, channel := range channels {
		QryChannelFinance(&channel)
	}
}
func ConfigDescribe() (rsp []resp.TemplateDescribeRsp, err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	var has bool
	var tmlDictType models.SysDictType
	has, err = utils.Get(session, &tmlDictType, utils.NewWhereCond("dict_type", constant.SysTemplateDictType))
	if !has || err != nil {
		return
	}

	var sysDictDataList []models.SysDictData
	conditions := []utils.Cond{
		utils.NewWhereCond("type_id", tmlDictType.ID),
		utils.NewBaseCond("`remark` != ''"),
	}
	if err = utils.Find(session, &sysDictDataList, conditions...); err != nil {
		panic(err)
	}

	for _, desc := range sysDictDataList {
		rsp = append(rsp, resp.TemplateDescribeRsp{
			ID:          desc.ID,
			TemplateKey: desc.Label,
			Description: desc.Remark,
		})
	}

	return rsp, nil
}

func InitTemplateConfigDescription() (err error) {
	session := daos.Mysql.NewSession()
	defer session.Close()

	var has bool
	var tmlDictType models.SysDictType
	has, err = utils.Get(session, &tmlDictType, utils.NewWhereCond("dict_type", constant.SysTemplateDictType))
	if !has || err != nil {
		return
	}

	var sysDictDataList []models.SysDictData
	conditions := []utils.Cond{
		utils.NewWhereCond("type_id", tmlDictType.ID),
		utils.NewBaseCond("`remark` != ''"),
	}
	if err = utils.Find(session, &sysDictDataList, conditions...); err != nil {
		panic(err)
	}

	existMapper := make(map[string]struct{}, 0)
	for _, _d := range sysDictDataList {
		existMapper[_d.Value] = struct{}{}
	}

	for _, templateName := range constant.TemplateMapper {
		if _, ok := existMapper[templateName]; ok {
			continue
		}
		var tml TemplateInterface
		if tml, err = NewTemplateWithBase(templateName, Base{}); err != nil {
			return
		}
		if tml != nil {
			utils.Update(session.Table(models.SysDictData{}.TableName()), map[string]any{
				"remark": tml.DefaultConfigDescribe(),
			}, utils.NewWhereCond("dict_value", templateName))
		} else {
			logger.Log.Error("InitTemplateConfigDescription", zap.String("templateName", templateName))
		}
	}
	return
}

func QryChannelFinanceByChannelID(channelID int64) (err error) {
	var channel models.Channel
	var has bool
	if channel, has, err = mysql.Channel.FromID(channelID); !has || err != nil {
		logger.Log.Error("QryChannelFinanceByChannelID",
			zap.Int64("channelID", channelID),
			zap.Error(err))
	}
	QryChannelFinance(&channel)
	return
}
