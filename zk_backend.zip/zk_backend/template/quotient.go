package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

// EtcOne 作为快充/慢充渠道
// Pcode 设置 yy的话就是 Y币

// 有凭证

type QuotientTml struct {
	Base
}

var _ TemplateInterface = new(QuotientTml)

func NewQuotientTml(base Base) (tml *QuotientTml) {
	return &QuotientTml{
		Base: base,
	}
}

func (tml QuotientTml) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	channelType := "2"
	if tml.channel.Etcone == "慢充" {
		channelType = "1"
	}

	var rechargeCmp string
	switch channelOrder.Isp {
	case int(constant.IspMobile):
		rechargeCmp = "yd"
	case int(constant.IspUniCom):
		rechargeCmp = "lt"
	case int(constant.IspTelCom):
		rechargeCmp = "dx"
	}
	if channelOrder.Pcode == "yy" {
		rechargeCmp = "yy"
	}

	payload := map[string]any{
		"quotientId":      utils.Violent2String(tml.channel.ApiID),
		"quotientOrderNo": tml.SetChannelOrderID(channelOrder),
		"channelType":     channelType,
		"rechargeCompany": rechargeCmp,
		"amount":          utils.Violent2String(channelOrder.FaceValue),
		"rechargeNo":      channelOrder.Phone,
		"notifyUrl":       tml.channel.BackUrl,
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[QuotientTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	var err error
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("[QuotientTml] Submit json Marshal", zap.Error(err))
		rsp.Err = err.Error()
		return
	}

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"message"`
	}{}
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[QuotientTml] [Submit]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		rsp.Err = "提交异常:" + err.Error()
		return
	}

	logger.Log.Info("[QuotientTml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}

	switch httpResult.Code {
	case 1000:
		rsp.Code = constant.ChannelSubmitSuccess
	case 9000:
		rsp.Code = constant.ChannelSubmitAbnormal
	case 9001:
		rsp.Code = constant.ChannelSubmitCustomerErr
	case 9002:
		rsp.Code = constant.ChannelSubmitSignErr
	case 9003:
		rsp.Code = constant.ChannelSubmitFaceValueUnConfig
	case 9004:
		rsp.Code = constant.ChannelSubmitDup
	case 9005:
		rsp.Code = constant.ChannelSubmitBalanceInsufficient
	case 9006:
		rsp.Code = constant.ChannelSubmitUnSupportIsp
	case 9007:
		rsp.Code = constant.ChannelSubmitCustomerClose
	case 9011:
		rsp.Code = constant.ChannelSubmitNotInWhiteList
	case 9020:
		rsp.Code = constant.ChannelSubmitException
	case 9021:
		rsp.Code = constant.ChannelSubmitApiLimit
	}
	rsp.Err = httpResult.Msg
}

func (tml QuotientTml) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type Callback struct {
		QuotientId      string `json:"quotientId" form:"quotientId"`
		ID              string `json:"id" form:"id"`
		QuotientOrderNo string `json:"quotientOrderNo" form:"quotientOrderNo"`
		RechargeNo      string `json:"rechargeNo" form:"rechargeNo"`
		Amount          string `json:"amount" form:"amount"`
		DiscountAmount  string `json:"discountAmount" form:"discountAmount"`
		RealAmount      string `json:"realAmount" form:"realAmount"`
		CreateTime      string `json:"createTime" form:"createTime"`
		OrderStatus     string `json:"orderStatus" form:"orderStatus"`
		OfficialOrder   string `json:"officialOrder" form:"officialOrder"`
		Sign            string `json:"sign" form:"sign"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[ReceiveCallback] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("QuotientTml Receive callback",
		zap.Any("params", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.QuotientOrderNo); err != nil {
		logger.Log.Error("[QuotientTml] [Callback]",
			zap.String("callback.OrderID", callback.QuotientOrderNo),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[QuotientTml] [Callback]",
			zap.String("callback.OrderID", callback.QuotientOrderNo),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	signMapper := utils.StructToMap(callback)
	delete(signMapper, "sign")
	selfSign := tml.sign(signMapper, tml.channel.ApiKey)
	if selfSign != callback.Sign {
		err = fmt.Errorf("签名错误")
		logger.Log.Error("[QuotientTml] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.String("callback.OrderID", callback.QuotientOrderNo),
			zap.Error(err),
			zap.String("callback sign", callback.Sign),
			zap.String("selfSign", selfSign))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}
	switch callback.OrderStatus {
	case "1":
		rsp.Status = constant.OrderReceiveCallbackSuccess
		rsp.Cert = callback.OfficialOrder
	case "2":
		rsp.Status = constant.OrderReceiveCallbackFail
	}
	resp.Resp(ctx, true, 200, "success", nil)
	return
}

func (tml QuotientTml) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {
	payload := map[string]any{
		"quotientId":      utils.Violent2String(tml.channel.ApiID),
		"quotientOrderNo": tml.SetChannelOrderID(channelOrder),
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[QuotientTml] [QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("QuotientTml Submit json Marshal", zap.Error(err))
		return
	}

	var body []byte
	httpResult := struct {
		Code int    `json:"code"`
		Msg  string `json:"message"`
		Data struct {
			OrderStatus   string `json:"orderStatus"`
			OfficialOrder string `json:"officialOrder"`
		} `json:"result"`
	}{}
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("[QuotientTml] [Submit]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		return
	}

	logger.Log.Info("[QuotientTml] [QryOrder] [result]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.String("apiKey", tml.channel.ApiKey))

	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	rsp.Cert = httpResult.Data.OfficialOrder
	switch httpResult.Code {
	case 1000:
		switch httpResult.Data.OrderStatus {
		case "0":
			rsp.Status = constant.OrderQryCreated
		case "1":
			rsp.Status = constant.OrderQrySuccess
		case "2":
			rsp.Status = constant.OrderQryFail
		case "3":
			rsp.Status = constant.OrderQryHandle
		}
	case 9000:
		rsp.Status = constant.OrderQryApiException
	case 9001:
		rsp.Status = constant.OrderQryCustomerNotExist
	case 9002:
		rsp.Status = constant.OrderQrySignErr
	case 9003:
		rsp.Status = constant.OrderQryParamsErr
	case 9007:
		rsp.Status = constant.OrderQryCustomerClose
	case 9010:
		rsp.Status = constant.OrderQryNoExist
	}
	rsp.ChannelMsg = httpResult.Msg
	return
}

func (tml QuotientTml) sign(requestParams map[string]any, apiSecret string) string {
	keys := make([]string, 0, len(requestParams))
	for k := range requestParams {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	var str string
	for _, key := range keys {
		value := requestParams[key]
		if value != nil && value != "" {
			str += fmt.Sprintf("%v", value)
		}
	}
	toSign := str + apiSecret

	hash := md5.New()
	hash.Write([]byte(toSign))
	signResult := hex.EncodeToString(hash.Sum(nil))

	return signResult
}

func (tml QuotientTml) QryBalance() (result resp.ClientFinanceResult, err error) {
	payload := map[string]any{
		"quotientId": utils.Violent2String(tml.channel.ApiID),
	}

	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[QuotientTml] [QryBalance]",
		zap.Int64("ChannelID", tml.channel.ID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("[QuotientTml] QryBalance json Marshal", zap.Error(err))
		return
	}

	var body []byte
	httpResult := struct {
		Code   int    `json:"code"`
		Msg    string `json:"message"`
		Result struct {
			Amount string `json:"amount"`
		}
	}{}
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.BalanceUrl).Do(); err != nil {
		logger.Log.Error("[QuotientTml] [QryBalance]",
			zap.Int64("ChannelID", tml.channel.ID),
			zap.Error(err))
		return
	}

	logger.Log.Info("[QuotientTml] [QryBalance]",
		zap.Int64("ChannelID", tml.channel.ID),
		zap.String("result", string(body)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	var status int
	var amount float64
	switch httpResult.Code {
	case 1000:
		status = constant.BalanceQrySuccess
	case 9000:
		status = constant.BalanceQryException
	case 9001:
		status = constant.BalanceQryCustomerErr
	case 9002:
		status = constant.BalanceQrySignErr
	}

	if amount, err = strconv.ParseFloat(httpResult.Result.Amount, 64); err != nil {
		logger.Log.Error("[QuotientTml] QryBalance parse amount", zap.Error(err))
		return
	}
	result.Msg = httpResult.Msg
	result.Status = status
	result.Amount = amount
	return
}

func (tml *QuotientTml) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： Quotient",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：有",
	// }
	return `<p>渠道简称: Quotient</p>
<p>模版: quotient</p>
<p>APPID(客户提供)：代理商编号</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：有</p>`
}
