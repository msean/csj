package template

import (
	"application/common/logger"
	"application/constant"
	"application/daos"
	"application/daos/mysql/partition"
	"application/models"
	"application/models/resp"
	"application/utils"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strings"

	"github.com/labstack/echo"
	"go.uber.org/zap"
)

// 渠道的etcone字段 作为 类型字段 0 移动 1 联通  2电信 3移动分省 4掌乐 5 移动旗舰店 6 电信旗舰店 7 电信分省 8 快手 9  分省综合
// pcode
// type 为分省综合 timeout/isp/province
// type 为指定运营商 timeout/isp/province 或者timeout/isp
// type 为云闪付 timeout/isp 或者 timeout

type MorganDesign2Tml struct {
	Base
}

var _ TemplateInterface = new(MorganDesign2Tml)

func NewMorganDesign2Tml(base Base) (tml *MorganDesign2Tml) {
	return &MorganDesign2Tml{
		Base: base,
	}
}

func (tml MorganDesign2Tml) Submit(channelOrder models.ChannelOrder, rsp *resp.ClientOrderSubmitResult) {
	var ispType int
	var isp int
	var province int
	var err error
	timeout := 300
	if !utils.IsBlankString(tml.channel.Etcone) {
		switch tml.channel.Etcone {
		case "分省综合":
			ispType = 9
			splits := strings.Split(channelOrder.Pcode, "/")
			if len(splits) == 3 {
				if err = utils.ConvertIntFromString(splits[0], &timeout); err != nil {
					rsp.Err = err.Error()
					return
				}
				if err = utils.ConvertIntFromString(splits[1], &isp); err != nil {
					rsp.Err = err.Error()
					return
				}
				if err = utils.ConvertIntFromString(splits[2], &province); err != nil {
					rsp.Err = err.Error()
					return
				}
			}
		case "指定运营商":
			splits := strings.Split(channelOrder.Pcode, "/")
			if len(splits) == 3 {
				if err = utils.ConvertIntFromString(splits[0], &timeout); err != nil {
					rsp.Err = err.Error()
					return
				}
				if err = utils.ConvertIntFromString(splits[1], &ispType); err != nil {
					rsp.Err = err.Error()
					return
				}
				if err = utils.ConvertIntFromString(splits[2], &province); err != nil {
					rsp.Err = err.Error()
					return
				}
			}

			if len(splits) == 2 {
				if err = utils.ConvertIntFromString(splits[0], &timeout); err != nil {
					rsp.Err = err.Error()
					return
				}
				if err = utils.ConvertIntFromString(splits[1], &ispType); err != nil {
					rsp.Err = err.Error()
					return
				}
			}
		case "云闪付":
			ispType = 8
			splits := strings.Split(channelOrder.Pcode, "/")
			if len(splits) == 2 {
				if err = utils.ConvertIntFromString(splits[0], &timeout); err != nil {
					rsp.Err = err.Error()
					return
				}
				if err = utils.ConvertIntFromString(splits[1], &ispType); err != nil {
					rsp.Err = err.Error()
					return
				}
			}
		}
	} else {
		if !utils.IsBlankString(channelOrder.Pcode) {
			splits := strings.Split(strings.TrimSpace(channelOrder.Pcode), "/")
			if len(splits) == 2 {
				if err = utils.ConvertIntFromString(splits[0], &timeout); err != nil {
					rsp.Err = err.Error()
					return
				}
				if err = utils.ConvertIntFromString(splits[1], &province); err != nil {
					rsp.Err = err.Error()
					return
				}
			} else if len(splits) == 1 {
				if err = utils.ConvertIntFromString(splits[0], &timeout); err != nil {
					rsp.Err = err.Error()
					return
				}
			}
		}
	}

	if ispType != 0 {
		switch channelOrder.Isp {
		case int(constant.IspMobile):
			ispType = 0
		case int(constant.IspUniCom):
			ispType = 1
		case int(constant.IspTelCom):
			ispType = 2
		}
	}

	payload := map[string]any{
		"orderId":   tml.SetChannelOrderID(channelOrder),
		"appKey":    utils.Violent2String(tml.channel.ApiID),
		"amount":    channelOrder.FaceValue,
		"phone":     channelOrder.Phone,
		"notifyUrl": tml.channel.BackUrl,
		"type":      ispType,
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)
	if province != 0 {
		payload["province"] = province
	}
	if isp != 0 {
		payload["isp"] = isp
	}

	logger.Log.Info("[MorganDesign2Tml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("[MorganDesign2Tml] Submit json Marshal", zap.Error(err))
		rsp.Err = err.Error()
		return
	}

	var body []byte
	httpResult := struct {
		Code string `json:"code"`
		Msg  string `json:"message"`
	}{}
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.SubmitUrl).Do(); err != nil {
		logger.Log.Error("[MorganDesign2Tml] [Submit]",
			zap.Int64("channelOrderID", channelOrder.ID),
			zap.String("customerOrderID", channelOrder.CustomerOrderID),
			zap.Error(err))
		rsp.Err = "提交异常:" + err.Error()
		return
	}

	logger.Log.Info("[MorganDesign2Tml] [Submit]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		rsp.Err = err.Error()
		return
	}

	switch httpResult.Code {
	case "success":
		rsp.Code = constant.ChannelSubmitSuccess
	default:
		rsp.Code = constant.ChannelSubmitFail
	}
	rsp.Err = httpResult.Msg

}

func (tml MorganDesign2Tml) ReceiveCallback(ctx echo.Context) (rsp resp.ClientOrderCallbackResult, err error) {
	type Callback struct {
		OrderID    string `json:"orderId" form:"orderId"`
		OperatorID string `json:"operatorId" form:"operatorId"`
		Amount     int    `json:"amount" form:"amount"`
		Timestamp  int    `json:"timestamp" form:"timestamp"`
		AppKey     string `json:"appKey" form:"appKey"`
		Status     int    `json:"status" form:"status"`
		Sign       string `json:"sign" form:"sign"`
	}
	var callback Callback
	if err = ctx.Bind(&callback); err != nil {
		logger.Log.Info("[MorganDesign2Tml] [ReceiveCallback] [Callback]", zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	logger.Log.Info("MorganDesign2Tml Receive callback", zap.Any("params", callback))

	var has bool
	var channelOrderID int64
	if channelOrderID, err = tml.ParseOrderID(callback.OrderID); err != nil {
		logger.Log.Error("[MorganDesign2Tml] [Callback]",
			zap.String("callback.OrderID", callback.OrderID),
			zap.Error(err))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	session := daos.Mysql.NewSession()
	defer session.Close()

	rsp.ChannelOrder, has, err = partition.GlobalChannelOrderPartition.FromID(session, channelOrderID)
	if !has || err != nil {
		logger.Log.Error("[MorganDesign2Tml] [Callback]",
			zap.String("callback.OrderID", callback.OrderID),
			zap.Error(err), zap.Bool("has", has))
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}

	m := utils.StructToMap(callback)
	delete(m, "sign")
	selfSign := tml.sign(m, tml.channel.ApiKey)
	if selfSign != callback.Sign {
		logger.Log.Error("[MorganDesign2Tml] [Callback]",
			zap.String("customerOrderID", rsp.ChannelOrder.CustomerOrderID),
			zap.String("callback.OrderID", callback.OrderID),
			zap.String("callback sign", callback.Sign),
			zap.String("self sign", selfSign),
		)
		resp.Resp(ctx, false, 500, "fail", nil)
		return
	}
	switch callback.Status {
	case 2, 5:
		rsp.Status = constant.OrderReceiveCallbackFail
	case 4:
		rsp.Status = constant.OrderReceiveCallbackSuccess
		rsp.Cert = callback.OperatorID
	default:
		ctx.JSON(http.StatusOK, map[string]any{
			"code":    "fail",
			"message": "失败",
		})
		return
	}
	ctx.JSON(http.StatusOK, map[string]any{
		"code":    "success",
		"message": "成功",
	})
	return
}

func (tml MorganDesign2Tml) QryOrder(channelOrder models.ChannelOrder) (rsp resp.ClientOrderQryResult, err error) {

	payload := map[string]any{
		"appKey":  tml.channel.ApiID,
		"orderId": tml.SetChannelOrderID(channelOrder),
	}
	payload["sign"] = tml.sign(payload, tml.channel.ApiKey)

	logger.Log.Info("[MorganDesign2Tml] [QryOrder]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.Any("payload", payload))

	var payloadByte []byte
	if payloadByte, err = json.Marshal(payload); err != nil {
		logger.Log.Error("MorganDesign2Tml Submit json Marshal", zap.Error(err))
		return
	}

	var body []byte
	httpResult := struct {
		Code string `json:"code"`
		Msg  string `json:"message"`
		Data struct {
			Status     int    `json:"status"`
			BusinessID string `json:"businessId"`
		} `json:"data"`
	}{}
	if _, body, err = utils.NewRequest().Payload(payloadByte).Post().Url(tml.channel.QueryUrl).Do(); err != nil {
		logger.Log.Error("[MorganDesign2Tml] [QryOrder]", zap.Error(err))
		return
	}

	logger.Log.Info("[MorganDesign2Tml] [QryOrder] [result]",
		zap.Int64("channelOrderID", channelOrder.ID),
		zap.String("customerOrderID", channelOrder.CustomerOrderID),
		zap.String("result", string(body)),
		zap.String("apiKey", tml.channel.ApiKey))
	if err = json.Unmarshal(body, &httpResult); err != nil {
		return
	}

	if httpResult.Code == "success" {
		switch httpResult.Data.Status {
		case 0:
			rsp.Status = constant.OrderQryCreated
		case 1:
			rsp.Status = constant.OrderQryHandle
		case 2:
			rsp.Status = constant.OrderQryFail
		case 3:
			rsp.Status = constant.OrderQrySuccess
			rsp.Cert = httpResult.Data.BusinessID
		case 4:
			rsp.Status = constant.OrderQryConfirmed
		case 5:
			rsp.Status = constant.OrderQryFailNotified
		}
	}
	rsp.ChannelMsg = httpResult.Code
	return
}

func (tml MorganDesign2Tml) sign(params map[string]interface{}, apiSecret string) string {
	var keys []string
	for k := range params {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	var str strings.Builder
	for i, key := range keys {
		value := params[key]
		if value != nil && value != "" {
			str.WriteString(fmt.Sprintf("%s=%v", key, value))
			if i < len(keys)-1 {
				str.WriteString("&")
			}
		}
	}

	toSign := str.String() + "&appSecret=" + apiSecret

	hash := md5.Sum([]byte(toSign))
	signResult := strings.ToUpper(hex.EncodeToString(hash[:]))
	return signResult
}

func (tml MorganDesign2Tml) QryBalance() (result resp.ClientFinanceResult, err error) {
	return
}

func (tml *MorganDesign2Tml) DefaultConfigDescribe() string {
	// return []string{
	// 	"模版： Quotient",
	// 	"APPID(客户提供)：代理商编号",
	// 	"APIKEY(客户提供)：密钥",
	// 	"是否存存余额地址：有",
	// 	"产品编码：配置超市时间或者指定省份 超时时间单位：秒， 默认值300, 若是指定省份，格式为：(超时时间)/(指定省份), 851 贵州 531 山东  250 江苏 200 广东 371河南 871 云南 591 福建 791 江西 731 湖南 270 湖北",
	// }
	return `<p>模版： MorganDesignationTwo</p>
<p>APPID(客户提供)：代理商编号</p>
<p>APIKEY(客户提供)：密钥</p>
<p>是否存存余额地址：有</p>
<p>产品编码：配置超时时间和指定省份 <br>
默认为指定超时时间，超时时间单位：秒， 默认值300, 
若是指定省份，格式为：(超时时间)/(指定省份), <br>
851 贵州 <br>
531 山东 <br>
250 江苏 <br>
200 广东 <br>
371 河南 <br>
871 云南 <br>
591 福建 <br>
791 江西 <br>
731 湖南 <br>
270 湖北
</p>
`
}
