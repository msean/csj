package conf

import (
	"github.com/spf13/viper"
	"os"
)

var (
	config    GlobalConfig
	BuildTime = ""
	BuildHash = ""
)

type GlobalConfig struct {
	Echo EchoConfig    `mapstructure:"echo"`
	Jwt  JwtConfig     `mapstructure:"jwt"`
	Xdb  XormConfig    `mapstructure:"mysql"`
	Rdb  RedisConfig   `mapstructure:"redis"`
	Ldb  LeveldbConfig `mapstructure:"leveldb"`
	Log  LogConfig     `mapstructure:"log"`
	Url  UrlConfig     `mapstructure:"url"`
}

func Config() GlobalConfig {
	return config
}

// ParseConfig 解析配置文件
func ParseConfig(cfg string) {
	viper.SetConfigFile(cfg)
	viper.SetConfigType("yaml")
	err := viper.ReadInConfig()
	if err != nil {
		panic(err)
	}

	err = viper.Unmarshal(&config)
	if err != nil {
		panic(err)
	}
}

func StaticPath() string {
	path := Config().Echo.StaticPath
	if path == "" {
		path, _ = os.Getwd()
		path = path + "/static"
	}

	return path
}
