package conf

type EchoConfig struct {
	Bind                     string `mapstructure:"bind"`
	StaticPath               string `mapstructure:"static_path"`
	CallbackAddr             string `mapstructure:"callback_addr"`
	RechargeConcurrency      int64  `mapstructure:"recharge_concurrency"`
	DispatcherWorkers        int64  `mapstructure:"dispatcher_workers"`
	WaitCallBackConcurrency  int64  `mapstructure:"wait_callback_concurrency"`
	ApiMetrics               bool   `mapstructure:"api_metrics"`
	ApiMetricsReportInterval int    `mapstructure:"api_metrics_report_interval"`
}
