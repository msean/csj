package conf

import "fmt"

type XormConfig struct {
	Host             string `mapstructure:"host"`
	Port             string `mapstructure:"port"`
	Username         string `mapstructure:"username"`
	Password         string `mapstructure:"password"`
	DBname           string `mapstructure:"dbname"`
	ShowSql          bool   `mapstructure:"show_sql"`
	Migrate          bool   `mapstructure:"migrate"`
	MigratePartition bool   `mapstructure:"migrate_partition"`
}

func GetDataSourceName() string {
	return fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8&parseTime=true&loc=%s",
		config.Xdb.Username, config.Xdb.Password, config.Xdb.Host, config.Xdb.Port, config.Xdb.DBname, "Local")
}
