package conf

import "fmt"

type RedisConfig struct {
	Has      bool   `mapstructure:"has"`
	Host     string `mapstructure:"host"`
	Port     string `mapstructure:"port"`
	Password string `mapstructure:"password"`
	DB       int    `mapstructure:"db"`
}

func GetRedisAddr() string {
	return fmt.Sprintf("%s:%s",
		config.Rdb.Host, config.Rdb.Port)
}
