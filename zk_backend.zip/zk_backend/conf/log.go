package conf

import "fmt"

type LogConfig struct {
	Path string `mapstructure:"path"`
	Name string `mapstructure:"name"`
}

func GetLogFilePath() string {
	return fmt.Sprintf("%s/%s", config.Log.Path, config.Log.Name)
}
