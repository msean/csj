package conf

type UrlConfig struct {
	Order          string `mapstructure:"order"`           // 下单地址
	Check          string `mapstructure:"check"`           // 查单地址
	Balance        string `mapstructure:"balance"`         // 余额地址
	CallbackPrefix string `mapstructure:"callback_prefix"` // 余额地址
}
