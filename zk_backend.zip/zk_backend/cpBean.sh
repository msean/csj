#!/usr/bin/env bash
cp ./daos/mysql/bean.go ./daos/mysql/bean_copy.go
cp ./services/bean.go ./services/bean_copy.go
cp ./models/role.go ./models/bean_copy.go