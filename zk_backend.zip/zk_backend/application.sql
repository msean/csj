/*
 Navicat Premium Data Transfer

 Source Server         : aaa
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : 192.168.0.106:3306
 Source Schema         : go_admin

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 04/08/2023 20:01:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for a_adminlog
-- ----------------------------
DROP TABLE IF EXISTS `a_adminlog`;
CREATE TABLE `a_adminlog`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `method` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '请求方式',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '请求地址',
  `params` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '请求参数',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '标题',
  `user_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'ip地址',
  `user_agent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '浏览器类型和操作系统',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `created` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `deleted` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户操作日志表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of a_adminlog
-- ----------------------------

-- ----------------------------
-- Table structure for a_logininfor
-- ----------------------------
DROP TABLE IF EXISTS `a_logininfor`;
CREATE TABLE `a_logininfor`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `login_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录账号',
  `ipaddr` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '操作系统',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '提示消息',
  `created` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统访问记录' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of a_logininfor
-- ----------------------------

-- ----------------------------
-- Table structure for a_menu
-- ----------------------------
DROP TABLE IF EXISTS `a_menu`;
CREATE TABLE `a_menu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '菜单名称',
  `parent_id` bigint(20) NULL DEFAULT 0 COMMENT '父菜单ID',
  `weights` int(11) NULL DEFAULT NULL COMMENT '权重',
  `method` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '请求方式',
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '#' COMMENT '请求地址',
  `pages` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '页面地址',
  `menu_type` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `classification` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '菜单分类（S查看 E更新 D删除）',
  `visible` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `icon` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '#' COMMENT '菜单图标',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '备注',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `created` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `updated` timestamp NULL DEFAULT NULL COMMENT '更新时间',
  `deleted` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  `version` bigint(20) NULL DEFAULT NULL COMMENT '版本',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '菜单权限表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of a_menu
-- ----------------------------
INSERT INTO `a_menu` VALUES (1, '权限管理', 0, 0, '', '', '', 'M', '', '0', 'Setting', '权限管理', 1, '2023-08-04 10:44:21', 1, '2023-08-04 16:55:00', NULL, 1);
INSERT INTO `a_menu` VALUES (2, '菜单管理', 1, 0, '', '', 'menuRules', 'C', '', '0', 'Operation', '菜单规则', 1, '2023-08-04 11:12:39', 1, '2023-08-04 13:19:46', NULL, 1);
INSERT INTO `a_menu` VALUES (3, '菜单新增&修改', 2, 0, 'POST', '/api/admin/menu/edit', '', 'F', 'E', '0', '', '新增&修改', 1, '2023-08-04 13:16:33', 1, '2023-08-04 17:39:19', NULL, 1);
INSERT INTO `a_menu` VALUES (4, '菜单删除', 2, 1, 'POST', '/api/admin/menu/del', '', 'F', 'D', '0', '', '删除', 1, '2023-08-04 14:24:56', 1, '2023-08-04 14:24:56', NULL, 1)
INSERT INTO `a_menu` VALUES (5, '菜单查询', 2, 1, 'GET', '/api/admin/menu/find', '', 'F', 'S', '0', '', '查询', 1, '2023-08-04 17:36:50', 1, '2023-08-04 17:42:15', NULL, 1);
INSERT INTO `a_menu` VALUES (6, '角色管理', 1, 1, '', '', 'roleGroup', 'C', '', '0', 'User', '角色组', 1, '2023-08-04 13:28:32', 1, '2023-08-04 13:28:32', NULL, 1);
INSERT INTO `a_menu` VALUES (7, '角色查询', 6, 1, 'GET', '/api/admin/role/find', '', 'F', 'S', '0', '', '查询', 1, '2023-08-04 17:38:27', 1, '2023-08-04 17:42:21', NULL, 1);
INSERT INTO `a_menu` VALUES (8, '角色新增&修改', 6, 1, 'POST', '/api/admin/role/edit', '', 'F', 'E', '0', '', '新增&修改', 1, '2023-08-04 17:39:11', 1, '2023-08-04 17:39:11', NULL, 1);
INSERT INTO `a_menu` VALUES (9, '角色删除', 6, 1, 'POST', '/api/admin/role/del', '', 'F', 'D', '0', '', '删除', 1, '2023-08-04 17:40:20', 1, '2023-08-04 17:40:20', NULL, 1);
INSERT INTO `a_menu` VALUES (10, '用户管理', 1, 2, '', '', 'administratorManage', 'C', '', '0', 'Avatar', '管理员管理', 1, '2023-08-04 15:55:17', 1, '2023-08-04 15:55:17', NULL, 1);
INSERT INTO `a_menu` VALUES (11, '用户查询', 10, 1, 'POST', '/api/admin/user/find', '', 'F', 'S', '0', '', '查询', 1, '2023-08-04 17:41:48', 1, '2023-08-04 17:41:48', NULL, 1);
INSERT INTO `a_menu` VALUES (12, '用户新增&修改', 10, 1, 'POST', '/api/admin/user/edit', '', 'F', 'E', '0', '', '新增&修改', 1, '2023-08-04 17:42:59', 1, '2023-08-04 17:42:59', NULL, 1);
INSERT INTO `a_menu` VALUES (13, '用户删除', 10, 1, 'POST', '/api/admin/user/del', '', 'F', 'D', '0', '', '删除', 1, '2023-08-04 17:43:23', 1, '2023-08-04 17:43:23', NULL, 1);
INSERT INTO `a_menu` VALUES (14, '操作日志', 1, 3, '', '', 'administratorLog', 'C', '', '0', 'Pointer', '操作日志', 1, '2023-08-04 17:36:53', 1, '2023-08-04 17:36:53', NULL, 1);
INSERT INTO `a_menu` VALUES (15, '操作查询', 14, 1, 'POST', '/api/admin/adminlog/find', '', 'F', 'S', '0', '', '查询', 1, '2023-08-04 17:43:55', 1, '2023-08-04 17:43:55', NULL, 1);
INSERT INTO `a_menu` VALUES (16, '操作删除', 14, 1, 'POST', '/api/admin/adminlog/del', '', 'F', 'D', '0', '', '删除', 1, '2023-08-04 17:44:36', 1, '2023-08-04 17:44:36', NULL, 1);
INSERT INTO `a_menu` VALUES (17, '常规管理', 0, 1, '', '', '', 'M', '', '0', 'Briefcase', '常规管理', 1, '2023-08-04 16:49:14', 1, '2023-08-04 16:52:17', NULL, 1);
INSERT INTO `a_menu` VALUES (18, '个人中心', 17, 0, '', '', 'personal', 'C', '', '0', 'User', '个人资料', 1, '2023-08-04 16:52:06', 1, '2023-08-04 16:52:06', NULL, 1);
INSERT INTO `a_menu` VALUES (19, '个人查询', 18, 1, 'GET', '/api/admin/user/me', '', 'F', 'S', '0', '', '查询', 1, '2023-08-04 17:45:33', 1, '2023-08-04 17:45:33', NULL, 1);
INSERT INTO `a_menu` VALUES (20, '个人更新', 18, 1, 'POST', '/api/admin/user/edit_me', '', 'F', 'E', '0', '', '更新', 1, '2023-08-04 17:46:01', 1, '2023-08-04 17:46:01', NULL, 1);

-- ----------------------------
-- Table structure for a_role
-- ----------------------------
DROP TABLE IF EXISTS `a_role`;
CREATE TABLE `a_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `parent_id` bigint(20) NULL DEFAULT NULL COMMENT '父角色',
  `superior_ids` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '所有上级角色id',
  `role_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色名称',
  `role_sort` int(11) NULL DEFAULT 1 COMMENT '显示顺序',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' COMMENT '角色状态（0正常 1停用）',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `created` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `updated` timestamp NULL DEFAULT NULL COMMENT '更新时间',
  `deleted` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  `version` bigint(20) NULL DEFAULT NULL COMMENT '版本',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of a_role
-- ----------------------------
INSERT INTO `a_role` VALUES (1, 0, NULL, '超级管理员', 1, '0', NULL, 1, '2023-08-04 19:56:08', 1, '2023-08-04 19:56:10', NULL, 1);

-- ----------------------------
-- Table structure for a_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `a_role_menu`;
CREATE TABLE `a_role_menu`  (
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  `menu_id` bigint(20) NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色和菜单关联表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of a_role_menu
-- ----------------------------
INSERT INTO `a_role_menu` VALUES (1, 1);
INSERT INTO `a_role_menu` VALUES (1, 2);
INSERT INTO `a_role_menu` VALUES (1, 3);
INSERT INTO `a_role_menu` VALUES (1, 4);
INSERT INTO `a_role_menu` VALUES (1, 5);
INSERT INTO `a_role_menu` VALUES (1, 6);
INSERT INTO `a_role_menu` VALUES (1, 7);
INSERT INTO `a_role_menu` VALUES (1, 8);
INSERT INTO `a_role_menu` VALUES (1, 9);
INSERT INTO `a_role_menu` VALUES (1, 10);
INSERT INTO `a_role_menu` VALUES (1, 11);
INSERT INTO `a_role_menu` VALUES (1, 12);
INSERT INTO `a_role_menu` VALUES (1, 13);
INSERT INTO `a_role_menu` VALUES (1, 14);
INSERT INTO `a_role_menu` VALUES (1, 15);
INSERT INTO `a_role_menu` VALUES (1, 16);
INSERT INTO `a_role_menu` VALUES (1, 17);
INSERT INTO `a_role_menu` VALUES (1, 18);
INSERT INTO `a_role_menu` VALUES (1, 19);
INSERT INTO `a_role_menu` VALUES (1, 20);

-- ----------------------------
-- Table structure for a_user
-- ----------------------------
DROP TABLE IF EXISTS `a_user`;
CREATE TABLE `a_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `parent_id` bigint(20) UNSIGNED NULL DEFAULT NULL COMMENT '上级ID',
  `superior_ids` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '所有上级用户id',
  `login_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录账号',
  `user_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '用户昵称',
  `user_type` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '01' COMMENT '用户类型（00系统用户 01注册用户）',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '用户邮箱',
  `phonenumber` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '手机号码',
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '密码',
  `status` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '0' COMMENT '帐号状态（0正常 1停用）',
  `login_ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '最后登陆IP',
  `login_date` timestamp NULL DEFAULT NULL COMMENT '最后登陆时间',
  `remark` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `create_by` bigint(20) NULL DEFAULT NULL COMMENT '创建者',
  `created` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  `update_by` bigint(20) NULL DEFAULT NULL COMMENT '更新者',
  `updated` timestamp NULL DEFAULT NULL COMMENT '更新时间',
  `deleted` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  `version` bigint(20) NULL DEFAULT NULL COMMENT '版本',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of a_user
-- ----------------------------
INSERT INTO `a_user` VALUES (1, 0, '0', 'admin', '超级管理员', '00', 'aa@aa.com', '15134566666', 'e10adc3949ba59abbe56e057f20f883e', '0', '192.168.0.197', '2023-08-04 18:13:44', '', 0, '2023-08-02 13:47:58', 1, '2023-08-04 18:13:44', NULL, 1);

-- ----------------------------
-- Table structure for a_user_role
-- ----------------------------
DROP TABLE IF EXISTS `a_user_role`;
CREATE TABLE `a_user_role`  (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户和角色关联表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of a_user_role
-- ----------------------------
INSERT INTO `a_user_role` VALUES (1, 1);

SET FOREIGN_KEY_CHECKS = 1;
